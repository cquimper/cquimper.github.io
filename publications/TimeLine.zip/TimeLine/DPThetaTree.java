// File: ThetaTree.java
// Implementation of the Theta tree data structure from Vilím's algorithm cited in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;


public class DPThetaTree {
    //  List<Task> tasks = new ArrayList< Task >();
    Task[] tasks;
    private int ect_of_nodes[];
    private int pSum_of_nodes[];
    private int b = 0x80000000;
    private int n;
    private int height;
    private int firstIndexOnTheLowestLevel;
    private int lastIndexOnTheLowestLevel;
    private int task_index_to_node_index[];
    private int minusInfinity;
        
    public DPThetaTree(Task[] tasks) {
  
        this.minusInfinity = 0x80000000;
        this.tasks = tasks;
        this.n = tasks.length;

        this.ect_of_nodes = new int[2 * n - 1];
        this.pSum_of_nodes = new int[2 * n - 1];
        this.task_index_to_node_index = new int [n];

        this.firstIndexOnTheLowestLevel = nextPowerOfTwoMinusOne(n);
        
        this.lastIndexOnTheLowestLevel = 2 * (n - 1);
        for (int r = 0; r < ect_of_nodes.length; r++) {
            ect_of_nodes[r] = minusInfinity;
            pSum_of_nodes[r] = 0;

        }
        int j = 0;
        Integer[] task_indices = new Integer[tasks.length];

        for (int q = 0; q < n; q++) {
            task_indices[q] = new Integer(q);

        }
        Arrays.sort(task_indices, new Task.ComparatorByEst(tasks));

        for (int q = 0; q < n; q++) {
            task_index_to_node_index[task_indices[q]]  = q;
        }
    }

    private static int nextPowerOfTwoMinusOne(int n) {
	// If n is a power of two
	if ((n & (n - 1)) == 0)
	    return n - 1;
	int shift = 1;
	int result = n;
	do {
	    n = result;
	    result = n | (n >> shift);
	    shift += shift;
	}
	while (n != result);
	return result;
    }
    public int[] ro(List<Task> u){
        int[] e = new int[u.size()];
        for (int q = 0; q < n; q++) 
            e[q]=task_index_to_node_index[q];
        return e;
    }

    public int[] whatisPro(List<Task> u){
        return pSum_of_nodes;
    }

    public int[] whatisEct(List<Task> u){
        return ect_of_nodes;
    }

    public int sizeOfTree(List<Task> u){
        return 2*n - 1;
    }


    public int firstIndex(List<Task> u){
        return firstIndexOnTheLowestLevel;
    }


    public int lasstIndex(List<Task> u){
        return lastIndexOnTheLowestLevel;
    }

    public  void scheduleTask(int a) {
        updateLeaf(a, tasks[a].earliestCompletionTime(), tasks[a].processingTime());
    }

    public void unScheduleTask(int a) {

        updateLeaf(a, minusInfinity, 0);
    }

    private void updateLeaf(int task_index, int new_ect, int new_processing_time) {
        int t = 0;
        int o = task_index_to_node_index[task_index];

        int b;
        if ( o <= (lastIndexOnTheLowestLevel - firstIndexOnTheLowestLevel))   
            b = firstIndexOnTheLowestLevel + o;
        else 
            b = lastIndexOnTheLowestLevel / 2 + o - ((lastIndexOnTheLowestLevel - firstIndexOnTheLowestLevel) + 1);        

        ect_of_nodes[b] = new_ect;
        pSum_of_nodes[b] = new_processing_time;
        int w = (b - 1) / 2;

        do {
            ect_of_nodes[w] = Math.max(ect_of_nodes[2 * w + 2], ect_of_nodes[2 * w + 1] + pSum_of_nodes[2 * w + 2]);
            pSum_of_nodes[w] = pSum_of_nodes[2 * w + 1] + pSum_of_nodes[2 * w + 2];
            w =  (int) Math.floor((w - 1)/ 2);
            if (w == 0) 
                t++;
            if (t > 1) 
                break;
        } while (w >= 0);
    }


    public int rootOfTree() {
        return ect_of_nodes[0];
    }

    public void print1() {
        for ( int i = 0 ; i < ect_of_nodes.length; i++ )
            System.out.println((int) ect_of_nodes[i]);
    }

    public void print2(){
        for ( int i = 0 ; i < pSum_of_nodes.length; i++ )
            System.out.println(pSum_of_nodes[i]);
    }

    public static void main(String[] args) {
    }
}
