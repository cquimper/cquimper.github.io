
// File: TimetablingConstraintWithTimeline.java
// Implementation of the Time tabling method by Union-Find data structure, described in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi


import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import java.util.Arrays;

import static java.lang.System.arraycopy;

public class TimetablingConstraintWithTimeline  extends AbstractLargeIntSConstraint {
    public static final int NO_CHANGE = 0;
    public static final int CHANGE = 1;
    private int proc[]; 
    static int z = 0;
    private int l;
    private Integer[] indices_sorted_by_processing_times;
    
    public static class TimetablingConstraintWithTimelineManager extends IntConstraintManager {   
        public SConstraint makeConstraint(Solver solver, IntegerVariable[] variables, Object parameters, List<String> options) {
            if (solver instanceof CPSolver) {
                return new TimetablingConstraintWithTimeline(solver.getVar(variables), (int[]) parameters);
            }
            return null;
        }
    }

    private TimetablingConstraintWithTimeline (IntDomainVar[] vars, final int[] processing_times) {
        super(vars);
        l = vars.length;
        proc = processing_times;  
        this.indices_sorted_by_processing_times = new Integer[processing_times.length];
        for (int q = 0; q < processing_times.length; q++) {
            indices_sorted_by_processing_times[q] = new Integer(q);
        }
        Arrays.sort(indices_sorted_by_processing_times, new Comparator<Integer>() {
            public int compare(Integer index1, Integer index2) {
                return processing_times[index1] - processing_times[index2];
            }
        });
    }

    public void propagate() throws ContradictionException {       
        boolean domains_have_changed;
        do {
            domains_have_changed = false;                
            Task[] sampleTasks = new Task[l - 1];
            Task[] sampleTasks2 = new Task[l - 1];
            for (int j = 0; j < l - 1; j++) {
                final int est = vars[j].getInf();
                final int lct = vars[j].getSup() + proc[j];
                sampleTasks[j] = new Task(est, lct, proc[j]);
                sampleTasks2[j] = new Task(-lct, -est, proc[j]);
            }
            if (hasFixedPartOrNot(sampleTasks)) {
                filterLowerBounds(sampleTasks); 
                filterLowerBounds(sampleTasks2);                             
                for (int a = 0; a < l - 1; a++) {                
                    if (vars[a].getInf() < sampleTasks[a].earliestStartingTime()) {
                        vars[a].setInf(sampleTasks[a].earliestStartingTime());
                        domains_have_changed = true;
                        z++;
                    }
                    if (vars[a].getSup() > -sampleTasks2[a].earliestCompletionTime()) {                    
                        vars[a].setSup(-sampleTasks2[a].earliestCompletionTime());  
                        domains_have_changed = true;
                        z++;
                    }            
                }
            }
        } while (domains_have_changed);
    //  System.out.println("timeline" + z);

    }

    public boolean overlap(int a, int b, int c, int d) {
        assert (a < b && c < d );    
        return ((c < a && a < d) || (c >= a && c < b));

    }

    public boolean fixedPart(Task a) {
        return (a.latestStartingTime() < a.earliestCompletionTime());

    }
    public boolean hasFixedPartOrNot(Task[] tasks) {
        for (int r = 0; r < tasks.length; r++) { 
            if (fixedPart(tasks[r]))
                return true;
        }
        return false;
    }

    public List<Task> sortAndFilter(Task[] tasks) {       
        final int num_tasks = tasks.length;
        List<Task> tasks_with_fixed_part = new ArrayList<Task>();
        for (int i = 0; i < num_tasks; i++) {
            Task current_task = tasks[i];
            if (current_task.hasFixedPart())
                tasks_with_fixed_part.add(current_task);
        }
        Collections.sort(tasks_with_fixed_part, new Task.TaskBylst());
        return tasks_with_fixed_part;
    }
    public  void filterLowerBounds(Task[] sampleTasks) throws ContradictionException {
        final int num_tasks = sampleTasks.length;
        UnionFind uf;
        boolean first_update;
        int first_region_index;
        int current_region_index;
        List<Task> forbidden_regions = sortAndFilter(sampleTasks);                       
        int n = forbidden_regions.size();
        for ( int i = 1; i < n; i++){
            forbidden_regions.get(i).pruneEarliestStartingTime(forbidden_regions.get(i - 1).earliestCompletionTime());
        }
        for (int o = 0; o < forbidden_regions.size(); o++) {
            if (!forbidden_regions.get(o).isConsistent()) {
                fail();   
            }
        }
        for ( int i = 0; i < n - 1; i++) {
            if (overlap(forbidden_regions.get(i).latestStartingTime(), forbidden_regions.get(i).earliestCompletionTime(), forbidden_regions.get(i + 1).latestStartingTime(), forbidden_regions.get(i + 1).earliestCompletionTime())) {
                fail();   
            }
        }
        Integer[] indices_sorted_by_est = new Integer[num_tasks];

        for (int q = 0; q < num_tasks; q++) {
           indices_sorted_by_est[q] = new Integer(q);
            //indices_sorted_by_est[q] = q;

        }
        Arrays.sort(indices_sorted_by_est, new Task.ComparatorByEst(sampleTasks));

        int i = 0;
        int[] task_to_region = new int[num_tasks];
        for (int o = 0; o < num_tasks; o++) {
            final int task_index = indices_sorted_by_est[o];
            Task task = sampleTasks[task_index];
            while (i < n && task.earliestStartingTime() >= forbidden_regions.get(i).earliestCompletionTime())
                i++;
            task_to_region[task_index] = i;
        }
        uf = new UnionFind(n);
        // V contains the indices of the tasks that do not have a fixed part. The indices are sorted by EST.
        int[] new_lower_bounds = new int[num_tasks];
        for (int o = 0; o < num_tasks; o++) {                   
            final int task_index = this.indices_sorted_by_processing_times[o];            
            Task task = sampleTasks[task_index];                       
            new_lower_bounds[task_index] = task.earliestStartingTime();
            if (task.hasFixedPart())
                continue;
            int region_index = task_to_region[task_index];
            if (region_index >= n)
                continue;
            first_region_index =  uf.smallest(region_index);
            current_region_index=first_region_index;
            assert(task.earliestStartingTime() < forbidden_regions.get(current_region_index).earliestCompletionTime());
            first_update = true;
            while (current_region_index < n && new_lower_bounds[task_index] + task.processingTime() > forbidden_regions.get(current_region_index).latestStartingTime()) 
            {
                current_region_index = uf.greatest(current_region_index);
                final int filtering_point = forbidden_regions.get(current_region_index).earliestCompletionTime();
                if (filtering_point > new_lower_bounds[task_index]) {
                    new_lower_bounds[task_index] = filtering_point;
                }
                if (!first_update)
                    uf.union(first_region_index, current_region_index);
                first_update = false;
                current_region_index += 1;
            }
        }
        for (i = 0; i < num_tasks; i++) {
            Task current_task = sampleTasks[i];            
            current_task.pruneEarliestStartingTime(new_lower_bounds[i]);
        }
    }

    public String pretty() {
        return null;
    }

    public void awake() throws ContradictionException {
        propagate();
    }
    public int[] newCodeForSorting(Task[] tasks) {
        int n = tasks.length;
        int[] tasks_indices = new int[n];
        for (int q = 0; q < n; q++) {
            tasks_indices[q] = q;
        }  
        relativeRadixSortIndices(tasks_indices, new EstGetterForIndices(tasks));
        return tasks_indices;
    }
    
    
    public static void relativeRadixSortIndices(int[] a, KeyGetterForIndices keyGetter) {
        int i, m, exp;
        int[] b;
        int l = a.length;                
        b = new int[l];              
        m = keyGetter.getkey(a[0]);
        exp = 1;
        for (i = 1; i < l; i++) {
            if (keyGetter.getkey(a[i]) > m)
                m = keyGetter.getkey(a[i]);
        }      
        while (m / exp > 0) {
            int bucketArray[] = { 0 };
            bucketArray = new int[10];
            for (i = 0; i < l; i++)
                bucketArray[(keyGetter.getkey(a[i]) / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucketArray[i] += bucketArray[i - 1];
            for (i = l - 1; i >= 0; i--)
                b[--bucketArray[(keyGetter.getkey(a[i]) / exp) % 10]] = a[i];
            for (i = 0; i < l; i++) {
                a[i] = b[i];
            }
            exp *= 10;
        }
    } 
    
    static int[] mergeSort(int[] A,  KeyGetterForIndices keyGetter) {
        int l = A.length;
         
         if (l > 1) {
             int q = l/2;
             int[] leftArray = Arrays.copyOfRange(A, 0, q);
             int[] rightArray = Arrays.copyOfRange(A,q,l);
             mergeSort(leftArray,   keyGetter);
             mergeSort(rightArray,   keyGetter);
             merge(A,leftArray,rightArray,  keyGetter);
             
         }
         return A;
     }  
     
     
     static void merge(int[] a, int[] l, int[] r, KeyGetterForIndices keyGetter) {
         int totElem = l.length + r.length;
         int i,li,ri;
         i = li = ri = 0;
         while ( i < totElem) {
             if ((li < l.length) && (ri<r.length)) {
                 if (keyGetter.getkey(l[li]) < keyGetter.getkey(r[ri])) {
                     a[i] = l[li];
                     i++;
                     li++;
                 }
                 else {
                     a[i] = r[ri];
                     i++;
                     ri++;
                 }
             }
             else {
                 if (li >= l.length) {
                     while (ri < r.length) {
                         a[i] = r[ri];
                         i++;
                         ri++;
                     }
                 }
                 if (ri >= r.length) {
                     while (li < l.length) {
                         a[i] = l[li];
                         li++;
                         i++;
                     }
                 }
             }
         }
     }  
  
}
