// File: DetectablePrecedencesConstraintWithTimeline.java
// Implementation of Detectable Precedences method by Time line, described in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi


import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import static java.lang.System.arraycopy;

public class DetectablePrecedencesConstraintWithTimeline  extends AbstractLargeIntSConstraint {
    public static final int NO_CHANGE = 0;
    public static final int CHANGE = 1;
    int[] new_lower_bounds;
    private int proc[];
    private int l;
    static  int z = 0;
    public static class DetectablePrecedencesConstraintWithTimelineManager extends IntConstraintManager {   
        public SConstraint makeConstraint(Solver solver, IntegerVariable[] variables, Object parameters, List<String> options) {
            if (solver instanceof CPSolver) {
                return new DetectablePrecedencesConstraintWithTimeline(solver.getVar(variables), (int[]) parameters);
            }
            return null;
        }
    }

    private DetectablePrecedencesConstraintWithTimeline (IntDomainVar[] vars, int[] processing_times) {
        super(vars);
        l = vars.length;
        proc = processing_times;  
    }

    public void propagate() throws ContradictionException {           
        Task[] sampleTasks = new Task[l - 1];
        Task[] negativeSampleTasks = new Task[l - 1];
        for (int j = 0; j < l - 1; j++) {
            final int est = vars[j].getInf();
            final int lct = vars[j].getSup() + proc[j];
            sampleTasks[j] = new Task(est, lct, proc[j]);
            negativeSampleTasks[j] = new Task(-lct, -est, proc[j]);
        }
        boolean change;
        do {
            change = false;
            int earliest_completion_time = filterLowerBound(sampleTasks);    
            IntDomainVar makespan = vars[l - 1];
            makespan.setInf(earliest_completion_time);
            filterLowerBound(negativeSampleTasks);     
            for (int a = 0; a < l - 1; a++) {
                if (sampleTasks[a].earliestStartingTime() > vars[a].getInf()) {
                    vars[a].setInf(sampleTasks[a].earliestStartingTime());
                    change = true;
                    z++;
                }
                if (-negativeSampleTasks[a].earliestCompletionTime() < vars[a].getSup()) {
                    vars[a].setSup(-negativeSampleTasks[a].earliestCompletionTime());
                    change = true;
                    z++;
                }
            }
        } while(change);
    }

    private  int filterLowerBound(Task[] sampleTasks) throws ContradictionException {
        int g = sampleTasks.length; 
        Task[] sorted_by_ect = Arrays.copyOf(sampleTasks, g);       
        Task[] sorted_by_lst = Arrays.copyOf(sampleTasks, g);
        Arrays.sort(sorted_by_ect, new Task.TaskByect());

        Arrays.sort(sorted_by_lst, new Task.TaskBylst()); 

        TimeLine timeline = new TimeLine(sorted_by_lst);
        int j = 0;
        int w = sorted_by_ect.length;
        new_lower_bounds = new int[w];
        for (int i = 0; i < w; i++) 
            new_lower_bounds[i] = sorted_by_ect[i].earliestStartingTime();
        int [] postponed_tasks = new int[g];
        int num_postponed_tasks = 0;
        int blocking_task = -1;
        for (int i = 0; i < w; i++) {
            Task CurrentTask = sorted_by_ect[i];
            while (j < g && sorted_by_lst[j].latestStartingTime() < CurrentTask.earliestCompletionTime()) { 
                if (sorted_by_lst[j].earliestCompletionTime() > sorted_by_lst[j].latestStartingTime()) {
                    if (blocking_task < 0) {
                        blocking_task = j;
                    } else {
                        fail(); 
                    }
                } else
                    timeline.scheduleTask(j);
                j++;
            } if (blocking_task >= 0) {
                if (sorted_by_lst[blocking_task] == CurrentTask) {
                    new_lower_bounds[i] = Math.max(new_lower_bounds[i], timeline.latestScheduledTime);
                    timeline.scheduleTask(blocking_task);
                    while (num_postponed_tasks > 0) {
                        new_lower_bounds[postponed_tasks[num_postponed_tasks - 1]] = Math.max(sorted_by_ect[num_postponed_tasks - 1].earliestStartingTime(), timeline.latestScheduledTime);
                        num_postponed_tasks--;
                    }
                    blocking_task = -1;
                }
                else {
                    postponed_tasks[num_postponed_tasks++] = i;
                }
            } else {
                new_lower_bounds[i] = Math.max(CurrentTask.earliestStartingTime(), timeline.latestScheduledTime);
            }
        }

        for (int i = 0; i < w; i++) {
            Task CurrentTask = sorted_by_ect[i];
            CurrentTask.pruneEarliestStartingTime(new_lower_bounds[i]);
            if (!CurrentTask.isConsistent()) {
                fail();
            }
        }
        return timeline.latestScheduledTime();
    }

    public String pretty() {
        return null;
    }

    public void awake() throws ContradictionException {
        propagate();
    }

    public static void relativeRadixSort(Task[] task, KeyGetter keyGetter) {

        int[] temp = new int[task.length];    
        for (int s = 0; s < task.length; s++) {
            temp[s] = task[s].latestCompletionTime();
        }
        int minOfArray = findMin(temp);

        for (int s = 0; s < task.length; s++) {

            task[s].setEarliestStartingTime(task[s].earliestStartingTime() - minOfArray);
            task[s].setLatestCompletionTime(task[s].latestCompletionTime() - minOfArray);

        }

        int i, m, exp;
        Task[] b;
        int l = task.length;                
        b = new Task[l];              
        m = keyGetter.getkey(task[0]);
        exp = 1;
        for (i = 1; i < l; i++) {
            if (keyGetter.getkey(task[i]) > m)
                m = keyGetter.getkey(task[i]);
        }      
        while (m / exp > 0) {
            int bucketArray[] = { 0 };
            bucketArray = new int[10];
            for (i = 0; i < l; i++)
                bucketArray[(keyGetter.getkey(task[i]) / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucketArray[i] += bucketArray[i - 1];
            for (i = l - 1; i >= 0; i--)
                b[--bucketArray[(keyGetter.getkey(task[i]) / exp) % 10]] = task[i];

            for (i = 0; i < l; i++) {
                task[i] = b[i];
            }
            exp *= 10;
        }

        for (int s = 0; s < task.length; s++) {
            task[s].setEarliestStartingTime(task[s].earliestStartingTime() + minOfArray);
            task[s].setLatestCompletionTime(task[s].latestCompletionTime() + minOfArray);       
        }       
    }


    private static int findMin(int[] myArray) {
        int min = myArray[0];
        for (int i = 1; i < myArray.length; i++) {
            if (myArray[i] < min) {
                min = myArray[i];
            }
        }
        return min;
    }


    private static void  mergeSort(Task[] A,  KeyGetter keyGetter) {
        int l = A.length;

        if (l > 1) {
            int q = l/2;
            Task[] leftArray = Arrays.copyOfRange(A, 0, q);
            Task[] rightArray = Arrays.copyOfRange(A,q,l);
            mergeSort(leftArray, keyGetter);
            mergeSort(rightArray, keyGetter);
            merge(A,leftArray,rightArray, keyGetter);

        }
    }  


    static void merge(Task[] a, Task[] l, Task[] r, KeyGetter keyGetter) {
        int totElem = l.length + r.length;
        int i,li,ri;
        i = li = ri = 0;
        while ( i < totElem) {
            if ((li < l.length) && (ri<r.length)) {
                if (keyGetter.getkey(l[li]) < keyGetter.getkey(r[ri])) {
                    a[i] = l[li];
                    i++;
                    li++;
                }
                else {
                    a[i] = r[ri];
                    i++;
                    ri++;
                }
            }
            else {
                if (li >= l.length) {
                    while (ri < r.length) {
                        a[i] = r[ri];
                        i++;
                        ri++;
                    }
                }
                if (ri >= r.length) {
                    while (li < l.length) {
                        a[i] = l[li];
                        li++;
                        i++;
                    }
                }
            }
        }
    }
}
