// File: UnionFind.java
// Implementation of the Union-find data structure described in:
// Hamed Fahimi and Claude-Guy Quimper,
//"Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi

public class UnionFind {
    public int tree[];
    public int labels[];
    public int smallest_element[];
    public int greatest_element[];

    public UnionFind(int n) {
        this.tree = new int[n];
        this.labels = new int[n];
        this.smallest_element = new int[n];
        this.greatest_element = new int[n];
        for (int i = 0; i < n; i++) {
            this.tree[i] = -1;
            this.labels[i] = i;
            this.smallest_element[i] = i;
            this.greatest_element[i] = i;
        }
    }

    public void print(int n) {
        for (int i = 0; i < n; i++) {
            System.out.printf("\n%d", tree[i]);
        }
    }

    private int find_representative(int x) {

        while (tree[x] >= 0) {
            x = tree[x];
        }
        return x;
    }

    private void compress(int x, int root) {
        if (x != root) {
            int parent = tree[x];
            while (parent != root) {
                tree[x] = root;
                x = parent;
                parent = tree[x];
                }
            }
    }


    public int findWithPathCompression(int x) {

        if (tree[x] >= 0)
            return x;
        else
            return tree[x] = findWithPathCompression(tree[x]);
    }



    public int find(int x) {
        final int root = find_representative(x);

        compress(x, root);
        return labels[root];
    }

    public int smallest(int x) {
        final int root = find_representative(x);
        compress(x, root);
        return smallest_element[root];
    }

    public int greatest(int x) {
        final int root = find_representative(x);
        compress(x, root);
        return greatest_element[root];
    }

    public boolean sameSet(int x, int y) {
        return (find(x) == find(y));
    }

    public void union (int x, int y) {    
        int root_x = find_representative(x);
        int root_y = find_representative(y);
        assert (root_x != root_y);
        assert (tree[root_x] < 0 && tree[root_y] < 0);
        int new_root;
        if (tree[root_x] <= tree[root_y]) {
            new_root = root_x;
            tree[root_x] += tree[root_y];
            tree[root_y] = x;
            compress(y, root_x);
            labels[root_x] = y;
        }
        else {
            new_root = root_y;
            tree[root_y] += tree[root_x];
            tree[root_x] = y;
            compress(x, root_y);
            labels[root_y] = x;
        }
        smallest_element[new_root] = Math.min(smallest_element[root_x], smallest_element[root_y]);
        greatest_element[new_root] = Math.max(greatest_element[root_x], greatest_element[root_y]);
        compress(x, new_root);
        compress(y, new_root);
    }
}
