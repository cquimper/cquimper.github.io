// File: OCConstraintWithThetatree.java
// Implementation of the Overload check method by Vilím's algorithm, cited in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi



import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static java.lang.System.arraycopy;

public class OCConstraintWithThetatree extends AbstractLargeIntSConstraint {
    private int proc[]; 
    private int l;

    public static class OverloadCheckConstraintManager extends IntConstraintManager {   
        public SConstraint makeConstraint(Solver solver, IntegerVariable[] variables, Object parameters, List<String> options) {
            if (solver instanceof CPSolver) {
                return new OCConstraintWithThetatree(solver.getVar(variables), (int[]) parameters);
            }
            return null;
        }
    }

    private OCConstraintWithThetatree (IntDomainVar[] vars, int[] processing_times) {
        super(vars);
        l = vars.length;

        proc = processing_times;    
    }

    public void propagate() throws ContradictionException {
  System.out.println("in thetatree");
       
        if (!isConsistent())    
            fail();            

    }  
    
    public boolean isConsistent() {
        Task[] sampleTasks = new Task[l - 1];
        for (int j = 0; j < l - 1; j++) {
            Task MyTask = new Task(vars[j].getInf(), vars[j].getSup() + proc[j], proc[j]);
            sampleTasks[j] = MyTask;
        }
        Arrays.sort(sampleTasks, new Task.TaskBylct());
        ThetaTree MyThetaTree = new ThetaTree(sampleTasks);
        for (int j = 0; j < l - 1; j++) {
            MyThetaTree.scheduleTask(j);
            if ( MyThetaTree.rootOfTree() > sampleTasks[j].latestCompletionTime()) 
                return false;
        }
        IntDomainVar makespan = vars[l - 1];
        final int earliest_completion_time = (int) MyThetaTree.rootOfTree();
        try {
            makespan.setInf(earliest_completion_time);
        } catch (ContradictionException e) {
            return false;
        }
        return true;
    }


    public String pretty() {
        return null;
    }

    public void awake() throws ContradictionException {
        propagate();
    }
}


