// File: TimetablingConstraintNotLinear.java
// Implementation of the Time tabling method by Ouellet & Quimper's algorithm, cited in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi

import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

import static java.lang.System.arraycopy;

public class TimetablingConstraintNotLinear  extends AbstractLargeIntSConstraint {
    public static final int NO_CHANGE = 0;
    public static final int CHANGE = 1;
   static int z = 0;
    private int proc[]; 
    public static class TimetablingConstraintNotLinearManager extends IntConstraintManager {   
        public SConstraint makeConstraint(Solver solver, IntegerVariable[] variables, Object parameters, List<String> options) {
            if (solver instanceof CPSolver) {
                return new TimetablingConstraintNotLinear(solver.getVar(variables), (int[]) parameters);
            }
            return null;
        }
    }

    private TimetablingConstraintNotLinear (IntDomainVar[] vars, int[] processing_times) {
        super(vars);
        assert(processing_times.length == vars.length - 1);
        proc = processing_times;  
    }

    public void propagate() throws ContradictionException {
        boolean domains_have_changed;
        do {
            domains_have_changed = false;
            Task[] sampleTasks = new Task[vars.length - 1];
            Task[] sampleTasks2 = new Task[vars.length - 1];
            for (int j = 0; j < vars.length - 1; j++) {
                final int est = vars[j].getInf();
                final int lct = vars[j].getSup() + proc[j];
                sampleTasks[j] = new Task(est, lct, proc[j]);
                sampleTasks2[j] = new Task(-lct, -est, proc[j]);
            }
            filterLowerBounds(sampleTasks); 
            filterLowerBounds(sampleTasks2); 
            for (int a = 0; a < sampleTasks.length; a++) {
                if (vars[a].getInf() < sampleTasks[a].earliestStartingTime()) {
                    vars[a].setInf(sampleTasks[a].earliestStartingTime());
                    domains_have_changed = true;
                    z++;
                }
                if (vars[a].getSup() > -sampleTasks2[a].earliestCompletionTime()) {                    
                    vars[a].setSup(-sampleTasks2[a].earliestCompletionTime());  
                    domains_have_changed = true;
                    z++;
                }
            }            
        } while (domains_have_changed);
 //  System.out.println("Pierre's" + z);
    }

    public  void filterLowerBounds(Task[] sampleTasks) throws ContradictionException {
        assert (sampleTasks.length > 0);
        Task[] I = new Task[sampleTasks.length];
        List<Task> F = new ArrayList< Task >();
        I = Arrays.copyOf(sampleTasks, sampleTasks.length);        
        Interval thisInterval;
        Task thisTask;
        int sorted_by_lst[] = new int[I.length];
        int sorted_by_ect[] = new int[I.length];
        int sorted_by_lct[] = new int[I.length];;
        int sorted_by_est[] = new int[I.length];;
        for (int i = 0; i < I.length; i++) {
            Task currentTask = I[i];
            sorted_by_lst[i] = currentTask.latestStartingTime();
            sorted_by_ect[i] = currentTask.earliestCompletionTime();
            sorted_by_lct[i] = currentTask.latestCompletionTime();
            sorted_by_est[i] = currentTask.earliestStartingTime();
        } 
        Arrays.sort(sorted_by_lst);
        Arrays.sort(sorted_by_ect);
        Arrays.sort(sorted_by_lct);
        Arrays.sort(sorted_by_est);

        Integer[] indices_sorted_by_lst  = new Integer[sampleTasks.length] ;  
        for (int r = 0; r < indices_sorted_by_lst.length; r++) 
            indices_sorted_by_lst[r] = r;
        Arrays.sort(indices_sorted_by_lst, new Task.ComparatorByLst(sampleTasks));
        Integer[] temp2  = new Integer[sampleTasks.length];           
        Integer[] indices_sorted_by_ect = new Integer[sampleTasks.length] ;  
        for (int r = 0; r < indices_sorted_by_ect.length; r++) 
            indices_sorted_by_ect[r] = r;
        Arrays.sort(indices_sorted_by_ect, new Task.ComparatorByEct(sampleTasks));        
        int[] r = Merge(sorted_by_lst, sorted_by_ect, sorted_by_lct, sorted_by_est);
        int[] ko1 = finder(r, sorted_by_lst); 
        int[] ko2 = finder(r, sorted_by_ect); 
        for (int m = 0; m < indices_sorted_by_lst.length; m++) 
            temp2[indices_sorted_by_lst[m]] = ko1[m];
        Integer[] temp4  = new Integer[sampleTasks.length];                  
        for (int m = 0; m < indices_sorted_by_ect.length; m++)
            temp4[indices_sorted_by_ect[m]] = ko2[m];
        int[] c = new int[r.length];
        Task[] T = new Task[sampleTasks.length];
        for (int i = 0; i < I.length; i++) {                
            if (I[i].earliestCompletionTime() > I[i].latestStartingTime()) {                                
                int a = temp2[i];
                int b = temp4[i];
                c[a]++;
                c[b]--;
                T[i] = new Task(I[i].earliestStartingTime(), I[i].latestCompletionTime(), I[i].processingTime() - I[i].earliestCompletionTime() + I[i].latestStartingTime());                                               
            }
            else { 
                T[i] = new Task(I[i].earliestStartingTime(), I[i].latestCompletionTime(), I[i].processingTime());                              
            }
        }

        for (int l = 1; l < r.length; l++) {
            c[l] = c[l] + c[l - 1];
            if (c[l - 1] > 1)  
                fail();
            if (c[l - 1] > 0) {
                if (F.size() > 0 && F.get(F.size() - 1).latestCompletionTime() == r[l-1]) {
                    Task oldTask = F.get(F.size() - 1);
                    Task newTask = new Task(oldTask.earliestStartingTime(), r[l], r[l] - oldTask.earliestStartingTime());
                    F.set(F.size() - 1, newTask);
                } else {
                    thisTask = new Task(r[l - 1], r[l], r[l] - r[l - 1]);
                    F.add(thisTask);
                }
            }

        }
        Interval[] S = new Interval[F.size()];               
        for (int z = 0; z < F.size(); z++) {
            S[z] = new Interval(F.get(z).earliestStartingTime(), F.get(z).latestCompletionTime());
        }
        for (int i = 0; i < T.length; i++) {
            int t = minIndexGreaterThanOrEqualToKey(S, T[i].earliestStartingTime(), 0, S.length - 1);
            if (t != -1) {
                int b = S[t].whatIsLCT();
                int a = S[t].whatIsEST();
                if (T[i].earliestStartingTime() + T[i].processingTime() > a) {
                    if (I[i].latestStartingTime() > I[i].earliestCompletionTime())
                        I[i].setEarliestStartingTime(b);
                    else
                        I[i].setEarliestStartingTime(Math.min(I[i].latestStartingTime(), b));
                }
            }       
        }
    }

    
    
    
    
    public static int[] Merge(int[] a, int[] b, int[]  c, int[] d) {
        
        int[] Q = new int [a.length + b.length + c.length + d.length];
        int i = 0;
        for ( int j = 0; j < a.length; j++)
        {  Q[i] = a[j];
        i++;
        }
           for (int j = 0; j < b.length; j++)
           {    Q[i] = b[j];
           i++;
           }
        
           for (int j = 0; j < c.length; j++)
           {    Q[i] = c[j];
           i++;
           }
           
           for (int j = 0; j < d.length; j++)
           {    Q[i] = d[j];
           i++;
           }           
           Arrays.sort(Q);           
           int newArray[] = new int[Q.length];
           newArray[0] = Q[0];
           int k = 1;
           for (int l = 0; l < Q.length - 1; l++) {
               if(Q[l+1] > Q[l]) {
                   newArray[k] = Q[l + 1];
                   k++;
               }
           }
           newArray = Arrays.copyOf(newArray, k);
           Q = newArray;
        return Q;                               
    }
 
    public static int minIndexGreaterThanOrEqualToKey(Interval[] A, int key,
            int min, int max) {

        if (max < min || key > A[max].whatIsLCT())
            return -1;
        if (key < A[min].whatIsLCT())
            return min;
        if (max == min) {
            if (key > A[max].whatIsLCT())  { 
                return -1;
            }
            else if (key == A[max].whatIsLCT() && (max+1) < A.length)
                return max + 1;

            else
                return max;
        }
        else {
            final int imid = (min + max) / 2;
            if (A[imid].whatIsLCT() < key)
                return minIndexGreaterThanOrEqualToKey(A, key, imid + 1, max);
            else
                return minIndexGreaterThanOrEqualToKey(A, key, min, imid);
        }
    }

    // Returns a vector f such that a[f[i]] = b[i].
    // a and b must be sorted.
    // Complexity: O(a.length + b.length)
    public static int[] finder(int[] a, int[] b) {
        int[] f = new int[b.length];  
        int i = 0;
        int k = 0;
        int w = 0;
        while (i < b.length) {
            if (b[i] == a[k]) {
                f[w] = k;
                w++;
                i++;
            }
            else
                k++;

        }
        return f;
    }

    public String pretty() {
        return null;
    }

    public void awake() throws ContradictionException {
        propagate();
    }
}
