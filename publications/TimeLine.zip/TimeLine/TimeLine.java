// File: TimeLine.java
// Implementation of the Time line data structure described in:
// Hamed Fahimi and Claude-Guy Quimper,
//"Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi

import java.util.Arrays;

public class TimeLine {
    Task[] tasks;
    UnionFind sets;
    int time_points[];
    private int capacity[];
    private int est_to_time_point[];
    public int latestScheduledTime = 0x80000000; // -infinity;

    public TimeLine(Task[] tasks) {
        int p = 0;
        final int n = tasks.length;
        this.tasks = tasks;
        this.est_to_time_point = new int[n];
        int greatestLct = 0x80000000;
        for (int i = 0; i < n; i++) {
            Task CurrentTask = tasks[i];
            if (CurrentTask.latestCompletionTime() > greatestLct)
                greatestLct = CurrentTask.latestCompletionTime();
            p += CurrentTask.processingTime();
        } 

	Integer[] task_indices_toSortWithJavaLibrary = sortWithJavaLibrary();
         
        this.time_points = new int[n + 1];
        int num_time_points = 0;
        for (int i = 0; i < n; i++) {
	    final int index = task_indices_toSortWithJavaLibrary[i];
            final int est = tasks[index].earliestStartingTime();
            if (num_time_points == 0 || est != time_points[num_time_points - 1]) {
                time_points[num_time_points++] = est;
            }
            est_to_time_point[index] = num_time_points - 1;
        }
        time_points[num_time_points++] = greatestLct + p;
        this.capacity = new int[num_time_points - 1];
        for (int i = 0; i < num_time_points - 1; i++) {
            capacity[i] = time_points[i + 1] - time_points[i];
        }
        this.sets = new UnionFind(num_time_points);
    }

    public void scheduleTask(int task_index) {
        Task CurrentTask = tasks[task_index];
        int p = CurrentTask.processingTime();
        int t = sets.find(this.est_to_time_point[task_index]);
        while (p > 0) {
            int g = sets.greatest(t);
            int delta = Math.min(this.capacity[g], p);
            p -= delta;
            capacity[g] -= delta;
            if (capacity[g] == 0) {
                int w = t;
                t = sets.find(g + 1);
                sets.union(w, t);
            }
        }
        int g = sets.greatest(t);
        if ((latestScheduledTime() == 0x0000000) || latestScheduledTime() < time_points[g + 1] - capacity[g]) {
            latestScheduledTime = (int) time_points[g + 1] - capacity[g];
        }
    }
    public int latestScheduledTime() {
        return latestScheduledTime;
    }

    public String toString() {
        int i = 0;
        int MaxIndex = time_points.length - 1;
        StringBuilder b = new StringBuilder();
        while (i < MaxIndex) {
            b.append(String.valueOf(time_points[i]));
            b.append("--");
            b.append(String.valueOf(capacity[i]));
            b.append("-->");
            i++;
        }
        b.append(String.valueOf(time_points[MaxIndex]));
        return b.toString();
    }

    public static void radixSortPositiveIntegers(int a[]) {
        int i, m, exp, b[];
        b = new int[a.length];
        m = a[0];
        exp = 1;
        for (i = 1; i < a.length; i++) {
            if (a[i] > m)
                m = a[i];
        }
        while (m / exp > 0) {
            int bucketArray[] = { 0 };
            bucketArray = new int[10];
            for (i = 0; i < a.length; i++)
                bucketArray[(a[i] / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucketArray[i] += bucketArray[i - 1];
            for (i = a.length - 1; i >= 0; i--)
                b[--bucketArray[(a[i] / exp) % 10]] = a[i];
            for (i = 0; i < a.length; i++)
                a[i] = b[i];
            exp *= 10;
        }

    }

    public static void radixsortPositiveAndNegativeIntegers(int a[]) {
        int minOfArray = findMin(a);
        for (int o = 0; o < a.length; o++)
            a[o] = a[o] - minOfArray;
        int i, m, exp, b[];
        b = new int[a.length];
        m = a[0];
        exp = 1;
        for (i = 1; i < a.length; i++) {
            if (a[i] > m)
                m = a[i];
        }
        while (m / exp > 0) {
            int bucketArray[] = { 0 };
            bucketArray = new int[10];
            for (i = 0; i < a.length; i++)
                bucketArray[(a[i] / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucketArray[i] += bucketArray[i - 1];
            for (i = a.length - 1; i >= 0; i--)
                b[--bucketArray[(a[i] / exp) % 10]] = a[i];
            for (i = 0; i < a.length; i++)
                a[i] = b[i];
            exp *= 10;
        }
        for (int o = 0; o < a.length; o++)
            a[o] = a[o] + minOfArray;
    }

    private static int findMin(int[] myArray) {
        int min = myArray[0];
        for (int i = 1; i < myArray.length; i++) {
            if (myArray[i] < min) {
                min = myArray[i];
            }
        }
        return min;
    }

    private static int findMax(int[] myArray) {
        int max = myArray[0];
        for (int i = 1; i < myArray.length; i++) {
            if (myArray[i] > max) {
                max = myArray[i];
            }
        }
        return max;
    }   

    public static void countingSortPositiveIntegers(int[] arr)   {
        int max = findMax(arr);
        int size = arr.length;
        int c [] = new int[size];
        int b[] = new int[max+1];
        for(int i = 0; i<size; i++)
            b[arr[i]] += 1;
        for(int i = 1; i<max+1; i++)
            b[i] += b[i-1];
        for (int i = 0; i<size; ++i) {
            c[b[arr[i]]-1] = arr[i];
            --b[arr[i]];
        }
        System.arraycopy(c, 0, arr, 0, size);
    }  

    public static void countingSortPositiveAndNegativeIntegers(int[] arr)   {
        int minOfArray = findMin(arr);
        for (int o = 0; o < arr.length; o++)
            arr[o] = arr[o] - minOfArray;       
        int max = findMax(arr);
        int size = arr.length;
        int c [] = new int[size];
        int b[] = new int[max+1];
        for(int i = 0; i<size; i++)
            b[arr[i]] += 1;
        for(int i = 1; i<max+1; i++)
            b[i] += b[i-1];
        for (int i = 0; i<size; ++i) {
            c[b[arr[i]]-1] = arr[i];
            --b[arr[i]];
        }
        System.arraycopy(c, 0, arr, 0, size);                            
        for (int o = 0; o < arr.length; o++)
            arr[o] = arr[o] + minOfArray;
    }

    public static void relativeRadixSortIndices(int[] a, KeyGetterForIndices keyGetter) {
        int i, m, exp;
        int[] b;
        int l = a.length;                
        b = new int[l];              
        m = keyGetter.getkey(a[0]);
        exp = 1;
        for (i = 1; i < l; i++) {
            if (keyGetter.getkey(a[i]) > m)
                m = keyGetter.getkey(a[i]);
        }      
        while (m / exp > 0) {
            int bucketArray[] = { 0 };
            bucketArray = new int[10];
            for (i = 0; i < l; i++)
                bucketArray[(keyGetter.getkey(a[i]) / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucketArray[i] += bucketArray[i - 1];
            for (i = l - 1; i >= 0; i--)
                b[--bucketArray[(keyGetter.getkey(a[i]) / exp) % 10]] = a[i];
            for (i = 0; i < l; i++) {
                a[i] = b[i];
            }
            exp *= 10;
        }
    }
    
    public Integer[] sortWithJavaLibrary() {
        int n = tasks.length;
        Integer[] tasks_indices = new Integer[n];
        for (int q = 0; q < n; q++) {
            tasks_indices[q] = new Integer(q);
        }  
        Arrays.sort(tasks_indices, new Task.ComparatorByEst(tasks));
        return tasks_indices;
    }

    public int[] sortWithRadixSort() {
        int n = tasks.length;
        int[] tasks_indices = new int[n];
        for (int q = 0; q < n; q++) {
            tasks_indices[q] = q;
        }  
        relativeRadixSortIndices(tasks_indices, new EstGetterForIndices(tasks));
        return tasks_indices;
    }
    
    static int[] mergeSort(int[] A,  KeyGetterForIndices keyGetter) {
	int l = A.length;
        
        if (l > 1) {
            int q = l/2;
            int[] leftArray = Arrays.copyOfRange(A, 0, q);
            int[] rightArray = Arrays.copyOfRange(A,q,l);
            mergeSort(leftArray,   keyGetter);
            mergeSort(rightArray,   keyGetter);
            merge(A,leftArray,rightArray,  keyGetter);
            
        }
        return A;
    } 
    
    static void merge(int[] a, int[] l, int[] r, KeyGetterForIndices keyGetter) {
        int totElem = l.length + r.length;
        int i,li,ri;
        i = li = ri = 0;
        while ( i < totElem) {
            if ((li < l.length) && (ri<r.length)) {
                if (keyGetter.getkey(l[li]) < keyGetter.getkey(r[ri])) {
                    a[i] = l[li];
                    i++;
                    li++;
                }
                else {
                    a[i] = r[ri];
                    i++;
                    ri++;
                }
            }
            else {
                if (li >= l.length) {
                    while (ri < r.length) {
                        a[i] = r[ri];
                        i++;
                        ri++;
                    }
                }
                if (ri >= r.length) {
                    while (li < l.length) {
                        a[i] = l[li];
                        li++;
                        i++;
                    }
                }
            }
        }
    }  
}
