// File: OCConstraintWithTimeline.java
// Implementation of the Overload check method by Time line data structure, described in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi

import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import static java.lang.System.arraycopy;

public class OCConstraintWithTimeline extends AbstractLargeIntSConstraint {
    private int proc[]; 
    private int l;
    public static class OverloadCheckConstraintManager extends IntConstraintManager {   
        public SConstraint makeConstraint(Solver solver, IntegerVariable[] variables, Object parameters, List<String> options) {
            if (solver instanceof CPSolver) {
                return new OCConstraintWithTimeline(solver.getVar(variables), (int[]) parameters);
            }
            return null;
        }
    }

    private OCConstraintWithTimeline (IntDomainVar[] vars, int[] processing_times) {
        super(vars);
         l = vars.length;
        proc = processing_times;    
    }

    public void propagate() throws ContradictionException {
        if (!isConsistent())   
            fail();            

    }  
    public boolean isConsistent() {
        Task[] sampleTasks = new Task[l - 1];
        for (int j = 0; j < l - 1; j++) {
            sampleTasks[j] = new Task(vars[j].getInf(), vars[j].getSup() + proc[j], proc[j]);
        }   
       Arrays.sort(sampleTasks, new Task.TaskBylct());
        TimeLine MyTimeline = new TimeLine(sampleTasks);
        for (int j = 0; j < l - 1; j++) {
            MyTimeline.scheduleTask(j);
            if ( MyTimeline.latestScheduledTime() > sampleTasks[j].latestCompletionTime()) 
                return false;
        }
        IntDomainVar makespan = vars[l - 1];
        final int earliest_completion_time = MyTimeline.latestScheduledTime();
        try {
            makespan.setInf(earliest_completion_time);
        } catch (ContradictionException e) {
            return false;
        }
        return true;
    }

    public String pretty() {
        return null;
    }

    public void awake() throws ContradictionException {
        propagate();
    }
    
    
    
    public static void relativeRadixSort(Task[] task, KeyGetter keyGetter) {
        int i, m, exp;
        Task[] b;
        int l = task.length;                
        b = new Task[l];              
        m = keyGetter.getkey(task[0]);
        exp = 1;
        for (i = 1; i < l; i++) {
            if (keyGetter.getkey(task[i]) > m)
                m = keyGetter.getkey(task[i]);
        }      
        while (m / exp > 0) {
            int bucketArray[] = { 0 };
            bucketArray = new int[10];
            for (i = 0; i < l; i++)
                bucketArray[(keyGetter.getkey(task[i]) / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucketArray[i] += bucketArray[i - 1];
            for (i = l - 1; i >= 0; i--)
                b[--bucketArray[(keyGetter.getkey(task[i]) / exp) % 10]] = task[i];

            for (i = 0; i < l; i++) {
                task[i] = b[i];
            }
            exp *= 10;
        }
    }
}


