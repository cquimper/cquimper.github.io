// File: DetectablePrecedencesConstraintWithThetatree.java
// Implementation of Detectable Precedences method by Vilím's algorithm, cited in:
// Hamed Fahimi and Claude-Guy Quimper,
// "Linear-Time Filtering Algorithms for the Disjunctive Constraint", AAAI-2014.
// By: Hamed Fahimi

import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import static java.lang.System.arraycopy;

public class DetectablePrecedencesConstraintWithThetatree  extends AbstractLargeIntSConstraint {
    public static final int NO_CHANGE = 0;
    public static final int CHANGE = 1;
    static  int z = 0;
    private int proc[]; 
    private int l;
    public static class DetectablePrecedencesConstraintWithThetatreeManager extends IntConstraintManager {   
        public SConstraint makeConstraint(Solver solver, IntegerVariable[] variables, Object parameters, List<String> options) {
            if (solver instanceof CPSolver) {
                return new DetectablePrecedencesConstraintWithThetatree(solver.getVar(variables), (int[]) parameters, true);
            }
            return null;
        }
    }

    private DetectablePrecedencesConstraintWithThetatree (IntDomainVar[] vars, int[] processing_times, boolean early_test_option_activated) {
        super(vars);
        l = vars.length;
        proc = processing_times;
    }

    public void propagate() throws ContradictionException {       
        Task[] sampleTasks = new Task[l - 1];             
        Task[] sampleTasks2 = new Task[l - 1];
        for (int j = 0; j < l - 1; j++) {            
            final int est = vars[j].getInf();
            final int lct = vars[j].getSup() + proc[j];
            sampleTasks[j] = new Task(est, lct, proc[j]);
            sampleTasks2[j] = new Task(-lct, -est, proc[j]);
        }

        boolean change;
        do {
            change = false;

            int earliest_completion_time = filterLowerBound(sampleTasks);    
            filterLowerBound(sampleTasks2);     
            for (int a = 0; a < l - 1; a++) {
                if (sampleTasks[a].earliestStartingTime() > vars[a].getInf()) {                                    
                    vars[a].setInf(sampleTasks[a].earliestStartingTime());
                    change = true;
                    z++;
                }
                if (-sampleTasks2[a].earliestCompletionTime() < vars[a].getSup()) {
                    vars[a].setSup(-sampleTasks2[a].earliestCompletionTime());  
                    change = true;
                    z++;
                }
            }
            IntDomainVar makespan = vars[l - 1];
            makespan.setInf(earliest_completion_time);
        } while(change);
    }

    private  int filterLowerBound(Task[] sampleTasks) throws ContradictionException {
        Task[] SupplementarySampleTasks = sampleTasks;
        int g = sampleTasks.length;
        SupplementarySampleTasks = Arrays.copyOf(sampleTasks, g);
        int indicesOfTinQ[];
        indicesOfTinQ = new int [g];
        int ko[];
        ko = new int[g];
        Arrays.sort(SupplementarySampleTasks, new Task.TaskByect());
        Integer[] task_indices = new Integer[g];
        for (int q = 0; q < g; q++) {
            task_indices[q] = new Integer(q);
        }
        Arrays.sort(task_indices, new Task.ComparatorByLst(SupplementarySampleTasks));
        Task[] Q = new Task[g];
        for (int i = 0; i < g; i++) {
            int j = (int)(task_indices[i]);
            Q[i] = SupplementarySampleTasks[j];
        }
        for (int q = 0; q < g; q++) {
            indicesOfTinQ[(Integer) task_indices[q]]  = q;

        }
        DPThetaTree ThisThetatree = new DPThetaTree(Q);
        int scheduledornot[];
        scheduledornot = new int [g];
        int i = 0;
        int j = 0;
        int v = 0;      
        for (i = 0 ; i < g; i++) {            
            while (j < g && SupplementarySampleTasks[i].earliestCompletionTime() > Q[j].latestStartingTime())  {
                Task currentTask = SupplementarySampleTasks[i];
                Task qTask = Q[j];
		if ( currentTask != qTask && currentTask.haveOverlappingFixedParts(qTask)) { 
                    fail();
                }
                ThisThetatree.scheduleTask(j);
                scheduledornot[j] = 1;
                j++;
            }  
            if (scheduledornot[indicesOfTinQ[i]] != 0) {        
                ThisThetatree.unScheduleTask(indicesOfTinQ[i]);
                v  = (int) Math.max(SupplementarySampleTasks[i].earliestStartingTime(), ThisThetatree.rootOfTree());
                ko[i] = v;
                ThisThetatree.scheduleTask(indicesOfTinQ[i]);
            }
            else {       
                v  = (int) Math.max(SupplementarySampleTasks[i].earliestStartingTime(), ThisThetatree.rootOfTree());
                ko[i] = v;
            }
        }
        for (i = 0; i < g; i++)
            SupplementarySampleTasks[i].setEarliestStartingTime(ko[i]);
        return ThisThetatree.rootOfTree();
    }

    public String pretty() {
        return null;
    }

    public void awake() throws ContradictionException {
        propagate();
    }
}
