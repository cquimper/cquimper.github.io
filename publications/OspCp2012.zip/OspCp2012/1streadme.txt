-----------------------------------------------------------------------------
| LICENSE                                                                   |
-----------------------------------------------------------------------------

Copyright (C) 2010  Michael Morin
This program is free software: you can redistribute it and/or modify
it under the terms of the  v. 3.0  or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the Academic Free License ("AFL")
v. 3.0  for more details.

You should have received a copy of the Academic Free License ("AFL") v. 3.0
along with this program.


-----------------------------------------------------------------------------
| ON THIS SOFTWARE                                                          |
-----------------------------------------------------------------------------

Application: OspCp2012
Version: 1.0
Publication:
 M. Morin, A.P. Papillon, F. Laviolette, I. Abi-Zeid, and C.G. Quimper, 
 "Constraint Programming for Path Planning with Uncertainty: Solving the 
 Optimal Search Path problem," in Proceedings of the 18th Conference on 
 Principles and Practice of Constraint Programming, Qu�bec, Qc, Canada, 
 2012, pp. 988-1003.
Description:
 An experiment for the CP 2012 conference.


-----------------------------------------------------------------------------
| FROM THE AUTHOR                                                           |
-----------------------------------------------------------------------------

This software uses the following third party libraries:
 - Choco Solver 2.1.3 (http://www.emn.fr/z-info/choco-solver)
 - Jung 2.0.1 (http://jung.sourceforge.net)
and is related to the following publication:
 M. Morin, A.P. Papillon, F. Laviolette, I. Abi-Zeid, and C.G. Quimper, 
 "Constraint Programming for Path Planning with Uncertainty: Solving the 
 Optimal Search Path problem," in Proceedings of the 18th Conference on 
 Principles and Practice of Constraint Programming, Qu�bec, Qc, Canada, 
 2012, pp. 988-1003.

Enhancements and comments are welcomed. Please let us know!  

Best regards,

Michael
http://www.michaelmorin.info


