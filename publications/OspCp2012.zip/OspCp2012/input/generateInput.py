 ##
 # Copyright (C) 2010  Michael Morin
 # This program is free software: you can redistribute it and/or modify
 # it under the terms of the  v. 3.0  or (at your option) any later version.
 #
 # This program is distributed in the hope that it will be useful, but WITHOUT
 # ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 # FITNESS FOR A PARTICULAR PURPOSE. See the Academic Free License ("AFL")
 # v. 3.0  for more details.
 #
 # You should have received a copy of the Academic Free License ("AFL") v. 3.0
 # along with this program.
 ##

 ##
 # From the author:
 # This script is related to the following publication:
 #  M. Morin, A.P. Papillon, F. Laviolette, I. Abi-Zeid, and C.G. Quimper, 
 #  "Constraint Programming for Path Planning with Uncertainty: Solving the 
 #  Optimal Search Path problem," in Proceedings of the 18th Conference on 
 #  Principles and Practice of Constraint Programming, Quebec, Qc, Canada, 
 #  2012, pp. 988-1003.
 # 
 # Enhancements and comments are welcomed. Please let us know!  
 #
 # Best regards,
 #
 # Michael
 # http://www.michaelmorin.info
 ##

 ##
 # File: generateInput.py
 # Created on 2012-05-19
 # Modified on 2012-06-26
 # Author: Michael Morin
 # Description:
 #  A short python script to generate input files for the Optimal Search 
 #  Path (OSP) problem experiment of the CP 2012 conference.
 ##

import math

def writeInputFile(environment_name, experiment, backtrack, time, scaleUp, verbosity, ospvHeuristicVerbosity, ospvHeuristicTexLogging, configRange, instancesRange):
    for c in configRange:
        for i in instancesRange:
            f = open('Curve_' + environment_name + str(c) + '_inst' + str(i) + '_scale' + str(scaleUp) + '.input', 'w')
            f.write('Experiment = ' + experiment + '\n')
            f.write('Instance = ' + str(i) + '\n')
            f.write('Configuration = ' + str(c) + '\n')
            f.write('Backtrack = ' + backtrack + '\n')
            f.write('Time = ' + time + '\n')
            f.write('ScaleUpFactor = ' + str(scaleUp) + '\n')
            f.write('Verbosity = ' + verbosity + '\n')
            f.write('ChocoLogging = ' + 'Curve_' + environment_name + str(c) + '_inst' + str(i) + '_scale' + str(scaleUp) + '.txt' + '\n')
            f.close

# Write star grid
list_scale_up = [10000]
list_T = [9,11,13,15,17,19]
list_env = range(1,4)
list_env_name = ['Campus', 'Plus', 'Star']
list_pod = range(1,4)
list_motion_model = range(3,6)

list_config = [102020102, 102050102]

for t in list_T:
    for env in list_env:
        for pod in list_pod:
            for motion in list_motion_model:
                for scale_up in list_scale_up:
                    id = int(env * math.pow(10,5) + pod * math.pow(10,4) + motion * math.pow(10,3) + t)
                    writeInputFile(list_env_name[env - 1], 'osp', '5000000', '1200000', scale_up, '4', '0', '-', list_config, range(id,id + 1))

