
/*
 *  Pathological example from Puget's 1998 alldiff paper
 */

#include <ilsolver/ilcint.h>
#include "../Propagator/gcc.h"


IlcFloat
testEvent( IlcInt n, IlcInt ub, IlcInt flag )
{
  IlcManager m(IlcEdit);
  IlcInt i, j;
  IlcFloat currtime, elapsed_time;

  currtime = m.getTime();

  IlcIntVarArray vars( m, ub*(2*n+1), 0, 2*n );

  for( i = 0; i <= n; i++ ) {
    if( ub == 1 ) {
      vars[i].setRange( i, n );
    }
    if( ub == 2 ) {
      vars[2*i  ].setRange( i, n );
      vars[2*i+1].setRange( i, n );
    }
    if( ub == 3 ) {
      vars[3*i  ].setRange( i, n );
      vars[3*i+1].setRange( i, n );
      vars[3*i+2].setRange( i, n );
    }
  }

  for( i = n+1; i <= 2*n; i++ ) {
    if( ub == 1 ) {
      vars[i].setRange( n, i );
    }
    if( ub == 2 ) {
      vars[2*i  ].setRange( n, i );
      vars[2*i+1].setRange( n, i );
    }
    if( ub == 3 ) {
      vars[3*i  ].setRange( n, i );
      vars[3*i+1].setRange( n, i );
      vars[3*i+2].setRange( n, i );
    }
  }

  int* minOccurrences = new int[2*n+1];
  int* maxOccurrences = new int[2*n+1];

  /*
   *  Set bounds on the occurrences of values.
   */
  for( i = 0; i < 2*n+1; i++ ) {
    minOccurrences[i] = ub;
    maxOccurrences[i] = ub;
  }
  IlcIntVarArray cards( m, 2*n+1, ub, ub );

  switch (flag) {
  case 0: m.add( IlcDistribute( cards, vars, IlcBasic    ) ); break;
  case 1: m.add( IlcDistribute( cards, vars, IlcExtended ) ); break;
  case 2: m.add( IlcNewGCC( vars, WithOutValueRemoval, 0, 2*n,
			    minOccurrences, maxOccurrences ) ); break;
  }

  m.add( IlcGenerate( vars ) );
  m.nextSolution();

  elapsed_time = (m.getTime() - currtime);

  m.end();

  return( elapsed_time );
}


#define N_SAMPLES 10

int
main( int argc, char** argv )
{
  IlcInt   i, n, ub, flag;
  IlcFloat totaltime;

  if( argc != 3 ) {
    cerr << "Usage: pathological ub flag" << endl;
    exit( 0 );
  }

  ub   = atoi( argv[1] );
  flag = atoi( argv[2] );

  printf( "ub = %d, flag = %d\n", ub, flag );
  for( n = 100; n <= 1600; n *= 2 ) {
    totaltime = 0.0;
    for( i = 0; i < N_SAMPLES; i++ ) {
      totaltime += testEvent( n, ub, flag );
      //printf( "%d:%d:%0.2f\n", n, flag, totaltime/((double)(i+1)) );
    }
    printf( "%d\t%0.2f\n", n, totaltime/((double)N_SAMPLES) );
    fflush( stdout );
  }

  return( 0 );
}

