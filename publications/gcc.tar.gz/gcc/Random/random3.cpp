
/*
 *  Random model of gcc problems.
 */

#include <ilsolver/ilcint.h>
#include "../Propagator/gcc.h"

double current_cpu;
double current_solution;
double total_cpu;
double total_solutions;

/*
\caption{
    Time (sec.) to first solution (or to detect inconsistency) for
    random problems where the bounds $[l_i, u_i]$ on the number of
    occurrences of each value are chosen uniformly at random from
    \{[0, 1], [0, 2], [1, 1], [1, 2], [1, 3], [2, 2], [2, 3], [2, 4]\}
    and the range of the domain values is $n/2$.
    Each data point is the average of 100 problems.
\label{TABLE:Random1}
}
\end{center}
\end{table}

In order to systematically study the scaling behavior
of the algorithm, we next consider random problems.
The problems consisted of a single gcc constraint
over $n$ variables and each variable had its
initial domain set to $[a, b]$, where $a$ and $b$, $a \leq b$,
were chosen uniformly at random from $[1, n/2]$.
The problems were then solved using the minimum domain
size variable ordering (see Table~\ref{TABLE:Random1}).
*/
void
testEvent( IlcInt n, IlcInt range, IlcInt flag )
{
  int  i, a, b, count;

  IlcManager m(IlcEdit);

  m.setTimeLimit( 600 );

  IlcFloat currtime   = m.getTime();

  int* minOccurrences = new int[range];
  int* maxOccurrences = new int[range];

  /*
   *  Set bounds on the occurrences of values.
   */
  for( i = 0; i < range; i++ ) {
    a = rand() % 3;
    b = a + (rand() % 3);
    while( a == 0 && b == 0 ) {
      a = rand() % 3;
      b = a + (rand() % 3);
    }
    //printf("%d, %d\n", a, b);
    minOccurrences[i] = a;
    maxOccurrences[i] = b;
  }

  IlcIntVarArray cards( m, range, 0, n );
  for( i = 0; i < range; i++ ) {
    cards[i].setRange( minOccurrences[i], maxOccurrences[i] );
  }

  /*
   *  Set variables and their initial domains.
   */
  IlcIntVarArray vars( m, n, 0, range-1 );
  for( i = 0; i < n; i++ ) {
    a = rand() % range;
    b = rand() % range;
    if( a <= b ) vars[i].setRange( a, b );
    else	 vars[i].setRange( b, a );
  }

  /*
   *  Post gcc constraint.
   */
  switch (flag) {
  case 0: m.add( IlcDistribute( cards, vars, IlcBasic    ) ); break;
  case 1: m.add( IlcDistribute( cards, vars, IlcExtended ) ); break;
  case 2: m.add( IlcNewGCC( vars, WithOutValueRemoval, 0, range-1,
			    minOccurrences, maxOccurrences ) ); break;
  }

  m.add( IlcGenerate( vars, IlcChooseMinSizeInt ) );

  count = 0;
  if( m.nextSolution() ) {
    count++;
  }

  current_cpu      = (m.getTime() - currtime);
  current_solution = count;
  total_cpu       += current_cpu;
  total_solutions += current_solution;

  delete minOccurrences;
  delete maxOccurrences;
  m.end();
}

void
initInfo()
{
  srand(0);
  total_cpu       = 0.0;
  total_solutions = 0.0;
}

void
printInfo( int n, int range, int iteration )
{
  cout << "n: " << n << "  ";
  cout << "range: " << range << "  ";
  cout << "iter: "  << iteration << "  ";
  cout << "time: "  << current_cpu << "  ";
  cout << "soln: "  << current_solution << endl;
}

void
printSummary( int n, int range, int iterations )
{
  cout << "n: " << n << "  ";
  cout << "range: " << range << "  ";
  cout << "iters: " << iterations << "  ";
  cout << "time: "  << total_cpu       / ((double)iterations) << "  ";
  cout << "solns: " << total_solutions / ((double)iterations) << endl;
}

int
main( int argc, char** argv )
{
  int k, n, range, iterations, flag;

  if( argc != 4 ) {
    cerr << "Usage: random n iters flag" << endl;
    cerr << "  where" << endl;
    cerr << "    n     is the number of variables" << endl;
    cerr << "    iters is the number of iterations" << endl;
    cerr << "    flag  is the propagator to use (0=ILOG,1=ILOG,2=new)" << endl;
    exit( 0 );
  }

  n          = atoi( argv[1] );
  iterations = atoi( argv[2] );
  flag       = atoi( argv[3] );

  //for( range = n/2-n/20; range <= n/2+n/20; range++ ) {
  //for( range = 1; range <= n; range++ ) {
  for( range = n/2; range <= n/2; range++ ) {
    initInfo();
    for( k = 1; k <= iterations; k++ ) {
      testEvent( n, range, flag );
      printInfo( n, range, k );
    }
    printSummary( n, range, iterations );
  }

  return 0;
}

