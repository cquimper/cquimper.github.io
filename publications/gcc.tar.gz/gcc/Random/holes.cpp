
/*
 *  Random model of gcc problems.
 */

#include <ilsolver/ilcint.h>
#include "../Propagator/gcc.h"

#define CUTOFF 2

double current_cpu;
int    current_solution;
int    total_not_solved;

void
testEvent( IlcInt n, IlcInt range, IlcInt flag, float prob )
{
  int  i, j, k, a, b, t;
  double p;

  IlcManager m(IlcEdit);

  m.setTimeLimit( CUTOFF );

  IlcFloat currtime = m.getTime();
  IlcInt   currfail = m.getNumberOfFails();

  int* valueCounts = new int[range];
  for( i = 0; i < range; i++ ) {
    valueCounts[i] = 0;
  }

  /*
   *  Set variables and their initial domains.
   */
  IlcIntVarArray vars( m, n, 0, range-1 );
  for( i = 0; i < n; i++ ) {
    a = rand() % range;
    b = rand() % range;
    if( b < a ) {
      t = b;
      b = a;
      a = t;
    }
    vars[i].setRange( a, b );
    valueCounts[a]++;
    valueCounts[b]++;

    for( j = a+1; j < b; j++ ) {
      p = ((double)rand())/32767.0;
      if( p < prob ) {
        vars[i].removeValue( j );
      }
      else {
        valueCounts[j]++;
      }
    }
  }

  int* minOccurrences = new int[range];
  int* maxOccurrences = new int[range];

  /*
   *  Set bounds on the occurrences of values.
   */
  for( i = 0; i < range; i++ ) {
    a = rand() % 3;
    b = a + (rand() % 3);
    while( a == 0 && b == 0 ) {
      a = rand() % 3;
      b = a + (rand() % 3);
    }
    minOccurrences[i] = a;
    if( minOccurrences[i] > valueCounts[i] ) {
      minOccurrences[i] = valueCounts[i];
    }
    maxOccurrences[i] = b;
  }

for( a = 0; a < range; a++ ) {
  k = 0;
  for( i = 0; i < n; i++ ) {
    if( vars[i].isInDomain( a ) ) k++;
  }
  if( minOccurrences[a] >= k ) {
    m.out() << minOccurrences[a] << " vs " << k << endl;
    //maxOccurrences[a] = k;
  }
}

  IlcIntVarArray cards( m, range, 0, n );
  for( i = 0; i < range; i++ ) {
    cards[i].setRange( minOccurrences[i], maxOccurrences[i] );
  }

  /*
   *  Post gcc constraint.
   */
  switch (flag) {
  case 0: m.add( IlcDistribute( cards, vars, IlcBasic    ) ); break;
  case 1: m.add( IlcDistribute( cards, vars, IlcExtended ) ); break;
  case 2: m.add( IlcNewGCC( vars, WithOutValueRemoval, 0, range-1,
			    minOccurrences, maxOccurrences ) ); break;
  case 3: m.add( IlcNewGCC( vars, WithValueRemoval, 0, range-1,
			    minOccurrences, maxOccurrences ) ); break;
  case 4:
	  m.add( IlcDistribute( cards, vars, IlcBasic ) );
	  m.add( IlcNewGCC( vars, WithOutValueRemoval, 0, range-1,
			    minOccurrences, maxOccurrences ) );
	  break;
  case 5:
	  m.add( IlcDistribute( cards, vars, IlcBasic ) );
	  m.add( IlcNewGCC( vars, WithValueRemoval, 0, range-1,
			    minOccurrences, maxOccurrences ) );
	  break;
  }

  //m.add( IlcGenerate( vars ) );
  m.add( IlcGenerate( vars, IlcChooseMinSizeInt ) );

  current_solution = 0;
  if( m.nextSolution() ) {
    current_solution++;
  }

  if( (m.getTime() - currtime) >= (CUTOFF - 0.01) ) {
    total_not_solved++;
  }

  current_cpu = (m.getTime() - currtime);
  m.out() << "fails:    " << (m.getNumberOfFails() - currfail) << endl;

  delete minOccurrences;
  delete maxOccurrences;
  delete valueCounts;
  m.end();
}

void
initInfo()
{
  srand(0);
  total_not_solved = 0;
}

void
printInfo( int n, int range, int iteration )
{
  cout << "n: " << n << "  ";
  cout << "range: " << range << "  ";
  cout << "iter: "  << iteration << "  ";
  cout << "time: "  << current_cpu << "  ";
  cout << "soln: "  << current_solution << endl;
}

void
printSummary( int n, int range, int iterations, float prob )
{
  cout << "n: " << n << "  ";
  cout << "range: " << range << "  ";
  cout << "iters: " << iterations << "  ";
  cout << "prob: " << prob << "  ";
  cout << "not solved: " << total_not_solved << endl;
}

int
main( int argc, char** argv )
{
  int k, n, range, iterations, flag;
  float prob;

  if( argc != 5 ) {
    cerr << "Usage: random n iters flag prob" << endl;
    cerr << "  where" << endl;
    cerr << "    n     is the number of variables" << endl;
    cerr << "    iters is the number of iterations" << endl;
    cerr << "    flag  is the propagator to use (0=ILOG,1=ILOG,2=new)" << endl;
    cerr << "    prob  is the probability a value is removed" << endl;
    exit( 0 );
  }

  n          = atoi( argv[1] );
  iterations = atoi( argv[2] );
  flag       = atoi( argv[3] );
  prob       = atof( argv[4] );
printf("%8.2f\n", prob);

  for( range = n/2; range <= n/2; range++ ) {
    initInfo();
    for( k = 1; k <= iterations; k++ ) {
      testEvent( n, range, flag, prob );
      printInfo( n, range, k );
    }
    printSummary( n, range, iterations, prob );
  }

  return 0;
}

