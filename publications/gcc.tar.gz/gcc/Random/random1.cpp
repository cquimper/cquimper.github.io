
/*
 *  Random model of gcc problems.
 */

#include <ilsolver/ilcint.h>
#include "../Propagator/gcc.h"

double current_cpu;
double current_solution;
double total_cpu;
double total_solutions;


void
testEvent( IlcInt n, IlcInt range, IlcInt ub, IlcInt flag )
{
  int  i, a, b, count;

  IlcManager m(IlcEdit);

  m.setTimeLimit( 600 );

  IlcFloat currtime   = m.getTime();

  int* minOccurrences = new int[range];
  int* maxOccurrences = new int[range];

  /*
   *  Set bounds on the occurrences of values.
   */
  for( i = 0; i < range; i++ ) {
    minOccurrences[i] = 0;
    maxOccurrences[i] = ub;
  }

  IlcIntVarArray cards( m, range, 0, ub );

  /*
   *  Set variables and their initial domains.
   */
  IlcIntVarArray vars( m, n, 0, range-1 );
  for( i = 0; i < n; i++ ) {
    a = rand() % range;
    b = rand() % range;
    if( a <= b ) vars[i].setRange( a, b );
    else	 vars[i].setRange( b, a );
  }

  /*
   *  Post gcc constraint.
   */
  switch (flag) {
  case 0: m.add( IlcDistribute( cards, vars, IlcBasic    ) ); break;
  case 1: m.add( IlcDistribute( cards, vars, IlcExtended ) ); break;
  case 2: m.add( IlcNewGCC( vars, WithOutValueRemoval, 0, range-1,
			    minOccurrences, maxOccurrences ) ); break;
  }

  m.add( IlcGenerate( vars, IlcChooseMinSizeInt ) );

  count = 0;
  if( m.nextSolution() ) {
    count++;
  }

  current_cpu      = (m.getTime() - currtime);
  current_solution = count;
  total_cpu       += current_cpu;
  total_solutions += current_solution;

  delete minOccurrences;
  delete maxOccurrences;
  m.end();
}

void
initInfo()
{
  srand(0);
  total_cpu       = 0.0;
  total_solutions = 0.0;
}

void
printInfo( int n, int range, int ub, int iteration )
{
  cout << "n: " << n << "  ";
  cout << "range: " << range << "  ";
  cout << "iter: "  << iteration << "  ";
  cout << "ub: "    << ub << "  ";
  cout << "time: "  << current_cpu << "  ";
  cout << "soln: "  << current_solution << endl;
}

void
printSummary( int n, int range, int ub, int iterations )
{
  cout << "n: " << n << "  ";
  cout << "range: " << range << "  ";
  cout << "iters: " << iterations << "  ";
  cout << "ub: "    << ub << "  ";
  cout << "time: "  << total_cpu       / ((double)iterations) << "  ";
  cout << "solns: " << total_solutions / ((double)iterations) << endl;
}

int
main( int argc, char** argv )
{
  int i, k, n, range, iterations, flag, ub;

  if( argc != 5 ) {
    cerr << "Usage: random n iters ub flag" << endl;
    cerr << "  where" << endl;
    cerr << "    n     is the number of variables" << endl;
    cerr << "    iters is the number of iterations" << endl;
    cerr << "    ub    is the upper on the occurrences of the values" << endl;
    cerr << "    flag  is the propagator to use (0=ILOG,1=ILOG,2=new)" << endl;
    exit( 0 );
  }

  n          = atoi( argv[1] );
  iterations = atoi( argv[2] );
  ub         = atoi( argv[3] );
  flag       = atoi( argv[4] );

  //for( range = 1; range <= n; range++ ) {
  for( i = 1, range = (n/ub)/2; i <= 3; i++, range *= 2 ) {
    initInfo();
    for( k = 1; k <= iterations; k++ ) {
      testEvent( n, range, ub, flag );
      printInfo( n, range, ub, k );
    }
    printSummary( n, range, ub, iterations );
  }

  return 0;
}

