/*
 * This file is part of choco-parsers, http://choco-solver.org/
 *
 * Copyright (c) 2021, IMT Atlantique. All rights reserved.
 *
 * Licensed under the BSD 4-clause license.
 *
 * See LICENSE file in the project root for full license information.
 */
package org.chocosolver.parser.flatzinc.parser;

/**
 * <br/>
 *
 * @author Charles Prud'homme
 * @since 26/10/12
 */
public class RandomPhrase {

    public static void main(String[] args) {
        for (int i = 0; i < 20; i++) {
//            org.antlr.tool.RandomPhrase.main(new String[]{"/Users/cprudhom/These/Notes/20121026_grammar/NDSL.g", "structure"});
//            org.antlr.tool.RandomPhrase.main(new String[]{"/Users/cprudhom/Sources/Choco3/parser/src/main/antlr3/parser/flatzinc/FlatzincFullExtWalker.g","engine"});
        }
    }
}
