[![Gitter](https://badges.gitter.im/chocoteam/choco-sat.svg)](https://gitter.im/chocoteam/choco-sat?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge) [![Build Status](https://travis-ci.org/chocoteam/choco-sat.svg?branch=master)](https://travis-ci.org/chocoteam/choco-sat) [![codecov.io](https://codecov.io/github/chocoteam/choco-sat/coverage.svg?branch=master)](https://codecov.io/github/chocoteam/choco-sat?branch=master)


choco-sat
=========

choco-sat is a Free and Open-Source Software dedicated to Boolean Satisfiabilty Problem, ie a SAT solver. 
It is a Java library written under BSD license. 