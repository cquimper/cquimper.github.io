# A MinCumulative Resource Constraint
This repository contains files related to the paper "A MinCumulative Resource Constraint" submitted to CPAIOR 2022. 

The code is available in the `choco-solver` directory. It is a modified version of Choco Solver with the algorithms proposed in this paper. 

The random instances and the model to solve them are available in the `random-instance` directory.
