import importlib
import sys
import csv
import random
import os
import time
import LNSOutput
import math

assignedLoomPath = sys.argv[1]
resetPercent = int(sys.argv[2])
solver = sys.argv[3]
seed = int(sys.argv[4])
concorde = int(sys.argv[5])
timeout = int(sys.argv[6])
innerTimeout = float(sys.argv[7])
initialObj = float(sys.argv[8])

def parseChrono(chronoString):
    print("before parsing: " + chronoString)
    chronoString = chronoString[len("% time elapsed: "):]
    chronoString = chronoString[:-2]
    chrono = float(chronoString)
    return chrono


def findObj(path, defaultVal):
    objList = []
    timeList = []
    try:
        with open(path, 'r') as txt:
            for line in txt:
                objPos = line.find("obj =")
                timePos = line.find("% time elapsed:")
                if objPos != -1:
                    obj = line
                    obj = obj.replace("obj = ", "")
                    obj = obj.replace(';\n', '')
                    objList.append(int(float(obj)))
                elif timePos != -1:
                    timeList.append(parseChrono(line))
    except:
        print("empty " + path)
    # Parse the last obj and time found
    if objList == []:
        objList = [defaultVal]
    if timeList == []:
        timeList = [0]

    return objList, timeList


def resetLoom(circuit, loom, jobTotal):
    toReset = circuit[jobTotal + loom - 1]
    while circuit[toReset - 1] < jobTotal and circuit[toReset - 1] != -1:
        next = circuit[toReset - 1]
        circuit[toReset - 1] = -1
        toReset = next
    circuit[toReset - 1] = -1
    circuit[jobTotal + loom - 1] = -1

def outputData(objList, timeList):
    try:
        with open("Minizinc/benchmarkOutput.txt", 'w') as output:
            outputString = ""
            for i in range(0, len(timeList)):
                outputString += "obj = " + str(objList[i]) + "\n"
                outputString += "% time elapsed: " + str(timeList[i]) + " s\n"
            if timeList == []:
                output.write("=====UNKNOWN=====\n")
            output.write(outputString)
        os.system("rm Minizinc/LNSHeuristic.txt")
        #os.system("rm Minizinc/LNSHeuristic.dzn")
    except IOError:
        print("could not write benchmarkOutput")


def mainSearchLoop(timeout):
    loopResetPercent = resetPercent
    random.seed(seed)
    maxUnsatInRow = 4
    unsatInRowToIncreaseReset = 1
    unknownInRowToDecreaseReset = 1
    unsatCount = 0
    obj = initialObj
    objList = []
    timeList = []
    initialTimeout = timeout
    innerTimeoutDuration = float(initialTimeout) / innerTimeout
    with open(assignedLoomPath, 'r') as assignedLoomCsv:
        if os.path.exists("Minizinc/LNSOutput.txt"):
            os.system("rm Minizinc/LNSOutput.txt")
        assignedLoom = {}
        jobs = set()
        looms = set()

        assignedLoomFileDict = list(csv.DictReader(assignedLoomCsv))
        for row in assignedLoomFileDict:
            assignedLoom["J" + row["Job"]] = row["PosteDeTravail"]
            jobs.add("J" + row["Job"])
            looms.add(row["PosteDeTravail"])

        jobTotal = len(jobs)
        loomTotal = len(looms)
        circuitHeuristic = []
        if concorde == 1:
            os.system("cp Minizinc/CircuitHeuristic.dzn Minizinc/CircuitHeuristic.py")
            from CircuitHeuristic import circuitHeuristic
        else:
            for i in range(0, jobTotal + loomTotal):
                circuitHeuristic.append(-1)

        previousFullCircuit = circuitHeuristic.copy()

        while math.floor(timeout) > 0:
            print("time left: " + str(timeout))
            numberLoomsReset = math.floor((loopResetPercent / 100.0) * loomTotal)
            print("looms to reset: " + str(numberLoomsReset) + " resetPercent: " + str(
                loopResetPercent) + "total looms: " + str(loomTotal))

            resetList = random.sample(range(1, loomTotal + 1), numberLoomsReset)
            print(resetList)

            print("before forgetting: " + str(circuitHeuristic))
            for loomToReset in resetList:
                resetLoom(circuitHeuristic, loomToReset, jobTotal)
            print("after forgetting: " + str(circuitHeuristic))

            with open("Minizinc/LNSHeuristic.txt", "w") as LnsCircuitData:
                LnsCircuitData.write("circuitHeuristic = " + str(circuitHeuristic) + ";\nobj = " + str(int(obj)) + ";")
            with open("Minizinc/LNSHeuristic.dzn", "w") as LnsCircuitData:
                LnsCircuitData.write("circuitHeuristic = " + str(circuitHeuristic) + ";\nmaxObj = " + str(int(obj)) + ";")

            os.system("minizinc --solver "
                      + solver
                      + " Minizinc/LNSbenchmark.mzn --output-time --time-limit "
                      + str(math.floor(min(timeout, innerTimeoutDuration)))
                      + " -r "
                      + str(seed)
                      + "-f --output-to-file Minizinc/LNSOutput.txt")
            print("reading output")

            if not os.path.exists("Minizinc/LNSOutput.txt"):
                print("LNSOutput.txt not written, previous best: " + str(obj))
                unsatCount = 0
                timeout = timeout - min(timeout, innerTimeoutDuration)
                circuitHeuristic = previousFullCircuit.copy()
                continue

            with open("Minizinc/LNSOutput.txt", "r") as output:
                circuitText = output.readline()
                objText = output.readline().replace("obj = ", "")

                if circuitText == "":
                    print("fatal error: empty LNSOutput.py")
                    timeout = 0
                    continue
                if circuitText.find("===UNKNOWN===") != -1 or objText.find("===UNKNOWN===") != -1:
                    print("unknown, previous best: " + str(obj))
                    unsatCount += 1
                    dummy, timeUsed = findObj("Minizinc/LNSOutput.txt", obj)
                    timeout = timeout - timeUsed[0] * 1000
                    circuitHeuristic = previousFullCircuit.copy()
                    os.system("cp Minizinc/LNSOutput.txt Minizinc/LNSOutput_bk.txt")
                    os.system("rm Minizinc/LNSOutput.txt")
                    if unsatCount >= unknownInRowToDecreaseReset and loopResetPercent > 0:
                        loopResetPercent = max(0, loopResetPercent - 10)
                        print("reset percent went down: " + str(loopResetPercent))
                        unsatCount = 0
                    elif unsatCount >= maxUnsatInRow:
                        print("ending; best obj found: " + str(objList[len(objList)-1]))
                        timeout = 0
                    continue
                if circuitText.find("=UNSATISFIABLE=") != -1 or objText.find("=UNSATISFIABLE=") != -1 or objText.find(
                        "==ERROR==") != -1 or circuitText.find("==ERROR==") != -1:
                    print("unsat, previous best: " + str(obj))
                    unsatCount += 1
                    dummy, timeUsed = findObj("Minizinc/LNSOutput.txt", obj)
                    timeout = timeout - timeUsed[0] * 1000
                    circuitHeuristic = previousFullCircuit.copy()
                    os.system("cp Minizinc/LNSOutput.txt Minizinc/LNSOutput_bk.txt")
                    os.system("rm Minizinc/LNSOutput.txt")
                    if unsatCount >= unsatInRowToIncreaseReset and loopResetPercent < 100:
                        loopResetPercent = min(100, loopResetPercent + 10)
                        print("reset percent went up: "+str(loopResetPercent))
                        unsatCount = 0
                    elif unsatCount >= maxUnsatInRow:
                        print("ending; best obj found: " + str(objList[len(objList)-1]))
                        timeout = 0
                    continue
            print(objText)
            newObj = int(float(objText[:-2]))
            print("newObj=" + str(newObj) + " prev=" + str(obj))
            if newObj < obj:  # somehow, exec doesn't work
                with open("Minizinc/LNSOutput.py", 'w') as newCircuitScript:
                    newCircuitScript.write(circuitText.replace(";", ""))
                importlib.reload(LNSOutput)
                from LNSOutput import circuitHeuristic as newCircuit
                circuitHeuristic = newCircuit.copy()
                previousFullCircuit = circuitHeuristic.copy()
                obj = newObj
            else:
                circuitHeuristic = previousFullCircuit.copy()
                os.system("cp Minizinc/LNSOutput.txt Minizinc/LNSOutput_bk.txt")
                os.system("rm Minizinc/LNSOutput.txt")
                unsatCount = 0
                continue
            dummy, timeUsed = findObj("Minizinc/LNSOutput.txt", obj)
            os.system("cp Minizinc/LNSOutput.txt Minizinc/LNSOutput_bk.txt")
            os.system("rm Minizinc/LNSOutput.txt")
            timeout = timeout - timeUsed[0] * 1000
            timeList.append((initialTimeout - timeout) / 1000)
            objList.append(obj)
            unsatCount = 0
        print("time is out")
    outputData(objList, timeList)


mainSearchLoop(timeout)
