// Raphaël Boudreault/Improved CP-Based Lagrangian Relaxation Approach with an Application to the TSP (IJCAI 2021)

package org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation.improvedAlgorithms;

import org.chocosolver.graphsolver.cstrs.cost.GraphLagrangianRelaxation;
import org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation.KruskalOneTree_GAC;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.util.objects.setDataStructures.ISet;
import org.chocosolver.util.objects.setDataStructures.ISetIterator;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;

public class Improved_OneTree extends KruskalOneTree_GAC {

    // Attributes for filtering algorithms
    int additionalFiltering;
    double currentObjective;
    double[] currentLagrangianModifications;
    double[] nodeToDecreaseValue;
    double[] nodeToIncreaseValue;
    ArrayDeque<Integer> edgesToEnforce;
    ArrayDeque<Integer> edgesToRemove;
    ArrayList<ArrayList<Integer>> edgeToCycleOfEdges;

    // Attributes related only to ALPHA-SETS algorithm
    OneTreeConstraintFactory oneTreeConstraintFactory;
    int depthLimit; // Fixed for the moment (>= 1)
    int maxNumberIterations; // Fixed for the moment
    int numberInitialConstraints;
    OneTreeConstraint reducedCostConstraint;
    ArrayDeque<OneTreeConstraint> listOfConstraints;
    ArrayDeque<Integer> potentialChoices;
    ArrayDeque<Integer> choices;
    BitSet isInChoices;
    ArrayDeque<ArrayDeque<Integer>> stackOfPotentialChoices;
    int numberAddedToList;
    ArrayDeque<Integer> stackNumberAddedToList;

    // Constructor
    public Improved_OneTree(int nbNodes, GraphLagrangianRelaxation propagator) {
        super(nbNodes, propagator);

        if (configOptions.mode == configOptions.Mode.CHOCO) return;

        additionalFiltering = 0;
        currentObjective = 0;
        currentLagrangianModifications = new double[n];
        nodeToDecreaseValue = new double[n];
        nodeToIncreaseValue = new double[n];
        edgesToEnforce = new ArrayDeque<>();
        edgesToRemove = new ArrayDeque<>();
        edgeToCycleOfEdges = new ArrayList<>(n * n);

        if (configOptions.mode == configOptions.Mode.SIMPLE_RELAXED) return;

        for (int i = 0; i < n*n; i++) {
            ArrayList<Integer> array = new ArrayList<>(n);
            edgeToCycleOfEdges.add(array);
        }

        if (configOptions.mode == configOptions.Mode.SIMPLE_COMPLETE) return;

        depthLimit = configOptions.depthLimit;
        maxNumberIterations = configOptions.numberIterations;
        assert depthLimit >= 1;
        assert maxNumberIterations >= 0;
        oneTreeConstraintFactory = new OneTreeConstraintFactory();
        numberInitialConstraints = 0;
        reducedCostConstraint = new OneTreeConstraint();
        listOfConstraints = new ArrayDeque<>(n);
        choices = new ArrayDeque<>(depthLimit);
        isInChoices = new BitSet(n);
        stackOfPotentialChoices = new ArrayDeque<>(depthLimit);
        numberAddedToList = 0;
        stackNumberAddedToList = new ArrayDeque<>(depthLimit);
    }

    /*
    //DEBUG
    private boolean checkSolution() {
        int[] nodes = {1, 20, 4, 28, 2, 25, 8, 11, 5, 27, 0, 23, 12, 15, 26, 7, 22, 6, 24, 18, 10, 21, 16, 13, 17, 14, 3, 9, 19, 1};
        boolean ok = true;
        for (int i = 0; i < n; i++) {
            if (!g.getNeighOf(nodes[i]).contains(nodes[i + 1])){
                ok = false;
            }
        }
        return ok;
    }
    */

    // --- PRE-TREATMENT OF THE 1-TREE ---
    /**
     * Overriden method of KruskalOneTree_GAC so that the pre-treatment is done while computing replacement edges.
     * The difference is that no compression is made during the exploration of the tree. Furthermore, constraints
     * related to edges in MST are stocked.
     */
    @Override
    protected void markTreeEdges(int[] parent, int i, int j) {
        if (configOptions.mode == configOptions.Mode.SIMPLE_RELAXED) {
            super.markTreeEdges(parent, i, j);
            return;
        }

        if (i == 0) {
            throw new UnsupportedOperationException();
        }

        // Find LCA between i and j
        // TODO: Would be slightly more efficient with DFS information (to get LCA)
        useful.clear();
        // Going up in tree starting from i
        int node;
        for (node = i; node != parent[node]; node = parent[node]) {
            useful.set(node);
        }
        useful.set(node);
        // Going up in tree starting from j
        int lca = j;
        while (!useful.get(lca)) {
            lca = parent[lca];
        }

        // Find all edges on the cycle and create corresponding constraints + replacement edges
        getEdgesOnBranch(parent, i, j, i, lca);
        getEdgesOnBranch(parent, i, j, j, lca);
    }

    private void getEdgesOnBranch(int[] parent, int i, int j, int from, int lca) {
        assert parent.length == n;
        assert 1 <= i && i <= n;
        assert 1 <= j && j <= n;
        assert 1 <= from && from <= n;
        assert 1 <= lca && lca <= n;
        int replacementEdge = i * n + j;
        for (int node = from; node != lca; node = parent[node]) {
            int p = parent[node];
            if (!propHK.isMandatory(node, p)) { // Add edges only if not mandatory
                int currentEdge = node < p ? node * n + p : p * n + node;
                edgeToCycleOfEdges.get(replacementEdge).add(currentEdge);
                edgeToCycleOfEdges.get(currentEdge).add(replacementEdge);
                assert edgeToCycleOfEdges.get(replacementEdge).size() < n * n / 4;
                assert edgeToCycleOfEdges.get(currentEdge).size() < n * n / 4;
                if (map[node][p] == -1) {
                    map[node][p] = map[p][node] = replacementEdge;
                }
            }
        }
    }

    private void addOneNodeEdges() {
        for (int node : Tree.getNeighOf(0)) {
            if (!propHK.isMandatory(0, node)) {
                ISetIterator iter = g.getNeighOf(0).newIterator();
                while (iter.hasNext()) {
                    int j = iter.next();
                    if (!Tree.edgeExists(0, j)) {
                        edgeToCycleOfEdges.get(node).add(j);
                        edgeToCycleOfEdges.get(j).add(node);
                    }
                }
            }
        }
    }

    // --- FILTERING ALGORITHMS ---

    public void performPruning(double UB) throws ContradictionException {
        //System.out.println("--- CALL TO IMPROVED FILTERING ---");
        double filteringValue = UB - treeCost;
        if (filteringValue < 0) {
            throw new UnsupportedOperationException("Lower bound is greater than the upper bound");
        }
        // DEBUG
        //boolean ok = checkSolution();

        // Pre-treatment: Compute reduced and replacement costs while creating constraints related to edges in G
        if (configOptions.mode != configOptions.Mode.SIMPLE_RELAXED) {
            for (int i = 0; i < n * n; i++) {
                if (g.isArcOrEdge(i / n, i % n) && !propHK.isMandatory(i / n, i % n)) {
                    edgeToCycleOfEdges.get(i).clear();
                }
            }
            addOneNodeEdges();
        }

        computeRepCosts();
        int numberOfEdges = g.getNumberOfEdges();

        reset();
        // Main loop on all non-mandatory edges
        for (int i = 0; i < n; i++) {
            ISetIterator iter = g.getNeighOf(i).newIterator();
            while (iter.hasNext()) {
                int j = iter.next();
                if (i < j && !propHK.isMandatory(i, j)) {
                    // (i, j) is the considered edge
                    //System.out.println("*Check (" + i + ", " + j + ")*");
                    currentObjective = filteringValue - getRepCost(i, j);
                    if (checkFiltering(i, j, currentObjective, false)) continue; // Initial check

                    // Check if improvement is possible
                    for (int node = 0; node < n; node++) {
                        currentLagrangianModifications[node] = 0;
                    }

                    // SIMPLE ALGORITHM
                    simpleAlgorithm(i, j);

                    if (checkFiltering(i, j, currentObjective, true)) continue;

                    // ALPHA-SETS ALGORITHM
                    if (configOptions.mode == configOptions.Mode.HYBRID && numberOfEdges < 2 * n) {
                        alphaSetsAlgorithm(i, j);
                    }
                }
            }
        }

        // Filter edges
        prune();
        if (additionalFiltering > 0) {
            //System.out.println("Add filtering = " + additionalFiltering);
        }

        //DEBUG
        //assert !ok || checkSolution();
    }

    private void reset() {
        for (int node = 0; node < n; node++) {
            nodeToIncreaseValue[node] = -1;
            nodeToDecreaseValue[node] = -1;
        }
        edgesToEnforce.clear();
        edgesToRemove.clear();
        additionalFiltering = 0;
    }

    private boolean checkFiltering(int i, int j, double value, boolean addFiltering) {

        if (i == 0 && Tree.edgeExists(i, j)) {
            //System.out.println("Not filtered by CHOCO -> Skip");
            return true;    // The 1-edges in 1-tree are not filtered by CHOCO
        }

        if (value < 0) {
            if (Tree.edgeExists(i, j)) {
                edgesToEnforce.push(i * n + j);
            }
            else {
                edgesToRemove.push(i * n + j);
            }
            if (addFiltering) additionalFiltering++;
            return true;
        }
        return false;
    }

    private void prune() throws ContradictionException {
        for (int edge : edgesToEnforce) {
            propHK.enforce(edge / n, edge % n);
        }
        for (int edge : edgesToRemove) {
            propHK.remove(edge / n, edge % n);
        }
    }

    // --- SIMPLE ALGORITHM ---
    private void simpleAlgorithm(int i, int j) {
        int rep = getRepEdge(i, j);
        assert rep != -1;
        int k = rep / n;
        int l = rep % n;
        if (Tree.edgeExists(i, j)) {
            if (i != k && i != l && Tree.getNeighOf(i).size() <= 2) {
                double v = -getPossibleDecreaseValue(i, j, k, l);
                assert v <= 0;
                currentLagrangianModifications[i] = v;
                double oldObjective = currentObjective;
                currentObjective -= (v * (Tree.getNeighOf(i).size() - 2) - v);
                assert  currentObjective <= oldObjective;
            }
            if (currentObjective < 0) return;
            if (j != k && j != l && Tree.getNeighOf(j).size() <= 2) {
                double v = -getPossibleDecreaseValue(j, i, k, l);
                assert v <= 0;
                currentLagrangianModifications[j] = v;
                double oldObjective = currentObjective;
                currentObjective -= (v * (Tree.getNeighOf(j).size() - 2) - v);
                assert  currentObjective <= oldObjective;
            }
        }
        else {
            if (i != k && i != l && Tree.getNeighOf(i).size() >= 2) {
                double v = getPossibleIncreaseValue(i, j, k, l);
                assert v >= 0;
                currentLagrangianModifications[i] = v;
                double oldObjective = currentObjective;
                currentObjective -= (v * (Tree.getNeighOf(i).size() - 2) + v);
                assert  currentObjective <= oldObjective;
            }
            if (currentObjective < 0) return;
            if (j != k && j != l && Tree.getNeighOf(j).size() >= 2) {
                double v = getPossibleIncreaseValue(j, i, k, l);
                assert v >= 0;
                currentLagrangianModifications[j] = v;
                double oldObjective = currentObjective;
                currentObjective -= (v * (Tree.getNeighOf(j).size() - 2) + v);
                assert  currentObjective <= oldObjective;
            }
        }
    }

    // (i, j) is the considered edge while we check if lambda_i could be decreased.
    // (k, l) is the replacement edge of (i, j)
    private double getPossibleDecreaseValue(int i, int j, int k, int l) {
        // Find the minimal reduced cost of edges adjacent to i (if not already computed)
        if (nodeToDecreaseValue[i] == -1) {
            ISet treeNei = Tree.getNeighOf(i);
            ISet graphNei = g.getNeighOf(i);
            double minRedCost = Double.MAX_VALUE;
            for (int adj : graphNei) {
                if (!treeNei.contains(adj)) {
                    double redCost = getRepCost(i, adj);
                    if (redCost < minRedCost) {
                        minRedCost = redCost;
                    }
                }
            }
            minRedCost = Math.floor(minRedCost * 1000) / 1000; // For numerical reasons
            assert minRedCost + 0.001 > 0;
            nodeToDecreaseValue[i] = minRedCost;
        }

        // Additionnal constraint: (k, l) must stay the replacement edge of (i, j) [only if j is not node One]
        double constraint = Double.MAX_VALUE;
        if (j != 0) {
            // RELAXED VERSION
            if (configOptions.mode == configOptions.Mode.SIMPLE_RELAXED) {
                for (int adj : g.getNeighOf(i)) {
                    if (!Tree.getNeighOf(i).contains(adj) && distMatrix[k][l] <= distMatrix[i][adj]) {
                        constraint = Math.min(constraint, distMatrix[i][adj] - distMatrix[k][l]);
                    }
                }
            }
            // COMPLETE VERSION
            else {
                for (int edge : edgeToCycleOfEdges.get(i < j ? i * n + j : j * n + i)) {
                    if (edge / n == i || edge % n == i) {   // edge is in the cut-set of (i, j) and adjacent to i
                        constraint = Math.min(constraint, costs[edge] - distMatrix[k][l]);
                    }
                }
            }
        }

        return Math.min(nodeToDecreaseValue[i], constraint);
    }

    // (i, j) is the considered edge while we check if lambda_i could be increased.
    // (k, l) is the support edge of (i, j)
    private double getPossibleIncreaseValue(int i, int j, int k, int l) {
        // Find the minimal replacement cost of edges adjacent to i (if not already computed)
        if (nodeToIncreaseValue[i] == -1) {
            ISet treeNei = Tree.getNeighOf(i);
            double minRepCost = Double.MAX_VALUE;
            for (int adj : treeNei) {
                if (!propHK.isMandatory(i, adj)) {
                    double repCost = getRepCost(i, adj);
                    if (repCost < minRepCost) {
                        minRepCost = repCost;
                    }
                }
            }
            minRepCost = Math.floor(minRepCost * 1000) / 1000; // For numerical reasons
            assert minRepCost + 0.001 > 0;
            nodeToIncreaseValue[i] = minRepCost;
        }

        // Additionnal constraint: (k, l) must stay the support edge of (i, j) [only if j is not node One]
        double constraint = Double.MAX_VALUE;
        if (j != 0) {
            // RELAXED VERSION
            if (configOptions.mode == configOptions.Mode.SIMPLE_RELAXED) {
                for (int adj : Tree.getNeighOf(i)) {
                    if (!propHK.isMandatory(i, adj) && distMatrix[k][l] >= distMatrix[i][adj]) {
                        constraint = Math.min(constraint, distMatrix[k][l] - distMatrix[i][adj]);
                    }
                }
            }
            // COMPLETE VERSION
            else {
                for (int edge : edgeToCycleOfEdges.get(i < j ? i * n + j : j * n + i)) {
                    if ((edge / n == i || edge % n == i) && !propHK.isMandatory(edge / n, edge % n)) {
                        // edge is in the cycle of (i, j), not mandatory and adjacent to i
                        constraint = Math.min(constraint, distMatrix[k][l] - costs[edge]);
                        break;
                    }
                }
            }
        }

        return Math.min(nodeToIncreaseValue[i], constraint);
    }

    // --- ALPHA-SETS ALGORITHM ---

    private void alphaSetsAlgorithm(int i, int j) {
        alphaSetsAlgorithmReset();
        ArrayDeque<Integer> initialChoices = initialize(i, j);
        //System.out.println("Initial constraints:" + numberInitialConstraints);
        if (initialChoices.size() == 0) return;

        int numberIterations = 0;
        for (int limit = 1; limit <= depthLimit; limit++) {
            // Reset search from first level
            //System.out.println("LIMIT = " + limit);
            potentialChoices = initialChoices.clone();
            if (limit != 1) resetAlphaSet();
            //System.out.println("Number of constraints in list:" + listOfConstraints.size());
            for (; numberIterations < maxNumberIterations; numberIterations++) {
                //System.out.println("ITERATION = " + numberIterations);
                double deltaValue = findAlphaSet(limit);
                if (deltaValue < 0.001) break; // No alpha-set found with this depth limit
                double increaseValue = computeIncreaseValue(deltaValue);
                //System.out.println("Increase value=" + increaseValue);
                currentObjective = currentObjective - increaseValue;
                //System.out.println("New obj=" + currentObjective);
                if (checkFiltering(i, j, currentObjective, true)) {
                    return;
                }
                if (numberIterations != maxNumberIterations - 1) {     // Undo last choice
                    //System.out.println("Update for next iteration...");
                    for (int choice : choices) {
                        int node = choice > 0 ? choice : -choice;
                        currentLagrangianModifications[node] += choice > 0 ? deltaValue : -deltaValue;
                    }
                    undoLastChoice(numberAddedToList);
                }
            }
        }
    }

    private double findAlphaSet(int depthLimit) {
        while (choices.size() > 0 || potentialChoices.size() > 0) {
            //System.out.println("Potential choices: " + potentialChoices.toString());
            if (potentialChoices.size() > 0) {
                // Make a choice
                int c = potentialChoices.pop();
                choices.push(c);
                //System.out.println("Choice=" + c);
                //System.out.println("Choices: " + choices.toString());
                isInChoices.set(c > 0 ? c : -c);
                numberAddedToList = 0;
                if (c > 0) {    // Increasing node |c|
                    increaseNode(c);
                }
                else {          // Decreasing node |c|
                    decreaseNode(-c);
                }
                //System.out.println("Number added constraints: " + numberAddedToList);
                //System.out.println("Number of constraints in list: " + listOfConstraints.size());

                // Find maximum increase value
                OneTreeConstraint restrainingConstraint = obtainRestriction();
                if (restrainingConstraint == null) {
                    return -propHK.getMinArcVal();
                }
                else {
                    //System.out.println("Restraining constraint: " + restrainingConstraint.toString());
                    double deltaValue = restrainingConstraint.getMaxDelta(currentLagrangianModifications, choices);
                    //System.out.println("DELTA=" + deltaValue);
                    if (deltaValue > 0.001) {    // Greater than 0?
                        return deltaValue;
                    }
                }

                // Didn't find an alpha-set (yet)
                if (choices.size() < depthLimit) {
                    // Go deeper. Determine potential choices for next level
                    //System.out.println("Going deeper");
                    stackOfPotentialChoices.push(potentialChoices);
                    stackNumberAddedToList.push(numberAddedToList);
                    potentialChoices = determinePotentialChoices(restrainingConstraint);
                }
                else {
                    undoLastChoice(numberAddedToList);
                }
            }
            else {      // Backtrack search
                //System.out.println("Backtrack!");
                undoLastChoice(stackNumberAddedToList.pop());
                potentialChoices = stackOfPotentialChoices.pop();
            }
        }
        return 0;
    }

    private double computeIncreaseValue(double deltaValue) {
        double increaseValue = 0;
        for (int choice : choices) {
            int node = choice > 0 ? choice : -choice;
            double v = choice > 0 ? deltaValue : -deltaValue;
            increaseValue += v * (Tree.getNeighOf(node).size() - 2);
            if (reducedCostConstraint.inPositiveNodes(node)) {
                assert choice < 0;
                increaseValue -= v;
            }
            if (reducedCostConstraint.inNegativeNodes(node)) {
                assert choice > 0;
                increaseValue += v;
            }
        }
        assert increaseValue >= 0;
        return increaseValue;
    }

    private void alphaSetsAlgorithmReset() {
        numberInitialConstraints = 0;
        for (int i = listOfConstraints.size(); i > 0; i--) {
            removeLastConstraint();
        }
        assert listOfConstraints.isEmpty();
        choices.clear();
        isInChoices.clear();
        stackOfPotentialChoices.clear();
        stackNumberAddedToList.clear();
    }

    private void resetAlphaSet() {
        for (int i = listOfConstraints.size(); i > numberInitialConstraints; i--) {
            removeLastConstraint();
        }
        assert listOfConstraints.size() == numberInitialConstraints;
        choices.clear();
        isInChoices.clear();
        stackOfPotentialChoices.clear();
        stackNumberAddedToList.clear();
    }

    private ArrayDeque<Integer> initialize(int i, int j) {
        assert numberInitialConstraints == 0;
        assert listOfConstraints.isEmpty();
        int rep = getRepEdge(i, j);
        assert rep != -1;
        int k = rep / n;
        int l = rep % n;
        if (Tree.edgeExists(i, j)) {
            // Ensure that (k, l) is the minimum edge in the cut-set of (i, j)
            for (int relatedEdge : edgeToCycleOfEdges.get(i * n + j)) {
                int p = relatedEdge / n;
                int q = relatedEdge % n;
                if (!(k == p && l == q || k == q && l == p)) {
                    OneTreeConstraint initialConstraint = oneTreeConstraintFactory.create(k, l, p, q, distMatrix[p][q] - distMatrix[k][l]);
                    addConstraint(initialConstraint);
                    numberInitialConstraints++;
                }
            }
            reducedCostConstraint.set(i, j, k, l, 0);
        }
        else {
            // Ensure that (k, l) is the maximum edge on the cycle formed by (i, j)
            for (int relatedEdge : edgeToCycleOfEdges.get(i * n + j)) {
                int p = relatedEdge / n;
                int q = relatedEdge % n;
                if (!(k == p && l == q || k == q && l == p)) {
                    OneTreeConstraint initialConstraint = oneTreeConstraintFactory.create(p, q, k, l, distMatrix[k][l] - distMatrix[p][q]);
                    addConstraint(initialConstraint);
                    numberInitialConstraints++;
                }
            }
            reducedCostConstraint.set(k, l, i, j, 0);
        }

        // Find initial potential choices given by the reduced cost
        //TODO IJCAI-2021: Some increasing choices are not considered. Missing some rare cases.
        return determinePotentialChoices(reducedCostConstraint);
    }

    private void addConstraint(OneTreeConstraint constraint) {
        listOfConstraints.push(constraint);
        numberAddedToList++;
    }

    private void removeLastConstraint() {
        OneTreeConstraint constraint = listOfConstraints.pop();
        oneTreeConstraintFactory.dispose(constraint);
    }

    private ArrayDeque<Integer> determinePotentialChoices(OneTreeConstraint restrainingConstraint) {
        ArrayDeque<Integer> potentialChoices = new ArrayDeque<>(4);
        for (int node : restrainingConstraint.positiveNodes) {
            //TODO IJCAI-2021: If the node is in {i, j, k, l}, the condition should be changed. Missing some rare cases.
            if (Tree.getNeighOf(node).size() <= 2 && !isInChoices.get(node) && !restrainingConstraint.inNegativeNodes(node) && !reducedCostConstraint.inNegativeNodes(node)) {
                potentialChoices.push(-node);
            }
        }
        for (int node : restrainingConstraint.negativeNodes) {
            //TODO IJCAI-2021: If the node is in {i, j, k, l}, the condition should be changed. Missing some rare cases.
            if (Tree.getNeighOf(node).size() >= 2 && !isInChoices.get(node) && !restrainingConstraint.inPositiveNodes(node) && !reducedCostConstraint.inPositiveNodes(node)) {
                potentialChoices.push(node);
            }
        }
        return potentialChoices;
    }

    private void increaseNode(int node) {
        assert (node > 0 && node < n);
        for (int k : Tree.getNeighOf(node)) {
            if (!propHK.isMandatory(node, k)) {
                // Add constraints related to (node, k)
                for (int edgeInCut : edgeToCycleOfEdges.get(node < k ? node * n + k : k * n + node)) {
                    int i = edgeInCut / n;
                    int j = edgeInCut % n;
                    OneTreeConstraint constraint = oneTreeConstraintFactory.create(node, k, i, j, distMatrix[i][j] - distMatrix[node][k]);
                    addConstraint(constraint);
                }
            }
        }
    }

    private void decreaseNode(int node) {
        assert (node > 0 && node < n);
        for (int k : g.getNeighOf(node)) {
            if (!Tree.edgeExists(node, k)) {
                // Add constraints related to (node, k)
                for (int edgeInCycle : edgeToCycleOfEdges.get(node < k ? node * n + k : k * n + node)) {
                    int i = edgeInCycle / n;
                    int j = edgeInCycle % n;
                    OneTreeConstraint constraint = oneTreeConstraintFactory.create(i, j, node, k, distMatrix[node][k] - distMatrix[i][j]);
                    addConstraint(constraint);
                }
            }
        }
    }

    /**
     * @return The restraining constraint in the list. Returns null if no restriction was found.
     */
    private OneTreeConstraint obtainRestriction() {
        OneTreeConstraint restrainingConstraint = null;
        double minValue = Double.MAX_VALUE;
        // Find the minimum maxDelta (i.e. the maximum possible value delta could take)
        for (OneTreeConstraint constraint : listOfConstraints) {
            double maxDelta = constraint.getMaxDelta(currentLagrangianModifications, choices);
            assert maxDelta == -1 || maxDelta + 0.001 >= 0;
            if (maxDelta != -1 && maxDelta < minValue) {
                restrainingConstraint = constraint;
                minValue = maxDelta;
            }
        }
        return restrainingConstraint;
    }

    private void undoLastChoice(int numberConstraints) {
        //System.out.println("Undo last choice");
        int choice = choices.pop();
        isInChoices.clear(choice > 0 ? choice : -choice);
        // Remove last added constraints
        int initialListSize = listOfConstraints.size();
        assert initialListSize >= numberConstraints;
        for (int i = 1; i <= numberConstraints; i++) {
            removeLastConstraint();
        }
        assert listOfConstraints.size() == initialListSize - numberConstraints;
        //System.out.println("Number of constraints: " + listOfConstraints.size());
    }
}
