// Raphaël Boudreault/Improved CP-Based Lagrangian Relaxation Approach with an Application to the TSP (IJCAI 2021)

package org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation.improvedAlgorithms;

import java.util.ArrayDeque;

/**
 * Used to model a lagrangian constraint of the form lambda_a + lambda_b - lambda_c - lambda_d <= w(c,d) - w(a,b).
 * This constraint is created with OneTreeConstraint(a, b, c, d, w(c,d) - w(a,b)).
 */
public class OneTreeConstraint {
    // Attributes
    int[] positiveNodes;
    int[] negativeNodes;
    double constant;

    // Constructor
    public OneTreeConstraint() {
        positiveNodes = new int[]{-1, -1};
        negativeNodes = new int[]{-1, -1};
        constant = -1;
    }

    public OneTreeConstraint(int pos1, int pos2, int neg1, int neg2, double c) {
        assert pos1 >= 0 && pos2 >= 0 && neg1 >= 0 && neg2 >= 0;
        assert c >= 0;
        positiveNodes = new int[]{pos1, pos2};
        negativeNodes = new int[]{neg1, neg2};
        constant = c;
    }

    // Methods
    public void set(int pos1, int pos2, int neg1, int neg2, double c) {
        assert pos1 >= 0 && pos2 >= 0 && neg1 >= 0 && neg2 >= 0;
        assert c >= 0;
        positiveNodes[0] = pos1;
        positiveNodes[1] = pos2;
        negativeNodes[0] = neg1;
        negativeNodes[1] = neg2;
        constant = c;
    }

    public boolean inPositiveNodes(int node) {
        return node == positiveNodes[0] || node == positiveNodes[1];
    }

    public boolean inNegativeNodes(int node) {
        return node == negativeNodes[0] || node == negativeNodes[1];
    }

    // Used by the improved filtering algorithm
    public double getMaxDelta(double[] currentLagrangianModifications, ArrayDeque<Integer> currentPathChoices) {
        // Find delta coefficient
        int deltaCoefficient = 0;
        for (int choice : currentPathChoices) {    //TODO IJCAI-2021: Use the sign to check at most 4 values
            boolean increase = choice > 0;
            int node = increase ? choice : -choice;
            if (inPositiveNodes(node)) {
                deltaCoefficient = increase ? deltaCoefficient + 1 : deltaCoefficient - 1;
            }
            if (inNegativeNodes(node)) {
                deltaCoefficient = increase ? deltaCoefficient - 1 : deltaCoefficient + 1;
            }
        }

        if (deltaCoefficient <= 0) {
            return -1; // No upper bound on the value of delta (infinity)
        }
        else {
            double v = constant + currentLagrangianModifications[negativeNodes[0]] + currentLagrangianModifications[negativeNodes[1]] - currentLagrangianModifications[positiveNodes[0]] - currentLagrangianModifications[positiveNodes[1]];
            return v / deltaCoefficient;
        }
    }

    @Override
    public String toString() {
        return positiveNodes[0] + " + " + positiveNodes[1] + " - " + negativeNodes[0] + " - " + negativeNodes[1] + " <= " + constant;
    }
}

class OneTreeConstraintFactory {

    private final ArrayDeque<OneTreeConstraint> vectorOfConstraints;

    public OneTreeConstraintFactory() {
        vectorOfConstraints = new ArrayDeque<>();
    }

    public OneTreeConstraint create(int pos1, int pos2, int neg1, int neg2, double c) {
        if (!vectorOfConstraints.isEmpty()) {
            OneTreeConstraint constraint = vectorOfConstraints.pop();
            constraint.set(pos1, pos2, neg1, neg2, c);
            return constraint;
        }
        else {
            return new OneTreeConstraint(pos1, pos2, neg1, neg2, c);
        }
    }

    public void dispose(OneTreeConstraint constraint) {
        vectorOfConstraints.add(constraint);
    }

}
