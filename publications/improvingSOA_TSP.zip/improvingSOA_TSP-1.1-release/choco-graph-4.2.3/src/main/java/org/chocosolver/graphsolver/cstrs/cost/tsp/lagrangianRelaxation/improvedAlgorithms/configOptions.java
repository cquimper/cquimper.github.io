// Raphaël Boudreault/Improved CP-Based Lagrangian Relaxation Approach with an Application to the TSP (IJCAI 2021)

package org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation.improvedAlgorithms;

import org.json.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

import static java.nio.file.Files.*;

public class configOptions {

    public enum Mode {CHOCO, SIMPLE_RELAXED, SIMPLE_COMPLETE, HYBRID}

    public static String configName;
    public static Mode mode;
    public static int depthLimit;
    public static int numberIterations;

    public configOptions(String JSONfile) {
        String content = null;
        try {
            content = readString(Paths.get(JSONfile), StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONObject obj = new JSONObject(content);

        try {
            configName = obj.getString("configName");
            String modeString = obj.getString("mode");
            mode = Mode.valueOf(modeString);
            if (mode == Mode.HYBRID) {
                depthLimit = obj.getInt("depthLimit");
                numberIterations = obj.getInt("numberIterations");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void printConfig() {
        System.out.println("--- " + configName + " ---");
        if (mode == Mode.HYBRID) {
            System.out.println("Depth limit: " + depthLimit);
            System.out.println("Number of iterations: " + numberIterations);
        }
    }


}
