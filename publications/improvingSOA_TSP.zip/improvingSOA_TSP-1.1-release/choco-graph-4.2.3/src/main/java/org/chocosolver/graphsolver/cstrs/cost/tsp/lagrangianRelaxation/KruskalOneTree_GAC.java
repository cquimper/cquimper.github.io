/*
 * Copyright (c) 1999-2014, Ecole des Mines de Nantes
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Ecole des Mines de Nantes nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Raphaël Boudreault/Improved CP-Based Lagrangian Relaxation Approach with an Application to the TSP (IJCAI 2021)

package org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation;

import org.chocosolver.graphsolver.cstrs.cost.GraphLagrangianRelaxation;
import org.chocosolver.graphsolver.cstrs.cost.trees.lagrangianRelaxation.KruskalMSTFinder;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.util.objects.graphs.UndirectedGraph;
import org.chocosolver.util.objects.setDataStructures.ISet;
import java.util.Arrays;

public class KruskalOneTree_GAC extends KruskalMSTFinder {

	//***********************************************************************************
	// VARIABLES
	//***********************************************************************************

	protected int min1, min2;
	protected int[][] map;
	private double[][] marginalCosts;
	private int[][] marginalEdge;
	private int[] fifo;

	//***********************************************************************************
	// CONSTRUCTORS
	//***********************************************************************************

	public KruskalOneTree_GAC(int nbNodes, GraphLagrangianRelaxation propagator) {
		super(nbNodes, propagator);
		map = new int[n][n];
		marginalCosts = new double[n][n];
		marginalEdge = new int[n][n];
		fifo = new int[n];
	}

	//***********************************************************************************
	// METHODS
	//***********************************************************************************

	public void computeMST(double[][] costs, UndirectedGraph graph) throws ContradictionException {
		super.computeMST(costs, graph);
		add0Node();
	}

	// Use only if costs changed, but not the MST
	public void updateMST(double[][] costs) throws ContradictionException {
		//System.out.println("Before: " + Arrays.toString(sortedMSTArcs));
		super.updateMST(costs);
		update0Nodes();
		//System.out.println("After:  " + Arrays.toString(sortedMSTArcs));
	}

	public void performPruning(double UB) throws ContradictionException {
		double delta = UB - treeCost;
		if (delta < 0) {
			throw new UnsupportedOperationException("mst>ub");
		}
		prepareMandArcDetection();
		if (selectRelevantArcs(delta)) {
			lca.preprocess(cctRoot, ccTree);
			pruning(0, delta);
		}
	}

	// stable : If true, keep the order of sortedArcs from last MST computation
	protected void sortArcs(boolean stable) {
		int size = 0;
		Tree.getNeighOf(0).clear();
		for (int i = 1; i < n; i++) {
			p[i] = i;
			rank[i] = 0;
			ccTp[i] = i;
			Tree.getNeighOf(i).clear();
			ccTree.removeNode(i);
			ccTree.addNode(i);
			size += g.getNeighOf(i).size();
		}
		size -= g.getNeighOf(0).size();
		assert size % 2 == 0;
		size /= 2;
		ISet nei;
		int idx = 0;
		for (int i = 1; i < n; i++) {
			nei = g.getNeighOf(i);
			for (int j : nei) {
				if (i < j) {
					if (!stable) {
						sortedArcs[idx] = i * n + j;
					}
					costs[i * n + j] = distMatrix[i][j];
					idx++;
				}
			}
		}
		for (int i = n; i < ccN; i++) {
			ccTree.removeNode(i);
		}
		sorter.sort(sortedArcs, size, comparator);
		int v;
		activeArcs.clear();
		activeArcs.set(0, size);
		for (idx = 0; idx < size; idx++) {
			v = sortedArcs[idx];
			indexOfArc[v / n][v % n] = idx;
		}
	}

	protected void pruning(int fi, double delta) throws ContradictionException {
		ISet nei = g.getNeighOf(0);
		for (int i : nei) {
			if (i != min1 && i != min2) {
				if (distMatrix[0][i] - distMatrix[0][min2] > delta) {
					propHK.remove(0, i);
				}
			}
		}

		for (int arc = activeArcs.nextSetBit(0); arc >= 0; arc = activeArcs.nextSetBit(arc + 1)) {
			int i = sortedArcs[arc] / n;
			int j = sortedArcs[arc] % n;
			if (!Tree.edgeExists(i, j)) {
				marginalCosts[i][j] = costs[i * n + j] - ccTEdgeCost[lca.getLCA(i, j)];
				if (marginalCosts[i][j] > delta) {
					activeArcs.clear(arc);
					propHK.remove(i, j);
				} else {
					markTreeEdges(ccTp, i, j);
				}
			}
		}
		for (int i = 1; i < n; i++) {
			nei = Tree.getNeighOf(i);
			for (int j : nei) {
				if (i < j) {
					if (map[i][j] == -1 || propHK.isMandatory(i, j)) {
						marginalCosts[i][j] = -propHK.getMinArcVal();
					} else {
						marginalCosts[i][j] = costs[map[i][j]] - costs[i * n + j];
					}
					if (marginalCosts[i][j] > delta) {
						propHK.enforce(i, j);
					}
				}
			}
		}
	}

	protected boolean selectRelevantArcs(double delta) throws ContradictionException {
		return selectAndCompress(delta);
	}

	protected boolean selectAndCompress(double delta) throws ContradictionException {
		// Trivially no inference
		int idx = activeArcs.nextSetBit(0);
		// Maybe interesting
		while (idx >= 0 && costs[sortedArcs[idx]] - maxTArc <= delta) {
			idx = activeArcs.nextSetBit(idx + 1);
		}
		// Trivially infeasible arcs
		while (idx >= 0) {
			if (!Tree.edgeExists(sortedArcs[idx] / n, sortedArcs[idx] % n)) {
				propHK.remove(sortedArcs[idx] / n, sortedArcs[idx] % n);
				activeArcs.clear(idx);
			}
			idx = activeArcs.nextSetBit(idx + 1);
		}
		//contract ccTree
		cctRoot++;
		int newNode = cctRoot;
		ccTree.addNode(newNode);
		ccTEdgeCost[newNode] = propHK.getMinArcVal();
		for (int i : ccTree.getNodes()) {
			if (ccTree.getPredOf(i).isEmpty()) {
				if (i != cctRoot) {
					ccTree.addArc(cctRoot, i);
				}
			}
		}
		return true;
	}

	//***********************************************************************************
	// Kruskal's
	//***********************************************************************************

	@Override
	protected int addMandatoryArcs() throws ContradictionException {
		int from, to, rFrom, rTo, arc;
		int tSize = 0;
		double val = propHK.getMinArcVal();
		for (int i = ma.size() - 1; i >= 0; i--) {
			arc = ma.get(i);
			from = arc / n;
			to = arc % n;
			if (from != 0 && to != 0) {
				rFrom = FIND(from);
				rTo = FIND(to);
				if (rFrom != rTo) {
					LINK(rFrom, rTo);
					Tree.addEdge(from, to);
					sortedMSTArcs[tSize] = arc;
					updateCCTree(rFrom, rTo, val);
					treeCost += costs[arc];
					tSize++;
				} else {
					propHK.contradiction();
				}
			}
		}
		return tSize;
	}

	protected void connectMST(int treeSize) throws ContradictionException {
		int from, to, rFrom, rTo;
		int idx = activeArcs.nextSetBit(0);
		minTArc = -propHK.getMinArcVal();
		maxTArc = propHK.getMinArcVal();
		double cost;
		int tSize = treeSize;
		while (tSize < n - 2) {
			if (idx < 0) {
				propHK.contradiction();
			}
			from = sortedArcs[idx] / n;
			to = sortedArcs[idx] % n;
			rFrom = FIND(from);
			rTo = FIND(to);
			if (rFrom != rTo) {
				LINK(rFrom, rTo);
				Tree.addEdge(from, to);
				sortedMSTArcs[tSize] = sortedArcs[idx];
				cost = costs[sortedArcs[idx]];
				updateCCTree(rFrom, rTo, cost);
				if (cost > maxTArc) {
					maxTArc = cost;
				}
				if (cost < minTArc) {
					minTArc = cost;
				}
				treeCost += cost;
				tSize++;
			}
			idx = activeArcs.nextSetBit(idx + 1);
		}
	}

	private void add0Node() throws ContradictionException {
		ISet nei = g.getNeighOf(0);
		min1 = -1;
		min2 = -1;
		boolean b1 = false, b2 = false;
		for (int j : nei) {
			if (!b1) {
				if (min1 == -1) {
					min1 = j;
				}
				if (distMatrix[0][j] < distMatrix[0][min1]) {
					min2 = min1;
					min1 = j;
				}
				if (propHK.isMandatory(0, j)) {
					if (min1 != j) {
						min2 = min1;
					}
					min1 = j;
					b1 = true;
				}
			}
			if (min1 != j && !b2) {
				if (min2 == -1 || distMatrix[0][j] < distMatrix[0][min2]) {
					min2 = j;
				}
				if (propHK.isMandatory(0, j)) {
					min2 = j;
					b2 = true;
				}
			}
		}
		if (min1 == min2) {
			throw new UnsupportedOperationException();
		}
		if (min1 == -1 || min2 == -1) {
			propHK.contradiction();
		}
		if (!propHK.isMandatory(0, min1)) {
			maxTArc = Math.max(maxTArc, distMatrix[0][min1]);
		}
		if (!propHK.isMandatory(0, min2)) {
			maxTArc = Math.max(maxTArc, distMatrix[0][min2]);
		}
		Tree.addEdge(0, min1);
		Tree.addEdge(0, min2);
		treeCost += distMatrix[0][min1] + distMatrix[0][min2];
	}

	private void update0Nodes() {
		assert min1 != -1 && min2 != -1 && min1 != min2;

		// Check if order has switched
		if (!propHK.isMandatory(0, min1) && !propHK.isMandatory(0, min2)) {
			if (distMatrix[0][min2] < distMatrix[0][min1]) {
				int oldMin2 = min2;
				min2 = min1;
				min1 = oldMin2;
			}
		}

		// Add 0-edges to tree
		Tree.addEdge(0, min1);
		Tree.addEdge(0, min2);
		treeCost += distMatrix[0][min1] + distMatrix[0][min2];
	}

	//***********************************************************************************
	// Detecting mandatory arcs
	//***********************************************************************************

	protected void prepareMandArcDetection() {
		// RECYCLING ccTp is used to model the compressed path
		ISet nei;
		for (int i = 0; i < n; i++) {
			ccTp[i] = -1;
		}
		useful.clear();
		useful.set(0);
		int k = 1;
		useful.set(k);
		ccTp[k] = k;
		int first = 0;
		int last = first;
		fifo[last++] = k;
		while (first < last) {
			k = fifo[first++];
			nei = Tree.getNeighOf(k);
			for (int s : nei) {
				if (ccTp[s] == -1) {
					ccTp[s] = k;
					map[s][k] = map[k][s] = -1;
					if (!useful.get(s)) {
						fifo[last++] = s;
						useful.set(s);
					}
				}
			}
		}
	}

	protected void markTreeEdges(int[] next, int i, int j) {
		int rep = i * n + j;
		if (i == 0) {
			throw new UnsupportedOperationException();
		}
		if (next[i] == next[j]) {
			if (map[i][next[i]] == -1) {
				map[i][next[i]] = map[next[i]][i] = rep;
			}
			if (map[j][next[j]] == -1) {
				map[j][next[j]] = map[next[j]][j] = rep;
			}
			return;
		}
		useful.clear();
		int meeting = j;
		int tmp;
		int a;
		for (a = i; a != next[a]; a = next[a]) {
			useful.set(a);
		}
		useful.set(a);
		while (!useful.get(meeting)) {
			meeting = next[meeting];
		}
		for (int b = j; b != meeting; ) {
			tmp = next[b];
			next[b] = meeting;
			if (map[b][tmp] == -1) {
				map[b][tmp] = map[tmp][b] = rep;
			}
			b = tmp;
		}
		for (a = i; a != meeting; ) {
			tmp = next[a];
			next[a] = meeting;
			if (map[a][tmp] == -1) {
				map[a][tmp] = map[tmp][a] = rep;
			}
			a = tmp;
		}
	}

	public double getRepCost(int from, int to) {
		if (from > to) {
			return getRepCost(to, from);
		}
		return marginalCosts[from][to];
	}

	//***********************************************************************************
	// Raphaël Boudreault's improvement
	//***********************************************************************************
	public void computeRepCosts() {
		// Init
		prepareMandArcDetection();
		lca.preprocess(cctRoot, ccTree);

		// NODE 0
		// Reduced costs
		ISet nei = g.getNeighOf(0);
		for (int i : nei) {
			if (i != min1 && i != min2) {
				marginalCosts[0][i] = distMatrix[0][i] - distMatrix[0][min2];
				marginalEdge[0][i] = min2;
				assert marginalCosts[0][i] + 0.001 >= 0;
			}
		}

		// Replacement costs
		if (!propHK.isMandatory(0, min1) || !propHK.isMandatory(0, min2)) {
			if (nei.size() > 2) {
				double minCostNotOneTree = Double.MAX_VALUE;
				int minCostNode = -1;
				for (int i : nei) {
					if (i != min1 && i != min2 && distMatrix[0][i] < minCostNotOneTree) {
						minCostNotOneTree = distMatrix[0][i];
						minCostNode = i;
					}
				}
				if (!propHK.isMandatory(0, min1)) {
					marginalCosts[0][min1] = minCostNotOneTree - distMatrix[0][min1];
					assert minCostNode != -1;
					marginalEdge[0][min1] = minCostNode;
					assert marginalCosts[0][min1] + 0.001 >= 0;
				}
				if (!propHK.isMandatory(0, min2)) {
					marginalCosts[0][min2] = minCostNotOneTree - distMatrix[0][min2];
					assert minCostNode != -1;
					marginalEdge[0][min2] = minCostNode;
					assert marginalCosts[0][min2] + 0.001 >= 0;
				}
			}
			else {	// No replacement edges (should be mandatory, but not done by default)
				marginalCosts[0][min1] = -propHK.getMinArcVal();
				marginalEdge[0][min1] = -1;
				marginalCosts[0][min2] = -propHK.getMinArcVal();
				marginalEdge[0][min2] = -1;
			}
		}

		// MST
		for (int arc = activeArcs.nextSetBit(0); arc >= 0; arc = activeArcs.nextSetBit(arc + 1)) {
			int i = sortedArcs[arc] / n;
			int j = sortedArcs[arc] % n;
			if (!Tree.edgeExists(i, j)) {
				int supportEdge = sortedMSTArcs[lca.getLCA(i, j) - n];
				if (propHK.isMandatory(supportEdge / n, supportEdge % n)) { // Cycle of mandatory edges
					marginalCosts[i][j] = Double.MAX_VALUE;
					marginalEdge[i][j] = -1;
				}
				else {
					marginalCosts[i][j] = costs[i * n + j] - costs[supportEdge];
					marginalEdge[i][j] = supportEdge;
				}
				markTreeEdges(ccTp, i, j);
				assert marginalCosts[i][j] + 0.001 >= 0;
			}
		}
		for (int i = 1; i < n; i++) {
			nei = Tree.getNeighOf(i);
			for (int j : nei) {
				if (i < j) {
					if (map[i][j] == -1 || propHK.isMandatory(i, j)) {
						marginalCosts[i][j] = Double.MAX_VALUE;
					} else {
						marginalCosts[i][j] = costs[map[i][j]] - costs[i * n + j];
						marginalEdge[i][j] = map[i][j];
					}
					assert marginalCosts[i][j] + 0.001 >= 0;
				}
			}
		}
	}

	public int getRepEdge(int from, int to) {
		if (from > to) {
			return getRepEdge(to, from);
		}
		return marginalEdge[from][to];
	}

	public void setRepCost(int from, int to, double value) {
		assert value + 0.001 >= 0;
		if (from > to) {
			setRepCost(to, from, value);
		}
		marginalCosts[from][to] = value;
	}
}
