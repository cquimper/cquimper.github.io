/*
 * Copyright (c) 1999-2014, Ecole des Mines de Nantes
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Ecole des Mines de Nantes nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Raphaël Boudreault/Improved CP-Based Lagrangian Relaxation Approach with an Application to the TSP (IJCAI 2021)

package org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation;

import gnu.trove.list.array.TIntArrayList;
import org.chocosolver.graphsolver.cstrs.cost.GraphLagrangianRelaxation;
import org.chocosolver.graphsolver.cstrs.cost.trees.lagrangianRelaxation.AbstractTreeFinder;
import org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation.improvedAlgorithms.Improved_OneTree;
import org.chocosolver.graphsolver.cstrs.cost.tsp.lagrangianRelaxation.improvedAlgorithms.configOptions;
import org.chocosolver.graphsolver.variables.GraphEventType;
import org.chocosolver.graphsolver.variables.UndirectedGraphVar;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.constraints.PropagatorPriority;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.Variable;
import org.chocosolver.solver.variables.events.IntEventType;
import org.chocosolver.util.ESat;
import org.chocosolver.util.objects.graphs.UndirectedGraph;
import org.chocosolver.util.objects.setDataStructures.ISet;

/**
 * TSP Lagrangian relaxation
 * Inspired from the work of Held & Karp
 * and Benchimol et. al. (Constraints 2012)
 *
 * @author Jean-Guillaume Fages
 */
public class PropLagr_OneTree extends Propagator<Variable> implements GraphLagrangianRelaxation {

	//***********************************************************************************
	// VARIABLES
	//***********************************************************************************

	protected UndirectedGraph g;
	protected UndirectedGraphVar gV;
	protected IntVar obj;
	protected int n;
	protected int[][] originalCosts;
	protected double[][] costs;
	protected double[] HKPenalties;
	protected double totalPenalties;
	protected UndirectedGraph mst;
	protected TIntArrayList mandatoryArcsList;
	protected double step;
	protected AbstractTreeFinder HKfilter, HK, HK_improved;
	protected boolean waitFirstSol;
	protected int nbSprints;
	protected int nbIter;
	protected boolean print;

	//***********************************************************************************
	// CONSTRUCTORS
	//***********************************************************************************

	protected PropLagr_OneTree(Variable[] vars, int[][] costMatrix) {
		super(vars, PropagatorPriority.CUBIC, false);
		originalCosts = costMatrix;
		n = originalCosts.length;
		costs = new double[n][n];
		totalPenalties = 0;
		HKPenalties = new double[n];
		mandatoryArcsList = new TIntArrayList();
		nbSprints = 30;
		nbIter = 5;
		HK = new PrimOneTreeFinder(n, this);
		HKfilter = new KruskalOneTree_GAC(n, this);
		HK_improved = new Improved_OneTree(n, this);
		print = false;
	}

	public PropLagr_OneTree(UndirectedGraphVar graph, IntVar cost, int[][] costMatrix) {
		this(new Variable[]{graph, cost}, costMatrix);
		g = graph.getUB();
		gV = graph;
		obj = cost;
	}

	//***********************************************************************************
	// HK Algorithm(s)
	//***********************************************************************************

	public void propagate(int evtmask) throws ContradictionException {
		if (waitFirstSol && getModel().getSolver().getSolutionCount() == 0) {
			return;//the UB does not allow to prune
		}
		// System.out.println("--- CALL TO PROP ---");
		// initialisation
		rebuild();
		updateCostMatrix(HKPenalties);
		int lb;
		lagrangianRelaxation(); // Only one round
		/*
		do {
			lb = obj.getLB();
			lagrangianRelaxation();
		} while (lb < obj.getLB());
		 */
		//System.exit(123);
	}

	protected void lagrangianRelaxation() throws ContradictionException {
		// System.out.println("* Starting lagrangian relaxation *");
		double hkb;
		double alpha = 2;
		double beta = 0.5;
		HKfilter.computeMST(costs, g);
		hkb = HKfilter.getBound() - totalPenalties;
		mst = HKfilter.getMST();
		if (hkb - Math.floor(hkb) < 0.001) {
			hkb = Math.floor(hkb);
		}
		//System.out.println("Bound: " + hkb);
		obj.updateLowerBound((int) Math.ceil(hkb), this);
		//System.out.println("Before: M=" + gV.getNumberMandatory() + ", F=" + gV.getNumberForbidden());
		HKfilter.performPruning((double) (obj.getUB()) + totalPenalties + 0.001);
		//System.out.println("After: M=" + gV.getNumberMandatory() + ", F=" + gV.getNumberForbidden());
		for (int iter = nbIter; iter > 0; iter--) {
			// System.out.println("Iteration " + iter);
			for (int i = nbSprints; i > 0; i--) {
				HK.computeMST(costs, g);
				hkb = HK.getBound() - totalPenalties;
				//System.out.println("Sprint " + i + " : " + hkb);
				mst = HK.getMST();
				if (hkb - Math.floor(hkb) < 0.001) {
					hkb = Math.floor(hkb);
				}
				obj.updateLowerBound((int) Math.ceil(hkb), this);
				// HK.performPruning((double) (obj.getUB()) + totalPenalties + 0.001);
				//	DO NOT FILTER HERE TO SPEED UP CONVERGENCE (not always true)
				updateStep(hkb, alpha);
				HKPenalize();
				updateCostMatrix(HKPenalties);
			}
			if (configOptions.mode != configOptions.Mode.CHOCO && iter == 1) {
				HK_improved.computeMST(costs, g);
				hkb = HK_improved.getBound() - totalPenalties;
				mst = HK_improved.getMST();
			}
			else {
				HKfilter.computeMST(costs, g);
				hkb = HKfilter.getBound() - totalPenalties;
				mst = HKfilter.getMST();
			}
			if (hkb - Math.floor(hkb) < 0.001) {
				hkb = Math.floor(hkb);
			}
			//System.out.println("Bound: " + hkb);
			obj.updateLowerBound((int) Math.ceil(hkb), this);
			// System.out.println("Before: M=" + gV.getNumberMandatory() + ", F=" + gV.getNumberForbidden());
			if (configOptions.mode != configOptions.Mode.CHOCO && iter == 1) {
				//print = true;
				HK_improved.performPruning((double) (obj.getUB()) + totalPenalties + 0.001);
				//print = false;
			}
			else {
				HKfilter.performPruning((double) (obj.getUB()) + totalPenalties + 0.001);
			}
			// System.out.println("After: M=" + gV.getNumberMandatory() + ", F=" + gV.getNumberForbidden());
			updateStep(hkb, alpha);
			HKPenalize();
			updateCostMatrix(HKPenalties);
			alpha *= beta;
			beta /= 2;
		}
	}

	//***********************************************************************************
	// DETAILS
	//***********************************************************************************

	protected void rebuild() {
		mandatoryArcsList.clear();
		ISet nei;
		for (int i = 0; i < n; i++) {
			nei = gV.getMandNeighOf(i);
			for (int j : nei) {
				if (i < j) {
					mandatoryArcsList.add(i * n + j);
				}
			}
		}
	}

	protected void updateStep(double hkb, double alpha) {
		double nb2viol = 0;
		double target = obj.getUB();
		if (target - hkb < 0) {
			target = hkb + 0.1;
		}
		int deg;
		for (int i = 0; i < n; i++) {
			deg = mst.getNeighOf(i).size();
			nb2viol += (2 - deg) * (2 - deg);
		}
		if (nb2viol == 0) {
			step = 0;
		} else {
			step = alpha * (target - hkb) / nb2viol;
		}
	}

	protected void HKPenalize() {
		if (step == 0) {
			return;
		}
		int deg;
		for (int i = 0; i < n; i++) {
			deg = mst.getNeighOf(i).size();
			HKPenalties[i] += (deg - 2) * step;
			assert !(HKPenalties[i] > Double.MAX_VALUE / (n - 1) || HKPenalties[i] < -Double.MAX_VALUE / (n - 1)) :
					"Extreme-value lagrangian multipliers. Numerical issue may happen";
		}
	}

	protected void updateCostMatrix(double[] penalties) {
		ISet nei;
		double sumPenalties = 0;
		for (int i = 0; i < n; i++) {
			nei = g.getNeighOf(i);
			for (int j : nei) {
				if (i < j) {
					costs[i][j] = originalCosts[i][j] + penalties[i] + penalties[j];
					costs[j][i] = costs[i][j];
				}
			}
			sumPenalties += penalties[i];
		}
		totalPenalties = 2 * sumPenalties;
	}

	//***********************************************************************************
	// INFERENCE
	//***********************************************************************************

	public void remove(int from, int to) throws ContradictionException {
		gV.removeArc(from, to, this);
		if (print) {
			System.out.println("Removing (" + from + ", " + to + ")");
		}
	}

	public void enforce(int from, int to) throws ContradictionException {
		if (!isMandatory(from, to)) {
			mandatoryArcsList.add(from * n + to); // Update mandatory edges list during HK process
			gV.enforceArc(from, to, this);
			if (print) {
				System.out.println("Enforcing (" + from + ", " + to + ")");
			}
		}
	}

	public void contradiction() throws ContradictionException {
		fails();
	}

	//***********************************************************************************
	// PROP METHODS
	//***********************************************************************************

	@Override
	public int getPropagationConditions(int vIdx) {
		if (vIdx == 0) {
			return GraphEventType.REMOVE_ARC.getMask() + GraphEventType.ADD_ARC.getMask();
		} else {
			return IntEventType.boundAndInst();
		}
	}

	@Override
	public ESat isEntailed() {
		return ESat.TRUE;// it is just implied filtering
	}

	public double getMinArcVal() {
		return -((double) obj.getUB());
	}

	public TIntArrayList getMandatoryArcsList() {
		return mandatoryArcsList;
	}

	public boolean isMandatory(int i, int j) {
		return gV.getMandNeighOf(i).contains(j);
	}

	public void waitFirstSolution(boolean b) {
		waitFirstSol = b;
	}

	public boolean contains(int i, int j) {
		return mst == null || mst.edgeExists(i, j);
	}

	public UndirectedGraph getSupport() {
		return mst;
	}

	public double getReplacementCost(int from, int to) {
		return HKfilter.getRepCost(from, to);
	}

	public double getMarginalCost(int from, int to) {
		return HKfilter.getRepCost(from, to);
	}
}
