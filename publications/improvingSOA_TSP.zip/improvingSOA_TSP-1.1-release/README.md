[Raphaël Boudreault](https://www.linkedin.com/in/raphael-boudreault-511910197) and [Claude-Guy Quimper](http://www.ift.ulaval.ca/~quimper/). *Improved CP-Based Lagrangian Relaxation Approach with an Application to the TSP.* To appear in Proceedings of the 30th International Joint Conference on Artificial Intelligence (IJCAI-21), 2021.

## Requirements

- Apache Maven 3.6.3 or greater
- Java JDK 14 or greater

## Execute the TSP solver for one instance

1. Compile the TSP solver:
   `mvn [clean] package -DskipTests`

2. Execute the TSP solver :
   `java -jar TSP_main.jar <Instance directory> <Instance name (_.tsp)> <Path to .json config>`

- Instances (.tsp) :
  - TSPLIB instances are located in [experiments/tsplib](experiments/tsplib)
  - Random instances are located in [experiments/random_instances](experiments/random_instances)
- JSON config files (.json) are located in [experiments/configs](experiments/configs)

## Execute experiments

The CMake script [experiments/CMakeLists.txt](experiments/CMakeLists.txt) allows to execute the solver on a complete benchmark with different configs. 

CMake 3.8.2 is required.

## Code

Choco 4.0.6 & Choco 4.2.3 have been directly modified. Important modified and new files are mainly in
`choco-graph-4.2.3\src\main\java\org\chocosolver\graphsolver\cstrs\cost\tsp\lagrangianRelaxation`

