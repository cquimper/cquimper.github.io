### Expected behavior

### Actual behavior

### Minimal Working Example

Experienced with choco-solver-_*{version here}*_

```java
{your hava code here}
```
