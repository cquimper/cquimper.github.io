Each problems has :

- The soft model (.mzn)
- The MCS Reduction model (.mzn)
- The original model, slightly modified for unsatisfiability (.mzn)
- An "soft.dzn" example
- The unsatisfiable instances folder (unsat_dzn)

### Using the soft model

To use the soft model with the No Reduction technique :
Use Minizinc with the soft model, the unsat instance and the soft.dzn. All bool in the soft.dzn file should be "true" if
No Reduction is wanted.
Make sure that in "soft.dzn" the arrays have the correct size for that specific unsat instance.

Ex : for RCPSP an instance can have 30 task, than "soft_duration" must have 30 + 2 entries and "soft_ressources" must
have 30 + 2 entries each of four bool.

The output has the previous values and the new values for every correctable parameter. The CMPCS needs to be calculated
with the difference between these values.

### Using the MCS technique

First in MiniZinc use the MCS Reduction model with the unsat instance.
This will output the reduction of parameters as a list of bool, with the names "activated_X". These must be copied to
the "soft.dzn" with the names changed to "soft_X"
Second use the soft model with this edited soft.dzn.

### Using the MUS techniques

First in MinZinc use findMUS on the original model. Then fix the active_constraint_X variables in the MCS Reduction
model. false if the constraint is in the MUSes true otherwise.
Second use the MCS technique as explained previously with the active_constraint_X fixed.

For the RCPSP use the model "MCS_MUS_RCPSP.mzn" because of how the precedences constraints has been implemented.

### Other

Using the option --free-search on solvers greatly decreased solving time for all techniques.