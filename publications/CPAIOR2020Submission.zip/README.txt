The code had to be withdrawn from this web site for reasons related to the intellectual property shared with our industrial partner. We are in the process to get it evaluated so that we can share it again. For any question, please write to claude-guy.quimper@ift.ulaval.ca

Claude-Guy Quimper
July 13th, 2020
