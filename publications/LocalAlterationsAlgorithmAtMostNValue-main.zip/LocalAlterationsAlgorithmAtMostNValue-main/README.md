# LocalAlterationsAlgorithmAtMostNValue
The algorithm for the atmostnvalue constraint
To run the experiments, you must downoload choco.
We used choco 4.0.5.
The experiments to run are in the "Experiments" folder.
Many methods were implemented or were strongly inspired by Hadrien Cambazard.
