package main.AtMostNValue.SubGradient;

public enum GradientMethod {
    Harmonic,
    Geometric,
    Newton
}