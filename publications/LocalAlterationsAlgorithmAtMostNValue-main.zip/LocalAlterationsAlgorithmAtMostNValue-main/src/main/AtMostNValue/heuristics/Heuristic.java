package main.AtMostNValue.heuristics;

public enum Heuristic {
    STAND,
    COST
}
