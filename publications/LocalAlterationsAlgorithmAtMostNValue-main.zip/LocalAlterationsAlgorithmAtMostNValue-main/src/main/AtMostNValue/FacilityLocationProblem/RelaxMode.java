package main.AtMostNValue.FacilityLocationProblem;

public enum RelaxMode {
    LIN,//LINEAR
    LINS,//LINEAR STRONG
    LAG,
    LAGS,
    OTHER;
}
