
/*
 *  Random model of all different problems.
 */

#include <ilsolver/ilcint.h>
#include "Propagator/Tromp/alldiff.h"


#define CUTOFF 5

int total_not_solved;


void
testEvent( IlcInt n, IlcInt range, IlcInt flag, float prob )
{
  int  i, j, a, b, t, count;
  double p;

  IlcManager m(IlcEdit);

  IlcFloat currtime   = m.getTime();
  IlcInt   currfail   = m.getNumberOfFails();

  m.setTimeLimit( CUTOFF );

  IlcIntVarArray vars( m, n, 0, range-1 );

  for( i = 0; i < n; i++ ) {
    a = rand() % range;
    b = rand() % range;
    if( b < a ) {
      t = b;
      b = a;
      a = t;
    }
    vars[i].setRange( a, b );

    for( j = a+1; j < b; j++ ) {
      p = ((double)rand())/32767.0;
      if( p < prob ) {
        vars[i].removeValue( j );
      }
    }
  }

  switch (flag) {
  case 0: m.add( IlcAllDiff( vars, IlcWhenValue  ) ); break;
  case 1: m.add( IlcAllDiff( vars, IlcWhenRange  ) ); break;
  case 2: m.add( IlcAllDiff( vars, IlcWhenDomain ) ); break;
  case 3: m.add( IlcNewAllDiff( vars, WithOutValueRemoval ) ); break;
  case 4: m.add( IlcNewAllDiff( vars, WithValueRemoval    ) ); break;
  }

  //m.add( IlcGenerate( vars ) );
  m.add( IlcGenerate( vars, IlcChooseMinSizeInt ) );

  count = 0;
  if( m.nextSolution() ) {
    count++;
  }

  if( (m.getTime() - currtime) >= (CUTOFF - 0.01) ) {
    total_not_solved++;
  }

/*
  switch (flag) {
    case 0: printf( "Value: "  ); break;
    case 1: printf( "Range: "  ); break;
    case 2: printf( "Domain: " ); break;
    case 3: printf( "Bound: "  ); break;
    case 4: printf( "Bound++: "); break;
  }

  printf("n: %d prob: %0.2f time: %0.3f soln: %d fails: %d\n",
    n,
    prob,
    (m.getTime() - currtime),
    count,
    (m.getNumberOfFails() - currfail)
  );
  fflush( stdout );
*/

  m.end();
}

int
main( int argc, char** argv )
{
  int k, n, iterations, flag;
  float prob;

  if( argc != 5 ) {
    cerr << "Usage: random n iterations flag prob" << endl;
    exit( 0 );
  }

  n          = atoi( argv[1] );
  iterations = atoi( argv[2] );
  flag       = atoi( argv[3] );
  prob       = atof( argv[4] );

  srand(0);
  total_not_solved = 0;

  for( k = 1; k <= iterations; k++ ) {
    testEvent( n, n, flag, prob );
  }

  printf( "%0.2f: total not solved = %d\n", prob, total_not_solved );

  return 0;
}

