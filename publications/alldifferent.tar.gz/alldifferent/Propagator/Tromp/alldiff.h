
/*============================================================
 *  User defined propagator for enforcing bounds consistency
 *  on the alldiff constraint.
 */

typedef struct {
  int min, max;		// start, end of interval
  int minrank, maxrank; // rank of min & max in bounds[] of an adcsp
} interval;

enum PropType { WithOutValueRemoval, WithValueRemoval };

class IlcNewAllDiffI : public IlcConstraintI
{
  public:
    IlcNewAllDiffI( IlcManager m, IlcIntVarArray vars, PropType prop );
    ~IlcNewAllDiffI();
    void post();
    void propagate();
    void propagateValue();
  private:
    IlcIntVarArray _vars;
    IlcRevInt currentLevel;
    int lastLevel;
    PropType _prop;
    int n;
    int *t;		// tree links
    int *d;		// diffs between critical capacities
    int *h;		// hall interval links
    interval *iv;
    interval **minsorted;
    interval **maxsorted;
    int *bounds;  // bounds[1..nb] hold set of min & max in the niv intervals
                  // while bounds[0] and bounds[nb+1] allow sentinels
    int nb;
    void sortit();
    int filterlower();
    int filterupper();
};

IlcConstraint IlcNewAllDiff( IlcIntVarArray vars, PropType prop );

