/******************************************************************************
 File: alldiff.hpp

 Implementation of Mehlhorn and Sven Thiel's algorithm for Bound-Consistency
 of the all-diff constraint.

 By: Claude-Guy Quimper

 ******************************************************************************/

/*============================================================
 *  User defined propagator for enforcing bounds consistency
 *  on the alldiff constraint.
 */

typedef struct {
  int min, max;		// start, end of interval
  int minsortedrank, maxsortedrank;
} interval;

typedef struct {
  interval *iv;
  int niv;
  interval **minsorted;
  interval **maxsorted;
} adcsp;

enum PropType { WithOutValueRemoval, WithValueRemoval };

class IlcNewAllDiffI : public IlcConstraintI
{
  public:
    IlcNewAllDiffI( IlcManager m, IlcIntVarArray vars, PropType prop );
    ~IlcNewAllDiffI();
    void post();
    void propagate();
    void propagateValue();
  private:
    IlcIntVarArray _vars;
    IlcRevInt currentLevel;
    int lastLevel;
    PropType _prop;
    adcsp *ad;
    void sortit();
};

IlcConstraint IlcNewAllDiff( IlcIntVarArray vars, PropType prop );

