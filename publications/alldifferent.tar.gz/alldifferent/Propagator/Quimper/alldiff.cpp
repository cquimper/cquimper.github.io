/******************************************************************************
 File: alldiff.cpp

 Implementation of K. Mehlhorn and S. Thiel's algorithm for bounds consistency
 of the alldifferent constraint.

 By: Claude-Guy Quimper
 ******************************************************************************/

#include <ilsolver/ilcint.h>
#include <assert.h>
#include <vector>
#include "alldiff.h"


const int INCONSISTENT = 0;
const int CHANGES = 1;
const int NO_CHANGES = 2;


IlcNewAllDiffI::IlcNewAllDiffI(
  IlcManager m,
  IlcIntVarArray vars,
  PropType prop )
  : IlcConstraintI( m ), _vars( vars ), _prop( prop )
{
  int i, n;

  n = vars.getSize();

  currentLevel.setValue( m, 1 );
  lastLevel = -1;

  ad            = (adcsp     *)malloc(sizeof(adcsp));
  ad->iv        = (interval  *)calloc(n, sizeof(interval  ));
  ad->minsorted = (interval **)calloc(n, sizeof(interval *));
  ad->maxsorted = (interval **)calloc(n, sizeof(interval *));

  for( i = 0; i < n; i++ ) {
    ad->minsorted[i] = ad->maxsorted[i] = &(ad->iv[i]);
  }

  ad->niv = n;
}


IlcNewAllDiffI::~IlcNewAllDiffI()
{
  free(ad->maxsorted);
  free(ad->minsorted);
  free(ad->iv);
  free(ad);
}


ILCDEMON1(propValue, IlcNewAllDiffI*, ct)
{
  ct->propagateValue();
}


void
IlcNewAllDiffI::post()
{
  if( _prop == WithValueRemoval ) {
    _vars.whenValue(propValue(getManager(),this));
  }
  _vars.whenRangeInterval(this);
}


void
IlcNewAllDiffI::propagateValue()
{
  IlcInt i, j, l;

  i = _vars.getIndexValue();
  l = _vars[i].getValue();

  for( j = 0; j < ad->niv; j++ ) if( j != i ) {
    _vars[j].removeValue( l );
  }
}


using namespace std;

struct YNode {
  int yNode;
  struct YNode* next;
  struct YNode* prev;
};

/*
   Definition of a component in the matching graph.
*/
class Component
{
private:
  int m_root;           // Value of the left most y-node
  int m_rightmost;      // Value of the right most y-node
  int m_maxX;           // Maximal upper bound for all variables (x-nodes) in the component
  int m_yNodeCount;
  struct YNode* m_firstYNode;
  struct YNode* m_lastYNode;
  Component* m_nextComponent; // used by the component pool
public:
  Component(); // Default constructor
  Component(int _root, int _rightmost, int _maxX);
  Component(const Component& c);
  virtual ~Component();
  inline int root() const {return m_root;}
  inline int rightmost() const {return m_rightmost;}
  inline int maxX() const {return m_maxX;}
  inline const struct YNode* firstYNode() const { return m_firstYNode;}
  inline const struct YNode* lastYNode() const { return m_lastYNode;}
  inline int yNodeCount() const { return m_yNodeCount; };
  void addYNode(int yNode);
  void moveYNodesFromComponent(Component& c); // Move all y-nodes from c in constant time
  void removeAllYNodes(); // To be called by the component pool

  inline void setMaxX(int max) {m_maxX = max;}
  inline void setRightmost(int rightmost) {m_rightmost = rightmost;}
  inline void setRoot(int root) {m_root = root;}

  inline Component* nextComponent() const {return m_nextComponent;}
  inline void setNextComponent(Component* next) { m_nextComponent = next;}

  bool operator<(const Component& c) const;
  bool operator==(const Component& c) const;
};

class ComponentPool {
private:
  Component* m_components;
  YNode* m_YNodes;
public:
  ComponentPool();
  virtual ~ComponentPool();

  // Components
  Component* getComponent(int _root, int _rightmost, int _maxX);
  void releaseComponent(Component* component);

  // YNodes
  YNode* getYNode();
  void releaseYNodes(YNode* firstYNode, YNode* lastYNode);
};

/*
   Disjoint sets data structure
*/
class DisjointSets
{
private:
  int* m_elements;
public:
  DisjointSets(int size);
  virtual ~DisjointSets();

  inline void merge(int leaderA, int leaderB) {m_elements[leaderA] = leaderB;} // LeaderA set is destroyed and merged with leaderB set
  int find(int element);
};


ComponentPool componentPool;

/*
  Component default constructor
*/
Component::Component()
: m_root(0),
  m_rightmost(0),
  m_maxX(0),
  m_yNodeCount(0),
  m_firstYNode(NULL),
  m_lastYNode(NULL),
  m_nextComponent(NULL)
{
}

/*
   Component constructor
*/
Component::Component(int _root, int _rightmost, int _maxX)
  : m_root(_root),
    m_rightmost(_rightmost),
    m_maxX(_maxX),
    m_yNodeCount(0),
    m_firstYNode(NULL),
    m_lastYNode(NULL),
    m_nextComponent(NULL)
{
}

/*
  Copy constructor
*/
Component::Component(const Component& c)
  : m_root(c.m_root),
    m_rightmost(c.m_rightmost),
    m_maxX(c.m_maxX),
    m_yNodeCount(0),
    m_firstYNode(NULL),
    m_lastYNode(NULL),
    m_nextComponent(NULL)
{
  for (const struct YNode* currentNode = c.m_firstYNode; currentNode != NULL; currentNode = currentNode->next)
    addYNode(currentNode->yNode);
}

Component::~Component() {
  if (m_firstYNode != NULL)
    componentPool.releaseYNodes(m_firstYNode, m_lastYNode);
}

bool Component::operator<(const Component& c) const {
  return this < &c; // Compare pointer addresses
}

bool Component::operator==(const Component& c) const {
  return this == &c; // Compare pointer addresses
}

void Component::addYNode(int yNode) {
  if (m_firstYNode == NULL) {
    m_firstYNode = m_lastYNode = componentPool.getYNode();
    m_firstYNode->yNode = yNode;
    m_firstYNode->next = NULL;
    m_firstYNode->prev = NULL;
  }
  else {
    struct YNode* newNode = componentPool.getYNode();
    newNode->yNode = yNode;
    newNode->next = NULL;
    newNode->prev = m_lastYNode;
    m_lastYNode->next = newNode;
    m_lastYNode = newNode;
  }
  m_yNodeCount++;
}

// Move all y-nodes from c in constant time
void Component::moveYNodesFromComponent(Component& c) {
  if (c.m_firstYNode != NULL) {
    c.m_firstYNode->prev = m_lastYNode;
    m_lastYNode->next = c.m_firstYNode;
    m_lastYNode = c.m_lastYNode;
    m_yNodeCount += c.m_yNodeCount;
    c.m_firstYNode = NULL;
    c.m_lastYNode = NULL;
    c.m_yNodeCount = 0;
  }
}

void Component::removeAllYNodes() {
  if (m_firstYNode != NULL)
    componentPool.releaseYNodes(m_firstYNode, m_lastYNode);
  m_firstYNode = m_lastYNode = NULL;
  m_yNodeCount = 0;
}

ComponentPool::ComponentPool()
  : m_components(NULL),
    m_YNodes(NULL)
{
}

ComponentPool::~ComponentPool() {
  // Destroy components
  while (m_components != NULL) {
    Component* tempC = m_components->nextComponent();
    delete m_components;
    m_components = tempC;
  }

  // Important: When a component is destroyed, its y-nodes are added to the
  // pool. Therefore, the y-nodes must be destroyed after the components.

  // Destroy y-nodes
  while (m_YNodes != NULL) {
    struct YNode* temp = m_YNodes->next;
    delete m_YNodes;
    m_YNodes = temp;
  }
}

Component* ComponentPool::getComponent(int _root, int _rightmost, int _maxX) {
  Component* res;
  if (m_components == NULL) {
    res = new Component(_root, _rightmost, _maxX);
  }
  else {
    res = m_components;
    m_components = m_components->nextComponent();
    res->setRoot(_root);
    res->setRightmost(_rightmost);
    res->setMaxX(_maxX);
  }
  return res;
}

void ComponentPool::releaseComponent(Component* component) {
  assert(component != NULL);
  component->removeAllYNodes();
  component->setNextComponent(m_components);
  m_components = component;
}

struct YNode* ComponentPool::getYNode() {
  struct YNode* res;
  if (m_YNodes != NULL) {
    res = m_YNodes;
    m_YNodes = m_YNodes->next;
  }
  else
    res = new struct YNode;

  return res;
}

void ComponentPool::releaseYNodes(YNode* firstYNode, YNode* lastYNode) {
  assert((firstYNode != NULL) && (lastYNode != NULL));
  lastYNode->next = m_YNodes;
  m_YNodes = firstYNode;
};


/*
   DisjointSets constructor

   size: Number of disjoint sets labeled from 0 to n - 1
*/
DisjointSets::DisjointSets(int size)
  : m_elements(new int[size])
{
  while(size--)
    m_elements[size] = size;
}

DisjointSets::~DisjointSets() {
  delete m_elements;
}

/*
  Finds an element in the sets and returns its leader label
*/
int DisjointSets::find(int element) {
  int res = element;
  int i, temp;
  while (m_elements[res] != res) /* find leader */
    res = m_elements[res];

  // Path compression
  for (i = element; m_elements[i] != i; i = temp) {
    temp = m_elements[i];
    m_elements[i] = res;
  }
  return res;
}

/* Compute a matching between the X-nodes and the Y-nodes.
   Input:
     Variables: Problem variables
     upperBoundSort: variables indexes sorted by increasing upper bound
   Output:
     Two tables allocated by the caller
     The variable variables[matchedXs[i]] is matched with matchedYs[i] for 0 <= i < variables.size()
 */
void computeMatching(adcsp *p, int* matchedYs, int* matchedXs) {
  int k_index = 0;
  int x = 0;
  int y = 0;
  int stackCount = 0;
  int l = p->minsorted[0]->min;
  int* elementToK = new int[p->niv];

  // Computes where are the sequences of insertions for the off-line maximum problem
  while ((x < p->niv) || (stackCount != 0)) {
    while ((x < p->niv) && (p->minsorted[x]->min == l)) {
      elementToK[p->minsorted[x]->maxsortedrank] = k_index;
      x++;
      stackCount++;
    }

    if (stackCount == 0) {
      if (x < p->niv)
	l = p->minsorted[x]->min;
    }
    else {
      k_index++;
      matchedYs[y++] = l++;
      stackCount--;
      }
    }

  // off-line maximum problem
  DisjointSets ds(k_index);
  int* extracted = new int[k_index];
  for (int k = 0; k < p->niv; k++){
    int j = ds.find(elementToK[k]);
    extracted[j] = k;
    if (j < k_index - 1)
      ds.merge(j, ds.find(j+1));
  }

  for (int j = 0; j < p->niv; j++)
    matchedXs[j] = p->maxsorted[extracted[j]]->minsortedrank;

  delete elementToK;
  delete extracted;
}

/*
  Computes strongly connected components
  Input:
    variables: Problem variables
    matchedXs: the y-node matchedYs[i] is matched with the variable variables[matchedXs[i]]
    matchedYs: the y-node matchedYs[i] is matched with the variable variables[matchedXs[i]]
  Output:
    components: All components in graph G
*/
// Complexity: n log n  Why?
void computeComponents(adcsp *p, int* matchedXs, int* matchedYs, vector<Component>& components)
{
  components.reserve(p->niv); // There is at most p->niv components
  Component** S = new Component*[p->niv]; // Stack of uncompleted components
  int STop = -1;

  int i = 0;
  while (i < p->niv) {
    if (STop < 0){
      // Adds a new uncompleted component
      S[++STop] = componentPool.getComponent(matchedYs[i], matchedYs[i], p->minsorted[matchedXs[i]]->max);
      S[STop]->addYNode(i);
    }
    else {
      if (S[STop]->maxX() >= matchedYs[i]) {
	// Creates a new uncompleted component
	Component* newUncompletedComponent = componentPool.getComponent(matchedYs[i], matchedYs[i], p->minsorted[matchedXs[i]]->max);
	newUncompletedComponent->addYNode(i);

	// Tries to merge the new created component with those on the stack
	while ((STop >= 0) && (S[STop]->rightmost() >= p->minsorted[matchedXs[i]]->min)) {
	  Component* componentAtTop = S[STop];
	  if (newUncompletedComponent->maxX() < componentAtTop->maxX())
	    newUncompletedComponent->setMaxX(componentAtTop->maxX());
	  newUncompletedComponent->moveYNodesFromComponent(*componentAtTop);
	  newUncompletedComponent->setRoot(componentAtTop->root());
	  componentPool.releaseComponent(componentAtTop);
	  STop--;
	}

	// Adds the new component onto the stack
	S[++STop] = newUncompletedComponent;
      }
      else {
	// This component is finished
	components.push_back(*S[STop]); // Performs a copy of the component time in O(component.yNodesCount)
	componentPool.releaseComponent(S[STop--]);
	i--; // Current variable was not processed. We will do it next iteration
      }
    }
    i++; // Next variable
  }
  // All components are now completed
  while (STop >= 0) {
    components.push_back(*S[STop]); // Performs a copy of the component time in O(component.yNodes.count)
    componentPool.releaseComponent(S[STop--]);
  }
  delete S; // delete stack
}

/*
  Computes the top level components. Those that are not nested to any other component.
  Input:
    components: The strongly connected components of G
    variableCount: Number of variables in the problem
  Output:
    topLevelComponents: The top level components sorted in decreasing order of root and rightmost
 */
void computeTopLevelComponent(const vector<Component>& components, vector<Component>& topLevelComponents, int variableCount) {
  unsigned int* matchedYToComponent = new unsigned int[variableCount];

  for (unsigned int i = 0; i < components.size(); i++)
    for(const struct YNode* current = components[i].firstYNode(); current != NULL; current = current->next)
      matchedYToComponent[current->yNode] = i;

  int y = variableCount - 1;
  while (y >= 0) {
    topLevelComponents.push_back(components[matchedYToComponent[y]]);
    y = components[matchedYToComponent[y]].lastYNode()->yNode - 1;
  }
  delete matchedYToComponent;
}

/* Marks all y-nodes that can reach a free-node
   Input:
     topLevelComponents: The top level components of G
   Output:
     markedYs: The marked y-nodes
*/
void markYNodes(const vector<Component>& topLevelComponents, vector<int>& markedYs) {
  int lastLowerBound = topLevelComponents[0].rightmost() + 2; // Force a gap
  int jstar = 0; // Initialize to zero to avoid the compiler warning
  for (vector<Component>::const_iterator c = topLevelComponents.begin(); c < topLevelComponents.end(); c++) {
    // If there is a gap with the previous component
    if (lastLowerBound - 1 > c->rightmost()) {
      // If the component can reach a free node in the gap
      if (c->maxX() > c->rightmost()) {
	//	markedYs.insert(markedYs.end(), c->yNodes().begin(), c->yNodes().end()); // Marks all y-nodes in the component
	const struct YNode* current = c->firstYNode();
	while (current != NULL) {
	  markedYs.insert(markedYs.end(), current->yNode);
	  current = current->next;
	}
	jstar = c->root(); // Component's root is the lowest marked y-node up to now
      }
      else
	jstar = c->rightmost() + 1; // The lowest y-node in the gap is the lowest free node up to now
    }
    else {
      // If the component can reach a free or a marked node
      if (c->maxX() >= jstar) {
	//	markedYs.insert(markedYs.end(), c->yNodes().begin(), c->yNodes().end()); // Marks all y-nodes in the component
	const struct YNode* current = c->firstYNode();
	while (current != NULL) {
	  markedYs.insert(markedYs.end(), current->yNode);
	  current = current->next;
	}
	jstar = c->root(); // Components's root is the lowest marked y-node up to now
      }
    }
    lastLowerBound = c->root();
  }
}

/* Creates a vector that maps each variable to its component to which it belongs
   Input:
     variables: Problem variables
     components: All components in G
     matchedXs: The variable indexes as they appear in the matching M
   Output:
     variableToComponent: variables[i] is in components[variableToComponent[i]]
*/
void mapVariablesToComponents(adcsp *p, const vector<Component>& components,
			      int* matchedXs, int* variableToComponent, int variableCount) {
  int i = variableCount;
  while(i--)
    variableToComponent[i] = -1;
  i = components.size();
  while(i--)
    for (const struct YNode* current = components[i].firstYNode(); current != NULL; current = current->next)
      variableToComponent[matchedXs[current->yNode]] = i;
}

/*
 *  Narrows variables lower bounds
 *  Input:
 *    variables: Problem variables (will be modified)
 *    upperBoundSort: variables indexes sorted by upper bound
 *    components: All strongly connected components in G
 *    matchedXs: the y-node matchedYs[i] is matched with the
 *      variable variables[matchedXs[i]]
 *    matchedYs: the y-node matchedYs[i] is matched with the
 *      variable variables[matchedXs[i]]
 *    variableToComponent: variables[i] is in components[variableToComponent[i]]
 */
void
narrowLowerBounds(
  adcsp *p,
  const vector<Component>& components,
  int* matchedXs,
  int* matchedYs,
  int* variableToComponent,
  int& status_lower)
{
  int** xsInComponents = new int*[components.size()];
  int* iterators = new int[components.size()];
  unsigned int j;
  for (j = 0; j < components.size(); j++) {
    xsInComponents[j] = new int[components[j].yNodeCount()];
    iterators[j] = 0;
  }
  for (j = 0; j < (unsigned int)p->niv; j++) {
    int componentIndex = variableToComponent[j];
    if (componentIndex >= 0)
      xsInComponents[componentIndex][iterators[componentIndex]++] = j;
  }
  delete iterators;

  status_lower = NO_CHANGES;

  for (unsigned int componentIdx = 0; componentIdx < components.size(); componentIdx++) {
    const Component& c = components[componentIdx];
    int* Xs = xsInComponents[componentIdx];
    const struct YNode* Y = c.lastYNode();
    for (int x = 0; x < c.yNodeCount(); x++) {
      while (matchedYs[Y->yNode] < p->minsorted[Xs[x]]->min) {
	Y = Y->prev;
      }
      if (p->minsorted[Xs[x]]->min < matchedYs[Y->yNode]) {
	p->minsorted[Xs[x]]->min = matchedYs[Y->yNode];
	status_lower = CHANGES;

	/* NEW */
	if( p->minsorted[Xs[x]]->min >
	    p->minsorted[Xs[x]]->max ) {
	  status_lower = INCONSISTENT;
	  goto cleanup;
	}

      }
    }
  }

cleanup:
  for (unsigned int k = 0; k < components.size(); k++)
    delete xsInComponents[k];
  delete xsInComponents;
}


/*
 *  Narrows the variables upper bounds
 *  Input:
 *    variables: Problem variables (will be modified)
 *    upperBoundSort: variables indexes sorted by upper bound
 *    components: All strongly connected components in G
 *    topLevelComponents: Top level strongly connected components in G
 *      (those that are not nested to any other components)
 *    markedYs: matchedYs[markedYs[i]] can reach a free node
 *    matchedXs: the y-node matchedYs[i] is matched with the
 *      variable variables[matchedXs[i]]
 *    matchedYs: the y-node matchedYs[i] is matched with the
 *      variable variables[matchedXs[i]]
 *    variableToComponent: variables[i] is in components[variableToComponent[i]]
 */
void
narrowUpperBounds(
  adcsp *p,
  const vector<Component>& components,
  const vector<Component>& topLevelComponents,
  vector<int>& markedYs,
  int* matchedXs,
  int* matchedYs,
  int* variableToComponent,
  int& status_upper)
{
  const unsigned int componentCount = components.size();
  int** XsInComponents = new int*[componentCount];
  unsigned int i = componentCount;
  while (i--) {
    XsInComponents[i] = new int[components[i].yNodeCount()] + components[i].yNodeCount();
  }

  for (interval **x = p->maxsorted; x != p->maxsorted + p->niv; x++) {
    int msrank = (*x)->minsortedrank;
    if (variableToComponent[msrank] >= 0)
      *(--XsInComponents[variableToComponent[msrank]]) = msrank;
  }
  // Maximal neighbour which belongs to the same strongly components
  int* s = new int[p->niv];
  for (int v = 0; v < p->niv; v++)
    s[v] = p->minsorted[v]->max;
  for (unsigned int componentIdx = 0; componentIdx < componentCount; componentIdx++) {
    const Component& c = components[componentIdx];
    int* Xs = XsInComponents[componentIdx];
    const struct YNode* Y = c.firstYNode();
    for (int x = 0; x < c.yNodeCount(); x++) {
      while ((Y != NULL) && (matchedYs[Y->yNode] > p->minsorted[Xs[x]]->max))
	Y = Y->next;

      if (Y == NULL) { // No solution
	unsigned int j = componentCount;
	while (j--) {
	  delete XsInComponents[j];
        }
	delete XsInComponents;
	delete s;
	status_upper = INCONSISTENT;
	return;
      }

      const int a = matchedYs[Y->yNode];
      const int b = p->minsorted[Xs[x]]->max;
      s[Xs[x]] = a < b ? a : b;
    }
  }

  unsigned j = componentCount;
  while (j--) {
    delete XsInComponents[j];
  }
  delete XsInComponents;
  XsInComponents = NULL;

  // Computes the unmarked matched y-nodes intervals
  int idxM = markedYs.size() - 1;
  int idxY = 0;
  int l;
  vector<pair<int, int> > U;
  while (idxM >= 0) {
    if (matchedYs[idxY] < matchedYs[markedYs[idxM]]) {
      l = idxY++;
      while ((idxY < p->niv) && (matchedYs[idxY] < matchedYs[markedYs[idxM]])) {
	if (matchedYs[idxY - 1] + 1 != matchedYs[idxY]) {
	  U.push_back(pair<int, int>(matchedYs[l], matchedYs[idxY - 1]));
	  l = idxY;
	}
	idxY++;
      }
      U.push_back(pair<int, int>(matchedYs[l], matchedYs[idxY - 1]));
    }
    else {
      idxM--;
      idxY++;
    }
  }
  if (idxY < p->niv) {
    int l = idxY++;
    while (idxY < p->niv) {
      if (matchedYs[idxY - 1] + 1 != matchedYs[idxY]) {
	U.push_back(pair<int, int>(matchedYs[l], matchedYs[idxY - 1]));
	l = idxY;
      }
      idxY++;
    }
    U.push_back(pair<int, int>(matchedYs[l], matchedYs[p->niv - 1]));
  }

  // Flag all variables that belong to a top level component
  bool* isInTopLevelComponent = new bool[p->niv];
  int k = p->niv;
  while (k--)
    isInTopLevelComponent[k] = false;
  const unsigned int topLevelComponentCount = topLevelComponents.size();
  for (unsigned int c = 0; c < topLevelComponentCount; c++)
    for (const struct YNode* current = topLevelComponents[c].firstYNode(); current != NULL; current = current->next)
      isInTopLevelComponent[matchedXs[current->yNode]] = true;

  status_upper = NO_CHANGES;
  unsigned int u = 0;
  const unsigned int USize = U.size();
  for (interval **xx = p->maxsorted; xx < p->maxsorted + p->niv; xx++) {
    int msrank = (*xx)->minsortedrank;
    if (isInTopLevelComponent[msrank]) {
      while ((u < USize) && (U[u].first <= p->minsorted[msrank]->max))
	u++;
      // If the variable upper bound belongs to an interval U, set its upper bound to max(U.lowerBound - 1, s[x])
      // Otherwise, set it to max(X.upperBound, s[x]) = X.upperBound (do nothing)
      if (u > 0) {
	const pair<int, int>& cu = U[u-1];
	if ((cu.first <= p->minsorted[msrank]->max) &&
            (p->minsorted[msrank]->max <= cu.second)) {
	  if (cu.first > s[msrank]) {
	    p->minsorted[msrank]->max = cu.first - 1;
	    status_upper = CHANGES;
          }
	  else {
	    p->minsorted[msrank]->max = s[msrank];
	    status_upper = CHANGES;
          }
        }
      }
    }
    else {
      p->minsorted[msrank]->max = s[msrank];
      status_upper = CHANGES;
    }
  }

  delete isInTopLevelComponent;
  delete s;
}


/*
 *  Narrow the variables bounds with respect to the all-diff constraint
 *  variables: Problem variables sorted by lower bound
 *  upperBoundSort: Variables indexes sorted by upper bound
*/
void
narrowRanges( adcsp *p, int& status_lower, int& status_upper )
{
  // Computes a matching
  int* matchedYs = new int[p->niv];
  int* matchedXs = new int[p->niv];
  computeMatching(p, matchedYs, matchedXs);

  // Computes the strongly connected components
  vector<Component> components;
  computeComponents(p, matchedXs, matchedYs, components);

  // Computes the top level strongly connected components
  vector<Component> topLevelComponents;
  computeTopLevelComponent(components, topLevelComponents, p->niv);

  // Marks the y-nodes that can reach a free node
  vector<int> markedYs;
  markYNodes(topLevelComponents, markedYs);

  // Creates a vector that maps each variable to its component
  int* variableToComponent = new int[p->niv];
  mapVariablesToComponents(p, components, matchedXs, variableToComponent, p->niv);

  // Narrows the lower bounds
  narrowLowerBounds(p, components, matchedXs, matchedYs, variableToComponent, status_lower);

  // Narrows the upper bounds
if( status_lower != INCONSISTENT ) {
  narrowUpperBounds(p, components, topLevelComponents, markedYs, matchedXs, matchedYs, variableToComponent, status_upper);
}

  delete variableToComponent;
  delete matchedYs;
  delete matchedXs;
}


void
sortmin( interval *v[], int n )
{
  int i, current;
  bool sorted;
  interval *t;

  current = n-1;
  sorted = false;
  while( !sorted ) {
    sorted = true;
    for( i = 0; i < current; i++ ) {
      if( v[i]->min > v[i+1]->min ) {
        t = v[i];
        v[i] = v[i+1];
        v[i+1] = t;
        sorted = false;
      }
    }
    current--;
  }
}

void
sortmax( interval *v[], int n )
{
  int i, current;
  bool sorted;
  interval *t;

  current = 0;
  sorted = false;
  while( !sorted ) {
    sorted = true;
    for( i = n-1; i > current; i-- ) {
      if( v[i]->max < v[i-1]->max ) {
        t = v[i];
        v[i] = v[i-1];
        v[i-1] = t;
        sorted = false;
      }
    }
    current++;
  }
}

/*
int mincmpiv(const void *x, const void *y)
{
  return (* ((interval **)x))->min - (* ((interval **)y))->min;
}

int maxcmpiv(const void *x, const void *y)
{
  return (* ((interval **)x))->max - (* ((interval **)y))->max;
}
*/

void
IlcNewAllDiffI::sortit()
{
  int i;

  sortmin( ad->minsorted, ad->niv );
  //qsort( ad->minsorted, ad->niv, sizeof(interval *), mincmpiv );
  for( i = 0; i < ad->niv; i++ ) {
    ad->minsorted[i]->minsortedrank = i;
  }

  sortmax( ad->maxsorted, ad->niv );
  //qsort( ad->maxsorted, ad->niv, sizeof(interval *), maxcmpiv );
  for( i = 0; i < ad->niv; i++ ) {
    ad->maxsorted[i]->maxsortedrank = i;
  }
}

void
IlcNewAllDiffI::propagate()
{
  int i, status_lower, status_upper;
  int a, b;
  int l, u;

  a = _vars.getRangeIndexMin();
  b = _vars.getRangeIndexMax();

  if( _prop == WithValueRemoval && (a == (b-1)) && _vars[a].isBound() ) {
    return;
  }

  currentLevel.setValue( _vars.getManager(), currentLevel.getValue() + 1 );

  if( lastLevel != (currentLevel.getValue()-1) ) {
    // not incremental
    status_lower = CHANGES;
    status_upper = CHANGES;
    IlcIntVarArrayIterator iter(_vars);
    IlcIntVar v;
    i = 0;
    while (iter.next(v)) {
      ad->iv[i].min = v.getMin();
      ad->iv[i].max = v.getMax();
      i++;
    }
  }
  else {
    // incremental
    status_lower = NO_CHANGES;
    status_upper = NO_CHANGES;
    for( i = a; i < b; i++ ) {
      l = ad->iv[i].min;
      u = ad->iv[i].max;
      ad->iv[i].min = _vars[i].getMin();
      ad->iv[i].max = _vars[i].getMax();
      if( l != ad->iv[i].min ) status_lower = CHANGES;
      if( u != ad->iv[i].max ) status_upper = CHANGES;
    }
  }

  lastLevel = currentLevel.getValue();

  if( status_lower == NO_CHANGES && status_upper == NO_CHANGES ) {
    return;
  }

  sortit();

  narrowRanges( ad, status_lower, status_upper );

  if( (status_lower == INCONSISTENT) || (status_upper == INCONSISTENT) ) {
    _vars.getManager().fail();
  }
  else
  if( (status_lower == CHANGES) || (status_upper == CHANGES) ) {
    IlcIntVarArrayIterator iter(_vars);
    IlcIntVar v;
    i = 0;
    while (iter.next(v)) {
      v.setRange( ad->iv[i].min, ad->iv[i].max );
      i++;
    }
  }
}


IlcConstraint
IlcNewAllDiff( IlcIntVarArray vars, PropType prop )
{
  IlcManager m = vars.getManager();
  return new (m.getHeap()) IlcNewAllDiffI( m, vars, prop );
}

/*
 *  End of user defined propagator for enforcing bounds consistency
 *=================================================================*/

