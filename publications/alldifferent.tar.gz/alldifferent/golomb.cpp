
/*
 *  Golomb ruler problem
 */

#include <ilsolver/ilcint.h>
#include "Propagator/Tromp/alldiff.h"


IlcInt
power2( IlcInt exponent )
{
  IlcInt i, mult;

  mult = 1;
  for( i = 1; i <= exponent; i++ ) {
    mult *= 2;
  }

  return( mult );
}



IlcInt
main( int argc, char** argv )
{
  IlcManager m(IlcEdit);
  IlcInt     i, j, k, n, allDiffFlag, upperBound, count;

  IlcFloat currtime=m.getTime();
  IlcInt   currfail=m.getNumberOfFails();

  if( argc != 3 ) {
    m.out() << "Usage: golomb n allDiffFlag" << endl;
    exit( 0 );
  }

  n           = atoi( argv[1] );
  allDiffFlag = atoi( argv[2] );

  if( (allDiffFlag < 0) || (allDiffFlag > 4) ) {
    m.out() << "Invalid allDiffFlag (0,1,2,3,4)" << endl;
    exit( 0 );
  }

  upperBound = power2( n-1 );

  IlcIntVarArray x( m, n, 1, upperBound );
  m.add( x[0] == 1 );
  for( i = 1; i < n; i++ ) {
    m.add( x[i-1] < x[i] );
  }

  IlcIntVarArray d( m, (n*(n-1))/2, 1, upperBound );
  k = 0;
  for( i = 0; i < n; i++ ) {
    for( j = i+1; j < n; j++ ) {
      m.add( d[k] == x[j] - x[i] );
      k++;
    }
  }

  // Break reflection symmetry
  //m.add( x[1] - x[0] < x[n-1] - x[n-2] );
  m.add( d[0] < d[(n*(n-1)/2)-1] );

  switch (allDiffFlag) {
  case 0:
    m.out() << "Value:";
    m.add( IlcAllDiff( d, IlcWhenValue ) );
    break;
  case 1:
    m.out() << "Range:";
    m.add( IlcAllDiff( d, IlcWhenRange ) );
    break;
  case 2:
    m.out() << "Domain:";
    m.add( IlcAllDiff( d, IlcWhenDomain ) );
    break;
  case 3:
    m.out() << "Bounds:";
    m.add( IlcNewAllDiff( d, WithOutValueRemoval ) );
    break;
  case 4:
    m.out() << "Bounds+ValueRemoval:";
    m.add( IlcNewAllDiff( d, WithValueRemoval ) );
    break;
  }

  m.setObjMin( x[n-1] );

  m.add( IlcGenerate( x, IlcChooseFirstUnboundInt ) );

  count = 0;
  while( m.nextSolution() ) {
    count++;
/*
    m.out() << "Solution: ";
    for( i = 0; i < n; i++ ) {
      m.out() << x[i].getValue() << " ";
    }
    m.out() << endl;
*/
  }

  m.out() << n << ":";
  m.out() << (m.getTime() - currtime) << ":";
  m.out() << (m.getNumberOfFails() - currfail) << endl;

  m.end();
  return( 0 );
}

