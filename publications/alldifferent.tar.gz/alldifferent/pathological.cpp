
/*
 *  Pathological example from Puget's 1998 alldiff paper
 */

#include <ilsolver/ilcint.h>
#include "Propagator/Tromp/alldiff.h"


IlcFloat
testEvent( IlcInt k, IlcInt flag )
{
  IlcManager m(IlcEdit);
  IlcInt i, j;
  IlcInt n = 2*k+1;
  IlcFloat currtime, elapsed_time;

  currtime = m.getTime();

  IlcIntVarArray vars( m, n, -k, k );

  for( i = 0; i <= k; i++ ) {
    vars[i].setRange( i-k, 0 );
  }

  for( i = k+1; i <= 2*k; i++ ) {
    vars[i].setRange( 0, i-k );
  }

  switch (flag) {
  case 0: m.add( IlcAllDiff( vars, IlcWhenValue  ) ); break;
  case 1: m.add( IlcAllDiff( vars, IlcWhenRange  ) ); break;
  case 2: m.add( IlcAllDiff( vars, IlcWhenDomain ) ); break;
  case 3: m.add( IlcNewAllDiff( vars, WithOutValueRemoval ) ); break;
  case 4: m.add( IlcNewAllDiff( vars, WithValueRemoval    ) ); break;
  }

  m.add( IlcGenerate( vars ) );
  m.nextSolution();

  elapsed_time = (m.getTime() - currtime);

  m.end();

  return( elapsed_time );
}


#define N_SAMPLES 10

int
main( int argc, char** argv )
{
  IlcInt   i, size, alldiff;
  IlcFloat totaltime;


  for( alldiff = 0; alldiff <= 2; alldiff++ ) {
    printf("\nalldiff = %d\n", alldiff);
    for( size = 100; size <= 3200; size += 100 ) {
      totaltime = 0.0;
      for( i = 0; i < N_SAMPLES; i++ ) {
        totaltime += testEvent( size, alldiff );
        //printf("%d:%d:%0.2f\n", size, alldiff, totaltime/((double)(i+1)));
      }
      printf("%d\t%0.2f\n", size, totaltime/((double)N_SAMPLES));
    }
  }

  return 0;
}

