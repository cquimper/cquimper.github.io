
Introduction
============

The file alldifferent.tar.gz contains an implementation of the
algorithm for bounds consistency propagation of the alldifferent
constraint presented in:

	A. Lopez-Ortiz, C.-G. Quimper, J. Tromp, and P. van Beek.
	A fast and simple algorithm for bounds consistency of the
	alldifferent constraint. IJCAI-2003.

Also included are some example benchmark and random problems that use
the alldifferent constraint. The bounds consistency propagator for
the alldifferent constraint and the examples that use the propagator
rely on the ILOG Solver Library.

	Peter van Beek
	vanbeek@uwaterloo.ca


Directory Contents
==================

./README.txt			  -- This file.

Example uses of the propagators:
./golomb.cpp			  -- Golomb rulers
./pathological.cpp		  -- Pathological problems
./random.cpp		  	  -- Random problems
./holes.cpp			  -- Random problems with holes in the domains

Bounds consistency propagators for the alldifferent constraint:
./Propagator/Tromp/alldiff.cpp
./Propagator/Tromp/alldiff.h
./Propagator/Tromp

    An implementation of the propagator given in:
	A. Lopez-Ortiz, C.-G. Quimper, J. Tromp, and P. van Beek.
	A fast and simple algorithm for bounds consistency of the
	alldifferent constraint. IJCAI-2003.

./Propagator/Quimper/alldiff.cpp
./Propagator/Quimper/alldiff.h
./Propagator/Quimper

    An implementation of the propagator given in:
	K. Mehlhorn and S. Thiel.
	Faster algorithms for bound-consistency of the sortedness
	and alldifferent constraint. In CP-2000, pp. 306-319.

