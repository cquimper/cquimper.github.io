
/*
 *  Random model of all different problems.
 */

#include <ilsolver/ilcint.h>
#include "Propagator/Tromp/alldiff.h"

double total_cpu;
double total_solutions;
double total_fails;


void
testEvent( IlcInt n, IlcInt range, IlcInt flag )
{
  int  i, a, b, count;

  IlcManager m(IlcEdit);

  IlcFloat currtime   = m.getTime();
  IlcInt   currfail   = m.getNumberOfFails();

  m.setTimeLimit( 600 );

  IlcIntVarArray vars( m, n, 0, range-1 );

  for( i = 0; i < n; i++ ) {
    a = rand() % range;
    b = rand() % range;
    if( a <= b ) vars[i].setRange( a, b );
    else         vars[i].setRange( b, a );
  }

  switch (flag) {
  case 0: m.add( IlcAllDiff( vars, IlcWhenValue  ) ); break;
  case 1: m.add( IlcAllDiff( vars, IlcWhenRange  ) ); break;
  case 2: m.add( IlcAllDiff( vars, IlcWhenDomain ) ); break;
  case 3: m.add( IlcNewAllDiff( vars, WithOutValueRemoval ) ); break;
  case 4: m.add( IlcNewAllDiff( vars, WithValueRemoval    ) ); break;
  }

  m.add( IlcGenerate( vars ) );

  count = 0;
  if( m.nextSolution() ) {
    count++;
  }

  total_cpu       += (m.getTime() - currtime);
  total_solutions += count;
  total_fails     += (m.getNumberOfFails() - currfail);

  m.end();
}

void
initInfo()
{
  srand(0);
  total_cpu       = 0.0;
  total_solutions = 0.0;
  total_fails     = 0.0;
}

void
printInfo( int n, int iterations, int flag )
{
  switch (flag) {
    case 0: cout << "Value: "; break;
    case 1: cout << "Range: "; break;
    case 2: cout << "Domain: "; break;
    case 3: cout << "Bound: "; break;
    case 4: cout << "Bound+ValueRemoval: "; break;
  }
  cout << "n: " << n << "  ";
  cout << "iters: " << iterations << "  ";
  cout << "time: "  << total_cpu       / ((double)iterations) << "  ";
  cout << "solns: " << total_solutions / ((double)iterations) << "  ";
  cout << "fails: " << total_fails     / ((double)iterations) << endl;
}

int
main( int argc, char** argv )
{
  int k, n, iterations, flag;

  if( argc != 4 ) {
    cerr << "Usage: random n iterations flag" << endl;
    exit( 0 );
  }

  n          = atoi( argv[1] );
  iterations = atoi( argv[2] );
  flag       = atoi( argv[3] );

  initInfo();
  for( k = 1; k <= iterations; k++ ) {
    testEvent( n, n, flag );
    printInfo( n, k, flag );
  }
  printInfo( n, iterations, flag );

  return 0;
}

