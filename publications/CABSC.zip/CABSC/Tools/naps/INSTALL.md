# Installation of NaPS 1.x

*NOTE!*  You need GNU-make and GCC to compile this software.

## INSTALLATION
We recommend to BigNum vesion, which is compiled by
  ```make rs```

### TIPS:
* For compile error related to gmp.h, install libgmp3-dev gmp-devel library.
* For compile error related to zlib.h, install zlib-devel library.
* On FreeBSD, use ```gmake``` for make.

