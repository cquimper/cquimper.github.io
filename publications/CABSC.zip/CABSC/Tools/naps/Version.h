/********* NaPS (Nagoya Pesudo-Boolena Solver) ***********/

#define naps_version "1.02b3"
//

