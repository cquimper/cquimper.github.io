#!/bin/bash

rm -rf */_tmp
rm -rf */tmp/
rm */logs/*
rm */Results/*
rm */out.*
rm */t.*
