import sys

sys.path.append(".")
print(sys.path)
