library(ggplot2)
library(reshape2)


made_graph <- function(name_file, heuristique, adresses) {
  result <-  read.table(paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/", name_file, sep = ""), sep = " ", header = T)
  resultduration <-result[1:90,]
  resultdistance <-result[91:180,]
  resultwide <- reshape(data = result[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
  resultduration_wide <- reshape(data = result[1:90,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
  resultdistance_wide <- reshape(data = result[91:180,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
  resultwide$Trucks<-factor(resultwide$Trucks)
  resultduration_wide$Trucks<-factor(resultduration_wide$Trucks)
  resultdistance_wide$Trucks<-factor(resultdistance_wide$Trucks)
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"ACSC",".pdf", sep = ""))
  print(qplot(resultwide$L_Max.2,resultwide$L_Max.7, data =resultwide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("L_Max 50 villes non résolues 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
    geom_abline(intercept = 0))
  print(qplot(resultduration_wide$L_Max.2,resultduration_wide$L_Max.7, data =resultduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
    geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$L_Max.2,resultdistance_wide$L_Max.7, data =resultdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
    geom_abline(intercept = 0))
  dev.off()
  
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"ACSC-BACK",".pdf", sep = ""))
  print(qplot(resultwide$Backtrack.2,resultwide$Backtrack.7, data =resultwide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("Backtrack 50 villes non résolues 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$Backtrack.2,resultduration_wide$Backtrack.7, data =resultduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("backtrack 50 villes (duration) non résolues 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$Backtrack.2,resultdistance_wide$Backtrack.7, data =resultdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("backtrack 50 villes (distance) non résolues 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
  
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"AMSM",".pdf", sep = ""))
  print(qplot(resultwide$L_Max.5,resultwide$L_Max.7, data =resultwide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("L_Max 50 villes non résolues 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$L_Max.5,resultduration_wide$L_Max.7, data =resultduration_wide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$L_Max.5,resultdistance_wide$L_Max.7, data =resultdistance_wide,xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
  
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"AMSM-BACK",".pdf", sep = ""))
  print(qplot(resultwide$Backtrack.5,resultwide$Backtrack.7, data =resultwide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("Backtrack 50 villes non résolues 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$Backtrack.5,resultduration_wide$Backtrack.7, data =resultduration_wide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("backtrack 50 villes (duration) non résolues 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$Backtrack.5,resultdistance_wide$Backtrack.7, data =resultdistance_wide,xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("backtrack 50 villes (distance) non résolues 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
}

made_graph_time <- function(name_file, heuristique, adresses) {
  result <-  read.table(paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/", name_file, sep = ""), sep = " ", header = T)
  resultduration <-result[1:90,]
  resultdistance <-result[91:180,]
  resultwide <- reshape(data = result[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
  resultduration_wide <- reshape(data = result[1:90,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
  resultdistance_wide <- reshape(data = result[91:180,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
  resultwide$Trucks<-factor(resultwide$Trucks)
  resultduration_wide$Trucks<-factor(resultduration_wide$Trucks)
  resultdistance_wide$Trucks<-factor(resultdistance_wide$Trucks)
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"ACSC",".pdf", sep = ""))
  print(qplot(resultwide$Time.2,resultwide$Time.7, data =resultwide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("Time 10 villes avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$Time.2,resultduration_wide$Time.7, data =resultduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("Time 10 villes (duration) avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$Time.2,resultdistance_wide$Time.7, data =resultdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("Time 50 villes (distance)  avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
  
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"ACSC-BACK",".pdf", sep = ""))
  print(qplot(resultwide$Backtrack.2,resultwide$Backtrack.7, data =resultwide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("Backtrack 50 villes non résolues 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$Backtrack.2,resultduration_wide$Backtrack.7, data =resultduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("backtrack 50 villes (duration) non résolues 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$Backtrack.2,resultdistance_wide$Backtrack.7, data =resultdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = paste("backtrack 50 villes (distance) non résolues 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
  
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"AMSM",".pdf", sep = ""))
  print(qplot(resultwide$Time.5,resultwide$Time.7, data =resultwide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("Time 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$Time.5,resultduration_wide$Time.7, data =resultduration_wide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("Time 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$Time.5,resultdistance_wide$Time.7, data =resultdistance_wide,xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("Time 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
  
  pdf(file = paste("/Users/kimrp/Documents/Universite/nsimtech/circuits/result/",substr(name_file,1,nchar(name_file)-4),"AMSM-BACK",".pdf", sep = ""))
  print(qplot(resultwide$Backtrack.5,resultwide$Backtrack.7, data =resultwide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("Backtrack 50 villes non résolues 2 mins\n avec l'heuristique", heuristique),color =Trucks) + 
          geom_abline(intercept = 0))
  print(qplot(resultduration_wide$Backtrack.5,resultduration_wide$Backtrack.7, data =resultduration_wide, xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("backtrack 50 villes (duration) non résolues 2 mins\n avec l'heuristique",heuristique),col =  Trucks)+ 
          geom_abline(intercept = 0))
  print(qplot(resultdistance_wide$Backtrack.5,resultdistance_wide$Backtrack.7, data =resultdistance_wide,xlab = "Sans mémorisation", ylab = "Avec mémorisation", main = paste("backtrack 50 villes (distance) non résolues 2 mins\n avec l'heuristique", heuristique),col = Trucks)+ 
          geom_abline(intercept = 0))
  dev.off()
}















result15 <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result_15.txt", sep = " ", header = T)
result15_wide <- reshape(data = result15[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result15_duration_wide <- reshape(data = result15[1:30,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result15_distance_wide <- reshape(data = result15[30:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result15_wide$Trucks<-factor(result15_wide$Trucks)
result15_duration_wide$Trucks<-factor(result15_duration_wide$Trucks)
result15_distance_wide$Trucks<-factor(result15_distance_wide$Trucks)


pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result15.pdf")
qplot(result15_wide$Time.7,data =result15_wide, xlab = "Time", ylab = "Quantité d'instances", main = "instance résolue",color =Trucks)

dev.off()



result50mem_sans <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_avec_sans_mem_sans_circuit.txt", sep = " ", header = T)
result50mem_sans_wide <- reshape(data = result50mem_sans[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50mem_sansduration_wide <- reshape(data = result50mem_sans[1:90,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50mem_sansdistance_wide <- reshape(data = result50mem_sans[91:180,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50mem_sans_wide$Trucks<-factor(result50mem_sans_wide$Trucks)
result50mem_sansduration_wide$Trucks<-factor(result50mem_sansduration_wide$Trucks)
result50mem_sansdistance_wide$Trucks<-factor(result50mem_sansdistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50_avec_sans_mem.txt.pdf")
qplot(result50mem_sans_wide$L_Max.7,result50mem_sans_wide$L_Max.5, data =result50mem_sans_wide, xlab = "Avec Mémorisation", ylab = "Sans mémorisation", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique Activity based searsh",color =Trucks) + 
  geom_abline(intercept = 0)
qplot(result50mem_sansduration_wide$L_Max.7,result50mem_sansduration_wide$L_Max.5, data =result50mem_sansduration_wide, xlab =  "Avec Mémorisation", ylab = "Sans mémorisation", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Activity based searsh",col =  Trucks)+ 
  geom_abline(intercept = 0)
qplot(result50mem_sansdistance_wide$L_Max.7,result50mem_sansdistance_wide$L_Max.5, data =result50mem_sansdistance_wide,xlab =  "Avec Mémorisation", ylab = "Sans mémorisation", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Activity based searsh",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()


pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50_avec_sans_mem_sans_circuit.txt.pdf")
qplot(result50mem_sans_wide$L_Max.7,result50mem_sans_wide$L_Max.2, data =result50mem_sans_wide, xlab = "Avec Mémorisation", ylab = "Sans circuit", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique Activity based searsh",color =Trucks) + 
  geom_abline(intercept = 0)
qplot(result50mem_sansduration_wide$L_Max.7,result50mem_sansduration_wide$L_Max.5, data =result50mem_sansduration_wide, xlab =  "Avec Mémorisation", ylab = "Sans circuit", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Activity based searsh",col =  Trucks)+ 
  geom_abline(intercept = 0)
qplot(result50mem_sansdistance_wide$L_Max.7,result50mem_sansdistance_wide$L_Max.5, data =result50mem_sansdistance_wide,xlab =  "Avec Mémorisation", ylab = "Sans circuit", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Activity based searsh",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()


result50abs <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_abs.txt", sep = " ", header = T)
result50absduration <-result50abs[1:60,]
result50absdistance <-result50abs[61:120,]
result50abs_wide <- reshape(data = result50abs[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50absduration_wide <- reshape(data = result50abs[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50absdistance_wide <- reshape(data = result50abs[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_wide$Trucks<-factor(result50abs_wide$Trucks)
result50absduration_wide$Trucks<-factor(result50absduration_wide$Trucks)
result50absdistance_wide$Trucks<-factor(result50absdistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50ABS.pdf")
qplot(result50abs_wide$L_Max.2,result50abs_wide$L_Max.5, data =result50abs_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique Activity based searsh",color =Trucks) + 
  geom_abline(intercept = 0)
qplot(result50absduration_wide$L_Max.2,result50absduration_wide$L_Max.5, data =result50absduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Activity based searsh",col =  Trucks)+ 
  geom_abline(intercept = 0)
qplot(result50absdistance_wide$L_Max.2,result50absdistance_wide$L_Max.5, data =result50absdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Activity based searsh",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()


















result50abs <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_abs.txt", sep = " ", header = T)
result50absduration <-result50abs[1:60,]
result50absdistance <-result50abs[61:120,]
result50abs_wide <- reshape(data = result50abs[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50absduration_wide <- reshape(data = result50abs[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50absdistance_wide <- reshape(data = result50abs[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_wide$Trucks<-factor(result50abs_wide$Trucks)
result50absduration_wide$Trucks<-factor(result50absduration_wide$Trucks)
result50absdistance_wide$Trucks<-factor(result50absdistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50ABS.pdf")
qplot(result50abs_wide$L_Max.2,result50abs_wide$L_Max.5, data =result50abs_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique Activity based searsh",color =Trucks) + 
  geom_abline(intercept = 0)
qplot(result50absduration_wide$L_Max.2,result50absduration_wide$L_Max.5, data =result50absduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Activity based searsh",col =  Trucks)+ 
  geom_abline(intercept = 0)
qplot(result50absdistance_wide$L_Max.2,result50absdistance_wide$L_Max.5, data =result50absdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Activity based searsh",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()



result50abs_res <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_abs_res.txt", sep = " ", header = T)
result50abs_resduration <-result50abs_res[1:60,]
result50abs_resdistance <-result50abs_res[61:120,]
result50abs_res_wide <- reshape(data = result50abs_res[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_resduration_wide <- reshape(data = result50abs_res[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_resdistance_wide <- reshape(data = result50abs_res[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_res_wide$Trucks<-factor(result50abs_res_wide$Trucks)
result50abs_resduration_wide$Trucks<-factor(result50abs_resduration_wide$Trucks)
result50abs_resdistance_wide$Trucks<-factor(result50abs_resdistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50ABS_res.pdf")
qplot(result50abs_res_wide$L_Max.2,result50abs_res_wide$L_Max.5, data =result50abs_res_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique Activity based searsh",color =Trucks) + 
  geom_abline(intercept = 0)
qplot(result50abs_resduration_wide$L_Max.2,result50abs_resduration_wide$L_Max.5, data =result50abs_resduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Activity based searsh",col =  Trucks)+ 
  geom_abline(intercept = 0)
qplot(result50abs_resdistance_wide$L_Max.2,result50abs_resdistance_wide$L_Max.5, data =result50abs_resdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Activity based searsh",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()




result50mo <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_md.txt", sep = " ", header = T)
result50moduration <-result50mo[1:60,]
result50modistance <-result50mo[61:120,]

result50mo_wide <- reshape(data = result50mo[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50moduration_wide <- reshape(data = result50mo[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50modistance_wide <- reshape(data = result50mo[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50mo_wide$Trucks<-factor(result50mo_wide$Trucks)
result50moduration_wide$Trucks<-factor(result50moduration_wide$Trucks)
result50modistance_wide$Trucks<-factor(result50modistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50MD.pdf")
qplot(result50mo_wide$L_Max.2,result50mo_wide$L_Max.5, data =result50mo_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique DowOverWDeg ",color =Trucks) + 
  geom_abline(intercept = 0)

qplot(result50moduration_wide$L_Max.2,result50moduration_wide$L_Max.5, data =result50moduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique DowOverWDeg",col =  Trucks)+ 
  geom_abline(intercept = 0)

qplot(result50modistance_wide$L_Max.2,result50modistance_wide$L_Max.5, data =result50modistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique DowOverWDeg",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()

result50md_res <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_md_res.txt", sep = " ", header = T)
result50md_resduration_wide <-result50md_res[1:60,]
result50md_resdistance_wid <-result50md_res[61:120,]

result50md_res_wide <- reshape(data = result50md_res[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50md_resduration_wide <- reshape(data = result50md_res[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50md_resdistance_wide <- reshape(data = result50md_res[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50md_res_wide$Trucks<-factor(result50md_res_wide$Trucks)
result50md_resduration_wide$Trucks<-factor(result50md_resduration_wide$Trucks)
result50md_resdistance_wide$Trucks<-factor(result50md_resdistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50MD_res.pdf")
qplot(result50md_res_wide$L_Max.2,result50md_res_wide$L_Max.5, data =result50md_res_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique DowOverWDeg ",color =Trucks) + 
  geom_abline(intercept = 0)

qplot(result50md_resduration_wide$L_Max.2,result50md_resduration_wide$L_Max.5, data =result50md_resduration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Min Domain",col =  Trucks)+ 
  geom_abline(intercept = 0)

qplot(result50md_resdistance_wide$L_Max.2,result50md_resdistance_wide$L_Max.5, data =result50md_resdistance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Min Domain",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()


result50abs_cd <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_md_res.txt", sep = " ", header = T)
result50abs_cd_duration_wide <-result50md_res[1:60,]
result50abs_cd_distance_wide <-result50md_res[61:120,]

result50abs_cd_wide <- reshape(data = result50abs_cd[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_cd_duration_wide <- reshape(data = result50abs_cd[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_cd_distance_wide <- reshape(data = result50abs_cd[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_cd_wide$Trucks<-factor(result50abs_cd_wide$Trucks)
result50abs_cd_duration_wide$Trucks<-factor(result50abs_cd_duration_wide$Trucks)
result50abs_cd_distance_wide$Trucks<-factor(result50abs_cd_distance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50abs_cd.pdf")
qplot(result50abs_cd_wide$L_Max.2,result50abs_cd_wide$L_Max.5, data =result50abs_cd_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique DowOverWDeg ",color =Trucks) + 
  geom_abline(intercept = 0)

qplot(result50abs_cd_duration_wide$L_Max.2,result50abs_cd_duration_wide$L_Max.5, data =result50abs_cd_duration_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (duration) non résolues 2 mins\n avec l'heuristique Min Domain",col =  Trucks)+ 
  geom_abline(intercept = 0)

qplot(result50abs_cd_distance_wide$L_Max.2,result50abs_cd_distance_wide$L_Max.5, data =result50abs_cd_distance_wide,xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes (distance) non résolues 2 mins\n avec l'heuristique Min Domain",col = Trucks)+ 
  geom_abline(intercept = 0)
dev.off()









result_total <- cbind(result50abs_wide[,c(1,2,3,4,6,7)], result50mo_wide[,c(3,4,6,7)], result50small_wide[,c(3,4,6,7)])
colnames(result_total) <- c("Instance", "Trucks", "LMax_ABS_SC", "Backtrack_ABS_SC", "LMax_ABS_C", "Backtrack_ABS_C", "LMax_MD_SC", "Backtrack_MD_SC", "LMax_MD_C", "Backtrack_MD_C", "LMax_MIN_SC", "Backtrack_MIN_SC", "LMax_MIN_C", "Backtrack_MIN_C")
circuits <- c(1:nrow(result_total))
heuristic <- c(1:nrow(result_total))

for (i in 1:nrow(result_total)) {
  line <- result_total[i, c(3,5,7,9,11,13)]
  index_min <- which(line==min(line))
  if (index_min[1] == 1) {
    heuristic[i] <- "ABS"
    circuits[i] <- "N"
  }
  else if (index_min[1] == 2) {
    heuristic[i] <- "ABS"
    circuits[i] <- "Y"
    
  }  
  else if (index_min[1] == 3) {
    heuristic[i] <- "MD"
    circuits[i] <- "N"
  }  
  else if (index_min[1] == 4) {
    heuristic[i] <- "MD"
    circuits[i] <- "Y"
    
  }  
  else if (index_min[1] == 5) {
    heuristic[i] <- "MIN"
    circuits[i] <- "N"
    
  }  
  else if (index_min[1] == 6) {
    heuristic[i] <- "MIN"
    circuits[i] <- "Y"
    
  } 
}
result_total$heuristics <- heuristic
result_total$circuits <- circuits
table_heuristics_circuits <- table(result_total$heuristics, result_total$circuits)
table_heuristics_circuits <- prop.table(table_heuristics_circuits)
table_heuristics_circuits <- round(addmargins(table_heuristics_circuits),2)
write.csv2(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/table_heuristics.csv",table_heuristics_circuits)





result100abs <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result100_abs.txt", sep = " ", header = T)
result100absduration <-result50static[1:60,]

result100abs_wide <- reshape(data = result100abs[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result100absduration_wide <- reshape(data = result100abs[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result100abs_wide$Trucks<-factor(result100abs_wide$Trucks)
result100absduration_wide$Trucks<-factor(result100absduration_wide$Trucks)




pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50static.pdf")
qplot(result100abs_wide$L_Max.2,result100abs_wide$L_Max.5, data =result100abs_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique DowOverWDeg ",color =Trucks) + 
  geom_abline(intercept = 0)
dev.off()




result50abs <- read.table("/Users/kimrp/Documents/Universite/nsimtech/circuits/result50_abs_restart.txt", sep = " ", header = T)
result50absduration <-result50abs[1:60,]
result50absdistance <-result50abs[61:120,]

result50abs_wide <- reshape(data = result50abs[,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50absduration_wide <- reshape(data = result50abs[1:60,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50absdistance_wide <- reshape(data = result50abs[61:120,-3], direction = "wide", idvar= c("Instance", "Trucks"),  timevar = c("Model"))
result50abs_wide$Trucks<-factor(result50abs_wide$Trucks)
result50absduration_wide$Trucks<-factor(result50absduration_wide$Trucks)
result50absdistance_wide$Trucks<-factor(result50absdistance_wide$Trucks)

pdf(file = "/Users/kimrp/Documents/Universite/nsimtech/circuits/result/result50ABS.pdf")
qplot(result50abs_wide$L_Max.2,result50abs_wide$L_Max.5, data =result50abs_wide, xlab = "Sans la contrainte circuits", ylab = "Avec la contrainte circuits", main = "L_Max 50 villes non résolues 2 mins\n avec l'heuristique Activity based searsh",color =Trucks) + 
  geom_abline(intercept = 0)
dev.off()

