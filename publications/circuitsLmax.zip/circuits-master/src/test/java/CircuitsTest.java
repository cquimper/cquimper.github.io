import javafx.util.Pair;
import org.apache.commons.lang3.ArrayUtils;
import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.IntStream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CircuitsTest {
    Model model = new Model();
    int[][] distance;
    IntVar[] cities;
    IntVar[] depot;
    int k;
    IntVar L ;
    public void set_up_4_cities(int k){
        this.k = k;
        this.distance = new int[][]{{0,2,4,5},
                                    {2,0,3,6},
                                    {4,3,0,1},
                                    {5,6,1,0}};
        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.cities = new IntVar[3];
        this.depot = this.model.intVarArray("depot", this.k,this.k,this.k + this.cities.length - 1);
        for (int i = 0 ; i < this.cities.length; i++) {
            this.cities[i] = this.model.intVar("cities[" + i + "]",
                    ArrayUtils.remove(IntStream.range(0, this.k + this.cities.length).toArray(),i + this.k));
        }
    }

    public void set_up_5_cities(int k){
        this.k = k;
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[4];
        this.depot = this.model.intVarArray("depot", this.k,this.k,this.k + this.cities.length - 1);
        for (int i = 0 ; i < this.cities.length; i++) {
            this.cities[i] = this.model.intVar("cities[" + i + "]",
                    ArrayUtils.remove(IntStream.range(0, this.k + this.cities.length).toArray(),i + this.k));
        }
    }

    public void set_up_6_cities(int k){
        this.k = k;
        this.distance = new int[][]{{0,2,4,5,1,2},
                                    {2,0,3,6,3,2},
                                    {4,3,0,1,2,2},
                                    {5,6,1,0,9,2},
                                    {1,3,2,9,0,2},
                                    {2,2,2,2,2,0}};
        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.cities = new IntVar[5];
        this.depot = this.model.intVarArray("depot", this.k,this.k,this.k + this.cities.length - 1);
        for (int i = 0 ; i < this.cities.length; i++) {
            this.cities[i] = this.model.intVar("cities[" + i + "]",
                    ArrayUtils.remove(IntStream.range(0, this.k + this.cities.length).toArray(),i + this.k));
        }
    }

    public void set_up_7_cities(int k){
        this.k = k;
        this.distance = new int[][]{{0,2,4,5,1,2,1},
                {2,0,3,6,3,2,1},
                {4,3,0,1,2,2,1},
                {5,6,1,0,9,2,1},
                {1,3,2,9,0,2,1},
                {2,2,2,2,2,0,1},
                {1,1,1,1,1,1,0}};
        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.cities = new IntVar[6];
        this.depot = this.model.intVarArray("depot", this.k,this.k,this.k + this.cities.length - 1 );
        for (int i = 0 ; i < this.cities.length; i++) {
            this.cities[i] = this.model.intVar("cities[" + i + "]",
                    ArrayUtils.remove(IntStream.range(0, this.k + this.cities.length).toArray(),i + this.k));
        }
    }

    public void set_up_8_cities(int k){
        this.k = k;
        this.distance = new int[][]{
                {0,2,4,5,1,2,1,10},
                {2,0,3,6,3,2,1,1},
                {4,3,0,1,2,2,1,1},
                {5,6,1,0,9,2,1,1},
                {1,3,2,9,0,2,1,1},
                {2,2,2,2,2,0,1,1},
                {1,1,1,1,1,1,0,1},
                {10,1,1,1,1,1,1,0}};
        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.cities = this.model.intVarArray(7,0,7);
        this.depot = this.model.intVarArray(this.k,1,7);
    }

    public void set_up_9_cities(int k){
        this.k = k;
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[8];
        this.depot = this.model.intVarArray("depot", this.k,this.k,this.k + this.cities.length - 1);
        for (int i = 0 ; i < this.cities.length; i++) {
            this.cities[i] = this.model.intVar("cities[" + i + "]",
                    ArrayUtils.remove(IntStream.range(0, this.k + this.cities.length).toArray(),i + this.k));
        }
    }


    public int count_solutions(int k, int n) {
        if ((k == n - 1) || k == 1) {
            return factorial(n - 1);
        }
        if (k > n-1 || n == 1) {
            return 0;
        }
        int number_solutions = 0;
        for (int i = 1 ; i <= n - k ; i++) {
            number_solutions += combination(i, n - 1) * factorial(i) * count_solutions(k - 1, n - i);
        }
        return number_solutions;
    }

    public static int[][] read_instances(String filename) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        line = reader.readLine();
        int number_adresses = Integer.parseInt(line);
        int[][] distance = new int[number_adresses][number_adresses];
        int row = 0;
        while ((line = reader.readLine()) != null)
        {
            Scanner scan = new Scanner(line);
            scan.useLocale(Locale.US);
            for (int i = 0 ; i < number_adresses; i++) {
                distance[row][i] = ((int) scan.nextFloat());
            }
            row++;
        }

        for(int i = 0 ; i < distance.length; i++) {
            for (int j = 0 ; j < i; j++) {
                int max = Math.max(distance[i][j], distance[j][i]);
                distance[i][j] = max;
                distance[j][i] = max;
            }
        }
        return distance;

    }

    public int factorial(int n) {
        assert n >= 0;
        if (n == 1 || n == 0) {
            return 1;
        }
        return n * factorial(n - 1);
    }

    public int combination(int k, int n) {
        assert k >= 0;
        assert k <= n;
        if (k == 0) {
            return 1;
        }
        if (2 * k > n) {
            return combination(n - k, n);
        }
        return combination(k - 1, n - 1) * n / k ;
    }

    private int calculate_sum_all_distance() {
        int sum = 0;
        for (int i = 0; i < this.distance.length ; i ++ ) {
            for (int j = 0 ; j < this.distance[i].length ; j++) {
                sum += distance[i][j];
            }
        }
        return sum;
    }

    private int solve_by_cycle(int num_cities, int num_trucks) throws ContradictionException {
        Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,0));
        this.model.post(c);
        Solver solver = this.model.getSolver();
        int min = Integer.MAX_VALUE;
        while(solver.solve()){
            int cost = calculate_cost_of_the_solution_max_cycle();
            if( min > cost){
                min = cost;
            }
        }
        solver.findAllSolutions();
        assertEquals(solver.getMeasures().getSolutionCount() / factorial(num_trucks), count_solutions(num_trucks,num_cities));
        return min;
    }


    @Test
    public void testFactorial() throws Exception {
        assertEquals(factorial(5), 120);
        assertEquals(factorial(4), 24);
        assertEquals(factorial(6), 720);
        assertEquals(factorial(0), 1);
        assertEquals(factorial(1), 1);
        try {
            factorial(-1);
        }
        catch (AssertionError e){
        }
    }

    @Test
    public void testCombination() throws Exception {
        assertEquals(combination(5,5), 1);
        assertEquals(combination(1,5), 5);
        assertEquals(combination(3,5), 10);
        assertEquals(combination(2,5), 10);
        assertEquals(combination(4,5), 5);
        assertEquals(combination(0,5), 1);
        try {
            combination(-3,1);
        }
        catch (AssertionError e){
        }
        try {
            combination(4,8);
        }
        catch (AssertionError e){
        }
    }


    int calculate_cost_of_the_solution_max_cycle() {
        int total_one_cycle = 0;
        int max_cycle = 0;
        for (int i = 0; i < this.depot.length; i++) {
            total_one_cycle = 0;
            int current_position = 0;
            int next_position = this.depot[i].getValue();
            total_one_cycle += this.distance[0][next_position - this.k + 1];
            current_position = next_position;
            next_position = this.cities[next_position - this.k].getValue();
            while (next_position >= this.k) {
                total_one_cycle += this.distance[current_position - this.k  + 1][next_position - this.k  + 1];
                current_position = next_position;
                next_position = this.cities[next_position - this.k].getValue();
            }
            total_one_cycle += distance[current_position - this.k  + 1][0];
            max_cycle = Math.max(max_cycle, total_one_cycle);
        }
        return max_cycle;
    }


    @Test
    public void testCircuits_4_cities_number_solutions() throws Exception {
        int num_cities = 4;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_4_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,1));
            this.model.post(c);
            Solver solver = this.model.getSolver();
            solver.findAllSolutions();
            assertEquals(count_solutions(num_trucks,num_cities),solver.getSolutionCount()  / factorial(num_trucks));
        }
    }

    @Test
    public void testCircuits_5_cities_number_solutions() throws Exception {
        int num_cities = 5;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_5_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,1));
            this.model.post(c);
            Solver solver = this.model.getSolver();
            solver.findAllSolutions();
            assertEquals(count_solutions(num_trucks,num_cities),solver.getSolutionCount()  / factorial(num_trucks));
        }
    }

    @Test
    public void testCircuits_6_cities_number_solutions() throws Exception {
        int num_cities = 6;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_6_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,1));
            this.model.post(c);
            Solver solver = this.model.getSolver();
            solver.findAllSolutions();
            assertEquals(count_solutions(num_trucks,num_cities),solver.getSolutionCount()  / factorial(num_trucks));
        }
    }


    @Test
    public void testCircuits_4_cities_solmin() throws Exception {
        int num_cities = 4;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_4_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_4_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,0));
            this.model.post(c);
            this.model.setObjective(Model.MINIMIZE, this.L);
            Solver solver = this.model.getSolver();
            while (solver.solve()){
            }
            assertEquals(min,solver.getBestSolutionValue());
        }
    }

    @Test
    public void testCircuits_5_cities_solmin() throws Exception {
        int num_cities = 5;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_5_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_5_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,0));
            this.model.post(c);
            this.model.setObjective(Model.MINIMIZE, this.L);
            Solver solver = this.model.getSolver();
            while (solver.solve()){
            }
            assertEquals(min,solver.getBestSolutionValue());
        }
    }

    @Test
    public void testCircuits_6_cities_solmin() throws Exception {
        int num_cities = 6;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_6_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_6_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,0));
            this.model.post(c);
            this.model.setObjective(Model.MINIMIZE, this.L);
            Solver solver = this.model.getSolver();
            while (solver.solve()){
            }
            assertEquals(min,solver.getBestSolutionValue());
        }
    }


    @Test
    public void testCircuits_4_cities_choco_et_circuits() throws Exception {
        int num_cities = 4;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_4_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_4_cities(num_trucks);
            Parameters param = new Parameters("allo",4,0,num_cities - 1,num_trucks,this.distance);
            assertEquals(min,param.getModel().getSolver().getBestSolutionValue());
        }
    }

    @Test
    public void testCircuits_5_cities_choco_et_circuits() throws Exception {
        int num_cities = 5;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_5_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_5_cities(num_trucks);
            Parameters param = new Parameters("allo",4,0,num_cities - 1,num_trucks,this.distance);
            assertEquals(min,param.getModel().getSolver().getBestSolutionValue());
        }
    }

    @Test
    public void testCircuits_6_cities_choco_et_circuits() throws Exception {
        int num_cities = 6;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_6_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_6_cities(num_trucks);
            Parameters param = new Parameters("allo",4,0,num_cities - 1,num_trucks,this.distance);
            assertEquals(min,param.getModel().getSolver().getBestSolutionValue());
        }
    }


    @Test
    public void testCreate_edges_from_depot() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        assertEquals(4, edges.size());
    }

    @Test
    public void testCreate_edges_from_depot2() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        assertEquals(4, edges.size());
    }

    @Test
    public void testCreate_edges_between_cities() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_between_cities();
        assertEquals(6, edges.size());
    }

    @Test
    public void testCreate_edges_between_cities2() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_between_cities();
        assertEquals(6, edges.size());
    }

    @Test
    public void testEdges_after_different_from_0() throws ContradictionException {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = new ArrayList();

        Edge edge01 = new Edge(0,1,2);
        Edge edge02 = new Edge(0,2,2);
        Edge edge03 = new Edge(0,3,2);
        Edge edge14 = new Edge(1,4,2);
        Edge edge15 = new Edge(1,5,2);

        edges.add(edge01);
        edges.add(edge02);
        edges.add(edge03);
        edges.add(edge14);
        edges.add(edge15);

        Pair result = circuit.edges_after_different_from_0(edges,0);
        assertEquals(false, (boolean) result.getKey());

        result = circuit.edges_after_different_from_0(edges,1);
        assertEquals(true, (boolean) result.getKey());
        assertEquals(2, (int) result.getValue());

        result = circuit.edges_after_different_from_0(edges,2);
        assertEquals(true, (boolean) result.getKey());
        assertEquals(1, (int) result.getValue());



    }

    @Test
    public void testKruskal() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_4_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] spanning_tree = (ArrayList<Edge>[]) circuit.kruskal(edges, true).getKey();
        int sum = 0;
        int cost = 0;
        for (int i = 0 ; i < spanning_tree.length ; i++ ) {
            sum += spanning_tree[i].size();
            for (int j = 0 ; j < spanning_tree[i].size(); j++) {
                cost += spanning_tree[i].get(j).cost();
            }
        }
        assertEquals(3, sum / 2);
        assertEquals(6, cost/2);
    }

    @Test
    public void testKruskal2() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] spanning_tree = (ArrayList<Edge>[]) circuit.kruskal(edges, true).getKey();
        int sum = 0;
        int cost = 0;
        for (int i = 0 ; i < spanning_tree.length ; i++ ) {
            sum += spanning_tree[i].size();
            for (int j = 0 ; j < spanning_tree[i].size(); j++) {
                cost += spanning_tree[i].get(j).cost();
            }
        }
        assertEquals(4, sum / 2);
        assertEquals(6, cost / 2);


    }

    @Test
    public void testKruskal3() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] spanning_tree = (ArrayList<Edge>[]) circuit.kruskal(edges, true).getKey();
        int sum = 0;
        int cost = 0;
        for (int i = 0 ; i < spanning_tree.length ; i++ ) {
            sum += spanning_tree[i].size();
            for (int j = 0 ; j < spanning_tree[i].size(); j++) {
                cost += spanning_tree[i].get(j).cost();
            }
        }
        assertEquals(5, sum / 2);
        assertEquals(8, cost / 2);

    }

    @Test
    public void textFind_max_cost_on_a_path() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[6];
        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,4);
        Edge edge12 = new Edge(1,2,5);
        Edge edge13 = new Edge(1,3,3);
        Edge edge14 = new Edge(1,4,8);
        Edge edge45 = new Edge(4,5,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge14);
        edges[4].add(edge14);
        edges[4].add(edge45);
        edges[5].add(edge45);

        assertEquals(4, circuit.find_max_cost_on_a_path(0,1,edges));
        assertEquals(5, circuit.find_max_cost_on_a_path(0,2,edges));
        assertEquals(4, circuit.find_max_cost_on_a_path(0,3,edges));
        assertEquals(8, circuit.find_max_cost_on_a_path(0,4,edges));
        assertEquals(8, circuit.find_max_cost_on_a_path(0,5,edges));
        assertEquals(8, circuit.find_max_cost_on_a_path(1,5,edges));
        assertEquals(2, circuit.find_max_cost_on_a_path(4,5,edges));
    }


    @Test
    public void testK_tree_increase() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_4_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L, 1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] min_spanning_tree = (ArrayList<Edge>[]) circuit.k_tree(edges).getKey();
        int sum = 0;
        for (int i = 0 ; i <min_spanning_tree.length ; i++ ) {
            sum += min_spanning_tree[i].size();
        }
        assertEquals(3, sum/2);
        assertEquals(num_trucks, min_spanning_tree[0].size());
    }
    @Test
    public void testK_tree_increase2() throws Exception {

        int num_trucks = 3;
        this.model = new Model();
        set_up_4_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L, 1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] min_spanning_tree = (ArrayList<Edge>[]) circuit.k_tree(edges).getKey();
        int sum = 0;
        for (int i = 0 ; i <min_spanning_tree.length ; i++ ) {
            sum += min_spanning_tree[i].size();
        }
        assertEquals(3, sum/2);
        assertEquals(num_trucks, min_spanning_tree[0].size());
    }

    @Test
    public void testK_tree_decrease() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        this.distance = new int[][] {
                {0,4,1,1,4},
                {4,0,2,2,3},
                {1,2,0,3,3},
                {1,2,3,0,2},
                {4,3,3,2,0}};
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L, 1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] min_spanning_tree = (ArrayList<Edge>[]) circuit.k_tree(edges).getKey();
        int sum = 0;
        for (int i = 0 ; i <min_spanning_tree.length ; i++ ) {
            sum += min_spanning_tree[i].size();
        }
        assertEquals(4, sum/2);
        assertEquals(num_trucks, min_spanning_tree[0].size());
    }

    @Test
    public void testK_tree_decrease2() throws Exception {
        int num_trucks = 1;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        this.distance = new int[][] {
                {0,1,1,1,4},
                {1,0,2,2,3},
                {1,2,0,3,3},
                {1,2,3,0,2},
                {4,3,3,2,0}};
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L, 1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] min_spanning_tree = (ArrayList<Edge>[]) circuit.k_tree(edges).getKey();
        int sum = 0;
        for (int i = 0 ; i <min_spanning_tree.length ; i++ ) {
            sum += min_spanning_tree[i].size();
        }
        assertEquals(4, sum/2);
        assertEquals(num_trucks, min_spanning_tree[0].size());
    }

    @Test
    public void testK_tree_decrease3() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        this.distance = new int[][] {
                {0,1,1,1,4},
                {1,0,2,2,3},
                {1,2,0,3,3},
                {1,2,3,0,2},
                {4,3,3,2,0}};
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L, 1);
        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        ArrayList<Edge>[] min_spanning_tree = (ArrayList<Edge>[]) circuit.k_tree(edges).getKey();
        int sum = 0;
        for (int i = 0 ; i <min_spanning_tree.length ; i++ ) {
            sum += min_spanning_tree[i].size();
        }
        assertEquals(4, sum/2);
        assertEquals(num_trucks, min_spanning_tree[0].size());
    }

    @Test
    public void testRemove_depot_from_spanning_tree() throws ContradictionException {
        int num_trucks = 1;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[6];
        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,4);
        Edge edge02 = new Edge(0,2,5);
        Edge edge13 = new Edge(1,3,3);
        Edge edge14 = new Edge(1,4,8);
        Edge edge45 = new Edge(4,5,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge02);
        edges[2].add(edge02);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge14);
        edges[4].add(edge14);
        edges[4].add(edge45);
        edges[5].add(edge45);

        ArrayList<Edge>[] edge_whitout_depot = circuit.remove_depot(edges);

        assertEquals(0, edge_whitout_depot[0].size());
        assertEquals(2, edge_whitout_depot[1].size());
        assertEquals(0, edge_whitout_depot[2].size());
        assertEquals(1, edge_whitout_depot[3].size());
        assertEquals(2, edge_whitout_depot[4].size());
        assertEquals(1, edge_whitout_depot[5].size());
    }

    @Test
    public void testCalcule_weigth_tree() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[6];
        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,4);
        Edge edge02 = new Edge(0,2,5);
        Edge edge13 = new Edge(1,3,3);
        Edge edge14 = new Edge(1,4,8);
        Edge edge25 = new Edge(2,5,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge02);
        edges[2].add(edge02);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge14);
        edges[4].add(edge14);
        edges[2].add(edge25);
        edges[5].add(edge25);

        int[] weigth = circuit.calcule_weigth_tree(edges);
        assertEquals(0, weigth[0]);
        assertEquals(9, weigth[1]);
        assertEquals(2, weigth[2]);
        assertEquals(0, weigth[3]);
        assertEquals(0, weigth[4]);
        assertEquals(0, weigth[5]);

    }

    @Test
    public void testDepth_first_search() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[6];
        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,4);
        Edge edge02 = new Edge(0,2,5);
        Edge edge13 = new Edge(1,3,3);
        Edge edge14 = new Edge(1,4,8);
        Edge edge25 = new Edge(2,5,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge02);
        edges[2].add(edge02);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge14);
        edges[4].add(edge14);
        edges[2].add(edge25);
        edges[5].add(edge25);

        ArrayList<Edge>[] edges_without_zero = circuit.remove_depot(edges.clone());

        int[] parent = circuit.depth_first_search(edges_without_zero, edges[0]);
        assertEquals(0, parent[0]);
        assertEquals(0, parent[1]);
        assertEquals(0, parent[2]);
        assertEquals(1, parent[3]);
        assertEquals(1, parent[4]);
        assertEquals(2, parent[5]);

    }

    @Test
    public void testCalculate_borne() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_5_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        Pair result = circuit.k_tree(edges);
        ArrayList<Edge>[] k_tree = (ArrayList<Edge>[]) result.getKey();
        ArrayList<Edge>[] other_edges = (ArrayList<Edge>[]) result.getValue();


        ArrayList<Edge>[] all_edges = other_edges.clone();
        for (int i = 0 ; i < all_edges.length ; i++) {
            all_edges[i].addAll((Collection<? extends Edge>) k_tree[i].clone());
        }

        ArrayList<Edge>[] all_edges_without_depot = circuit.remove_depot(all_edges.clone());

        int[] tree_parent = circuit.depth_first_search(all_edges_without_depot, k_tree[0]);
        int[] tree_weight = circuit.calcule_weigth_tree(k_tree);

        int borne = circuit.calculate_borne(tree_parent,tree_weight, (ArrayList<Edge>) k_tree[0].clone());
        assertEquals(3,borne);
    }

    @Test
    public void testCalculate_borne2() throws Exception {
        int num_trucks = 2;
        this.k = num_trucks;
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[4];
        this.depot = this.model.intVarArray("depot[" + 1 + "[",this.k, new int[]{2,4,5});
        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0,1});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{4,5});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{0,1,3,5});
        this.cities[3] = this.model.intVar("cities[" + 3 + "]",new int[]{0,1,3,4});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        Pair result = circuit.k_tree(edges);
        ArrayList<Edge>[] k_tree = (ArrayList<Edge>[]) result.getKey();
        ArrayList<Edge>[] other_edges = (ArrayList<Edge>[]) result.getValue();


        ArrayList<Edge>[] all_edges = other_edges.clone();
        for (int i = 0 ; i < all_edges.length ; i++) {
            all_edges[i].addAll((Collection<? extends Edge>) k_tree[i].clone());
        }

        ArrayList<Edge>[] all_edges_without_depot = circuit.remove_depot(all_edges.clone());

        int[] tree_parent = circuit.depth_first_search(all_edges_without_depot, k_tree[0]);
        int[] tree_weight = circuit.calcule_weigth_tree(k_tree);

        int borne = circuit.calculate_borne(tree_parent,tree_weight, (ArrayList<Edge>) k_tree[0].clone());
        assertEquals(4,borne);
    }


    @Test
    public void testCircuits_4_cities_solmin_updateLB() throws Exception {
        int num_cities = 4;
        for (int num_trucks = 1 ; num_trucks < 4 ; num_trucks++) {
            this.model = new Model();
            set_up_4_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_4_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,1));
            this.model.post(c);
            this.model.setObjective(Model.MINIMIZE, this.L);
            Solver solver = this.model.getSolver();
            while (solver.solve()){
            }
            assertEquals(min,solver.getBestSolutionValue());
        }
    }

    @Test
    public void testCircuits_5_cities_solmin_updateLB() throws Exception {
        int num_cities = 5;
        for (int num_trucks = 1 ; num_trucks < num_cities ; num_trucks++) {
            this.model = new Model();
            set_up_5_cities(num_trucks);
            int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_5_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,1));
            this.model.post(c);
            this.model.setObjective(Model.MINIMIZE, this.L);
            Solver solver = this.model.getSolver();
            while (solver.solve()){
            }
            assertEquals(min,solver.getBestSolutionValue());
        }
    }

    @Test
    public void testCircuits_6_cities_solmin_updateLB() throws Exception {
        int num_cities = 6;
        for (int num_trucks = 5 ; num_trucks < 6 ; num_trucks++) {
            this.model = new Model();
            set_up_6_cities(num_trucks);
            //int min = solve_by_cycle(num_cities, num_trucks);
            this.model = new Model();
            set_up_6_cities(num_trucks);
            Constraint c = new Constraint("MyConstraint", new Circuits(this.cities, this.depot, this.distance,
                    this.k, this.L,1));
            this.model.post(c);
            this.model.setObjective(Model.MINIMIZE, this.L);
            Solver solver = this.model.getSolver();
            while (solver.solve()){
            }
            assertEquals(28,solver.getBestSolutionValue());
        }
    }
    @Test
    public void testBug_ktree1() throws Exception {
        int num_trucks = 1;
        this.k = num_trucks;
        this.distance = new int[][]{{0,2,4,5},
                {2,0,3,6},
                {4,3,0,1},
                {5,6,1,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[3];
        this.depot = this.model.intVarArray("depot[" + 1 + "[",this.k, new int[]{1});
        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{0});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{0});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        try {
            Pair result = circuit.k_tree(edges);
            assertTrue(false);
        }
        catch (ContradictionException e) {
            assertTrue(true);
        }

    }

    @Test
    public void testBug_ktree2() throws Exception {
        int num_trucks = 1;
        this.k = num_trucks;
        this.distance = new int[][]{{0,2,4,5},
                {2,0,3,6},
                {4,3,0,1},
                {5,6,1,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[3];
        this.depot = this.model.intVarArray("depot[" + 1 + "[",this.k, new int[]{1});
        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{0});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{1});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        try {
            Pair result = circuit.k_tree(edges);
            assertTrue(false);
        }
        catch (ContradictionException e) {
            assertTrue(true);
        }

    }

    @Test
    public void testBug_ktree3() throws Exception {
        int num_trucks = 2;
        this.k = num_trucks;
        this.distance = new int[][]{{0,2,4,5},
                {2,0,3,6},
                {4,3,0,1},
                {5,6,1,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[3];
        this.depot = new IntVar[2];
        this.depot[0] = this.model.intVar("depot[" + 1 + "[", new int[]{2});
        this.depot[1] = this.model.intVar("depot[" + 1 + "[", new int[]{2});

        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{2});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{2,3});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        try {
            Pair result = circuit.k_tree(edges);
            assertTrue(false);
        }
        catch (ContradictionException e) {
            assertTrue(true);
        }

    }
    @Test
    public void testBug_ktree4() throws Exception {
        int num_trucks = 1;
        this.k = num_trucks;
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[4];
        this.depot = new IntVar[1];
        this.depot[0] = this.model.intVar("depot[" + 1 + "[", new int[]{1});

        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{3});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{1,2,4});
        this.cities[3] = this.model.intVar("cities[" + 2 + "]",new int[]{0});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        Pair result = circuit.k_tree(edges);
        ArrayList<Edge>[] spanning = (ArrayList<Edge>[]) result.getKey();
        assertEquals(spanning[0].size(), 1);
        assertEquals(spanning[1].size(), 1);
        assertEquals(spanning[2].size(), 1);
        assertEquals(spanning[3].size(), 3);
        assertEquals(spanning[4].size(), 2);


    }

    @Test
    public void testBug_ktree5() throws Exception {
        int num_trucks = 1;
        this.k = num_trucks;
        this.distance = new int[][]{{0,2,4,5,1,2},
                {2,0,3,6,3,2},
                {4,3,0,1,2,2},
                {5,6,1,0,9,2},
                {1,3,2,9,0,2},
                {2,2,2,2,2,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[5];
        this.depot = new IntVar[1];
        this.depot[0] = this.model.intVar("depot[" + 1 + "[", new int[]{1});

        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{1});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{4,5});
        this.cities[3] = this.model.intVar("cities[" + 3 + "]",new int[]{0});
        this.cities[4] = this.model.intVar("cities[" + 4 + "]",new int[]{4});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        try {
            Pair result = circuit.k_tree(edges);
            ArrayList<Edge>[] spanning = (ArrayList<Edge>[]) result.getKey();
            assertTrue(false);
        }
        catch (ContradictionException e) {
            assertTrue(true);
        }

    }

    @Test
    public void testBug_ktree6() throws Exception {
        int num_trucks = 3;
        this.k = num_trucks;
        this.distance = new int[][]{{0,2,4,5,1,2},
                {2,0,3,6,3,2},
                {4,3,0,1,2,2},
                {5,6,1,0,9,2},
                {1,3,2,9,0,2},
                {2,2,2,2,2,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[5];
        this.depot = new IntVar[3];
        this.depot[0] = this.model.intVar("depot[" + 1 + "[", new int[]{3});
        this.depot[1] = this.model.intVar("depot[" + 2 + "[", new int[]{3});
        this.depot[2] = this.model.intVar("depot[" + 3 + "[", new int[]{3});

        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{5,6,7});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{6,7});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{0});
        this.cities[3] = this.model.intVar("cities[" + 3 + "]",new int[]{0});
        this.cities[4] = this.model.intVar("cities[" + 4 + "]",new int[]{0});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        Pair result = circuit.k_tree(edges);
        ArrayList<Edge>[] spanning = (ArrayList<Edge>[]) result.getKey();
        assertEquals(3,spanning[0].size());
    }


    @Test
    public void testFind_max_edge_leaving_0_connected() throws Exception {
        int num_trucks = 1;
        this.k = num_trucks;
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.model = new Model();
        this.L = this.model.intVar("L",0,calculate_sum_all_distance());
        this.cities =  new IntVar[4];
        this.depot = new IntVar[1];
        this.depot[0] = this.model.intVar("depot[" + 1 + "[", new int[]{1});

        this.cities[0] = this.model.intVar("cities[" + 0 + "]",new int[]{0});
        this.cities[1] = this.model.intVar("cities[" + 1 + "]",new int[]{3});
        this.cities[2] = this.model.intVar("cities[" + 2 + "]",new int[]{1,2,4});
        this.cities[3] = this.model.intVar("cities[" + 2 + "]",new int[]{0});


        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);

        ArrayList<Edge> edges = circuit.create_edges_from_depot();
        edges.addAll(circuit.create_edges_between_cities());
        Pair kruskal = circuit.kruskal(edges,false);
        int from3 = circuit.find_max_edge_leaving_0_connected(3, (ArrayList<Edge>[]) kruskal.getKey());
        int from4 = circuit.find_max_edge_leaving_0_connected(4, (ArrayList<Edge>[]) kruskal.getKey());

        assertEquals(2, from3);
        assertEquals(1, from4);

    }

    @Test
    public void verify_change() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[6];
        ArrayList<Edge>[] edges_copie = new ArrayList[6];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            edges_copie[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,4);
        Edge edge02 = new Edge(0,2,5);
        Edge edge13 = new Edge(1,3,3);
        Edge edge14 = new Edge(1,4,8);
        Edge edge25 = new Edge(2,5,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge02);
        edges[2].add(edge02);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge14);
        edges[4].add(edge14);
        edges[2].add(edge25);
        edges[5].add(edge25);

        edges_copie[0].add(edge01);
        edges_copie[1].add(edge01);
        edges_copie[0].add(edge02);
        edges_copie[2].add(edge02);
        edges_copie[1].add(edge13);
        edges_copie[3].add(edge13);
        edges_copie[1].add(edge14);
        edges_copie[4].add(edge14);
        edges_copie[2].add(edge25);
        edges_copie[5].add(edge25);
    }

    @Test
    public void verify_change2() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[6];
        ArrayList<Edge>[] edges_copie = new ArrayList[6];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            edges_copie[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,4);
        Edge edge02 = new Edge(0,2,5);
        Edge edge13 = new Edge(1,3,3);
        Edge edge14 = new Edge(1,4,8);
        Edge edge25 = new Edge(2,5,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge02);
        edges[2].add(edge02);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge14);
        edges[4].add(edge14);
        edges[2].add(edge25);
        edges[5].add(edge25);

        edges_copie[0].add(edge01);
        edges_copie[1].add(edge01);
        edges_copie[0].add(edge02);
        edges_copie[2].add(edge02);
        edges_copie[1].add(edge13);
        edges_copie[3].add(edge13);
        edges_copie[1].add(edge14);
        edges_copie[2].add(edge25);
        edges_copie[5].add(edge25);
        assertTrue(!circuit.verify_change(edges_copie,edges));
    }


    @Test
    public void simpleswtich() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[4];
        ArrayList<Edge>[] other_edges = new ArrayList[4];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge23 = new Edge(2,3,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge03);
        edges[3].add(edge03);
        edges[1].add(edge12);
        edges[2].add(edge12);
        other_edges[2].add(edge23);
        other_edges[3].add(edge23);

        ArrayList<Edge> simpleSwitch = circuit.simple_switch(edges,other_edges);

        assertEquals(2,simpleSwitch.size());
        assertEquals(3,simpleSwitch.get(1).target());
        assertEquals(2,simpleSwitch.get(1).source());
        assertEquals(0,simpleSwitch.get(0).source());
        assertEquals(3,simpleSwitch.get(0).target());

    }

    @Test
    public void simpleswtich2() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[4];
        ArrayList<Edge>[] other_edges = new ArrayList[4];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge23 = new Edge(2,3,3);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge03);
        edges[3].add(edge03);
        edges[1].add(edge12);
        edges[2].add(edge12);
        other_edges[2].add(edge23);
        other_edges[3].add(edge23);

        ArrayList<Edge> simpleSwitch = circuit.simple_switch(edges,other_edges);

        assertEquals(0,simpleSwitch.size());
    }

    @Test
    public void simpleswtich3() throws Exception {
        int num_trucks = 3;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[5];
        ArrayList<Edge>[] other_edges = new ArrayList[5];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,2);
        Edge edge04 = new Edge(0,4,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge23 = new Edge(2,3,2);
        Edge edge24 = new Edge(2,4,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge03);
        edges[3].add(edge03);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[1].add(edge12);
        edges[2].add(edge12);
        other_edges[2].add(edge23);
        other_edges[3].add(edge23);
        other_edges[2].add(edge24);
        other_edges[4].add(edge24);
        ArrayList<Edge> simpleSwitch = circuit.simple_switch(edges,other_edges);

        assertEquals(4,simpleSwitch.size());
        assertEquals(3,simpleSwitch.get(1).target());
        assertEquals(2,simpleSwitch.get(1).source());
        assertEquals(0,simpleSwitch.get(0).source());
        assertEquals(3,simpleSwitch.get(0).target());

        assertEquals(0,simpleSwitch.get(2).source());
        assertEquals(4,simpleSwitch.get(2).target());
        assertEquals(2,simpleSwitch.get(3).source());
        assertEquals(4,simpleSwitch.get(3).target());
    }

    @Test
    public void simpleswtich4() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[5];
        ArrayList<Edge>[] other_edges = new ArrayList[5];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,2);
        Edge edge04 = new Edge(0,4,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge23 = new Edge(2,3,2);
        Edge edge24 = new Edge(2,4,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge03);
        edges[3].add(edge03);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[1].add(edge12);
        edges[2].add(edge12);
        other_edges[2].add(edge23);
        other_edges[3].add(edge23);
        other_edges[2].add(edge24);
        other_edges[4].add(edge24);
        ArrayList<Edge> simpleSwitch = circuit.simple_switch(edges,other_edges);

        assertEquals(2,simpleSwitch.size());
        assertEquals(3,simpleSwitch.get(1).target());
        assertEquals(2,simpleSwitch.get(1).source());
        assertEquals(0,simpleSwitch.get(0).source());
        assertEquals(3,simpleSwitch.get(0).target());
    }

    @Test
    public void made_the_switch() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[4];
        ArrayList<Edge>[] other_edges = new ArrayList[4];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge23 = new Edge(2,3,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge03);
        edges[3].add(edge03);
        edges[1].add(edge12);
        edges[2].add(edge12);
        other_edges[2].add(edge23);
        other_edges[3].add(edge23);

        ArrayList<Edge> simpleSwitch = circuit.simple_switch(edges,other_edges);
        circuit.make_the_switch(edges,other_edges,simpleSwitch);

        assertEquals(1, edges[0].size());
        assertEquals(2, edges[1].size());
        assertEquals(2, edges[2].size());
        assertEquals(1, edges[3].size());

        assertEquals(1, other_edges[0].size());
        assertEquals(0, other_edges[1].size());
        assertEquals(0, other_edges[2].size());
        assertEquals(1, other_edges[3].size());


    }

    @Test
    public void testfind_edge_to_add_and_to_remove() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[7];
        ArrayList<Edge>[] other_edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,4);
        Edge edge04 = new Edge(0,4,2);
        Edge edge06 = new Edge(0,6,6);
        Edge edge12 = new Edge(1,2,1);
        Edge edge13 = new Edge(1,3,1);
        Edge edge35 = new Edge(3,5,3);
        Edge edge45 = new Edge(4,5,4);
        Edge edge56 = new Edge(5,6,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[4].add(edge45);
        edges[5].add(edge45);
        edges[5].add(edge56);
        edges[6].add(edge56);
        other_edges[0].add(edge03);
        other_edges[3].add(edge03);
        other_edges[0].add(edge06);
        other_edges[6].add(edge06);
        other_edges[3].add(edge35);
        other_edges[5].add(edge35);
        ArrayList<Edge>[] edges_clone = edges.clone();

        Edge[] predecessor = circuit.get_predecessors_edges(edge35.source(), edge35.target(), edges);
        Edge edge_max = circuit.get_max_edge_from_predecessors_edges(edge35.source(),edge35.target(),predecessor);
        assertEquals(edge_max,edge45);

        circuit.find_edge_to_add_and_to_remove(edge35,edges,other_edges,edge_max,edges_clone);
        assertEquals(2,edges_clone[0].size());
        assertEquals(3,edges_clone[1].size());
        assertEquals(1,edges_clone[2].size());
        assertEquals(2,edges_clone[3].size());
        assertEquals(1,edges_clone[4].size());
        assertEquals(2,edges_clone[5].size());
        assertEquals(1,edges_clone[6].size());

    }

    @Test
    public void testfind_edge_to_add_and_to_remove2() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[7];
        ArrayList<Edge>[] other_edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,4);
        Edge edge04 = new Edge(0,4,2);
        Edge edge06 = new Edge(0,6,6);
        Edge edge12 = new Edge(1,2,1);
        Edge edge13 = new Edge(1,3,1);
        Edge edge35 = new Edge(3,5,3);
        Edge edge45 = new Edge(4,5,1);
        Edge edge56 = new Edge(5,6,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[4].add(edge45);
        edges[5].add(edge45);
        edges[5].add(edge56);
        edges[6].add(edge56);
        other_edges[0].add(edge03);
        other_edges[3].add(edge03);
        other_edges[0].add(edge06);
        other_edges[6].add(edge06);
        other_edges[3].add(edge35);
        other_edges[5].add(edge35);
        ArrayList<Edge>[] edges_clone = edges.clone();

        Edge[] predecessor = circuit.get_predecessors_edges(edge35.source(), edge35.target(), edges);
        Edge edge_max = circuit.get_max_edge_from_predecessors_edges(edge35.source(),edge35.target(),predecessor);
        assertEquals(edge_max,edge04);

        circuit.find_edge_to_add_and_to_remove(edge35,edges,other_edges,edge_max,edges_clone);
        assertEquals(2,edges_clone[0].size());
        assertEquals(3,edges_clone[1].size());
        assertEquals(1,edges_clone[2].size());
        assertEquals(2,edges_clone[3].size());
        assertEquals(1,edges_clone[4].size());
        assertEquals(2,edges_clone[5].size());
        assertEquals(1,edges_clone[6].size());
    }

    @Test
    public void testfind_edge_to_add_and_to_remove3() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_6_cities(num_trucks);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[9];
        ArrayList<Edge>[] other_edges = new ArrayList[9];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,4);
        Edge edge04 = new Edge(0,4,3);
        Edge edge06 = new Edge(0,6,6);
        Edge edge07 = new Edge(0,7,2);
        Edge edge08 = new Edge(0,8,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge13 = new Edge(1,3,1);
        Edge edge35 = new Edge(3,5,3);
        Edge edge45 = new Edge(4,5,1);
        Edge edge56 = new Edge(5,6,2);
        Edge edge78 = new Edge(7,8,1);


        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[0].add(edge08);
        edges[8].add(edge08);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[4].add(edge45);
        edges[5].add(edge45);
        edges[5].add(edge56);
        edges[6].add(edge56);
        edges[7].add(edge78);
        edges[8].add(edge78);
        other_edges[0].add(edge07);
        other_edges[7].add(edge07);
        other_edges[0].add(edge03);
        other_edges[3].add(edge03);
        other_edges[0].add(edge06);
        other_edges[6].add(edge06);
        other_edges[3].add(edge35);
        other_edges[5].add(edge35);
        ArrayList<Edge>[] edges_clone = edges.clone();

        Edge[] predecessor = circuit.get_predecessors_edges(edge35.source(), edge35.target(), edges);
        Edge edge_max = circuit.get_max_edge_from_predecessors_edges(edge35.source(),edge35.target(),predecessor);
        assertEquals(edge_max,edge04);

        circuit.find_edge_to_add_and_to_remove(edge35,edges,other_edges,edge_max,edges_clone);
        assertEquals(3,edges_clone[0].size());
        assertEquals(3,edges_clone[1].size());
        assertEquals(1,edges_clone[2].size());
        assertEquals(2,edges_clone[3].size());
        assertEquals(1,edges_clone[4].size());
        assertEquals(3,edges_clone[5].size());
        assertEquals(1,edges_clone[6].size());
        assertEquals(1,edges_clone[7].size());
        assertEquals(1,edges_clone[7].size());

    }

    @Test
    public void testnewBorne() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_7_cities(num_trucks);
        this.distance = new int[][]{
                {0,1,0,4,2,0,6},
                {1,0,1,1,0,0,0},
                {0,1,0,0,0,0,0},
                {4,1,0,0,0,5,0},
                {2,0,0,0,0,4,0},
                {0,0,0,5,4,0,2},
                {6,0,0,0,0,2,0}};
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[7];
        ArrayList<Edge>[] other_edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,4);
        Edge edge04 = new Edge(0,4,2);
        Edge edge06 = new Edge(0,6,6);
        Edge edge12 = new Edge(1,2,1);
        Edge edge13 = new Edge(1,3,1);
        Edge edge35 = new Edge(3,5,5);
        Edge edge45 = new Edge(4,5,4);
        Edge edge56 = new Edge(5,6,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[4].add(edge45);
        edges[5].add(edge45);
        edges[5].add(edge56);
        edges[6].add(edge56);
        other_edges[0].add(edge03);
        other_edges[3].add(edge03);
        other_edges[0].add(edge06);
        other_edges[6].add(edge06);
        other_edges[3].add(edge35);
        other_edges[5].add(edge35);
        ArrayList<Edge>[] edges_clone = edges.clone();


        int borne = circuit.calculate_reduce_cost(edge35, edges, other_edges);
        assertEquals(6,borne);
    }

    @Test
    public void testnewBorne2() throws Exception {
        int num_trucks = 2;
        this.model = new Model();
        set_up_7_cities(num_trucks);
        this.distance = new int[][]{
                {0,1,0,4,2,0,6},
                {1,0,1,1,0,0,0},
                {0,1,0,0,0,0,0},
                {4,1,0,0,0,5,0},
                {2,0,0,0,0,1,0},
                {0,0,0,5,1,0,2},
                {6,0,0,0,0,2,0}};
        Circuits circuits = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[7];
        ArrayList<Edge>[] other_edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,4);
        Edge edge04 = new Edge(0,4,2);
        Edge edge06 = new Edge(0,6,6);
        Edge edge12 = new Edge(1,2,1);
        Edge edge13 = new Edge(1,3,1);
        Edge edge35 = new Edge(3,5,3);
        Edge edge45 = new Edge(4,5,1);
        Edge edge56 = new Edge(5,6,2);

        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[4].add(edge45);
        edges[5].add(edge45);
        edges[5].add(edge56);
        edges[6].add(edge56);
        other_edges[0].add(edge03);
        other_edges[3].add(edge03);
        other_edges[0].add(edge06);
        other_edges[6].add(edge06);
        other_edges[3].add(edge35);
        other_edges[5].add(edge35);
        ArrayList<Edge>[] edges_clone = edges.clone();

        int borne = circuits.calculate_reduce_cost(edge35, edges, other_edges);
        assertEquals(6,borne);

    }

    @Test
    public void testnewBorne3() throws Exception {
        int num_trucks = 3;
        this.model = new Model();
        set_up_9_cities(num_trucks);
        this.distance = new int[][]{
                {0,1,0,4,2,0,6,2,2},
                {1,0,1,1,0,0,0,0,0},
                {0,1,0,0,0,0,0,0,0},
                {4,1,0,0,0,5,0,0,0},
                {2,0,0,0,0,1,0,0,0},
                {0,0,0,5,1,0,2,0,0},
                {6,0,0,0,0,2,0,0,0},
                {2,0,0,0,0,0,0,0,1},
                {2,0,0,0,0,0,0,1,0}
        };
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge>[] edges = new ArrayList[9];
        ArrayList<Edge>[] other_edges = new ArrayList[9];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
            other_edges[i] = new ArrayList<>();
        }
        Edge edge01 = new Edge(0,1,1);
        Edge edge03 = new Edge(0,3,4);
        Edge edge04 = new Edge(0,4,3);
        Edge edge06 = new Edge(0,6,6);
        Edge edge07 = new Edge(0,7,2);
        Edge edge08 = new Edge(0,8,2);
        Edge edge12 = new Edge(1,2,1);
        Edge edge13 = new Edge(1,3,1);
        Edge edge35 = new Edge(3,5,3);
        Edge edge45 = new Edge(4,5,1);
        Edge edge56 = new Edge(5,6,2);
        Edge edge78 = new Edge(7,8,1);


        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[0].add(edge04);
        edges[4].add(edge04);
        edges[0].add(edge08);
        edges[8].add(edge08);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[4].add(edge45);
        edges[5].add(edge45);
        edges[5].add(edge56);
        edges[6].add(edge56);
        edges[7].add(edge78);
        edges[8].add(edge78);
        other_edges[0].add(edge07);
        other_edges[7].add(edge07);
        other_edges[0].add(edge03);
        other_edges[3].add(edge03);
        other_edges[0].add(edge06);
        other_edges[6].add(edge06);
        other_edges[3].add(edge35);
        other_edges[5].add(edge35);
        ArrayList<Edge>[] edges_clone = edges.clone();



        int borne = circuit.calculate_reduce_cost(edge35, edges, other_edges);
        assertEquals(11,borne);



    }

    @Test
    public void test_10_instance_1() throws Exception {
        this.distance = read_instances("../nsim/instances/duration_matrix/10adresses/coordinates10-2.txt");
        this.depot = new IntVar[2];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 2,2);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.cities = new IntVar[9];
        this.cities[0] = this.model.intVar("cities["+0+"]",8,8);
        this.cities[1] = this.model.intVar("cities["+1+"]",new int[]{1,5});
        this.cities[2] = this.model.intVar("cities["+2+"]",7,7);
        this.cities[3] = this.model.intVar("cities["+3+"]",new int[]{1,10});
        this.cities[4] = this.model.intVar("cities["+4+"]",3,3);
        this.cities[5] = this.model.intVar("cities["+5+"]",new int[]{5,10});
        this.cities[6] = this.model.intVar("cities["+6+"]",4,4);
        this.cities[7] = this.model.intVar("cities["+7+"]",6,6);
        this.cities[8] = this.model.intVar("cities["+8+"]",9,9);
        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.k = 1;
        Circuits c = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = c.create_edges_from_depot();
        edges.addAll(c.create_edges_between_cities());
        c.k_tree(edges);
    }

    @Test
    public void test_5_instance_1() throws Exception {
        this.distance = read_instances("../nsim/instances/duration_matrix/5adresses/coordinates5-2.txt");
        this.depot = new IntVar[4];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 6,6);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.depot[2] = this.model.intVar("depot[" + 0+"]", 4,4);
        this.depot[3] = this.model.intVar("depot[" + 1+"]", 2,2);
        this.cities = new IntVar[4];
        this.cities[0] = this.model.intVar("cities["+0+"]",new int[]{5});
        this.cities[1] = this.model.intVar("cities["+1+"]",new int[]{7});
        this.cities[2] = this.model.intVar("cities["+2+"]",new int[]{3});
        this.cities[3] = this.model.intVar("cities["+3+"]",new int[]{1});

        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.k = 2;
        Circuits c = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = c.create_edges_from_depot();
        edges.addAll(c.create_edges_between_cities());
        c.k_tree(edges);
    }

    @Test
    public void test_10_instance_2() throws Exception {
        this.distance = read_instances("../nsim/instances/duration_matrix/10adresses/coordinates10-1.txt");
        this.depot = new IntVar[2];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 2,2);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.cities = new IntVar[9];
        this.cities[0] = this.model.intVar("cities["+0+"]",new int[]{6,10});
        this.cities[1] = this.model.intVar("cities["+1+"]",new int[]{4});
        this.cities[2] = this.model.intVar("cities["+2+"]",new int[]{6,8});
        this.cities[3] = this.model.intVar("cities["+3+"]",new int[]{3});
        this.cities[4] = this.model.intVar("cities["+4+"]",new int[]{8,10});
        this.cities[5] = this.model.intVar("cities["+5+"]",new int[]{9});
        this.cities[6] = this.model.intVar("cities["+6+"]",new int[]{7});
        this.cities[7] = this.model.intVar("cities["+7+"]",new int[]{1});
        this.cities[8] = this.model.intVar("cities["+8+"]",new int[]{5});
        this.L = this.model.intVar(0,calculate_sum_all_distance());
        this.k = 1;
        Circuits c = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        ArrayList<Edge> edges = c.create_edges_from_depot();
        edges.addAll(c.create_edges_between_cities());
        c.k_tree(edges);
    }







    @Test
    public void test_new_kruskal() throws  Exception{
        this.distance = read_instances("../nsim/instances/duration_matrix/5adresses/coordinates5-1.txt");
        this.depot = new IntVar[4];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 5,5);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.depot[2] = this.model.intVar("depot[" + 2+"]", 4,4);
        this.depot[3] = this.model.intVar("depot[" + 3+"]", 2,2);
        this.cities = new IntVar[4];
        this.cities[0] = this.model.intVar("cities["+4+"]",new int[]{1});
        this.cities[1] = this.model.intVar("cities["+5+"]",new int[]{6});
        this.cities[2] = this.model.intVar("cities["+6+"]",new int[]{7});
        this.cities[3] = this.model.intVar("cities["+7+"]",new int[]{3});
        IntVar L = this.model.intVar(0,IntVar.MAX_INT_BOUND);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance, 2, L);

    }

    @Test
    public void test_new_create_edges() throws  Exception{
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.depot = new IntVar[4];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 5,5);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.depot[2] = this.model.intVar("depot[" + 2+"]", 4,4);
        this.depot[3] = this.model.intVar("depot[" + 3+"]", 2,2);
        this.cities = new IntVar[4];
        this.cities[0] = this.model.intVar("cities["+4+"]",new int[]{1});
        this.cities[1] = this.model.intVar("cities["+5+"]",new int[]{6});
        this.cities[2] = this.model.intVar("cities["+6+"]",new int[]{7});
        this.cities[3] = this.model.intVar("cities["+7+"]",new int[]{3});
        IntVar L = this.model.intVar(0,IntVar.MAX_INT_BOUND);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance, 2, L);
        int[] sum_component = new int[this.distance.length];
        ArrayList<Edge> edges_cities = new ArrayList<>();
        DisjointSets sets = new DisjointSets(this.distance.length);
        int[] cardinality_components = new int[this.distance.length];
        Edge[] min_weight= new Edge[this.distance.length];
        ArrayList<Edge> min_spanning_tree = new ArrayList<>();
        ArrayList<Edge>[] trees = new ArrayList[this.distance.length];
        for (int i = 0 ; i < trees.length ; i++) {
            trees[i] = new ArrayList<Edge>();
        }
        Arrays.fill(cardinality_components,1);
        int[] weigth_eache_side = new int[this.distance.length];
        DisjointSets sets_each_side = new DisjointSets(this.distance.length);

        Pair edges_and_sets = circuit.create_edges_between_cities_and_disjoint_set(sum_component, edges_cities,sets,
                cardinality_components,min_weight,min_spanning_tree, trees);
        int union = (int) edges_and_sets.getValue();

        assertEquals(2, union);
        assertEquals(0, edges_cities.size());

    }

    @Test
    public void test_new_create_edges2() throws  Exception{
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.depot = new IntVar[4];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 5,5);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.depot[2] = this.model.intVar("depot[" + 2+"]", 4,4);
        this.depot[3] = this.model.intVar("depot[" + 3+"]", 2,2);
        this.cities = new IntVar[4];
        this.cities[0] = this.model.intVar("cities["+4+"]",new int[]{1,6});
        this.cities[1] = this.model.intVar("cities["+5+"]",new int[]{6});
        this.cities[2] = this.model.intVar("cities["+6+"]",new int[]{7});
        this.cities[3] = this.model.intVar("cities["+7+"]",new int[]{3,4});
        IntVar L = this.model.intVar(0,IntVar.MAX_INT_BOUND);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance, 2, L);
        int[] sum_component = new int[this.distance.length];
        int[] cardinality_components = new int[this.distance.length];
        Edge[] min_weight = new Edge[this.distance.length];
        ArrayList<Edge> min_spanning_tree = new ArrayList<>();
        ArrayList<Edge>[] trees = new ArrayList[this.distance.length];
        for (int i = 0 ; i < trees.length ; i++) {
            trees[i] = new ArrayList<Edge>();
        }
        Arrays.fill(cardinality_components,1);
        ArrayList<Edge> edges_cities = new ArrayList<>();
        DisjointSets sets = new DisjointSets(this.distance.length);
        int[] weigth_eache_side = new int[this.distance.length];
        DisjointSets sets_each_side = new DisjointSets(this.distance.length);

        Pair edges_and_sets = circuit.create_edges_between_cities_and_disjoint_set(sum_component, edges_cities, sets,
                cardinality_components,min_weight, min_spanning_tree, trees);
        int union = (int) edges_and_sets.getValue();

        assertEquals(2, union);
        assertEquals(2, edges_cities.size());

    }

    @Test
    public void test_new_create_edges3() throws  Exception{
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};
        this.depot = new IntVar[4];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 5,5);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.depot[2] = this.model.intVar("depot[" + 2+"]", 4,4);
        this.depot[3] = this.model.intVar("depot[" + 3+"]", 2,2);
        this.cities = new IntVar[4];
        this.cities[0] = this.model.intVar("cities["+4+"]",new int[]{1,6});
        this.cities[1] = this.model.intVar("cities["+5+"]",new int[]{6});
        this.cities[2] = this.model.intVar("cities["+6+"]",new int[]{4,7});
        this.cities[3] = this.model.intVar("cities["+7+"]",new int[]{3,4,6});
        IntVar L = this.model.intVar(0,IntVar.MAX_INT_BOUND);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance, 2, L);
        int[] sum_component = new int[this.distance.length];
        ArrayList<Edge> edges_cities = new ArrayList<>();
        DisjointSets sets = new DisjointSets(this.distance.length);
        int[] cardinality_components = new int[this.distance.length];
        Arrays.fill(cardinality_components,1);
        Edge[] min_weight = new Edge[this.distance.length];
        ArrayList<Edge> min_spanning_tree = new ArrayList<>();
        ArrayList<Edge>[] trees = new ArrayList[this.distance.length];
        for (int i = 0 ; i < trees.length ; i++) {
            trees[i] = new ArrayList<Edge>();
        }
        int[] weigth_eache_side = new int[this.distance.length];
        DisjointSets sets_each_side = new DisjointSets(this.distance.length);

        Pair edges_and_sets = circuit.create_edges_between_cities_and_disjoint_set(sum_component,
                edges_cities, sets, cardinality_components,min_weight,min_spanning_tree, trees);
        int union = (int) edges_and_sets.getValue();

        assertEquals(1, union);
        assertEquals(3, edges_cities.size());

    }

    @Test
    public void test_dfs_all_graph() throws Exception{
        this.distance = new int[][]{
                {0,2,4,5,1,2},
                {2,0,3,6,3,2},
                {4,3,0,1,2,2},
                {5,6,1,0,9,2},
                {1,3,2,9,0,2},
                {2,2,2,2,2,0}};        this.depot = new IntVar[4];
        this.depot[0] = this.model.intVar("depot[" + 0+"]",5 ,5);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.depot[2] = this.model.intVar("depot[" + 2+"]", 4,4);
        this.depot[3] = this.model.intVar("depot[" + 3+"]", 2,2);
        this.cities = new IntVar[5];
        this.cities[0] = this.model.intVar("cities["+4+"]",new int[]{1});
        this.cities[1] = this.model.intVar("cities["+5+"]",new int[]{6});
        this.cities[2] = this.model.intVar("cities["+6+"]",new int[]{7});
        this.cities[3] = this.model.intVar("cities["+7+"]",new int[]{3});
        this.cities[4] = this.model.intVar("cities["+7+"]",new int[]{3});

        IntVar L = this.model.intVar(0,IntVar.MAX_INT_BOUND);
        Circuits circuit = new Circuits(this.cities, this.depot, this.distance, 2, L);
        ArrayList<Edge>[] edges = new ArrayList[6];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        Edge edge12 = new Edge(1,2,3);
        Edge edge34 = new Edge(3,4,9);
        Edge edge35 = new Edge(3,5,2);
        Edge edge45 = new Edge(4,5,2);


        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[4].add(edge34);
        edges[3].add(edge34);
        edges[5].add(edge35);
        edges[3].add(edge35);
        edges[4].add(edge45);
        edges[5].add(edge45);

        int[] parent = circuit.depth_first_search_all_graph(edges);
        assertEquals(-1,parent[0]);
        assertEquals(-1,parent[1]);
        assertEquals(1,parent[2]);
        assertEquals(-1,parent[3]);
        assertEquals(3,parent[4]);
        assertEquals(3,parent[5]);

    }

    @Test
    public void test_10_instance_6() throws Exception {
        this.distance = read_instances("../nsim/instances/duration_matrix/10adresses/coordinates10-6.txt");
        this.depot = new IntVar[2];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 3,3);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.cities = new IntVar[9];
        this.cities[0] = this.model.intVar("cities["+0+"]",new int[]{7});
        this.cities[1] = this.model.intVar("cities["+1+"]",new int[]{6});
        this.cities[2] = this.model.intVar("cities["+2+"]",new int[]{5});
        this.cities[3] = this.model.intVar("cities["+3+"]",new int[]{1});
        this.cities[4] = this.model.intVar("cities["+4+"]",new int[]{9});
        this.cities[5] = this.model.intVar("cities["+5+"]",new int[]{4});
        this.cities[6] = this.model.intVar("cities["+6+"]",new int[]{10});
        this.cities[7] = this.model.intVar("cities["+7+"]",new int[]{8});
        this.cities[8] = this.model.intVar("cities["+8+"]",new int[]{1,2});
        this.L = this.model.intVar(0,9800);
        this.k = 1;
        Circuits c = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        c.propagate(1);
    }

    @Test
    public void test_10_instance_1_1() throws Exception {
        this.distance = read_instances("../nsim/instances/duration_matrix/10adresses/coordinates10-6.txt");
        this.depot = new IntVar[2];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", 2,2);
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.cities = new IntVar[9];
        this.cities[0] = this.model.intVar("cities["+0+"]",new int[]{7,8,10});
        this.cities[1] = this.model.intVar("cities["+1+"]",new int[]{4});
        this.cities[2] = this.model.intVar("cities["+2+"]",new int[]{7,8,9});
        this.cities[3] = this.model.intVar("cities["+3+"]",new int[]{3});
        this.cities[4] = this.model.intVar("cities["+4+"]",new int[]{9,10});
        this.cities[5] = this.model.intVar("cities["+5+"]",new int[]{6});
        this.cities[6] = this.model.intVar("cities["+6+"]",new int[]{7,9,10});
        this.cities[7] = this.model.intVar("cities["+7+"]",new int[]{1});
        this.cities[8] = this.model.intVar("cities["+8+"]",new int[]{5});
        this.L = this.model.intVar(7943,9467);
        this.k = 1;
        Circuits c = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        c.propagate(1);
    }


    @Test
    public void test_find_first_composant() throws  Exception {
        Edge edge12 = new Edge(1,2,3);
        Edge edge34 = new Edge(3,4,9);
        Edge edge35 = new Edge(3,5,2);
        ArrayList<Edge> all_edges = new ArrayList<>();
        all_edges.add(edge12);
        all_edges.add(edge34);
        all_edges.add(edge35);
        all_edges.sort(Edge.EdgeComparatorByCost);
        Collections.reverse(all_edges);
        ArrayList<Edge>[] edges = new ArrayList[6];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[4].add(edge34);
        edges[3].add(edge34);
        edges[5].add(edge35);
        edges[3].add(edge35);

        Edge edge36 = new Edge(3,6,25);

        ArrayList<Edge>[] request = new ArrayList[7];
        for (int i = 0 ; i < request.length; i++) {
            request[i] = new ArrayList<>();
        }
        request[3].add(edge36);
        request[6].add(edge36);
        int[] decremential_connectivity = new int[]{0,0,0,1,1,1};
        CartesianTree ct = new CartesianTree(all_edges,edges, request);

        assertEquals(1,ct.find_first_composant(0,0,all_edges,decremential_connectivity));
        assertEquals(0,ct.find_first_composant(1,0,all_edges,decremential_connectivity));

    }

    @Test
    public void test_dfs() throws  Exception {
        Edge edge12 = new Edge(1,2,3);
        Edge edge34 = new Edge(3,4,9);
        Edge edge35 = new Edge(3,5,2);
        Edge edge25 = new Edge(2,5,10);

        ArrayList<Edge> all_edges = new ArrayList<>();
        all_edges.add(edge12);
        all_edges.add(edge34);
        all_edges.add(edge35);

        all_edges.sort(Edge.EdgeComparatorByCost);
        Collections.reverse(all_edges);
        ArrayList<Edge>[] edges = new ArrayList[6];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[4].add(edge34);
        edges[3].add(edge34);
        edges[5].add(edge35);
        edges[3].add(edge35);


        int[] decremential_connectivity = new int[]{0,0,0,0,0,0};
        Edge edge36 = new Edge(3,6,2);
        ArrayList<Edge>[] request = new ArrayList[7];
        for (int i = 0 ; i < request.length; i++) {
            request[i] = new ArrayList<>();
        }
        request[3].add(edge36);
        request[6].add(edge36);

        CartesianTree ct = new CartesianTree(all_edges,edges, request);
        ct.depth_first_search(edges,decremential_connectivity,edge25,0);
        assertEquals(0, decremential_connectivity[0]);
        assertEquals(1, decremential_connectivity[1]);
        assertEquals(1, decremential_connectivity[2]);
        assertEquals(0, decremential_connectivity[3]);
        assertEquals(0, decremential_connectivity[4]);
        assertEquals(0, decremential_connectivity[5]);

    }

    @Test
    public void test_dfs2() throws  Exception {
        Edge edge01 = new Edge(0,1,3);
        Edge edge12 = new Edge(1,2,4);
        Edge edge13 = new Edge(1,3,6);
        Edge edge34 = new Edge(3,4,5);
        Edge edge35 = new Edge(3,5,5);
        Edge edge56 = new Edge(5,6,1);


        ArrayList<Edge> all_edges = new ArrayList<>();
        all_edges.add(edge01);
        all_edges.add(edge12);
        all_edges.add(edge34);
        all_edges.add(edge35);
        all_edges.add(edge56);


        all_edges.sort(Edge.EdgeComparatorByCost);
        Collections.reverse(all_edges);
        ArrayList<Edge>[] edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[4].add(edge34);
        edges[3].add(edge34);
        edges[5].add(edge35);
        edges[3].add(edge35);
        edges[5].add(edge56);
        edges[6].add(edge56);

        int[] decremential_connectivity = new int[]{0,0,0,0,0,0,0};
        ArrayList<Edge>[] request = new ArrayList[7];
        for (int i = 0 ; i < request.length; i++) {
            request[i] = new ArrayList<>();
        }
        Edge edge36 = new Edge(3,6,25);

        request[3].add(edge36);
        request[6].add(edge36);
        CartesianTree ct = new CartesianTree(all_edges,edges, request);
        ct.depth_first_search(edges,decremential_connectivity,edge13,0);
        assertEquals(1, decremential_connectivity[0]);
        assertEquals(1, decremential_connectivity[1]);
        assertEquals(1, decremential_connectivity[2]);
        assertEquals(0, decremential_connectivity[3]);
        assertEquals(0, decremential_connectivity[4]);
        assertEquals(0, decremential_connectivity[5]);
        assertEquals(0, decremential_connectivity[6]);


    }

    @Test
    public void test_build_tree() throws  Exception {
        Edge edge01 = new Edge(0,1,3);
        Edge edge12 = new Edge(1,2,4);
        Edge edge13 = new Edge(1,3,6);
        Edge edge34 = new Edge(3,4,5);
        Edge edge35 = new Edge(3,5,2);
        Edge edge56 = new Edge(5,6,1);
        Edge edge36 = new Edge(3,6,8);


        ArrayList<Edge> all_edges = new ArrayList<>();
        all_edges.add(edge01);
        all_edges.add(edge12);
        all_edges.add(edge34);
        all_edges.add(edge35);
        all_edges.add(edge56);
        all_edges.add(edge13);


        all_edges.sort(Edge.EdgeComparatorByCost);
        Collections.reverse(all_edges);
        ArrayList<Edge>[] edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[4].add(edge34);
        edges[3].add(edge34);
        edges[5].add(edge35);
        edges[3].add(edge35);
        edges[5].add(edge56);
        edges[6].add(edge56);

        int[] decremential_connectivity = new int[]{0,0,0,0,0,0,0};
        ArrayList<Edge>[] request = new ArrayList[7];
        for (int i = 0 ; i < request.length; i++) {
            request[i] = new ArrayList<>();
        }
        request[3].add(edge36);
        request[6].add(edge36);

        CartesianTree ct = new CartesianTree(all_edges,edges,request);
        ct.build_cartesian_tree();
        assertEquals(6,ct.root.cost);
        assertEquals(4,ct.root.left_node.cost);
        assertEquals(3,ct.root.left_node.left_node.cost);
        assertEquals(4,ct.root.left_node.right_node.cost);
        assertEquals(2,ct.root.left_node.right_node.name);
        assertEquals(3,ct.root.left_node.left_node.left_node.cost);
        assertEquals(3,ct.root.left_node.left_node.right_node.cost);
        assertEquals(0,ct.root.left_node.left_node.left_node.name);
        assertEquals(1,ct.root.left_node.left_node.right_node.name);

        assertEquals(5,ct.root.right_node.cost);
        assertEquals(5,ct.root.right_node.right_node.cost);
        assertEquals(4,ct.root.right_node.right_node.name);

        assertEquals(2,ct.root.right_node.left_node.cost);
        assertEquals(2,ct.root.right_node.left_node.left_node.cost);
        assertEquals(3,ct.root.right_node.left_node.left_node.name);
        assertEquals(1,ct.root.right_node.left_node.right_node.cost);

        assertEquals(1,ct.root.right_node.left_node.right_node.left_node.cost);
        assertEquals(5,ct.root.right_node.left_node.right_node.left_node.name);
        assertEquals(1,ct.root.right_node.left_node.right_node.right_node.cost);
        assertEquals(6,ct.root.right_node.left_node.right_node.right_node.name);

    }

    @Test
    public void test_olca() throws  Exception {
        Edge edge01 = new Edge(0,1,3);
        Edge edge12 = new Edge(1,2,4);
        Edge edge13 = new Edge(1,3,6);
        Edge edge34 = new Edge(3,4,5);
        Edge edge35 = new Edge(3,5,2);
        Edge edge56 = new Edge(5,6,1);

        Edge edge36 = new Edge(3,6,8);
        Edge edge23 = new Edge(2,3,7);
        Edge edge06 = new Edge(0,6,8);
        Edge edge45 = new Edge(4,5,8);



        ArrayList<Edge> all_edges = new ArrayList<>();
        all_edges.add(edge01);
        all_edges.add(edge12);
        all_edges.add(edge34);
        all_edges.add(edge35);
        all_edges.add(edge56);
        all_edges.add(edge13);


        all_edges.sort(Edge.EdgeComparatorByCost);
        Collections.reverse(all_edges);
        ArrayList<Edge>[] edges = new ArrayList[7];

        for (int i = 0 ; i < edges.length ; i++) {
            edges[i] = new ArrayList<>();
        }
        edges[0].add(edge01);
        edges[1].add(edge01);
        edges[1].add(edge13);
        edges[3].add(edge13);
        edges[1].add(edge12);
        edges[2].add(edge12);
        edges[4].add(edge34);
        edges[3].add(edge34);
        edges[5].add(edge35);
        edges[3].add(edge35);
        edges[5].add(edge56);
        edges[6].add(edge56);

        int[] decremential_connectivity = new int[]{0,0,0,0,0,0,0};
        ArrayList<Edge>[] request = new ArrayList[7];
        for (int i = 0 ; i < request.length; i++) {
            request[i] = new ArrayList<>();
        }
        request[3].add(edge36);
        request[6].add(edge36);
        request[0].add(edge06);
        request[6].add(edge06);
        request[2].add(edge23);
        request[3].add(edge23);
        request[4].add(edge45);
        request[5].add(edge45);

        CartesianTree ct = new CartesianTree(all_edges,edges,request);
        ct.build_cartesian_tree();
        HashMap<Edge, Integer> result = ct.OLCA();
        assertEquals(2, result.get(edge36).intValue());
        assertEquals(6, result.get(edge06).intValue());
        assertEquals(6, result.get(edge23).intValue());
        assertEquals(5, result.get(edge45).intValue());

    }

    @Test
    public void test_10_instance_7() throws Exception {
        this.distance = read_instances("../nsim/instances/duration_matrix/10adresses/coordinates10-7.txt");
        this.depot = new IntVar[2];
        this.depot[0] = this.model.intVar("depot[" + 0+"]", new int[]{5,6,7,10});
        this.depot[1] = this.model.intVar("depot[" + 1+"]", 0,0);
        this.cities = new IntVar[9];
        this.cities[0] = this.model.intVar("cities["+0+"]",new int[]{9});
        this.cities[1] = this.model.intVar("cities["+1+"]",new int[]{1});
        this.cities[2] = this.model.intVar("cities["+2+"]",new int[]{3,5,6,7,10});
        this.cities[3] = this.model.intVar("cities["+3+"]",new int[]{3,4,6,7,10});
        this.cities[4] = this.model.intVar("cities["+4+"]",new int[]{3,4,5,7,10});
        this.cities[5] = this.model.intVar("cities["+5+"]",new int[]{8});
        this.cities[6] = this.model.intVar("cities["+6+"]",new int[]{2});
        this.cities[7] = this.model.intVar("cities["+7+"]",new int[]{3,4,5,6,10});
        this.cities[8] = this.model.intVar("cities["+8+"]",new int[]{3,4,5,6,7});
        this.L = this.model.intVar(7783,9194);
        this.k = 1;
        Circuits c = new Circuits(this.cities, this.depot, this.distance,
                this.k, this.L,1);
        c.propagate(1);
    }

    @Test
    public void test_avec_mem_sans_mem() throws Exception {
        this.distance = new int[][]{
                {0,2,4,5,1},
                {2,0,3,6,3},
                {4,3,0,1,2},
                {5,6,1,0,9},
                {1,3,2,9,0}};

        this.k=1;

        Parameters parameters = new Parameters("test", 7 , 1 ,
                distance.length - 1, this.k, distance);
        System.out.print(parameters);

        System.out.print(" ");
        System.out.print(parameters.getResult());

        parameters = new Parameters("test", 5 , 1 ,
                distance.length - 1, this.k, distance);

        System.out.print(parameters);
        System.out.print(" ");
        System.out.print(parameters.getResult());

    }

    @Test
    public void test_avec_mem_sans_mem2() throws Exception {
        int[][] distance = read_instances("../nsim/instances/duration_matrix/5adresses/coordinates5-3.txt");
       Parameters parameters = new Parameters("test", 7 , 1 ,
                distance.length - 1, 3, distance);
        System.out.print(parameters);

        System.out.print(" ");
        System.out.print(parameters.getResult());

        parameters = new Parameters("test", 5 , 1 ,
                distance.length - 1, 3, distance);

        System.out.print(parameters);
        System.out.print(" ");
        System.out.print(parameters.getResult());

    }

    @Test
    public void testReadTspInstances() throws Exception {
        int[][] result = main.readTspInstances("tsplib_data/eil51_test.tsp");

    }
}