import java.util.Comparator;


public class Edge {
    private int m_cost;
    private int m_source;
    private int m_target;

    private int m_capacity;
    private int m_flow;

    private Edge m_reverseEdge;

    public Edge(int source, int target, int cost){
        this(source, target, cost, 1);
    }

    public Edge(int source, int target, int cost, int capacity) {
        m_source = source;
        m_target = target;
        m_cost = cost;
        m_capacity = capacity;
        m_flow = 0;

        m_reverseEdge = null;
    }

    public int source(){return m_source;}
    public int target(){return m_target;}
    public int cost(){return m_cost;}
    public int capacity(){return m_capacity;}
    public int flow(){return m_flow;}
    public int residualCapacity(){return m_capacity - m_flow;}

    public void setCost(int new_cost){
        this.m_cost = new_cost;
    }

    public void addFlow(int flow){m_flow += flow;}

    public void setReverseEdge(Edge reverseEdge){m_reverseEdge = reverseEdge;}
    public Edge reverseEdge(){return m_reverseEdge;}

    public static Comparator<Edge> EdgeComparatorByCostZeroFirst = new Comparator<Edge>() {
        public int compare(Edge edge1, Edge edge2) {
            if (edge1.cost() - edge2.cost() != 0){
                return edge1.cost() - edge2.cost();
            }
            else {
                return Math.min(edge1.target(), edge1.source()) - Math.min(edge2.target(), edge2.source());
            }
        }
    };
    public static Comparator<Edge> EdgeComparatorByCostZeroAfter = new Comparator<Edge>() {
        public int compare(Edge edge1, Edge edge2) {
            if (edge1.cost() - edge2.cost() != 0){
                return edge1.cost() - edge2.cost();
            }
            else if (edge1.target() == 0 || edge1.source() == 0){
                return 1;
            }
            else {
                return -1;
            }
        }
    };
    public static Comparator<Edge> EdgeComparatorByCost = new Comparator<Edge>() {
        public int compare(Edge edge1, Edge edge2) {
            //ascending order
            return edge1.cost() - edge2.cost();
        }
    };



    @Override
    public String toString()
    {
        return "(" + this.source() + " --> " + this.target() + " | " + this.cost() + ")";
    }
}
