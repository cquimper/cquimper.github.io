import org.chocosolver.solver.exception.ContradictionException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
public class main {

    public static int[][] read_instances(String filename) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        line = reader.readLine();
        int number_adresses = Integer.parseInt(line);
        int[][] distance = new int[number_adresses][number_adresses];
        int row = 0;
        while ((line = reader.readLine()) != null) {
            Scanner scan = new Scanner(line);
            scan.useLocale(Locale.US);
            for (int i = 0; i < number_adresses; i++) {
                distance[row][i] = ((int) scan.nextFloat());
            }
            row++;
        }

        for (int i = 0; i < distance.length; i++) {
            for (int j = 0; j < i; j++) {
                int max = Math.max(distance[i][j], distance[j][i]);
                distance[i][j] = max;
                distance[j][i] = max;
            }
        }
        return distance;

    }

    public static int[][] read_instance_benchmark(String filename) throws IOException {

        return null;
    }

    public static void create_file(String file, int cities, int trucks, Parameters parameters) throws IOException {
        String[] split = file.split("/");
        String union = "";
        for (int i = 0; i < split.length; i++) {
            if (i != 3) {
                union = union + split[i] + "/";
            }
        }
        BufferedReader reader = new BufferedReader(new FileReader(union));
        String line;
        line = reader.readLine();
        float[] longitude = new float[cities];
        float[] latitude = new float[cities];
        int scanneur = 0;
        while ((line = reader.readLine()) != null) {
            Scanner scan = new Scanner(line);
            scan.useLocale(Locale.US);
            scan.useDelimiter(";");
            scan.next();
            longitude[scanneur] = scan.nextFloat();
            latitude[scanneur] = scan.nextFloat();
            scanneur++;
        }

        int[] depot_next = parameters.getDepot_next();
        int[] cities_next = parameters.getCities_next();
        FileWriter output_file = new FileWriter("jsonfile/" + parameters.instance_name + "-" + parameters.num_trucks + ".txt");
        output_file.write(Integer.toString(parameters.num_trucks));
        output_file.write("\n");
        for (int i = 0; i < 2 * parameters.num_trucks; i += 2) {
            output_file.write(Float.toString(-longitude[0]));
            output_file.write(" ");
            output_file.write(Float.toString(latitude[0]));
            output_file.write("\n");
            int next = depot_next[i];
            while (next >= 2 * trucks) {
                output_file.write(Float.toString(-longitude[next - 2 * trucks + 1]));
                output_file.write(" ");
                output_file.write(Float.toString(latitude[next - 2 * trucks + 1]));
                output_file.write("\n");
                next = cities_next[next - 2 * trucks];
            }
            output_file.write(Float.toString(-longitude[0]));
            output_file.write(" ");
            output_file.write(Float.toString(latitude[0]));
            output_file.write("\n");
            output_file.write("..\n");

        }
        output_file.flush();
        output_file.close();
    }

    public static void create_json(String file, int cities, int trucks, Parameters parameters) throws IOException {
        String[] split = file.split("/");
        String union = "";
        for (int i = 0; i < split.length; i++) {
            if (i != 3) {
                union = union + split[i] + "/";
            }
        }
        BufferedReader reader = new BufferedReader(new FileReader(union));
        String line;
        line = reader.readLine();
        float[] longitude = new float[cities];
        float[] latitude = new float[cities];
        int i = 0;
        while ((line = reader.readLine()) != null) {
            Scanner scan = new Scanner(line);
            scan.useLocale(Locale.US);
            scan.useDelimiter(";");
            scan.next();
            longitude[i] = scan.nextFloat();
            latitude[i] = scan.nextFloat();
            i++;
        }

        int[] depot_next = parameters.getDepot_next();
        int[] cities_next = parameters.getCities_next();


        for (int j = 0; j < depot_next.length; j += 2) {
            JSONObject featureCollection = new JSONObject();
            featureCollection.put("type", "FeatureCollection");
            JSONArray JSONArrayCoordTotal = new JSONArray();

            JSONArray features = new JSONArray();

            JSONObject feature = new JSONObject();
            JSONObject geometry = new JSONObject();
            JSONArray JSONArrayCoord = new JSONArray();

            JSONArrayCoord.add(0, -longitude[0]);
            JSONArrayCoord.add(1, latitude[0]);
            JSONArrayCoordTotal.add(JSONArrayCoord);

            int next = depot_next[j];
            while (next >= 2 * trucks) {
                JSONArrayCoord = new JSONArray();
                JSONArrayCoord.add(0, -longitude[next - 2 * trucks + 1]);
                JSONArrayCoord.add(1, latitude[next - 2 * trucks + 1]);
                JSONArrayCoordTotal.add(JSONArrayCoord);
                next = cities_next[next - 2 * trucks];
            }
            JSONArrayCoord = new JSONArray();

            JSONArrayCoord.add(0, -longitude[0]);
            JSONArrayCoord.add(1, latitude[0]);

            JSONArrayCoordTotal.add(JSONArrayCoord);

            geometry.put("coordinates", JSONArrayCoordTotal);
            geometry.put("type", "LineString");


            JSONObject properties = new JSONObject();
            properties.put("name", "trajet");
            properties.put("color", "#0000f" + j);


            feature.put("geometry", geometry);
            feature.put("propreties", properties);
            features.add(feature);
            feature.put("type", "Feature");
            featureCollection.put("features", features);

            FileWriter fileJson = new FileWriter("jsonfile/" + parameters.instance_name + "-" + parameters.num_model
                    + "-" + parameters.propagation + "-" + parameters.num_trucks + "-" + j + ".json");
            fileJson.write(featureCollection.toJSONString());
            fileJson.flush();
        }

    }

    public static int[][] readTspInstances(String file) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        int line_count = 0;
        //skip the first 3 lines
        while ((line = reader.readLine()) != null && line_count < 3) {
            line_count += 1;
        }
        //get the dimension
        Scanner scan = new Scanner(line);
        scan.next();
        scan.next();
        int dimension = scan.nextInt();

        //skip the next two lines
        reader.readLine();
        reader.readLine();

        int[] xs = new int[dimension];
        int[] ys = new int[dimension];

        int position_count = 0;
        line = reader.readLine();
        while (!line.equals("EOF")) {
            scan = new Scanner(line);
            scan.useLocale(Locale.US);
            int id = scan.nextInt();
            xs[position_count] = scan.nextInt();
            ys[position_count] = scan.nextInt();
            position_count += 1;
            line = reader.readLine();
        }
        int[][] distance = new int[xs.length][xs.length];
        for (int i = 0; i < xs.length; i++) {
            distance[i][i] = 0;
            for (int j = i + 1; j < xs.length; j++) {
                distance[i][j] = (int) Math.sqrt(Math.pow(xs[i], 2) + Math.pow(ys[j], 2));
                distance[j][i] = distance[i][j];
            }
        }


        return distance;
    }


    public static void compute_information_instance(int[][] distance) {
        float mean = 0;
        float sd = 0;

        int n = distance.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mean += distance[i][j];
                sd += (distance[i][j] * distance[i][j]);
            }
        }
        mean = mean / (n * n);
        sd = sd / (n * n);
        sd = sd - (mean * mean);
        sd = (float) Math.sqrt(sd);
        System.out.print(mean + " " + sd + "\n");

    }

    public static void main(String[] args) throws IOException, ContradictionException {
        //int[][] distance = read_instances(args[0]);
        //compute_information_instance(distance);

        //int[][] distance = read_instances(args[0]);
        //String[] split = args[0].split("/");
        //String name = split[3].substring(0, split[3].length() - 7) + split[5].substring(11, split[5].length() - 4);
        //System.out.print("Instance Model Propagation Trucks L_Max Backtrack Time\n");

        int[][] distance = readTspInstances(args[0]);
        System.out.print("Instance Model Propagation Trucks L_Max Backtrack Time TimeBestSol\n");
        String name = args[0];


        ArrayList<Integer> trucks = new ArrayList<>();
        trucks.add(1);
        trucks.add(2);
        trucks.add(3);
        trucks.add(5);
        trucks.add(7);


        for (int i : trucks) {
            Parameters parameters = new Parameters(name, 2, 1,
                    distance.length - 1, i, distance);

            System.out.print(parameters);
            System.out.print(" ");
            System.out.print(parameters.getResult());

            parameters.solve();

            parameters = new Parameters(name, 7, 1,
                    distance.length - 1, i, distance);

            System.out.print(parameters);
            System.out.print(" ");
            System.out.print(parameters.getResult());
        }
    }
}


