import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;

public class CartesianTree {

    protected Node root;
    protected int number_of_node;
    int[] decremential_connectivity;
    ArrayList<Edge> all_edges;
    ArrayList<Edge>[] neighbours;
    ArrayList<Edge>[] requests;
    ArrayList<Pair<Edge,Node>>[] new_requests;

    protected class Node {
        protected Node left_node;
        protected Node right_node;
        protected int cost ;
        protected int name = -1;
        protected boolean leaf;
        protected int number ;
        protected Node ancestor;
        protected Node parent;
        protected int color;
        protected int rank;

        private Node(int edge) {
            this.left_node = null;
            this.right_node = null;
            this.cost = edge;
            this.leaf = true;
        }

        private Node(int edge, int name) {
            this.left_node = null;
            this.right_node = null;
            this.cost = edge;
            this.leaf = true;
            this.name = name;


        }

        private void set_right_node(Node node) {
            this.right_node = node;
            this.leaf = false;
        }

        private void set_left_node(Node node) {
            this.left_node = node;
            this.leaf = false;
        }

        private Node left_note() {
            return this.left_node;
        }

        private Node right_node() {
            return this.right_node;
        }

        private int edge() {
            return this.cost;
        }
        @Override
        public boolean equals(Object o) {
            Node others = (Node) o;
            return this.cost == others.cost && this.name == others.name;
        }
    }

    public CartesianTree(ArrayList<Edge> all_edges, ArrayList<Edge>[] neighbours,ArrayList<Edge>[] requests) {
        this.requests = requests;
        this.decremential_connectivity = new int[neighbours.length];
        this.all_edges = all_edges;
        this.neighbours = neighbours;
        this.all_edges.sort(Edge.EdgeComparatorByCost);
        Collections.reverse(all_edges);
    }

    protected void build_cartesian_tree() {
        this.new_requests = new ArrayList[this.requests.length];
        for (int i = 0 ; i < this.new_requests.length ; i++) {
            this.new_requests[i] = new ArrayList<>();
        }
        this.root = recursive_build_cartesian_tree(0,0, this.all_edges, this.neighbours, this.decremential_connectivity);
    }

    private Node recursive_build_cartesian_tree(int composant, int index, ArrayList<Edge> all_edges,
                                                ArrayList<Edge>[] neighbours, int[] decremential_connectivity) {
        Edge current_edge = all_edges.get(index);
        this.number_of_node++;
        Node root = new Node(current_edge.cost());

        neighbours[current_edge.target()].remove(current_edge);
        neighbours[current_edge.source()].remove(current_edge);

        depth_first_search(neighbours, decremential_connectivity, current_edge, composant);

        int next_composant = NumberUtils.max(decremential_connectivity);

        int next_composant_source_side = find_first_composant(decremential_connectivity[current_edge.source()],
                index + 1, all_edges, decremential_connectivity);
        int next_composant_target_side = find_first_composant(decremential_connectivity[current_edge.target()],
                index + 1, all_edges, decremential_connectivity);

        if (next_composant_source_side == -1 && next_composant_target_side == -1) {
            root.set_left_node(new Node(current_edge.cost(), current_edge.source()));
            root.set_right_node(new Node(current_edge.cost(), current_edge.target()));
            for (Edge edge_to_add : this.requests[current_edge.source()]) {
                int next_edge = edge_to_add.source() == current_edge.source() ? edge_to_add.target() : edge_to_add.source();
                new_requests[next_edge].add(Pair.of(edge_to_add, root.left_node));

            }
            for (Edge edge_to_add : this.requests[current_edge.target()]) {
                int next_edge = edge_to_add.source() == current_edge.target() ? edge_to_add.target() : edge_to_add.source();
                new_requests[next_edge].add(Pair.of(edge_to_add, root.right_node));
            }
        }

        else if (next_composant_source_side == -1) {
            root.set_left_node(new Node(all_edges.get(index).cost(), all_edges.get(index).source()));
            root.set_right_node(recursive_build_cartesian_tree(next_composant,next_composant_target_side,
                    all_edges,neighbours, decremential_connectivity));
            for (Edge edge_to_add : this.requests[current_edge.source()]) {
                int next_edge = edge_to_add.source() == current_edge.source() ? edge_to_add.target() : edge_to_add.source();
                new_requests[next_edge].add(Pair.of(edge_to_add, root.left_node));
            }
        }

        else if (next_composant_target_side == -1) {
            root.set_right_node(new Node(all_edges.get(index).cost(), all_edges.get(index).target()));
            root.set_left_node(recursive_build_cartesian_tree(composant,next_composant_source_side,
                    all_edges,neighbours, decremential_connectivity));
            for (Edge edge_to_add : this.requests[current_edge.target()]) {
                int next_edge = edge_to_add.source() == current_edge.target() ? edge_to_add.target() : edge_to_add.source();
                new_requests[next_edge].add(Pair.of(edge_to_add, root.right_node));
            }
        }

        else {
            root.set_left_node(recursive_build_cartesian_tree(composant,next_composant_source_side,
                    all_edges,neighbours, decremential_connectivity));
            root.set_right_node(recursive_build_cartesian_tree(next_composant,next_composant_target_side,
                    all_edges,neighbours, decremential_connectivity));
        }

        return root;
    }

    protected int find_first_composant(int composant, int index, ArrayList<Edge> all_edges, int[] decremential_connectivity) {
       for (int i = index ; i < all_edges.size(); i++) {
           if (decremential_connectivity[all_edges.get(i).source()] == composant) {
               return i;
           }
       }
       return -1;
    }

    protected void depth_first_search(ArrayList<Edge>[] neighbours, int[] decremential_connectivity, Edge edge,
                                    int composant) {
        int[] visited = new int[neighbours.length];
        int source = edge.source();
        int target = edge.target();
        LinkedList<Integer> source_queue = new LinkedList<>();
        LinkedList<Integer> target_queue = new LinkedList<>();
        ArrayList<Integer> source_dfs = new ArrayList<>();
        ArrayList<Integer> target_dfs = new ArrayList<>();

        source_queue.add(source);
        target_queue.add(target);
        source_dfs.add(source);
        target_dfs.add(target);


        while (!source_queue.isEmpty() && !target_queue.isEmpty()) {
            int current_source = source_queue.pop();
            int current_target = target_queue.pop();

            for (int i = 0 ; i < neighbours[current_source].size(); i++) {
                int next = neighbours[current_source].get(i).source() == current_source ?
                        neighbours[current_source].get(i).target() : neighbours[current_source].get(i).source();
                if (visited[next] != 1){
                    source_queue.add(next);
                    visited[next] = 1;
                    source_dfs.add(next);
                }
            }

            for (int i = 0 ; i < neighbours[current_target].size(); i++) {
                int next = neighbours[current_target].get(i).source() == current_target ?
                        neighbours[current_target].get(i).target() : neighbours[current_target].get(i).source();
                if (visited[next] != 1){
                    target_queue.add(next);
                    visited[next] = 1;
                    target_dfs.add(next);
                }
            }
        }
        composant = NumberUtils.max(decremential_connectivity) + 1;
        if (source_queue.isEmpty()) {
            for (int i = 0 ; i < source_dfs.size() ; i++) {
                decremential_connectivity[source_dfs.get(i)] = composant;
            }
        }
        else {
            for (int i = 0 ; i < target_dfs.size() ; i++) {
                decremential_connectivity[target_dfs.get(i)] = composant;
            }
        }

    }

    public HashMap<Edge, Integer> OLCA() {
        HashMap<Edge, Integer> result = new HashMap<>();
        return recursive_OLCA(this.root, result);
    }


    private HashMap<Edge,Integer> recursive_OLCA(Node node, HashMap<Edge, Integer> result) {
        make_set(node);
        node.ancestor = node;
        if (node.left_node != null) {
            recursive_OLCA( node.left_node, result);
            union(node,node.left_node);
            find(node).ancestor = node;
        }
        if(node.right_node != null) {
            recursive_OLCA(node.right_node, result);
            union(node,node.right_node);
            find(node).ancestor = node;
        }
        node.color = 1;
        if (node.name != -1) {
            for (Pair pair_next : new_requests[node.name]) {
                Node node_next = (Node) pair_next.getRight();
                if (node_next.color == 1) {
                    result.put((Edge) pair_next.getLeft(), find(node_next).ancestor.cost);
                }
            }
        }
        return result;
    }

    void make_set(Node x) {
        x.parent = x;
        x.rank = 0;
        x.color = 0;
    }

    void union(Node x, Node y) {
        Node xroot = find(x);
        Node yroot = find(y);
        if (xroot.rank > yroot.rank)
            yroot.parent = xroot;
        else if (y.rank > x.rank) {
            xroot.parent = yroot;
        }
        else {
            yroot.parent = x;
            xroot.rank += 1;
        }
    }

    Node find(Node x) {
        if (!(x.parent.equals(x)))
            x.parent = find(x.parent);
        return x.parent;
    }
}
