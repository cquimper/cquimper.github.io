import javafx.util.Pair;
import org.chocosolver.memory.IStateInt;
import org.chocosolver.memory.IStateIntVector;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.ESat;
import org.chocosolver.util.iterators.DisposableValueIterator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Circuits extends Propagator {
    private IntVar[] cities;	// Les villes qui ne sont pas un depot sont identifiees par les valeurs de 2k à 2k + n - 1
    private IntVar[] depot;	// Les depots sont dupliques (entrée du depot et la sortie du depot) et prennent les valeurs 0 à 2k - 1
    private int[][] distance;
    private int num_trucks = 1;
    private IntVar L;
    private int propagation = 0;
    // Pour deboguer
    private boolean debug = false;
    BufferedWriter bw = null;
    FileWriter fw = null;
    IStateIntVector old_domains_cities;
    IStateIntVector old_domains_depot;
    int memory = 0;
    IStateInt old_upper_bound ;
    IStateInt old_lower_bound;
    int size_old_domains_cities ;
    int size_old_domains_depot ;




    public Circuits(IntVar[] cities, IntVar[] depot, int[][] distance, int k, IntVar L) throws ContradictionException {
        super(org.apache.commons.lang3.ArrayUtils.addAll(org.apache.commons.lang3.ArrayUtils.addAll(cities,depot),L));
        assert cities.length > 0;
        assert distance.length == cities.length + 1;
        assert k > 0;
        assert k <= cities.length;
        assert L.getLB() >= 0;
        for (int i = 0; i < distance.length; i++) {
            assert distance[i].length == cities.length + 1;
            for (int j = 0 ; j < distance[i].length; j++){
                if(i == j)
                    assert distance[i][j] == 0;
                else
                    assert distance[i][j] >= 0;
            }
        }
        assert depot.length == 2*k;
        this.depot = depot;
        this.cities = cities;
        this.distance = distance;
        this.num_trucks = k;
        this.L = L;
        try {
            fw = new FileWriter("tests_instance_10.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        bw = new BufferedWriter(fw);
        this.old_domains_cities = this.getModel().getEnvironment().makeIntVector(2 * (this.distance.length - 2),-1);
        this.size_old_domains_cities = 2 * (this.distance.length - 2);
        this.size_old_domains_depot = 4 * this.num_trucks;
        this.old_domains_depot = this.getModel().getEnvironment().makeIntVector(4 * this.num_trucks,-1);
        this.old_upper_bound = this.getModel().getEnvironment().makeInt(this.L.getUB());
        this.old_lower_bound = this.getModel().getEnvironment().makeInt(this.L.getLB());

    }

    public Circuits(IntVar[] cities, IntVar[] depot, int[][] distance, int k, IntVar L, int propagation) throws ContradictionException {
        this(cities,depot,distance,k,L);
        this.propagation = propagation;
    }

    public Circuits(IntVar[] cities, IntVar[] depot, int[][] distance, int k, IntVar L, int propagation, int memory) throws ContradictionException {
        this(cities,depot,distance,k,L);
        this.propagation = propagation;
        this.memory = 1;
    }

    @Override
    public void propagate(int evtmask) throws ContradictionException {
        try {
            print_domaine_in_file(debug);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (this.memory == 1) {
            if (this.propagation == 1 && (this.old_upper_bound.get() > this.L.getUB() ||check_is_filtering())) {
                this.old_upper_bound.set(this.L.getUB());
                this.old_lower_bound.set(this.L.getLB());
                filter();
            }
        }
        else {
            if (this.propagation == 1) {
                filter();
            }
        }
        verify_solution();
        try {
            print_domaine_in_file(debug);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void filter() throws ContradictionException {
        ArrayList<Edge> edges_depot = create_edges_from_depot();
        if (edges_depot.size() < this.num_trucks) {
            throw new ContradictionException();
        }
        int[] sum_componnent = new int[this.distance.length];// Weight of a tree in the forest
        int[] cardinality_components = new int[this.distance.length];
        Arrays.fill(cardinality_components,1);
        Edge[] max_weight_by_tree = new Edge[this.distance.length];
        ArrayList<Edge> edges_cities = new ArrayList<>();
        DisjointSets sets = new DisjointSets(this.distance.length);
        ArrayList<Edge> others_edges = new ArrayList<>();
        ArrayList<Edge> min_spanning_tree = new ArrayList<>();
        ArrayList<Edge>[] neighbours = new ArrayList[this.distance.length];
        for (int i = 0 ; i < neighbours.length ; i++) {
            neighbours[i] = new ArrayList<Edge>();
        }

        Pair weight_union = create_edges_between_cities_and_disjoint_set(sum_componnent,
                edges_cities, sets, cardinality_components, max_weight_by_tree,
                min_spanning_tree, neighbours);
        int weight = (int)weight_union.getKey();
        int union = (int)weight_union.getValue();
        DisjointSets sets_for_filter_depot = new DisjointSets(sets);

        Pair borne_maxweight = (Pair) kruskal_new_bound(edges_cities,sets,
                sets_for_filter_depot, union, sum_componnent,
                weight,edges_depot,cardinality_components, max_weight_by_tree,others_edges,min_spanning_tree,neighbours);
        Pair components = (Pair)borne_maxweight.getKey();
        int max_components = (int)components.getKey();
        int nb_components = (int)components.getValue();
        int max_weight = (int)borne_maxweight.getValue();

        if (max_components > max_weight) {
            if (Math.ceil((double)(max_components) /
                    (this.num_trucks - nb_components + 1)) > this.L.getLB()) {
                this.L.updateLowerBound((max_components) /
                        (this.num_trucks - nb_components + 1), this);
            }
        }
        else {
            if (Math.ceil((double)max_weight / this.num_trucks) > this.L.getLB()) {
                this.L.updateLowerBound((max_weight) / this.num_trucks, this);
            }
        }

        ArrayList<Edge>[] split_spanning_tree = new ArrayList[distance.length];
        ArrayList<Edge>[][] split_requests = new ArrayList[distance.length][this.distance.length];
        ArrayList<Edge> resquest_different_tree = new ArrayList<>();

        for (int i = 0 ; i < split_requests.length ; i++) {
            split_spanning_tree[i] = new ArrayList<>();
        }

        ArrayList<Edge>[][] split_spanning_tree_neighbours = new ArrayList[distance.length][this.distance.length];
        for (int i = 0 ; i < split_spanning_tree_neighbours.length ; i++) {
            for (int j = 0 ; j < split_spanning_tree_neighbours[i].length ; j++) {
                split_spanning_tree_neighbours[i][j] = new ArrayList<>();
                split_requests[i][j] = new ArrayList<>();
            }
        }


        create_k_different_trees_and_requests(sets, min_spanning_tree, others_edges,split_spanning_tree,
                split_requests,resquest_different_tree, split_spanning_tree_neighbours);

        filter_cities2(edges_depot, edges_cities, sets, nb_components,
                max_weight, sum_componnent, max_weight_by_tree,
                split_spanning_tree, split_requests, resquest_different_tree, split_spanning_tree_neighbours, sets_for_filter_depot);


        filter_depot(edges_depot, max_weight, sum_componnent, sets_for_filter_depot, nb_components);
    }

    private boolean check_is_filtering() {
        if (old_domains_cities.quickGet(0) == -1) {
            return true;
        }
        else if (old_domains_depot.quickGet(0) == -1) {
            return true;
        }
        else {
            for (int i  = 0 ; i < this.size_old_domains_cities ; i+=2) {
                int value1 = old_domains_cities.quickGet(i);
                int value2 = old_domains_cities.quickGet(i+1);
                if (!cities[value1 - 1].contains(value2 + 2 * this.num_trucks - 1) && !cities[value2 - 1].contains(value1 + 2 * this.num_trucks - 1)){
                    return true;
                }
            }
            for (int i = 0 ; i <this.size_old_domains_depot ; i += 2) {
                int value_depot = Math.min(old_domains_depot.quickGet(i), old_domains_depot.quickGet(i+1));
                int value_citie = Math.max(old_domains_depot.quickGet(i), old_domains_depot.quickGet(i+1));
                if (value_citie != -1 && value_depot != -1) {
                    boolean not_in_all_depot = false;
                    for (int j = 0; j < this.depot.length; j += 2) {
                        if (this.depot[j].contains(value_citie + 2 * this.num_trucks - 1)) {
                            not_in_all_depot = true;
                            break;
                        }
                    }
                    if (not_in_all_depot) {
                        not_in_all_depot = false;
                        for (int j = 1; j < this.depot.length; j += 2) {
                            if (this.cities[value_citie - 1].contains(j)) {
                               not_in_all_depot = true;
                            }
                        }
                    }
                    if (!not_in_all_depot) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void create_k_different_trees_and_requests(DisjointSets sets, ArrayList<Edge> min_spanning_tree,
                                                       ArrayList<Edge> others_edges, ArrayList<Edge>[] split_spanning_tree,
                                                       ArrayList<Edge>[][] split_requests,
                                                       ArrayList<Edge> resquest_different_tree,
                                                       ArrayList<Edge>[][] split_spanning_tree_neighbours) {
        for (Edge edge : min_spanning_tree ) {
            int rep_source = sets.find(edge.source());
            split_spanning_tree[rep_source].add(edge);
            split_spanning_tree_neighbours[rep_source][edge.source()].add(edge);
            split_spanning_tree_neighbours[rep_source][edge.target()].add(edge);
        }

        for (Edge edge : others_edges) {
            int rep_source = sets.find(edge.source());
            int rep_target = sets.find(edge.target());
            if(rep_source == rep_target) {
                split_requests[rep_source][edge.source()].add(edge);
                split_requests[rep_source][edge.target()].add(edge);
            }
            else {
                resquest_different_tree.add(edge);
            }
        }
    }

    private void filter_depot(ArrayList<Edge> edges_depot, int sum, int[] sum_componnent,
                              DisjointSets sets_for_filter_depot, int number_component) throws ContradictionException {
        edges_depot.sort(Edge.EdgeComparatorByCost);

        int cost_keme_edge = 2*edges_depot.get(this.num_trucks-1).cost();
        float cost_of_k_minus_one_edge = sum - cost_keme_edge;
        for (int i = this.num_trucks; i < edges_depot.size(); i++) {
            if (Math.ceil((double)(cost_of_k_minus_one_edge+edges_depot.get(i).cost()) / this.num_trucks) > this.L.getUB()) {
                for (int j = 0 ; j < this.depot.length ; j++) {
                    int next = Math.max(edges_depot.get(i).target(), edges_depot.get(i).source());
                    depot[j].removeValue(next + 2 * this.num_trucks - 1, this);
                    for (int k  = 0 ; k < 2 * this.num_trucks  ; k++) {
                        cities[next - 1].removeValue(k, this);
                    }
                }
            }
        }
        int position_depot = 0;
        //TODO : ICI

        Edge[] small_edge_depot = new Edge[distance.length];
        Edge[] second_small_edge_depot = new Edge[distance.length];

        for (Edge edge : edges_depot) {
            int next = Math.max(edge.target(), edge.source());
            int representant = sets_for_filter_depot.find(next);
            if (small_edge_depot[representant] == null) {
                small_edge_depot[representant] = edge;

            } else if (second_small_edge_depot[representant] == null) {
                second_small_edge_depot[representant] = edge;

            }

            else {
                int new_borne = edge.cost() - second_small_edge_depot[representant].cost();
                if (Math.ceil((double) (new_borne + sum_componnent[representant]) / (this.num_trucks - number_component + 1)) > this.L.getUB()) {
                    for (int j = 0; j < this.depot.length; j++) {
                        depot[j].removeValue(next + 2 * this.num_trucks - 1, this);
                        for (int k = 0; k < 2 * this.num_trucks; k++) {
                            cities[next - 1].removeValue(k, this);
                        }
                    }
                }
            }
        }
        for (int i = position_depot ; i < this.size_old_domains_depot ; i++) {
            old_domains_depot.quickSet(i,-1);
        }
    }

    private void filter_cities2(ArrayList<Edge> edges_depot,
                                ArrayList<Edge> edges_cities,
                                DisjointSets sets,
                                int nb_component,
                                int weight,
                                int[] sum_componnent,
                                Edge[] max_weight_by_tree,
                                ArrayList<Edge>[] split_spanning_tree,
                                ArrayList<Edge>[][] split_requests,
                                ArrayList<Edge> resquest_different_tree,
                                ArrayList<Edge>[][] split_spanning_tree_neighbours,
                                DisjointSets sets_depot) throws ContradictionException {

        for (Edge edge : resquest_different_tree) {
            /*
            int rep1 = sets.find(edge.source());
            int rep2 = sets.find(edge.target());
            int max;
            int rep_min;
            int rep_max;
            int start;
            int sum_to_add;
            if(!(max_weight_by_tree[rep1] == null && max_weight_by_tree[rep2] == null)) {
                if (max_weight_by_tree[rep1] == null) {
                    max = max_weight_by_tree[rep2].cost();
                    rep_min = rep1;
                    rep_max = rep2;
                    start = edge.target();
                } else if (max_weight_by_tree[rep2] == null) {
                    max = max_weight_by_tree[rep1].cost();
                    rep_min = rep2;
                    rep_max = rep1;
                    start = edge.source();
                } else if (max_weight_by_tree[rep1].cost() > max_weight_by_tree[rep2].cost()) {
                    max = max_weight_by_tree[rep1].cost();
                    rep_min = rep2;
                    rep_max = rep1;
                    start = edge.source();
                } else {
                    max = max_weight_by_tree[rep2].cost();
                    rep_min = rep1;
                    rep_max = rep2;
                    start = edge.target();
                }

                sum_to_add = total_wigth_each_side_of_max_edge[sets_for_max_each_side.find(rep_max)];
            }
            else {
                max = 0;
                sum_to_add = 0;
                rep_min = rep1;
            }*/

            int rep = sets_depot.find(edge.source());
            int max = max_weight_by_tree[rep].cost();


            if (Math.ceil((double) (-max + weight + edge.cost() ) / this.num_trucks) > this.L.getUB()){
                this.cities[edge.source() - 1].removeValue(edge.target() + 2 * this.num_trucks - 1,this);
                this.cities[edge.target() - 1].removeValue(edge.source() + 2 * this.num_trucks - 1,this);
            }
            //TODO : ICI

            if (Math.ceil((double) (-max + sum_componnent[rep] + edge.cost()) / (this.num_trucks-nb_component + 1)) > this.L.getUB()) {
                this.cities[edge.source() - 1].removeValue(edge.target() + 2 * this.num_trucks - 1,this);
                this.cities[edge.target() - 1].removeValue(edge.source() + 2 * this.num_trucks - 1,this);
            }

        }

        for (int i = 0 ; i < split_spanning_tree.length ; i++) {
            if (split_spanning_tree[i].size() > 0) {
                CartesianTree cartesianTree = new CartesianTree(split_spanning_tree[i],
                        split_spanning_tree_neighbours[i],split_requests[i]);
                cartesianTree.build_cartesian_tree();
                HashMap<Edge, Integer> result = cartesianTree.OLCA();
                for (Edge key : result.keySet()){

                    if (Math.ceil((double)(key.cost() - result.get(key) + weight) / this.num_trucks)  > this.L.getUB()) {
                        this.cities[key.source() - 1].removeValue(key.target() + 2 * this.num_trucks - 1,this);
                        this.cities[key.target() - 1].removeValue(key.source() + 2 * this.num_trucks - 1,this);
                    }
                    //TODO : ICI

                    if (Math.ceil((double) (sum_componnent[sets.find(key.target())] + key.cost() - result.get(key))
                            / (this.num_trucks - nb_component + 1))  > this.L.getUB()) {
                        this.cities[key.source() - 1].removeValue(key.target() + 2 * this.num_trucks - 1,this);
                        this.cities[key.target() - 1].removeValue(key.source() + 2 * this.num_trucks - 1,this);
                    }
                }
            }
        }
    }


    protected void verify_solution() throws ContradictionException {
        boolean all_variable_instanciated = true;
        for (IntVar city : this.cities) {
            if (!city.isInstantiated()) {
                all_variable_instanciated = false;
                break;
            }
        }
        if (all_variable_instanciated){
            for (IntVar depot : this.depot) {
                if(!depot.isInstantiated()) {
                    all_variable_instanciated = false;
                    break;
                }
            }
        }
        if (all_variable_instanciated && !is_constraint_consistent()) {
            throw new ContradictionException();
        }

        else if(all_variable_instanciated && this.L.getUB() < calculate_cost_of_the_solution_max_cycle()) {
            throw new ContradictionException();
        }
        else if (all_variable_instanciated && !this.L.isInstantiated()) {
            this.L.instantiateTo(calculate_cost_of_the_solution_max_cycle(), this);
        }
        else if(all_variable_instanciated && this.L.isInstantiated() && this.L.getValue() != calculate_cost_of_the_solution_max_cycle()) {
            throw new ContradictionException();
        }
    }

    private boolean is_constraint_consistent() {
        int[] start_position = new int[this.depot.length];
        int[] cities_position = new int[this.cities.length + 1];
        for (int i = 0 ; i < start_position.length; i+=2) { //go through the num_trucks cycles
            int current_position = i;
            int next_position = this.depot[i].getValue();
            start_position[i]+=1;
            if (next_position == 0){
                return false;
            }
            boolean complete_tour = false;
            while (!complete_tour){
                if (next_position < 2*this.num_trucks) { // Complete the cycle
                    cities_position[0]++;
                    start_position[next_position]++;
                    complete_tour = true;
                }
                else if (next_position == current_position) { // stay at the same position
                    return false;
                }
                else  { //we continue in the cycle
                    if (++cities_position[next_position - 2*this.num_trucks + 1] > 1)
                        return false;
                    current_position = next_position;
                    next_position = this.cities[next_position - 2*this.num_trucks].getValue();
                }
            }
        }
        for (int i = 1 ; i < cities_position.length ; i++) { // if we didn't go through all the cities
            if (cities_position[i] != 1)
                return false;
        }
        for (int i = 0 ; i < start_position.length ; i++) { // if we didn't go through all the depots
            if (start_position[i] != 1)
                return false;
        }
        // if there are exactly num_trucks departures from the depot
        return cities_position[0] == this.num_trucks;
    }
    private int calculate_cost_of_the_solution_max_cycle() {
        int total_one_cycle = 0;
        int max_cycle = 0;
        for (int i = 0; i < this.depot.length; i+=2) {
            total_one_cycle = 0;
            int current_position = 0;
            int next_position = this.depot[i].getValue();
            total_one_cycle += this.distance[0][next_position - 2*this.num_trucks + 1];
            current_position = next_position;
            next_position = this.cities[next_position - 2*this.num_trucks].getValue();
            while (next_position >= 2*this.num_trucks) {
                total_one_cycle += this.distance[current_position - 2*this.num_trucks  + 1][next_position - 2*this.num_trucks  + 1];
                current_position = next_position;
                next_position = this.cities[next_position - 2*this.num_trucks].getValue();
            }
            total_one_cycle += distance[current_position - 2*this.num_trucks  + 1][0];
            max_cycle = Math.max(max_cycle, total_one_cycle);
        }
        return max_cycle;
    }

    protected ArrayList<Edge> create_edges_from_depot(){
        ArrayList<Edge> edges = new ArrayList<>();
        for (int i = 0; i < this.cities.length; i++) {
            for (int j = 0; j < 2 * this.num_trucks; j++) {
                if ((this.cities[i].contains(j) || this.depot[j].contains(2 * this.num_trucks + i))) {
                    edges.add(new Edge(0, i + 1, distance[0][i + 1])); // In the graph, there is only one depot labeled with 0
                    break;
                }
            }
        }
        return edges;
    }

    protected Pair create_edges_between_cities_and_disjoint_set(int[] sum_componnent,
                                                                ArrayList<Edge> edges,
                                                                DisjointSets sets,
                                                                int[] cardinality_components,
                                                                Edge[] max_weight_by_tree,
                                                                ArrayList<Edge> edges_in_spanning_tree,
                                                                ArrayList<Edge>[] spanning_tree
                                                                ) {
        int union = 0;
        int weight = 0;
        for (int i = 0 ; i < this.cities.length ; i++) {
            for (DisposableValueIterator iterator = this.cities[i].getValueIterator(true); iterator.hasNext();) {
                int next = iterator.next();
                if (next >= 2 * this.num_trucks) {
                    int representant_source = sets.find(i+1);
                    int representant_target = sets.find(next - 2 * this.num_trucks + 1);
                    // If next is a city, its next destination is known, and the trees were not already united
                    if ( this.cities[i].getDomainSize() == 1 && representant_source != representant_target) {
                        int total_sum = sum_componnent[representant_source] + sum_componnent[representant_target] +
                                distance[i + 1][next - 2 * this.num_trucks + 1];
                        int total_cardinality = cardinality_components[representant_source] + cardinality_components[representant_target];
                        Edge new_edge =  new Edge(i+1,next - 2 * this.num_trucks + 1,distance[i + 1][next - 2 * this.num_trucks + 1]);
                        if (max_weight_by_tree[representant_source] == null) {
                            max_weight_by_tree[representant_source] = new_edge;
                        }


                        if (max_weight_by_tree[representant_target] == null) {
                            max_weight_by_tree[representant_target] = new_edge;
                        }


                        edges_in_spanning_tree.add(new_edge);
                        spanning_tree[i+1].add(new_edge);
                        spanning_tree[next - 2 * this.num_trucks + 1 ].add(new_edge);
                        sets.union(i + 1, next - 2 * this.num_trucks + 1);
                        old_domains_cities.quickSet(2 * union,i+1);
                        old_domains_cities.quickSet(2 * union + 1,next - 2 * this.num_trucks + 1);
                        int final_representant = sets.find(i + 1);
                        sum_componnent[final_representant] = total_sum;
                        max_weight_by_tree[final_representant] = new_edge;
                        cardinality_components[final_representant] = total_cardinality;
                        union++;
                        weight += distance[i + 1][next - 2 * this.num_trucks + 1];
                    }
                    else if (i+1 < next - 2 * this.num_trucks + 1 ||
                            ((i+1 > next - 2 * this.num_trucks + 1) &&
                                    !this.cities[next - 2 * this.num_trucks].contains(i + 2*this.num_trucks))) {
                        edges.add(new Edge(i + 1, next - 2 * this.num_trucks + 1,
                                distance[i + 1][next - 2 * this.num_trucks + 1]));
                    }
                }

            }
        }
        return new Pair(weight, union);
    }

    protected Pair kruskal_new_bound(ArrayList<Edge> edges_cities,
                                     DisjointSets sets_cities,
                                     DisjointSets sets_depots,
                                     int union,
                                     int[] sum_componnent,
                                     int total_weight,
                                     ArrayList<Edge> edges_depot,
                                     int[] cardinality_component, Edge[] max_weight_by_tree,
                                     ArrayList<Edge> others_edges, ArrayList<Edge> edges_in_spanning_tree,
                                     ArrayList<Edge>[] spanning_tree)
	throws ContradictionException {
        edges_cities.sort(Edge.EdgeComparatorByCost);
        edges_depot.sort(Edge.EdgeComparatorByCost);
        int sum_depot = 0;
        for (int i = 0 ; i < this.num_trucks ; i++) {
            sum_depot += edges_depot.get(i).cost();
        }
        sum_depot *= 2 ;
        int number_components = this.distance.length - 1 - union;
        for (int i = 0 ; i < edges_cities.size(); i++) {
            Edge edge = edges_cities.get(i);
            int rep_source = sets_depots.find(edge.source());
            int rep_target = sets_depots.find(edge.target());
            if (rep_source != rep_target) {
                if (number_components > this.num_trucks) {
                    int total_sum = sum_componnent[rep_source] + sum_componnent[rep_target] + edge.cost();
                    int cardinality = cardinality_component[rep_source] + cardinality_component[rep_target];
                    if (max_weight_by_tree[rep_source] == null) {
                        max_weight_by_tree[rep_source] = edge;
                    }

                    if (max_weight_by_tree[rep_target] == null){
                        max_weight_by_tree[rep_target] = edge;
                    }

                    total_weight += edge.cost();
                    spanning_tree[edge.source()].add(edge);
                    spanning_tree[edge.target()].add(edge);
                    edges_in_spanning_tree.add(edge);
                    sets_cities.union(edge.source(), edge.target());
                    sets_depots.union(edge.source(), edge.target());
                    old_domains_cities.quickSet(2 * union,edge.source());
                    old_domains_cities.quickSet(2 * union + 1,edge.target());
                    int final_representant = sets_cities.find(edge.source());
                    sum_componnent[final_representant] = total_sum;
                    cardinality_component[final_representant]  = cardinality;
                    max_weight_by_tree[final_representant] = edge;
                    number_components--;
                    union++;
                }
                else if (number_components <= this.num_trucks) {
                    others_edges.add(edge);
                    old_domains_cities.quickSet(2 * union,edge.source());
                    old_domains_cities.quickSet(2 * union+  1,edge.target());
                    int sum_rep_source = sum_componnent[sets_depots.find(edge.source())];
                    int sum_rep_target = sum_componnent[sets_depots.find(edge.target())];
                    sets_depots.union(edge.source(), edge.target());
                    int final_rep = sets_depots.find(edge.source());
                    sum_componnent[final_rep] = sum_rep_source + sum_rep_target;
                    max_weight_by_tree[final_rep] = edge;
                    number_components--;
                    union++;
                }
            }
            else {
                others_edges.add(edge);
            }
        }

        if (number_components > this.num_trucks) {
            throw  new ContradictionException();
        }
        int max_component = getMax_component(sets_depots, sum_componnent, edges_depot, cardinality_component);
        assert this.num_trucks <= number_components;
        total_weight += sum_depot;
        return new Pair (new Pair(max_component,number_components), total_weight);
    }

    private int getMax_component(DisjointSets sets_depots, int[] sum_componnent, ArrayList<Edge> edges_depot, int[] cardinality_component) {
        int max_component = 0;
        Edge[] low_edge = new Edge[this.distance.length];
        for (int i = 1 ; i < sum_componnent.length ; i++) {
            int current_component_weight = 0;
            int representant = sets_depots.find(i);
            if (representant == i) {
                if (cardinality_component[representant] > 1 ){
                    int position_depot = 0;
                    for (Edge edge: edges_depot){
                        int representant_edge = sets_depots.find(Math.max(edge.target(),edge.source()));
                        if (representant_edge == i) {
                            if (low_edge[i] == null) {
                                low_edge[i]= edge;
                                current_component_weight += edge.cost();
                                old_domains_depot.quickSet(position_depot,edge.source());
                                old_domains_depot.quickSet(position_depot+1,edge.target());
                                position_depot+=2;
                            }
                            else {
                                current_component_weight += edge.cost();
                                old_domains_depot.quickSet(position_depot,edge.source());
                                old_domains_depot.quickSet(position_depot+1,edge.target());
                                position_depot+=2;
                                break;
                            }
                        }
                    }
                }
                else {
                    for (Edge edge: edges_depot){
                        int representant_edge = sets_depots.find(Math.max(edge.target(),edge.source()));
                        if (representant_edge == i) {
                            current_component_weight += 2 * edge.cost();
                        }
                    }
                }

                if (sum_componnent[i] + current_component_weight > max_component) {
                    max_component = sum_componnent[i] + current_component_weight;
                }
                sum_componnent[i] += current_component_weight;
            }
        }
        return max_component;
    }


    protected int[] depth_first_search_all_graph(ArrayList<Edge>[] all_graph) {
        int[] parent = new int[all_graph.length];
        int[] visited = new int[all_graph.length];
        for (int i = 0 ; i < all_graph.length ; i++) {
            parent[i] = -1;
            visited[i] = -1;
        }

        for (int i = 1 ; i < visited.length ; i++) {
            LinkedList<Integer> stack = new LinkedList<>();
            if (visited[i] == -1) {
                stack.add(i);
            }
            while (!stack.isEmpty()) {
                int current = stack.pop();
                if (visited[current] == -1) {
                    visited[current] = 1;
                    for (int j = 0 ; j < all_graph[current].size() ; j++) {
                        int next = all_graph[current].get(j).source() != current ?
                                all_graph[current].get(j).source() : all_graph[current].get(j).target();
                        if (visited[next]==-1 && parent[next] == -1) {
                            stack.push(next);
                            parent[next] = current;
                        }
                    }
                }
            }
        }
        return parent;
    }
    protected int[] depth_first_search(ArrayList<Edge>[] all_graph, ArrayList<Edge> start) {
        int[] parent = new int[all_graph.length];
        int[] visited = new int[all_graph.length];


        for (int i = 0 ; i < start.size() ; i++) {
            int first = start.get(i).source() != 0 ? start.get(i).source() : start.get(i).target();
            LinkedList<Integer> stack = new LinkedList<>();
            stack.add(first);
            while (!stack.isEmpty()) {
                int current = stack.pop();
                if (visited[current] == 0) {
                    visited[current] = 1;
                    for (int j = 0 ; j < all_graph[current].size() ; j++) {
                        int next = all_graph[current].get(j).source() != current ?
                                all_graph[current].get(j).source() : all_graph[current].get(j).target();
                        if (visited[next]==0) {
                            stack.push(next);
                            parent[next] = first;
                        }
                    }
                }
            }
        }
        return parent;
    }
    protected ArrayList<Edge> create_edges_between_cities(){
        ArrayList<Edge> edges = new ArrayList<>();
        for (int i = 2*this.num_trucks ; i < this.cities.length + 2*this.num_trucks - 1; i++) {
            for (int j = i + 1 ; j < this.cities.length + 2*this.num_trucks; j++) {
                if (this.cities[i - 2*this.num_trucks].contains(j) || this.cities[j - 2*this.num_trucks].contains(i)) {
                    edges.add(new Edge(i - 2*this.num_trucks + 1, j - 2*this.num_trucks + 1,
                            distance[i - 2*this.num_trucks + 1][j - 2*this.num_trucks + 1]));
                }
            }

        }
        return edges;
    }
    protected int calculate_optimiste_borne() throws ContradictionException, IOException {
        ArrayList<Edge> edges = create_edges_from_depot();
        edges.addAll(create_edges_between_cities());
        Pair result = k_tree(edges);
        ArrayList<Edge>[] k_tree = (ArrayList<Edge>[]) result.getKey();
        ArrayList<Edge>[] other_edges = (ArrayList<Edge>[]) result.getValue();

        print_domaine_in_file(debug);

        ArrayList<Edge>[] all_edges = other_edges.clone();
        for (int i = 0 ; i < all_edges.length ; i++) {
            all_edges[i].addAll((Collection<? extends Edge>) k_tree[i].clone());
        }

        ArrayList<Edge>[] all_edges_without_depot = remove_depot(all_edges.clone());

        int[] tree_parent = depth_first_search(all_edges_without_depot, k_tree[0]);
        int[] tree_weight = calcule_weigth_tree(k_tree);
        int i;
        return calculate_borne(tree_parent, tree_weight, (ArrayList<Edge>) k_tree[0].clone());

    }
    protected int calculate_borne(int[] tree_parent, int[] tree_weight, ArrayList<Edge> neighbour_of_0) {
        int total_sum = 0;
        while (neighbour_of_0.size() != 0) {
            int next = neighbour_of_0.get(0).target() != 0 ?
                    neighbour_of_0.get(0).target() : neighbour_of_0.get(0).source();
            int j = 1;
            int composant = 1;
            int partial_sum = tree_weight[next] + this.distance[0][next];
            while (j < neighbour_of_0.size()) {
                int next_vertex = neighbour_of_0.get(j).target() != 0 ?
                        neighbour_of_0.get(j).target() : neighbour_of_0.get(j).source();
                if (tree_parent[next_vertex] == next) {
                    partial_sum += (tree_weight[next_vertex] + distance[0][next_vertex]);
                    composant++;
                    neighbour_of_0.remove(j);
                }
                else {
                    j++;
                }
            }
            total_sum = Math.max((int) Math.ceil(partial_sum/composant), total_sum);
            neighbour_of_0.remove(0);
        }

        return total_sum;
    }
    protected int[] calcule_weigth_tree(ArrayList<Edge>[] k_tree) {
        int[] weigth = new int[k_tree.length];
        int[] label = new int[k_tree.length];
        label[0] = 1;
        for (int i = 0 ; i < k_tree[0].size() ; i++) {
            int first = k_tree[0].get(i).source() != 0 ? k_tree[0].get(i).source() : k_tree[0].get(i).target();
            int somme = 0;
            LinkedList<Integer> stack = new LinkedList<>();
            stack.add(first);
            while (!stack.isEmpty())  {
                int current = stack.pop();
                if (label[current] == 0) {
                    label[current] = 1;
                    for (int j = 0 ; j < k_tree[current].size() ; j++) {
                        int next = k_tree[current].get(j).source() != current ?
                                k_tree[current].get(j).source() : k_tree[current].get(j).target();
                        if (next != 0 && label[next]==0) {
                            somme += this.distance[current][next];
                            stack.push(next);
                        }
                    }
                }
            }
            weigth[first] = somme;
        }
        return weigth;
    }
    protected ArrayList<Edge>[] remove_depot(ArrayList<Edge>[] k_tree) {

        for (int i = 0 ; i < k_tree[0].size() ; i++) {
            int next = k_tree[0].get(i).source() != 0 ? k_tree[0].get(i).source() : k_tree[0].get(i).target();
            for (int j = 0 ; j < k_tree[next].size() ; j++) {
                if (k_tree[next].get(j).source() == 0 || k_tree[next].get(j).target() == 0) {
                    k_tree[next].remove(j);
                    break;
                }
            }
        }
        k_tree[0] = new ArrayList<>();
        return k_tree;
    }
    protected Pair kruskal(ArrayList<Edge> edges, boolean zero_first) {
        if (zero_first) {
            edges.sort(Edge.EdgeComparatorByCostZeroFirst);
        }
        else {
            edges.sort(Edge.EdgeComparatorByCostZeroAfter);
        }

        ArrayList<Edge>[] others_edges = new ArrayList[this.distance.length];

        ArrayList<Edge>[] min_spanning_tree = new ArrayList[this.distance.length];
        for (int i = 0 ; i < min_spanning_tree.length ; i++) {
            min_spanning_tree[i] = new ArrayList<Edge>();
        }
        for (int i = 0 ; i < others_edges.length ; i++) {
            others_edges[i] = new ArrayList<Edge>();
        }

        DisjointSets sets = new DisjointSets(this.distance.length);
        for (int i = 0 ; i < edges.size(); i++) {
            Edge edge = edges.get(i);
            if (edge.source() == 0 || edge.target() == 0) {
                Pair result = edges_after_different_from_0(edges,i);
                if (min_spanning_tree[0].size() == this.num_trucks && (boolean) result.getKey()) {
                    Collections.swap(edges, i, i + (int) result.getValue());
                    edge = edges.get(i);
                }
            }
            if(sets.find(edge.source()) != sets.find(edge.target())) {
                min_spanning_tree[edge.source()].add(edge);
                min_spanning_tree[edge.target()].add(edge);
                sets.union(edge.source(), edge.target());
            }
            else {
                others_edges[edge.target()].add(edge);
                others_edges[edge.source()].add(edge);
            }
        }
        return new Pair(min_spanning_tree, others_edges);
    }
    protected Pair edges_after_different_from_0(ArrayList<Edge> edges, int i) {
        int number_zero = 1;
        int number_non_zero_after = 0;
        int cost = edges.get(i).cost();
        int current_postion = i + 1;
        while (current_postion < edges.size()&& edges.get(current_postion).cost() == cost) {
            if (edges.get(current_postion).source() == 0 || edges.get(current_postion).target() == 0) {
                number_zero++;
            }
            else {
                number_non_zero_after++;
            }
            current_postion++;
        }
        return new Pair(number_non_zero_after >= number_zero, number_zero) ;
    }
    protected Pair k_tree(ArrayList<Edge> edges) throws ContradictionException, IOException {
        boolean fix_point = false;
        boolean fix_point2 = false;
        Pair kruskal = kruskal((ArrayList<Edge>) edges.clone(), true);
        ArrayList<Edge>[] others_edges_current = (ArrayList<Edge>[]) kruskal.getValue();
        ArrayList<Edge>[] min_spanning_tree_current = (ArrayList<Edge>[]) kruskal.getKey();
        ArrayList<Edge>[] min_spanning_tree_pred = clone(min_spanning_tree_current);
        boolean faisable = verify_faisability(min_spanning_tree_current,others_edges_current);
        if(faisable) {
            while (min_spanning_tree_current[0].size() != this.num_trucks && !fix_point2) {
                int min_delta = Integer.MAX_VALUE;
                min_spanning_tree_pred = clone(min_spanning_tree_current);
                if (min_spanning_tree_current[0].size() < this.num_trucks) {
                    min_delta = getMin_delta_for_adding_edge(others_edges_current[0], min_spanning_tree_current, min_delta);
                    for (int i = 0; i < others_edges_current[0].size() + min_spanning_tree_current[0].size() ; i++) {
                        edges.get(i).setCost(edges.get(i).cost() - min_delta);
                    }
                    kruskal = kruskal((ArrayList<Edge>) edges.clone(), true);
                }
                else if (min_spanning_tree_current[0].size() > this.num_trucks) {
                    min_delta = getMin_delta_for_remove_edge2(others_edges_current, min_spanning_tree_current);
                    for (int i = 0 ; i < others_edges_current[0].size() + min_spanning_tree_current[0].size() ; i++) {
                        edges.get(i).setCost(edges.get(i).cost() + min_delta);
                    }
                    kruskal = kruskal((ArrayList<Edge>) edges.clone(), false);
                }
                others_edges_current = (ArrayList<Edge>[]) kruskal.getValue();
                min_spanning_tree_current = (ArrayList<Edge>[]) kruskal.getKey();
                if (min_spanning_tree_current[0].size() > this.num_trucks) {
                    ArrayList<Edge> simple_switch = simple_switch(min_spanning_tree_current.clone(),
                            others_edges_current.clone());
                    make_the_switch(min_spanning_tree_current, others_edges_current, simple_switch);
                }
                if (min_spanning_tree_current[0].size() == min_spanning_tree_pred[0].size() && min_delta == 0) {
                    fix_point = true;
                }
                if (verify_change(min_spanning_tree_current, min_spanning_tree_pred) &&
                        !verify_change_edge(min_spanning_tree_current, min_spanning_tree_pred) && fix_point) {
                    fix_point2 = true;
                }
                if (verify_change(min_spanning_tree_current, min_spanning_tree_pred) ||
                        verify_change_edge(min_spanning_tree_current, min_spanning_tree_pred)) {
                    fix_point = true;
                }
                else {
                    fix_point = false;
                    fix_point2 = false;
                }
            }
            if (fix_point && fix_point2) {
                throw new ContradictionException();
            }
            return new Pair(min_spanning_tree_current, others_edges_current);
        }
        throw new ContradictionException();
    }
    private int getMin_delta_for_remove_edge(ArrayList<Edge>[] others_edges_current, ArrayList<Edge>[] min_spanning_tree_current, int min_delta) {
        int delta;
        for (Edge edge : min_spanning_tree_current[0]) {
            int start = edge.target() != 0 ? edge.target() : edge.source();
            for (Edge edge_not_chose : others_edges_current[start]) {
                if (edge_not_chose.source() != 0 && edge_not_chose.target() !=0) {
                    delta = edge_not_chose.cost() - Math.max(
                            find_max_edge_leaving_0_connected(edge_not_chose.source(), min_spanning_tree_current),
                            find_max_edge_leaving_0_connected(edge_not_chose.target(), min_spanning_tree_current));
                    if (delta >= 0)  {
                        min_delta = delta < min_delta ? delta : min_delta;
                    }
                }
            }
        }
        return min_delta;
    }
    private int getMin_delta_for_remove_edge2(ArrayList<Edge>[] others_edges_current, ArrayList<Edge>[] min_spanning_tree_current) {
        int min_delta = Integer.MAX_VALUE;
        for (int i = 1 ; i < others_edges_current.length ; i ++) {
            for (Edge edge : others_edges_current[i]) {
                int cost_to_0_from_source = find_max_edge_leaving_0_connected(edge.source(), min_spanning_tree_current);
                int cost_to_0_from_target = find_max_edge_leaving_0_connected(edge.target(), min_spanning_tree_current);
                int delta = edge.cost() - Math.max(cost_to_0_from_source, cost_to_0_from_target);
                if (delta >= 0) {
                    min_delta = delta < min_delta ? delta : min_delta;
                }
            }
        }
        return min_delta;
    }
    private int getMin_delta_for_adding_edge(ArrayList<Edge> others_edges_current, ArrayList<Edge>[] min_spanning_tree_current, int min_delta) {
        int delta ;
        for (Edge edge : others_edges_current) {
            int destination = edge.target() != 0 ? edge.target() : edge.source();
            int cost_edge_0i = edge.cost();
            int cost_max_edge_path_0i = find_max_cost_on_a_path_wihtout_0(0, destination, min_spanning_tree_current);
            delta = cost_edge_0i - cost_max_edge_path_0i;
            min_delta = delta < min_delta ? delta : min_delta;
        }
        return min_delta;
    }
    private int find_max_cost_on_a_path_wihtout_0(int i, int destination, ArrayList<Edge>[] min_spanning_tree_current) {
        Edge[] predecessor = get_predecessors_edges(i, destination, min_spanning_tree_current);
        int max = 0;
        int current = destination;
        while (current != i) {
            int next = predecessor[current].target() != current ?
                    predecessor[current].target() : predecessor[current].source();
            if (next != 0) {
                max = predecessor[current].cost() > max ? predecessor[current].cost() : max;
            }
            current = next;
            if (next == i) {
                break;
            }
        }
        return max;
    }
    protected void make_the_switch(ArrayList<Edge>[] min_spanning_tree_current, ArrayList<Edge>[] others_dedges_current,
                                   ArrayList<Edge> simple_switch) {
        while (simple_switch.size() != 0) {
            min_spanning_tree_current[simple_switch.get(0).source()].remove(simple_switch.get(0));
            min_spanning_tree_current[simple_switch.get(0).target()].remove(simple_switch.get(0));
            others_dedges_current[simple_switch.get(0).source()].add(simple_switch.get(0));
            others_dedges_current[simple_switch.get(0).target()].add(simple_switch.get(0));

            others_dedges_current[simple_switch.get(1).source()].remove(simple_switch.get(1));
            others_dedges_current[simple_switch.get(1).target()].remove(simple_switch.get(1));
            min_spanning_tree_current[simple_switch.get(1).source()].add(simple_switch.get(1));
            min_spanning_tree_current[simple_switch.get(1).target()].add(simple_switch.get(1));

            simple_switch.remove(0);
            simple_switch.remove(0);
        }
    }
    protected ArrayList<Edge> simple_switch(ArrayList<Edge>[] min_spanning_tree, ArrayList<Edge>[] others_edges) {
        int number_swtch = min_spanning_tree[0].size() - this.num_trucks;
        ArrayList<Edge> swtich = new ArrayList<>();

        for (int i = 0 ; i < min_spanning_tree[0].size() ; i++) {
            int start = min_spanning_tree[0].get(i).source() != 0 ? min_spanning_tree[0].get(i).source() :
                    min_spanning_tree[0].get(i).target();
            for (int j = 0 ; j < others_edges[start].size() ; j++) {
                if (others_edges[start].get(j).cost() ==  min_spanning_tree[0].get(i).cost()) {
                    swtich.add(min_spanning_tree[0].get(i));
                    swtich.add(others_edges[start].get(j));
                    number_swtch--;
                }
                if (number_swtch == 0) {
                    return swtich;
                }
            }
        }
        return swtich;
    }
    private boolean verify_change_edge(ArrayList<Edge>[] min_spanning_tree_current, ArrayList<Edge>[] min_spanning_tree_pred) {
        for (int i = 0 ; i < min_spanning_tree_current.length ; i++) {
            for (int j = 0 ; j < min_spanning_tree_current[i].size() ; j++) {
                for (int k = 0 ; k < min_spanning_tree_pred[i].size() ; k++)
                if ((min_spanning_tree_current[i].get(j).source() == min_spanning_tree_pred[i].get(k).source() ||
                        min_spanning_tree_current[i].get(j).source() == min_spanning_tree_pred[i].get(k).target()) &&
                        (min_spanning_tree_current[i].get(j).target() == min_spanning_tree_pred[i].get(k).source() ||
                                min_spanning_tree_current[i].get(j).target() == min_spanning_tree_pred[i].get(k).target())
                        && min_spanning_tree_current[i].get(j).cost() != min_spanning_tree_pred[i].get(k).cost());
                return false;
            }
        }
        return true;
    }
    protected boolean verify_change(ArrayList<Edge>[] min_spanning_tree_current, ArrayList<Edge>[] min_spanning_tree_next) {
        for (int i = 0 ; i < min_spanning_tree_current.length ; i ++) {
            if (min_spanning_tree_current[i].size() != min_spanning_tree_next[i].size()) {
                return false;
            }

            for (int j = 0 ; j < min_spanning_tree_current[i].size() ; j++) {
                int next = min_spanning_tree_current[i].get(j).source() != i ?
                        min_spanning_tree_current[i].get(j).source() : min_spanning_tree_current[i].get(j).target();
                boolean inside = false;
                for (int k = 0 ; k < min_spanning_tree_next[i].size() ; k++) {
                    if ((min_spanning_tree_next[i].get(k).source() == next ||
                            min_spanning_tree_next[i].get(k).target() == next)){
                        inside = true;
                    }
                }
                if (!inside) {
                    return false;
                }
            }
        }
        return true;
    }
    protected int find_max_edge_leaving_0_connected(int start, ArrayList<Edge>[] edges) {
        int[] visited = new int[edges.length];
        visited[start] = 1;
        LinkedList<Integer> queue = new LinkedList<>();
        queue.add(start);
        while (!queue.isEmpty()) {
            int current = queue.poll();
            for (Edge edge : edges[current]) {
                int next = edge.target() != current ? edge.target() : edge.source();
                if (next == 0) {
                    return distance[0][current];
                }
                if (visited[next] != 1) {
                    visited[next] = 1;
                    queue.add(next);
                }
            }
        }
        return Integer.MAX_VALUE;
    }
    protected ArrayList<Edge>[] clone(ArrayList<Edge>[] to_clone) {
        ArrayList[] clone = new ArrayList[to_clone.length];
        for (int i = 0 ; i < clone.length ; i++) {
            clone[i] = new ArrayList();
            for (Edge edge : to_clone[i]) {
                clone[i].add(new Edge(edge.source(),edge.target(),edge.cost()));
            }
        }
        return clone;
    }
    protected boolean verify_faisability(ArrayList<Edge>[] min_spanning_tree, ArrayList<Edge>[] others_edges) {
        int sum = 0;
        for (int i = 1 ; i < others_edges.length ; i++) {
            sum += others_edges[i].size();
            sum += min_spanning_tree[i].size();
        }
        sum -= others_edges[0].size();
        sum -= min_spanning_tree[0].size();
        sum = sum/2;

        int number_isolate_0 = 0;

        for (int i = 1 ; i < others_edges.length ; i++) {
            if (others_edges[i].size() + min_spanning_tree[i].size() == 1) {
                if (others_edges[i].size() > 0 &&
                        (others_edges[i].get(0).source() == 0 || others_edges[i].get(0).target() == 0)) {
                    number_isolate_0++;
                }
                else if (min_spanning_tree[i].size() > 0 &&
                        (min_spanning_tree[i].get(0).source() == 0 || min_spanning_tree[i].get(0).target() == 0)){
                    number_isolate_0++;
                }
            }
        }

        return sum >= this.cities.length - this.num_trucks &&
                min_spanning_tree[0].size() + others_edges[0].size() >= this.num_trucks &&
                (this.num_trucks == this.cities.length || number_isolate_0 < this.num_trucks);
    }
    protected int find_max_cost_on_a_path(int start, int destination, ArrayList<Edge>[] edges) {
        Edge[] predecessor = get_predecessors_edges(start, destination, edges);
        return get_max_from_predecessors_edges(start, destination, predecessor);
    }
    private int get_max_from_predecessors_edges(int start, int destination, Edge[] predecessor) {
        int max = 0;
        int current = destination;
        while (current != start) {
            int next = predecessor[current].target() != current ?
                    predecessor[current].target() : predecessor[current].source();
            max = predecessor[current].cost() > max ? predecessor[current].cost() : max;
            current = next;
            if (next == start) {
                break;
            }
        }
        return max;
    }
    Edge[] get_predecessors_edges(int start, int destination, ArrayList<Edge>[] edges) {
        int[] visited = new int[edges.length];
        Edge[] predecessor = new Edge[edges.length];
        LinkedList<Integer> queue = new LinkedList<>();
        queue.add(start);
        visited[start] = 1;
        while (!queue.isEmpty()) {
            int current = queue.poll();
            if (current == destination) {
                break;
            }
            for (Edge edge : edges[current]) {
                int next = edge.target() != current ? edge.target() : edge.source();
                if (visited[next] != 1) {
                    predecessor[next] = edge;
                    visited[next] = 1;
                    queue.add(next);
                }
            }
        }
        return predecessor;
    }
    public void filter (ArrayList<Edge>[] min_spanning_tree, ArrayList<Edge>[] other_edges) {
        for (int i = 1 ; i < other_edges.length ; i++) {
            for (Edge edge : other_edges[i]) {
                int reduced_cost = calculate_reduce_cost(edge, min_spanning_tree, other_edges);

            }
        }
    }
    Edge get_max_edge_from_predecessors_edges(int start, int destination, Edge[] predecessor) {
        int max = 0;
        Edge edge_max = new Edge(0,0,0);
        int current = destination;
        while (current != start) {
            int next = predecessor[current].target() != current ?
                    predecessor[current].target() : predecessor[current].source();
            if (next == start) {
                break;
            }
            if (predecessor[current].cost() > max) {
                max = predecessor[current].cost();
                edge_max = predecessor[current];
            }
            current = next;
        }
        return edge_max;
    }
    protected int calculate_reduce_cost(Edge edge, ArrayList<Edge>[] min_spanning_tree, ArrayList<Edge>[] others_edges) {
        Edge[] predecessor = get_predecessors_edges(edge.source(), edge.target(), min_spanning_tree);
        Edge edge_max = get_max_edge_from_predecessors_edges(edge.source(),edge.target(),predecessor);
        ArrayList<Edge>[] new_spanning_tree = min_spanning_tree.clone();
        find_edge_to_add_and_to_remove(edge, min_spanning_tree, others_edges, edge_max, new_spanning_tree);

        ArrayList<Edge>[] all_edges = others_edges.clone();
        for (int i = 0 ; i < all_edges.length ; i++) {
            all_edges[i].addAll((Collection<? extends Edge>) new_spanning_tree[i].clone());
        }

        ArrayList<Edge>[] all_edges_without_depot = remove_depot(all_edges.clone());

        int[] tree_parent = depth_first_search(all_edges_without_depot, new_spanning_tree[0]);
        int[] tree_weight = calcule_weigth_tree(new_spanning_tree);

        return calculate_borne(tree_parent, tree_weight, (ArrayList<Edge>)new_spanning_tree[0].clone());
    }
    protected void find_edge_to_add_and_to_remove(Edge edge, ArrayList<Edge>[] min_spanning_tree, ArrayList<Edge>[] others_edges, Edge edge_max, ArrayList<Edge>[] new_spanning_tree) {
        if (edge_max.source() !=0 && edge_max.target() != 0) {
            new_spanning_tree[edge_max.source()].remove(edge_max);
            new_spanning_tree[edge_max.target()].remove(edge_max);
            new_spanning_tree[edge.source()].add(edge);
            new_spanning_tree[edge.target()].add(edge);
            others_edges[edge_max.source()].add(edge_max);
            others_edges[edge_max.target()].add(edge_max);
        }
        else {
            new_spanning_tree[edge_max.source()].remove(edge_max);
            new_spanning_tree[edge_max.target()].remove(edge_max);
            new_spanning_tree[edge.source()].add(edge);
            new_spanning_tree[edge.target()].add(edge);
            others_edges[edge_max.source()].add(edge_max);
            others_edges[edge_max.target()].add(edge_max);

            Edge to_add = new Edge(0,0,0);
            Edge to_remove = new Edge(0,0,0);
            int cost_to_adjuste = edge.cost();
            edge.setCost(Integer.MIN_VALUE);
            int min_delta = Integer.MAX_VALUE;
            for (Edge new_edge : others_edges[0]) {
                int destination = new_edge.target() != 0 ? new_edge.target() : new_edge.source();
                int cost_edge_0i = new_edge.cost();
                Edge[] predecessor_new_path = get_predecessors_edges(0, destination, min_spanning_tree);
                Edge edge_cost_max_path_0i = get_max_edge_from_predecessors_edges(0,destination,predecessor_new_path);
                int delta = cost_edge_0i - edge_cost_max_path_0i.cost();
                if (delta < min_delta) {
                    min_delta = delta;
                    to_remove = edge_cost_max_path_0i;
                    to_add = new_edge;
                }

            }
            edge.setCost(cost_to_adjuste);
            new_spanning_tree[to_remove.source()].remove(to_remove);
            new_spanning_tree[to_remove.target()].remove(to_remove);
            new_spanning_tree[to_add.source()].add(to_add);
            new_spanning_tree[to_add.target()].add(to_add);
            others_edges[to_remove.source()].add(to_remove);
            others_edges[to_remove.target()].add(to_remove);
        }
    }
    public void print_domaine_in_file(boolean debug) throws IOException {
        if (debug) {
            String line = "";
            for (int i = 0; i < this.depot.length; i++) {
                DisposableValueIterator my_it = this.depot[i].getValueIterator(true);
                while (my_it.hasNext()) {
                    int next = my_it.next();
                    line += next;
                    line += " ";
                }
                line += "\n";
                bw.write(line);
                line = "";
            }
            line += "\n";
            bw.write(line);
            line = "";
            for (int i = 0; i < this.cities.length; i++) {
                DisposableValueIterator my_it = this.cities[i].getValueIterator(true);
                while (my_it.hasNext()) {
                    int next = my_it.next();
                    line += next;
                    line += " ";
                }
                line += "\n";
                bw.write(line);
                line = "";
            }
            line += "\n";
            line += this.L.getLB();
            line += " ";
            line += this.L.getUB();
            line += "\n\n";
            bw.write(line);
            bw.flush();
        }

    }

    @Override
    public ESat isEntailed() {
        return ESat.UNDEFINED;
    }
}
