import org.apache.commons.lang3.ArrayUtils;
import org.chocosolver.graphsolver.GraphModel;
import org.chocosolver.graphsolver.cstrs.channeling.edges.PropNeighIntsChannel1;
import org.chocosolver.graphsolver.cstrs.channeling.edges.PropSuccIntsChannel1;
import org.chocosolver.graphsolver.variables.DirectedGraphVar;
import org.chocosolver.graphsolver.variables.UndirectedGraphVar;
import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solution;
import org.chocosolver.solver.constraints.Arithmetic;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.constraints.Operator;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.search.strategy.Search;
import org.chocosolver.solver.search.strategy.assignments.DecisionOperator;
import org.chocosolver.solver.search.strategy.decision.Decision;
import org.chocosolver.solver.search.strategy.decision.IntDecision;
import org.chocosolver.solver.search.strategy.selectors.values.IntValueSelector;
import org.chocosolver.solver.search.strategy.selectors.variables.VariableSelector;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.PoolManager;
import org.chocosolver.util.objects.graphs.DirectedGraph;
import org.chocosolver.util.objects.graphs.UndirectedGraph;
import org.chocosolver.util.objects.setDataStructures.SetType;
import java.util.Arrays;
import java.util.stream.IntStream;

import static org.chocosolver.solver.search.strategy.Search.intVarSearch;

public class Parameters {
    int num_model;
    String instance_name;
    GraphModel model;
    int num_trucks;
    int num_cities;
    int[][] distance;
    int propagation = 0;
    int[] depot_next;
    int[] cities_next;
    float timestamp = 0;

    public Parameters(String instance_name, int model, int propagation, int num_cities, int num_trucks, int[][] distance) throws ContradictionException {
        assert num_cities > 0;
        assert num_trucks > 0;
        assert num_cities >= num_trucks;

        this.model = new GraphModel();

        for (int i = 0; i < distance.length; i++) {
            assert distance[i].length == num_cities + 1;
            for (int j = 0 ; j < distance[i].length; j++){
                if(i == j)
                    assert distance[i][j] == 0;
                else
                    assert distance[i][j] >= 0;
            }
        }
        this.instance_name = instance_name;
        this.num_model = model;
        this.num_trucks = num_trucks;
        this.num_cities = num_cities;
        this.distance = distance;
        this.model.getSolver().limitTime("60s");


        int[][] order = getVariableOrder(create_adjustedDistance_withouifelse());


        if (model == 2) {
            create_choco_model_circuit_whitout_ifelse();
        }

        else if(model == 5) {
            this.propagation = propagation;
            //this.model.getSolver().limitTime("600s");
            create_circuits_model_with_circuit_choco_with_new_domaine_and_element();
        }

        else if(model == 6) {
            this.propagation = propagation;
            //this.model.getSolver().limitTime("600s");
            create_circuits_model_with_circuit_choco_with_new_domaine_and_element_dom();
        }
        else if(model == 7) {
            this.propagation = propagation;
            this.model.getSolver().limitTime("60s");
            create_circuits_model_with_circuit_choco_with_new_domaine_and_element_no_keep();
        }
    }

    private int[][] getVariableOrder(int[][] adjustedDistance) {
        int[][] order = new int[adjustedDistance.length][adjustedDistance.length];

        for (int i = this.num_trucks * 2 ; i < adjustedDistance.length ; i++) {
            int[] elements = (int[])adjustedDistance[i].clone();
            int min = Integer.MAX_VALUE;
            for (int j = this.num_trucks * 2 ; j < adjustedDistance.length ; j++) {
                if (elements[j] < elements[min]) {
                   min = j;
                }
            }
            elements[min] = Integer.MAX_VALUE;
            for (int j = 0 ; j < this.num_trucks * 2 ; j++) {
                order[j][i - 2*this.num_trucks] = min;
            }
        }


        for (int i = this.num_trucks * 2 ; i < adjustedDistance.length ; i++) {
            int[] elements = (int[])adjustedDistance[i].clone();
            elements[i] = Integer.MAX_VALUE;
            int min = elements[0];
            for (int j = this.num_trucks * 2 ; j < adjustedDistance.length ; j++)
            {
                if (elements[j] < elements[min])
                {
                    min = j;
                }
            }
            elements[min] = Integer.MAX_VALUE;
            order[i][i - this.num_trucks * 2] = min;
        }
        return order;
    }

    private void create_circuits_model_with_circuit_choco_with_new_domaine_and_element_no_keep() throws ContradictionException {
        IntVar[] nextCities = new IntVar[this.distance.length + (this.num_trucks * 2) - 1];
        int[][] adjustedDistance = create_adjustedDistance_withouifelse();

        for(int i = 0 ; i < this.num_trucks * 2; i++ ){
            if (Math.floorMod(i,2) == 1){
                nextCities[i] = this.model.intVar(i - 1);
            }
            else {
                nextCities[i] = this.model.intVar("cities[" + i + "]",2 * this.num_trucks, nextCities.length - 1);
            }
        }

        for (int i = this.num_trucks * 2 ; i < nextCities.length; i++) {
            nextCities[i] = this.model.intVar("cities[" + i + "]", ArrayUtils.remove(IntStream.range(0, nextCities.length).toArray(),i));
        }

        this.model.circuit(nextCities).post();

        IntVar[] trajet = this.model.intVarArray("trajet",nextCities.length,0,IntVar.MAX_INT_BOUND-1,true);
        IntVar[] distanceNext = new IntVar[nextCities.length];
        IntVar[] trajetNext = new IntVar[nextCities.length];

        for (int i = 0 ; i < distanceNext.length ; i ++) {
            distanceNext[i] = this.model.intVar("distanceNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(distanceNext[i], adjustedDistance[i], nextCities[i], 0).post();
        }


        for(int i = 1 ; i < 2 * this.num_trucks ; i+=2) {
            trajet[i] = this.model.intVar("trajet[" + i + "]", 0);
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0);
        }

        for(int i = 0 ; i < 2 * this.num_trucks ; i+=2) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }


        for (int i = this.num_trucks * 2 ; i < distanceNext.length ; i ++) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }

        IntVar trajet_max = this.model.intVar("trajet_max",0, IntVar.MAX_INT_BOUND-1,true);
        for (int i = 0 ; i < this.num_trucks*2 ; i++) {
            //this.model.post(new Arithmetic(trajet[i], Operator.get(">="), trajet[i+2]));
            this.model.arithm(trajet_max, ">=", trajet[i]).post();
        }

        Constraint c = new Constraint("MyConstraint", new Circuits(
                Arrays.copyOfRange(nextCities, 2*this.num_trucks, nextCities.length),
                Arrays.copyOfRange(nextCities, 0, 2*this.num_trucks),
                this.distance, this.num_trucks, trajet_max, this.propagation, 1));

        this.model.post(c);

        UndirectedGraph graphLB = new UndirectedGraph(model, this.num_trucks * 2 + this.distance.length - 1, SetType.BITSET, true);
        UndirectedGraph graphUB = new UndirectedGraph(model, this.num_trucks * 2 + this.distance.length - 1, SetType.BITSET, true);
        UndirectedGraphVar graphVar = new UndirectedGraphVar("graphe", model, graphLB, graphUB);

        for (int i = 0 ; i < adjustedDistance.length - 1 ; i++) {
            for (int j = 1 ; j < adjustedDistance.length ; j++) {
                graphUB.addEdge(i, j);
            }
        }


        model.tsp(graphVar, trajet_max, adjustedDistance, 1);
        //this.model.getSolver().setSearch(Search.domOverWDegSearch(nextCities), Search.inputOrderLBSearch(trajet_max));
        model.neighborsChanneling(graphVar,nextCities).post();
        model.setObjective(false, trajet_max);



        Solution best = null;
        while (model.getSolver().solve()) {
            if(best == null) best = new Solution(model);
            best.record();
            if(trajet_max.isInstantiated()) {
                int ms = best.getIntVal(trajet_max);
                this.timestamp = model.getSolver().getTimeCount();
                //System.out.println(ms + " (" + String.format("%.2f", timestamp) + "s)");
            }
        }

        //Solution best = this.model.getSolver().findOptimalSolution(trajet_max,false);

        this.depot_next = new int[2*this.num_trucks];
        this.cities_next = new int[nextCities.length - 2*this.num_trucks];

        for (int i = 0 ; i < this.depot_next.length ; i++) {
            depot_next[i] = best.getIntVal(nextCities[i]);
        }
        for (int i = 0 ; i < this.cities_next.length ; i++) {
            cities_next[i] = best.getIntVal(nextCities[i + 2*this.num_trucks]);
        }
    }

    private void create_circuits_model_with_circuit_choco_with_new_domaine_and_element() throws ContradictionException {
        IntVar[] nextCities = new IntVar[this.distance.length + (this.num_trucks * 2) - 1];
        int[][] adjustedDistance = create_adjustedDistance_withouifelse();

        for(int i = 0 ; i < this.num_trucks * 2; i++ ){
            if (Math.floorMod(i,2) == 1){
                nextCities[i] = this.model.intVar(i - 1);
            }
            else {
                nextCities[i] = this.model.intVar("cities[" + i + "]",2 * this.num_trucks, nextCities.length - 1);
            }
        }


        for (int i = this.num_trucks * 2 ; i < nextCities.length; i++) {
            nextCities[i] = this.model.intVar("cities[" + i + "]", ArrayUtils.remove(IntStream.range(0, nextCities.length).toArray(),i));
        }

        this.model.circuit(nextCities).post();

        IntVar[] trajet = this.model.intVarArray("trajet",nextCities.length,0,IntVar.MAX_INT_BOUND-1,true);
        IntVar[] distanceNext = new IntVar[nextCities.length];
        IntVar[] trajetNext = new IntVar[nextCities.length];

        for (int i = 0 ; i < distanceNext.length ; i ++) {
            distanceNext[i] = this.model.intVar("distanceNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(distanceNext[i], adjustedDistance[i], nextCities[i], 0).post();
        }


        for(int i = 1 ; i < 2 * this.num_trucks ; i+=2) {
            trajet[i] = this.model.intVar("trajet[" + i + "]", 0);
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0);
        }

        for(int i = 0 ; i < 2 * this.num_trucks ; i+=2) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }


        for (int i = this.num_trucks * 2 ; i < distanceNext.length ; i ++) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }

        IntVar trajet_max = this.model.intVar("trajet_max",0, IntVar.MAX_INT_BOUND-1,true);
        for (int i = 0 ; i < trajet.length; i++) {
            this.model.arithm(trajet_max, ">=",trajet[i]).post();
            //this.model.post(new Arithmetic(trajet_max, Operator.get(">="), trajet[i]));
        }

        Constraint c = new Constraint("MyConstraint", new Circuits(
                Arrays.copyOfRange(nextCities, 2*this.num_trucks, nextCities.length),
                Arrays.copyOfRange(nextCities, 0, 2*this.num_trucks),
                this.distance, this.num_trucks, trajet_max, this.propagation));

        this.model.post(c);
        this.model.setObjective(Model.MINIMIZE, trajet_max);
        this.model.getSolver().setSearch(Search.activityBasedSearch(nextCities));

        Solution best = this.model.getSolver().findOptimalSolution(trajet_max,false);

        this.depot_next = new int[2*this.num_trucks];
        this.cities_next = new int[nextCities.length - 2*this.num_trucks];

        for (int i = 0 ; i < this.depot_next.length ; i++) {
            depot_next[i] = best.getIntVal(nextCities[i]);
        }
        for (int i = 0 ; i < this.cities_next.length ; i++) {
            cities_next[i] = best.getIntVal(nextCities[i + 2*this.num_trucks]);
        }


    }


    private void create_circuits_model_with_circuit_choco_with_new_domaine_and_element_dom() throws ContradictionException {
        IntVar[] nextCities = new IntVar[this.distance.length + (this.num_trucks * 2) - 1];
        int[][] adjustedDistance = create_adjustedDistance_withouifelse();

        for(int i = 0 ; i < this.num_trucks * 2; i++ ){
            if (Math.floorMod(i,2) == 1){
                nextCities[i] = this.model.intVar(i - 1);
            }
            else {
                nextCities[i] = this.model.intVar("cities[" + i + "]",2 * this.num_trucks, nextCities.length - 1);
            }
        }


        for (int i = this.num_trucks * 2 ; i < nextCities.length; i++) {
            nextCities[i] = this.model.intVar("cities[" + i + "]", ArrayUtils.remove(IntStream.range(0, nextCities.length).toArray(),i));
        }

        this.model.circuit(nextCities).post();

        IntVar[] trajet = this.model.intVarArray("trajet",nextCities.length,0,IntVar.MAX_INT_BOUND-1);
        IntVar[] distanceNext = new IntVar[nextCities.length];
        IntVar[] trajetNext = new IntVar[nextCities.length];

        for (int i = 0 ; i < distanceNext.length ; i ++) {
            distanceNext[i] = this.model.intVar("distanceNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1);
            this.model.element(distanceNext[i], adjustedDistance[i], nextCities[i], 0).post();
        }


        for(int i = 1 ; i < 2 * this.num_trucks ; i+=2) {
            trajet[i] = this.model.intVar("trajet[" + i + "]", 0);
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0);
        }

        for(int i = 0 ; i < 2 * this.num_trucks ; i+=2) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }


        for (int i = this.num_trucks * 2 ; i < distanceNext.length ; i ++) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }

        IntVar trajet_max = this.model.intVar("trajet_max",0, IntVar.MAX_INT_BOUND-1);
        for (int i = 0 ; i < trajet.length; i++) {
            this.model.arithm(trajet_max, ">=", trajet[i]).post();

            //this.model.post(new Arithmetic(trajet_max, Operator.get(">="), trajet[i]));
        }

        Constraint c = new Constraint("MyConstraint", new Circuits(
                Arrays.copyOfRange(nextCities, 2*this.num_trucks, nextCities.length),
                Arrays.copyOfRange(nextCities, 0, 2*this.num_trucks),
                this.distance, this.num_trucks, trajet_max, this.propagation));

        this.model.post(c);
        this.model.setObjective(Model.MINIMIZE, trajet_max);
        //this.model.getSolver().setSearch(Search.activityBasedSearch(nextCities));

        Solution best = this.model.getSolver().findOptimalSolution(trajet_max,false);

        this.depot_next = new int[2*this.num_trucks];
        this.cities_next = new int[nextCities.length - 2*this.num_trucks];

        for (int i = 0 ; i < this.depot_next.length ; i++) {
            depot_next[i] = best.getIntVal(nextCities[i]);
        }
        for (int i = 0 ; i < this.cities_next.length ; i++) {
            cities_next[i] = best.getIntVal(nextCities[i + 2*this.num_trucks]);
        }


    }


    private void create_choco_model_circuit_whitout_ifelse() {
        IntVar[] nextCities = new IntVar[this.distance.length + (this.num_trucks * 2) - 1];
        int[][] adjustedDistance = create_adjustedDistance_withouifelse();

        for(int i = 0 ; i < this.num_trucks * 2; i++ ){
            if (Math.floorMod(i,2) == 1){
                nextCities[i] = this.model.intVar(i - 1);
            }
            else {
                nextCities[i] = this.model.intVar("cities[" + i + "]",2 * this.num_trucks, nextCities.length - 1);
            }
        }


        for (int i = this.num_trucks * 2 ; i < nextCities.length; i++) {
            nextCities[i] = this.model.intVar("cities[" + i + "]", ArrayUtils.remove(IntStream.range(0, nextCities.length).toArray(),i));
        }

        this.model.circuit(nextCities).post();

        IntVar[] trajet = this.model.intVarArray("trajet",nextCities.length,0,IntVar.MAX_INT_BOUND-1,true);
        IntVar[] distanceNext = new IntVar[nextCities.length];
        IntVar[] trajetNext = new IntVar[nextCities.length];

        for (int i = 0 ; i < distanceNext.length ; i ++) {
            distanceNext[i] = this.model.intVar("distanceNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(distanceNext[i], adjustedDistance[i], nextCities[i], 0).post();
        }


        for(int i = 1 ; i < 2 * this.num_trucks ; i+=2) {
            trajet[i] = this.model.intVar("trajet[" + i + "]", 0);
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0);
        }

        for(int i = 0 ; i < 2 * this.num_trucks ; i+=2) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }


        for (int i = this.num_trucks * 2 ; i < distanceNext.length ; i ++) {
            trajetNext[i] = this.model.intVar("trajetNext[" + i + "]", 0, IntVar.MAX_INT_BOUND-1,true);
            this.model.element(trajetNext[i], trajet, nextCities[i], 0).post();
            this.model.arithm(trajet[i], "=", distanceNext[i], "+", trajetNext[i]).post();
        }

        IntVar trajet_max = this.model.intVar("trajet_max",0, IntVar.MAX_INT_BOUND-1,true);
        for (int i = 0 ; i < this.num_trucks*2 - 1; i++) {
            //this.model.post(new Arithmetic(trajet[i], Operator.get(">="), trajet[i+2]));

            this.model.arithm(trajet_max, ">=", trajet[i]).post();
            //this.model.post(new Arithmetic(trajet_max, Operator.get(">="), trajet[i]));

        }
        UndirectedGraph graphLB = new UndirectedGraph(model, this.distance.length + (this.num_trucks * 2) - 1, SetType.BITSET, true);
        UndirectedGraph graphUB = new UndirectedGraph(model, this.distance.length + (this.num_trucks * 2) - 1, SetType.BITSET, true);

        UndirectedGraphVar graphVar = new UndirectedGraphVar("graphe", model, graphLB, graphUB);
        model.tsp(graphVar, trajet_max, adjustedDistance, 1);
        //this.model.getSolver().setSearch(Search.domOverWDegSearch(nextCities), Search.inputOrderLBSearch(trajet_max));
        model.neighborsChanneling(graphVar,nextCities).post();
        for (int i = 0 ; i < adjustedDistance.length - 1 ; i++) {
            for (int j = 1 ; j < adjustedDistance.length ; j++) {
                graphUB.addEdge(i, j);
            }
        }
        this.model.setObjective(Model.MINIMIZE, trajet_max);
        //this.model.getSolver().setSearch(Search.domOverWDegSearch(nextCities), Search.inputOrderLBSearch(trajet_max));

        //Solution best = this.model.getSolver().findOptimalSolution(trajet_max,false);
        model.setObjective(false, trajet_max);
        Solution best = null;
        while (model.getSolver().solve()) {
            if(best == null) best = new Solution(model);
            best.record();
                int ms = best.getIntVal(trajet_max);
                this.timestamp = model.getSolver().getTimeCount();
                //System.out.println(ms + " (" + String.format("%.2f", timestamp) + "s)");

        }


        this.depot_next = new int[2*this.num_trucks];
        this.cities_next = new int[nextCities.length - 2*this.num_trucks];

        for (int i = 0 ; i < this.depot_next.length ; i++) {
            depot_next[i] = best.getIntVal(nextCities[i]);
        }
        for (int i = 0 ; i < this.cities_next.length ; i++) {
            cities_next[i] = best.getIntVal(nextCities[i + 2*this.num_trucks]);
        }
        /*
        for (int i = 0 ; i < this.depot_next.length ; i++) {
            System.out.print(depot_next[i] + " ");
        }
        System.out.print("\n");
        for (int i = 0 ; i < this.cities_next.length ; i++) {
            System.out.print(cities_next[i] + " ");
        }*/
    }

    public int[] getCities_next() {
        return cities_next;
    }

    public int[] getDepot_next() {
        return depot_next;
    }

    protected int[][] create_adjustedDistance_withouifelse() {
        int[][] adjustedDistance = new int[this.distance.length + (this.num_trucks * 2) - 1]
                [this.distance.length + (2 * this.num_trucks) - 1];

        for(int i = 0 ; i < adjustedDistance.length ; i ++) {
            for (int j = 0 ; j < adjustedDistance.length ; j++) {
                if (i < 2 * this.num_trucks && j < 2 * this.num_trucks) {
                    adjustedDistance[i][j] = 0;
                }
                else if (i < 2 * this.num_trucks) {
                    adjustedDistance[i][j] = distance[0][j - (2 * this.num_trucks) + 1];
                }
                else if(j < 2 * this.num_trucks) {
                    adjustedDistance[i][j] = distance[i - (2 * this.num_trucks) + 1][0];
                }
                else{
                    adjustedDistance[i][j] = distance[i - (2 * this.num_trucks) + 1][j - (2 * this.num_trucks) + 1];
                }
            }
        }
        return adjustedDistance;
    }

    public Model getModel() {
        return this.model;
    }

    public void solve() {
        while (this.model.getSolver().solve()) {
        }
    }

    public String getResult() {
        return this.model.getSolver().getBestSolutionValue() + " " +
                this.model.getSolver().getBackTrackCount() + " " + this.model.getSolver().getTimeCount() + " " + this.timestamp + "\n" ;
    }

    @Override
    public String toString() {
        return this.instance_name + " " + this.num_model + " " + this.propagation + " " + this.num_trucks;
    }
}
