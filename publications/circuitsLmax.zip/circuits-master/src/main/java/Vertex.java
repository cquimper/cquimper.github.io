import java.util.ArrayList;

/**
 * Created by Vincent on 2017-01-26.
 */
public class Vertex {
    private String m_label;
    private int m_index;
    private ArrayList<Edge> neighbour;

    public Vertex(int index, String label){
        this.m_label = label;	// TODO(CG): Clone de la string
        this.m_index = index;
        this.neighbour = new ArrayList<>();

    }

    public String label() {
	return m_label;
    }

    public int index() {
	return m_index;
    }

    public void addNeighbour(Edge edge) {
        if (!this.neighbour.contains(edge)){
            this.neighbour.add(edge);
        }
    }

    public ArrayList<Edge> getNeighbours() {
        return this.neighbour;
    }

}
