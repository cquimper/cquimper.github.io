import org.chocosolver.solver.search.strategy.assignments.DecisionOperator;
import org.chocosolver.solver.search.strategy.assignments.DecisionOperatorFactory;
import org.chocosolver.solver.search.strategy.decision.Decision;
import org.chocosolver.solver.search.strategy.decision.IntDecision;
import org.chocosolver.solver.search.strategy.selectors.values.IntValueSelector;
import org.chocosolver.solver.search.strategy.selectors.variables.VariableSelector;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.PoolManager;

public class minimumNextHeuristic extends AbstractStrategy<IntVar> {


    protected int[][] order;
    protected IntVar[] scope;
    PoolManager<IntDecision> pool;

    public minimumNextHeuristic(IntVar[] scope, VariableSelector<IntVar> varSelector, IntValueSelector valSelector,
                                DecisionOperator<IntVar> decOperator, int[][] order) {
        super(scope);
        this.order = order;
        this.scope = scope;
        pool = new PoolManager();
    }

    @Override
    public Decision<IntVar> getDecision() {
        IntDecision d = pool.getE();
        if (d == null) d = new IntDecision(pool);
        IntVar next = null;
        int i = 0;
        for (IntVar v : scope) {
            if (!v.isInstantiated()) {
                next = v;
                break;
            }
            i++;
        }
        int value = 0;
        if (next == null) {
            return null;
        } else {
            for (int temp_value : order[i]) {
                if (next.contains(temp_value)) {
                    value = temp_value;
                    break;
                }
            }
            d.set(next, value, DecisionOperatorFactory.makeIntEq());
            return d;
        }
    }
}
