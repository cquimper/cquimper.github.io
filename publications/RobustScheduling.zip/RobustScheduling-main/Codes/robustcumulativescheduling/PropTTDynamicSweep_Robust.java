Note: If you need this code, you will have to contact the authors of: 

Derrien A, Petit T, Zampelli S (2014) A declarative paradigm for robust cumulative scheduling. Principles and Practice of Constraint Programming, 298–306 (Springer).