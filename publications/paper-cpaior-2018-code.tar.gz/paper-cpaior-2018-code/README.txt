This code was written by Yanick Ouellet (yanickouellet@gmail.com).

Feel free to use it and include it to your personnal, research, or
commercial projects. However, we are not responsable for any issue you
might encounter with this code. If you want to cite this code, use this reference.

Yanick Ouellet and Claude-Guy Quimper. A O(n log^2 n) Checker and
O(n^2 log n) Filtering Algorithm for the Energetic
Reasoning. Proceedings of the 15th International Conference on the
Integration of Constraint Programming, Artificial Intelligence, and
Operations Research (CPAIOR 2018), 2018.

The class src/main/java/constraints/cumulative/algorithms/BinarySearchPropagator.java makes the call to filtering algorithm.

The class src/main/java/Main.java is our experimental setup.
