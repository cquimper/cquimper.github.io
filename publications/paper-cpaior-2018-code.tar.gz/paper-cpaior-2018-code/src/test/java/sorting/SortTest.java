package sorting;

import org.junit.Test;

import static org.junit.Assert.*;
import java.util.Random;
import java.util.Arrays;

public class SortTest {
    private static Random r = new Random();
    private Data data;

    public int[] generateInstance(int n) {
        int[] array = new int[n];

        for (int i = 0; i < n; i++) {
            //array[i] = r.nextInt(Integer.MAX_VALUE);
            array[i] = r.nextInt(20);
        }

        return array;
    }

    @Test
    public void test() {
        int times = 100;
        int[] ns = {100, 200, 400, 500, 1000, 10000, 20000};
        //int[] ns = {11};

        for (int n : ns) {
            data = new Data();
            for (int i = 0; i < times; i++) {
                testAndCompareSpeed(generateInstance(n));
            }
            System.out.printf("n: %d, java: %f, quick: %f, insertion: %f\n",
                              n, ((float) data.java) / data.count, ((float) data.insertion) / data.count,
                              ((float) data.quick) / data.count);
        }
    }

    private void testAndCompareSpeed(int[] array) {
        int n = array.length;
        int[] insertion = Arrays.copyOf(array, n);
        int[] java = Arrays.copyOf(array, n);
        int[] quick = Arrays.copyOf(array, n);

        data.count += 1;
        long t1, t2;

        t1 = System.currentTimeMillis();
        Arrays.sort(java);
        t2 = System.currentTimeMillis();
        data.java += t2 - t1;

        t1 = System.currentTimeMillis();
        Sort.insertionSort(insertion);
        t2 = System.currentTimeMillis();
        data.insertion += t2 - t1;

        t1 = System.currentTimeMillis();
        Sort.quickSort(quick);
        t2 = System.currentTimeMillis();
        data.quick += t2 - t1;

        for (int i = 0; i < n; i++) {
            //System.out.println(quick[i]);
        }

        if (!Arrays.equals(java, quick)) {
            int a = 2;
        }
        assertArrayEquals(java, insertion);
        assertArrayEquals(java, quick);
    }

    private class Data {
        public int count;
        public long java;
        public long insertion;
        public long quick;

        public Data() {
            count =  0;
            java = insertion = quick = 0;
        }
    }

}
