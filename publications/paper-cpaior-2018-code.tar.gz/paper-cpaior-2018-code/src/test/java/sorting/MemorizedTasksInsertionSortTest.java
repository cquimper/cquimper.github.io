package sorting;

import org.junit.Test;
import constraints.cumulative.Task;

import static org.junit.Assert.*;

public class MemorizedTasksInsertionSortTest {

    @Test
    public void testSort() throws Exception {
        Task[] tasks = {
                new Task(1, 2, 10, 1),
                new Task(2, 3, 9, 2),
                new Task(3, 2, 11, 4),
                new Task(4, 5, 6, 1)
        };

        MemorizedTasksInsertionSort insertionSort = new MemorizedTasksInsertionSort(tasks, (a, b) -> a.getEst() - b.getEst());

        insertionSort.sort();
        for (int i = 0; i < tasks.length - 1; i++)  {
            assertTrue(tasks[i].getEst() <= tasks[i+1].getEst());
        }

        insertionSort = new MemorizedTasksInsertionSort(tasks, (a, b) -> b.getLct() - a.getLct());
        insertionSort.sort();
        for (int i = 0; i < tasks.length - 1; i++)  {
            assertTrue(tasks[i].getLct() >= tasks[i+1].getLct());
        }
    }
}