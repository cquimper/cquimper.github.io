package constraints.cumulative;

import energetic.baptiste.BaptisteEnergeticChecker;
import org.junit.Test;
import energetic.binarysearch.BruteMatrix;
import tools.TasksGenerator;
import energetic.binarysearch.BruteFilteringMatrix;

import java.io.File;
import java.util.Scanner;

public class CumulativeModelRunnerTest {
    @SuppressWarnings("Duplicates")
    @Test
    public void runCustomCumul() throws Exception {
        int[] ns = {2, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150, 200, 250, 500, 750, 1000, 1500, 2000, 3000, 4000};
        int fail = 0;
        int success = 0;

        long timeTree = 0;
        long timeTimeline = 0;

        for (int n : ns) {
            timeTimeline = 0;
            timeTree = 0;

            Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
            Task[] baseTasks = new Task[n];

            int k = 0;
            while (sc.hasNext()) {
                sc.nextLine();
                int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
                for (int i = 0; i < n; i++) {
                    String[] line = sc.nextLine().split(",");
                    baseTasks[i] = new Task(
                            Integer.parseInt(line[0].trim()),
                            Integer.parseInt(line[1].trim()),
                            Integer.parseInt(line[2].trim()),
                            Integer.parseInt(line[3].trim()),
                            Integer.parseInt(line[4].trim()));
                }

                BruteMatrix matrix = new BruteMatrix(baseTasks, C);


                if (false && k++ == 10322) {
                    matrix.printMatrix();
                    System.out.println(TasksGenerator.generateTestFromTask(baseTasks));
                    System.exit(0);
                }

                if (matrix.isOtFailIfAllO2Pass()) {
                    matrix.printMatrix();
                    System.out.println(TasksGenerator.generateTestFromTask(baseTasks));
                    System.exit(0);
                }

                BruteFilteringMatrix filteringMatrix = new BruteFilteringMatrix(baseTasks, C);
                BaptisteEnergeticChecker baptiste = new BaptisteEnergeticChecker(baseTasks, C);
                // if (baptiste.isConsistent() && !matrix.checkConsistency()) {
                if (false && baptiste.isConsistent() && !filteringMatrix.isMonotone()) {
                    filteringMatrix.printMatrix();
                    System.out.println(TasksGenerator.generateTestFromTask(baseTasks));
                    System.out.println(C);
                    System.exit(0);
                }
            }
            // System.out.println(String.format("%d successes and %d fails.
            // Ratio of %f", success, fail, success * 1f /fail));
            /*
             * System.out.println(String.
             * format("%f tree and %f timeline Ratio of %f", timeTree /
             * 1000000f, timeTimeline / 1000000f, timeTree* 1f /timeTimeline));
             */
            for (Integer key : BruteMatrix.histogram.keySet()) {
                if (key != 0)
                    System.out.printf("%d, %d\n", key, BruteMatrix.histogram.get(key));
            }
            System.out.println(String.format("%d, %f, %f, %f",
                    n,
                    timeTree / 1000000f,
                    timeTimeline / 1000000f,
                    timeTree * 1f / timeTimeline));
        }
    }
}
