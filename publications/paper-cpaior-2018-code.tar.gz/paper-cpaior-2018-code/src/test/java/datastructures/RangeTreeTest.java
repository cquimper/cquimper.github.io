package datastructures;

import static org.junit.Assert.*;

public class RangeTreeTest {

}