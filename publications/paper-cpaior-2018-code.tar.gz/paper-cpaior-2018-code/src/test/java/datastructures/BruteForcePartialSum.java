package datastructures;

public class BruteForcePartialSum {
    private PartialSum.Tuple[] tuples;

    public BruteForcePartialSum(PartialSum.Tuple[] tuples) {
        this.tuples = tuples;
    }

    public int computePartialSum(int l, int u) {
        int upper = computeSumForValue(u);
        int lower = computeSumForValue(l);
        return computeSumForValue(u) - computeSumForValue(l);
    }

    private int computeSumForValue(int value) {
        int sum = 0;
        for (PartialSum.Tuple tuple : tuples) {
            sum += tuple.value * (Math.max(0, value - tuple.position));
        }
        return sum;
    }
}
