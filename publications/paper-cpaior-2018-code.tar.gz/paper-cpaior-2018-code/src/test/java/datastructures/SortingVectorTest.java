package datastructures;

import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.*;

public class SortingVectorTest {
    @Test
    public void testOriginalPosition() {
        SortingVector v = new SortingVector(100);
        for (int i = 0; i < v.size(); i++) {
            v.set(i, i);
        }

        Random r = new Random();
        for (int i = 0; i < 500; i++) {
            int j = r.nextInt(v.size());
            int k = r.nextInt(v.size());
            v.swap(j, k);
        }

        for (int i = 0; i < v.size(); i++) {
            assertEquals((int)v.getOriginal(i), i);
        }
    }

    @Test
    public void testSwap() {
        SortingVector v = new SortingVector(100);
        for (int i = 0; i < v.size(); i++) {
            v.set(i, i);
        }

        for (int i = 0; i < v.size() - 1; i++) {
            v.swap(i, i+1);
        }

        for (int i = 0; i < v.size(); i++) {
            assertEquals((int)v.get(i), (i+1) % v.size());
        }
    }

    @Test
    public void testSort() {
        SortingVector v = new SortingVector(100);
        for (int i = 0; i < v.size(); i++) {
            v.set(i, v.size() - i - 1);
        }

        v.sort();

        for (int i = 0; i < v.size(); i++) {
            assertEquals(i, v.get(i));
        }
    }

    @Test
    public void testOriginalAfterSort() {
        SortingVector v = new SortingVector(100);
        for (int i = 0; i < v.size(); i++) {
            v.set(i, v.size() - i - 1);
        }

        v.sort();

        for (int i = 0; i < v.size(); i++) {
            assertEquals(v.size() - i - 1, (int) v.getOriginal(i));
        }
    }
}