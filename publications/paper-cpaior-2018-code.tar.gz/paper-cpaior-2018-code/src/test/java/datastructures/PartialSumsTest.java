package datastructures;

import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.*;

@SuppressWarnings("ALL")
public class PartialSumsTest {
    Random r = new Random();

    @Test
    public void partialSumTestOnSmallInstance() throws Exception {
        PartialSum sum = new PartialSum(generateSmallInstance());

        assertEquals(90, sum.computePartialSum(0, 6));
        assertEquals(0, sum.computePartialSum(0, 1));
        assertEquals(0, sum.computePartialSum(12, 13));

        assertEquals(90, sum.computePartialSum(0, 6));

        assertEquals(5 * 1, sum.computePartialSum(1, 2));
        assertEquals(25 * 1, sum.computePartialSum(1, 3));
        assertEquals(15 * 1, sum.computePartialSum(3, 4));

        assertEquals(35 + 20 + 75 + 10, sum.computePartialSum(3, 12));

        bruteForceTest(generateSmallInstance(), 24);
    }

    @Test
    public void testRandomInstances() throws Exception {
        int n = 250;
        int max = 1000;
        int nbInstances = 10;

        for (int i = 0; i < nbInstances; i++) {
            testRandomInstance(n, max);
            System.out.println("Instance " + i + " done.");
        }
    }

    public PartialSum.Tuple[] generateSmallInstance() {
        PartialSum.Tuple[] tuples = {
                new PartialSum.Tuple(1, 5),
                new PartialSum.Tuple(3, -5),

                new PartialSum.Tuple(2, 5),
                new PartialSum.Tuple(10, -5),

                new PartialSum.Tuple(2, 10),
                new PartialSum.Tuple(5, -10),

                new PartialSum.Tuple(4, 15),
                new PartialSum.Tuple(9, -15),

                new PartialSum.Tuple(10, 5),
                new PartialSum.Tuple(12, -5),
        };

        return tuples;
    }

    private void testRandomInstance(int n, int max) {
        int hMin = 1;
        int hMax = 100;

        PartialSum.Tuple[] tuples = new PartialSum.Tuple[2 * n];
        for(int i = 0; i < n; i++) {
            int h = r.nextInt(hMax - hMin) + hMax;
            int lower = r.nextInt(max - 1);
            tuples[i] = new PartialSum.Tuple(lower, h);

            int upper = r.nextInt(max - lower) + lower;
            tuples[n + i] = new PartialSum.Tuple(upper, -h);
        }

        bruteForceTest(tuples, 2 * max - 10);
    }

    private void bruteForceTest(PartialSum.Tuple[] tuples, int max) {
        PartialSum partialSum = new PartialSum(tuples);
        BruteForcePartialSum bruteForce = new BruteForcePartialSum(tuples);

        for (int l = 0; l < max; l++) {
            for (int u = l; u < max; u++) {
                assertEquals(bruteForce.computePartialSum(l, u), partialSum.computePartialSum(l, u));
            }
        }
    }
}