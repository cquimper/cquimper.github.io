package datastructures

import org.junit.Test

import org.junit.Assert.*

class BruteRangeTreeTest {

    @Test
    fun testQuery() {
        val tree = BruteRangeTree(generateSmallInstance())
        val rangeTree = RangeTree(generateSmallInstance())

        assertEquals(3, tree.query(0, 3, 1))
        assertEquals(9, tree.query(0, 3, 5))
        assertEquals(10, tree.query(0, 10, 1))
        assertEquals(30, tree.query(0, 10, 5))

        assertEquals(3, rangeTree.query(0, 3, 1))
        assertEquals(9, rangeTree.query(0, 3, 5))
        assertEquals(10, rangeTree.query(0, 10, 1))
        assertEquals(30, rangeTree.query(0, 10, 5))
    }

    fun generateSmallInstance() : Array<Point> {
        return arrayOf(Point(0, 5, 1, 1), Point(0, 10, 5, 2), Point(5, 15, 1, 1))
    }
}