package energetic.binarysearch;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.Instance;
import constraints.cumulative.Task;
import datastructures.VirtualInitialisationCache;
import energetic.FilteringUtil;
import energetic.baptiste.BaptisteEnergeticChecker;
import tools.TestHelpers;
import org.junit.Test;
import tools.TasksGenerator;
import energetic.baptiste.DoubleBruteForceEnergeticReasoning;
import energetic.baptiste.BruteForceEnergeticReasoning;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

@SuppressWarnings("Duplicates")
public class BinarySearchFilteringTest {
    private int count;

    @Test
    public void bug1() {
        testInstance(TestHelpers.prepareSkiingBugExample1());
    }

    @Test
    public void bug2() {
        testInstance(TestHelpers.prepareSkiingBug2());
    }

    @Test
    public void bug3() {
        testInstance(TestHelpers.prepareSkiingBug3());
    }

    @Test
    public void bug4() {
        testInstance(TestHelpers.prepareSkiingBug4());
    }

    @Test
    public void bug5() {
        testInstance(TestHelpers.prepareSkiingBug5());
    }

    @Test
    public void bug6() {
        testInstance(TestHelpers.prepareSkiingBug6());
    }

    @Test
    public void bug7() {
        testInstance(TestHelpers.prepareSkiingBug7());
    }

    @Test
    public void bug8() {
        testInstance(TestHelpers.prepareSkiingBug8());
    }

    @Test
    public void bug9() {
        testInstance(TestHelpers.prepareSkiingBug9());
    }

    @Test
    public void bug10() {
        testInstance(TestHelpers.prepareSkiingBug10());
    }

    @Test
    public void bug11() {
        testInstance(TestHelpers.prepareSkiingBug11());}

    @Test
    public void bug12() {
        testInstance(TestHelpers.prepareSkiingBug12());
    }

    @Test
    public void bug13() {
        testInstance(TestHelpers.prepareSkiingBug13());
    }

    @Test
    public void bug14() {
        testInstance(TestHelpers.prepareSkiingBug14());
    }

    @Test
    public void bug15() {
        testInstance(TestHelpers.prepareSkiingBug15());
    }

    @Test
    public void bug16() {
        testInstance(TestHelpers.prepareSkiingBug16());
    }

    @Test
    public void bug17() {
        testInstance(TestHelpers.prepareSkiingBug17());
    }

    @Test
    public void bug18() {
        testInstance(TestHelpers.prepareSkiingBug18());
    }

    @Test
    public void bug19() {
        testInstance(TestHelpers.prepareSkiingBug19());
    }

    @Test
    public void bug20() {
        testInstance(TestHelpers.prepareSkiingBug20());
    }

    @Test
    public void bug21() {
        testInstance(TestHelpers.prepareSkiingBug21());
    }

    @Test
    public void bug22() {
        testInstance(TestHelpers.prepareSkiingBug22());
    }

    @Test
    public void bug23() {
        testInstance(TestHelpers.prepareSkiingBug23());
    }

    @Test
    public void bug24() {
        testInstance(TestHelpers.prepareSkiingBug24());
    }

    @Test
    public void bug25() {
        testInstance(TestHelpers.prepareSkiingBug25());
    }

    @Test
    public void bug26() {
        testInstance(TestHelpers.prepareSkiingBug26());
    }

    @Test
    public void bug27() {
        testInstance(TestHelpers.prepareSkiingBug27());
    }

    @Test
    public void bug28() {
        testInstance(TestHelpers.prepareSkiingBug28());
    }

    @Test
    public void bug29() {
        testInstance(TestHelpers.prepareSkiingBug29());
    }

    @Test
    public void bug30() {
        testInstance(TestHelpers.prepareSkiingBug30());
    }

    @Test
    public void bug31() {
        testInstance(TestHelpers.prepareSkiingBug31());
    }

    @Test
    public void bug32() {
        testInstance(TestHelpers.prepareSkiingBug32());
    }

    @Test
    public void bug33() {
        testInstance(TestHelpers.prepareSkiingBug33());
    }

    @Test
    public void bug34() {
        testInstance(TestHelpers.prepareSkiingBug34());
    }

    @Test
    public void bug35() {
        testInstance(TestHelpers.prepareSkiingBug35());
    }

    @Test
    public void bug36() {
        testInstance(TestHelpers.prepareSkiingBug36());
    }

    @Test
    public void bug37() {
        testInstance(TestHelpers.prepareSkiingBug37());
    }

    @Test
    public void bug38() {
        testInstance(TestHelpers.prepareSkiingBug38());
    }

    @Test
    public void bug39() {
        testInstance(TestHelpers.prepareSkiingBug39());
    }

    @Test
    public void bug40() {
        testInstance(TestHelpers.prepareSkiingBug40());
    }

    @Test
    public void bug41() {
        testInstance(TestHelpers.prepareSkiingBug41());
    }

    @Test
    public void bug42() {
        testInstance(TestHelpers.prepareSkiingBug42());
    }

    @Test
    public void baptisteBug1() {
        testInstance(TestHelpers.prepareBaptisteBug1());
    }

    @Test
    public void baptisteBug2() {
        testInstance(TestHelpers.prepareBaptisteBug2());
    }

    @Test
    public void baptisteBug3() {
        testInstance(TestHelpers.prepareBaptisteBug3());
    }

    @Test
    public void baptisteBug4() {
        testInstance(TestHelpers.prepareBaptisteBug4());
    }

    @Test
    public void baptisteBug5() {
        testInstance(TestHelpers.prepareBaptisteBug5());
    }

    @Test
    public void baptisteBug6() {
        testInstance(TestHelpers.prepareBaptisteBug6());
    }

    @Test
    public void baptisteBug7() {
        testInstance(TestHelpers.prepareBaptisteBug7());
    }

    @Test
    public void baptisteBug8() {
        testInstance(TestHelpers.prepareBaptisteBug8());
    }

    @Test
    public void baptisteBug9() {
        testInstance(TestHelpers.prepareBaptisteBug9());
    }

    @Test
    public void baptisteBug10() {
        testInstance(TestHelpers.prepareBaptisteBug9());
    }

    @Test
    public void binaryFilteringBug1() {
        testInstance(TestHelpers.prepareBinaryFilteringBug1());
    }

    @Test
    public void binaryFilteringBug2() {
        testInstance(TestHelpers.prepareBinaryFilteringBug2());
    }

    @Test
    public void binaryFilteringBug3() {
        testInstance(TestHelpers.prepareBinaryFilteringBug3());
    }

    @Test
    public void binaryFilteringBug4() {
        testInstance(TestHelpers.prepareBinaryFilteringBug4());
    }

    @Test
    public void binaryFilteringBug5() {
        testInstance(TestHelpers.prepareBinaryFilteringBug5());
    }

    @Test
    public void binaryFilteringBug6() {
        testInstance(TestHelpers.prepareBinaryFilteringBug6());
    }

    @Test
    public void binaryFilteringBug7() {
        testInstance(TestHelpers.prepareBinaryFilteringBug7());
    }

    @Test
    public void binaryFilteringBug8() {
        testInstance(TestHelpers.prepareBinaryFilteringBug8());
    }

    @Test
    public void binaryFilteringBug9() {
        testInstance(TestHelpers.prepareBinaryFilteringBug9());
    }

    @Test
    public void binaryFilteringBug10() {
        testInstance(TestHelpers.prepareBinaryFilteringBug10());
    }

    @Test
    public void binaryFilteringBug11() {
        testInstance(TestHelpers.prepareBinaryFilteringBug11());
    }

    @Test
    public void binaryFilteringBug12() {
        testInstance(TestHelpers.prepareBinaryFilteringBug12());
    }

    @Test
    public void binaryFilteringBug13() {
        testInstance(TestHelpers.prepareBinaryFilteringBug13());
    }

    @Test
    public void binaryFilteringBug14() {
        testInstance(TestHelpers.prepareBinaryFilteringBug14());
    }

    @Test
    public void binaryFilteringBug15() {
        testInstance(TestHelpers.prepareBinaryFilteringBug15());
    }

    @Test
    public void binaryFilteringBug16() {
        testInstance(TestHelpers.prepareBinaryFilteringBug16());
    }

    @Test
    public void binaryFilteringBug17() {
        testInstance(TestHelpers.prepareBinaryFilteringBug17());
    }

    @Test
    public void binaryFilteringBug18() {
        Instance instance = TestHelpers.prepareBinaryFilteringBug18();
        testInstance(instance);
    }

    @Test
    public void binaryFilteringBug19() {
        Instance instance = TestHelpers.prepareBinaryFilteringBug19();
        testInstance(instance);
    }

    @Test
    public void binaryFilteringBug20() {
        Instance instance = TestHelpers.prepareBinaryFilteringBug20();
        testInstance(instance);
    }

    @Test
    public void derrienBug1() {
        Instance instance = TestHelpers.prepareDerrienBug1();
        testInstance(instance);
    }

    @Test
    public void derrienBug2() {
        Instance instance = TestHelpers.prepareDerrienBug2();
        testInstance(instance);
    }

    @Test
    public void derrienBug3() {
        Instance instance = TestHelpers.prepareDerrienBug3();
        testInstance(instance);
    }

    @Test
    public void derrienBug4() {
        Instance instance = TestHelpers.prepareDerrienBug4();
        testInstance(instance);
    }

    @Test
    public void intervalBug1() {
        Instance instance = TestHelpers.prepareIntervalBug1();
        testInstance(instance);
    }

    @Test
    public void intervalBug2() {
        Instance instance = TestHelpers.prepareIntervalBug2();
        testInstance(instance);
    }

    @Test
    public void intervalBug3() {
        Instance instance = TestHelpers.prepareIntervalBug3();
        testInstance(instance);
    }

    @Test
    public void intervalBug4() {
        Instance instance = TestHelpers.prepareIntervalBug4();
        testInstance(instance);
    }

    @Test
    public void intervalBug5() {
        Instance instance = TestHelpers.prepareIntervalBug5();
        testInstance(instance);
    }

    @Test
    public void intervalBug6() {
        Instance instance = TestHelpers.prepareIntervalBug6();
        testInstance(instance);
    }

    @Test
    public void intervalBug7() {
        Instance instance = TestHelpers.prepareIntervalBug7();
        testInstance(instance);
    }

    @Test
    public void intervalBug8() {
        Instance instance = TestHelpers.prepareIntervalBug8();
        testInstance(instance);
    }

    @Test
    public void quickTest() {
        BruteForceEnergeticReasoning brute = new BruteForceEnergeticReasoning(
                new Task[] {
                        new constraints.cumulative.Task(1, 4, 39, 17, 2),
                        new constraints.cumulative.Task(2, 8, 26, 10, 2),
                        new constraints.cumulative.Task(3, 8, 16, 7, 1),
                        new constraints.cumulative.Task(4, 24, 34, 1, 1),
                }, 3
        );

        System.out.println(Arrays.toString(brute.filter().est));
    }

    @Test
    public void printInstance() {
        Instance instance = TestHelpers.preparePaperRunningExample();
        new BruteMatrix(instance.getTasks(), instance.getC()).printMatrix();
    }

    public Instance reverseInstance(Instance instance) {
        Task[] tasks = instance.getTasks();
        Task[] reverseTasks = new Task[tasks.length];
        int maxLct = 0;

        for (Task task : tasks) {
            maxLct = Math.max(maxLct, task.getLct());
        }

        for (int i = 0; i < tasks.length; i++) {
            reverseTasks[i] = new Task(i+1, maxLct - tasks[i].getLct(), maxLct - tasks[i].getEst(), tasks[i].getP(), tasks[i].getH());
        }

        return new Instance(reverseTasks, instance.getC());
    }

    public void testInstance(Instance instance) {
        //new BruteMatrix(instance.getTasks(), instance.getC()).printMatrix();

        CumulativeArguments args = new CumulativeArguments(true, true);

        int horizon = 0;

        for (int i = 0; i < instance.getTasks().length; i++) {
            horizon = Math.max(horizon, instance.getTasks()[i].getLct());
        }

        args.useVirtualInitialisation = true;
        args.virtualCache = new VirtualInitialisationCache((horizon*3) * (horizon*3));
        args.restrictBinarySearch = true;

        BinarySearchChecker binarySearchChecker = new BinarySearchChecker(instance.getTasks(), instance.getC(), args);
        BaptisteEnergeticChecker baptiste = new BaptisteEnergeticChecker(instance.getTasks(), instance.getC(), args);

        Task[] reverseTasks = reverseInstance(instance).getTasks();
        BinarySearchChecker reverseBinarySearchChecker = new BinarySearchChecker(reverseTasks, instance.getC(), args);
        BaptisteEnergeticChecker reverseBaptiste = new BaptisteEnergeticChecker(reverseTasks, instance.getC(), args);

        boolean b = baptiste.isConsistent() && reverseBaptiste.isConsistent();

        args.virtualCache.reinitialise();

        if (true) {
            count++;
            BinarySearchFiltering binarySearchFiltering = new BinarySearchFiltering(instance.getTasks(), instance.getC(), args);
            BaptisteEnergeticChecker baptisteFiltering = new BaptisteEnergeticChecker(instance.getTasks(), instance.getC(), args);

            DoubleBruteForceEnergeticReasoning bruteFiltering = new DoubleBruteForceEnergeticReasoning(instance.getTasks(), instance.getC());
            BruteForceEnergeticReasoning simpleBrute = new BruteForceEnergeticReasoning(instance.getTasks(), instance.getC());

            try {
                FilteringUtil.filterAndCompareAtFixpoint(baptisteFiltering, binarySearchFiltering, instance.getTasks());
            } catch (FilteringUtil.NonMatchingBoundsExeception ignored) {
                System.out.printf("%d\n", instance.getC());
                System.out.printf("%s\n", TasksGenerator.generateTestFromTask(instance.getTasks()));
                fail();
            }
        }

        for (int key : BruteFilteringMatrix.histogram.keySet()) {
            //System.out.println("=======" + key + "=======");
            HashMap<Integer, Integer> map = BruteFilteringMatrix.histogram.get(key);
            double average = 0;
            double total = 0;
            for (int count: map.keySet()) {
                //System.out.println(count + ", " + map.get(count));
                average += count * map.get(count);
                total += map.get(count);
            }
            System.out.printf("n: %d, avg: %f\n", key, average / total);
        }
    }

    @Test
    public void generateSpecificExemple() {
        Task[] tasks;
        boolean pass = true;
        do {
            pass = true;
            Instance instance = TasksGenerator.generateCumulativeTasks(3, 0, 10, 2);
            tasks = instance.getTasks();
            int C = instance.getC();

            if (instance.getC() != 2) {
                //pass = false;
            }

            BruteMatrix matrix = new BruteMatrix(tasks, C);
            if (matrix.countFail() == 0) {
                //pass = false;
            }
        } while(!pass);

        System.out.println(TasksGenerator.generateTestFromTask(tasks));
    }

    //@Test
    public void testEverything() throws FileNotFoundException {
        int[] ns = {2, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150};
        for (int n : ns) {
            count = 0;
            System.out.println(n);
            Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
            Task[] baseTasks = new Task[n];

            int k = 0;
            while (sc.hasNext()) {
                k++;
                sc.nextLine();
                int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
                for (int i = 0; i < n; i++) {
                    String[] line = sc.nextLine().split(",");
                    baseTasks[i] = new Task(
                            Integer.parseInt(line[0].trim()),
                            Integer.parseInt(line[1].trim()),
                            Integer.parseInt(line[2].trim()),
                            Integer.parseInt(line[3].trim()),
                            Integer.parseInt(line[4].trim()));
                }
                // System.out.println(++k);
                if (k == -1) {
                    System.out.println(C);
                    System.out.println(TasksGenerator.generateTestFromTask(baseTasks));
                }
                testInstance(new Instance(baseTasks, C));
            }
        }
    }

    //@Test
    public void testSpeed() throws FileNotFoundException {
        int[] ns = {2, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150};
        for (int n : ns) {
            long timeBaptiste = 0;
            long timeBinary = 0;
            count = 0;
            Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
            Task[] baseTasks = new Task[n];

            int k = 0;
            while (sc.hasNext()) {
                k++;
                sc.nextLine();
                int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
                for (int i = 0; i < n; i++) {
                    String[] line = sc.nextLine().split(",");
                    baseTasks[i] = new Task(
                            Integer.parseInt(line[0].trim()),
                            Integer.parseInt(line[1].trim()),
                            Integer.parseInt(line[2].trim()),
                            Integer.parseInt(line[3].trim()),
                            Integer.parseInt(line[4].trim()));
                }

                CumulativeArguments args = new CumulativeArguments(true, true);
                int horizon = 0;

                for (int i = 0; i < baseTasks.length; i++) {
                    horizon = Math.max(horizon, baseTasks[i].getLct());
                }

                args.useVirtualInitialisation = true;
                args.virtualCache = new VirtualInitialisationCache((horizon*3) * (horizon*3));
                args.restrictBinarySearch = true;

                BaptisteEnergeticChecker baptiste = new BaptisteEnergeticChecker(baseTasks, C, args);
                BinarySearchFiltering binary = new BinarySearchFiltering(baseTasks, C, args);
                if (baptiste.isConsistent()) {
                    count++;
                    long t1, t2;

                    t1 = System.currentTimeMillis();
                    FilteringUtil.filterUntilFixpoint(baptiste, baseTasks);
                    t2 = System.currentTimeMillis();
                    timeBaptiste += t2 - t1;

                    t1 = System.currentTimeMillis();
                    FilteringUtil.filterUntilFixpoint(binary, baseTasks);
                    t2 = System.currentTimeMillis();
                    timeBinary += t2 - t1;
                }
            }
            //System.out.printf("N: %d, Count: %d, Avg Baptiste: %f, Avg binary: %f\n", n, count, ((float)timeBaptiste) / count, ((float)timeBinary) / count);
            int c = BinarySearchChecker.count;
            System.out.printf("n:%d, avg O1: %d, max O1: %d, avg O2: %d, maxO2: %d\n", n, BinarySearchChecker.sumO1 / c, BinarySearchChecker.maxO1, BinarySearchChecker.sumO2 / c, BinarySearchChecker.maxO2);
            System.out.printf("%d, %f, %f\n", n, ((float)timeBaptiste) / count, ((float)timeBinary) / count);

            BinarySearchChecker.reset();
        }
    }
}
