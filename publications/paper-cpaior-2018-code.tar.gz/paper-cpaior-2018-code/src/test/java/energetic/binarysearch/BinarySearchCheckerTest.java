package energetic.binarysearch;

import constraints.cumulative.Instance;
import datastructures.VirtualInitialisationCache;
import energetic.baptiste.BaptisteEnergeticChecker;
import org.junit.Test;
import tools.TestHelpers;
import tools.TasksGenerator;
import constraints.cumulative.Task;
import benchmarking.cumulative.CumulativeArguments;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import static org.junit.Assert.*;

@SuppressWarnings("Duplicates")
public class BinarySearchCheckerTest {
    @Test
    public void smallTest() {
        Instance instance = TestHelpers.prepareSkiingSmallCounterExample();

        StandaloneBinarySearchChecker binarySearchChecker = new StandaloneBinarySearchChecker(instance.getTasks(), instance.getC());
        binarySearchChecker.isConsistent();
    }

    @Test
    public void bug1() {
        testInstance(TestHelpers.prepareSkiingBugExample1());
    }

    @Test
    public void bug2() {
        testInstance(TestHelpers.prepareSkiingBug2());
    }

    @Test
    public void bug3() {
        testInstance(TestHelpers.prepareSkiingBug3());
    }

    @Test
    public void bug4() {
        testInstance(TestHelpers.prepareSkiingBug4());
    }

    @Test
    public void bug5() {
        testInstance(TestHelpers.prepareSkiingBug5());
    }

    @Test
    public void bug6() {
        testInstance(TestHelpers.prepareSkiingBug6());
    }

    @Test
    public void bug7() {
        testInstance(TestHelpers.prepareSkiingBug7());
    }

    @Test
    public void bug8() {
        testInstance(TestHelpers.prepareSkiingBug8());
    }

    @Test
    public void bug9() {
        testInstance(TestHelpers.prepareSkiingBug9());
    }

    @Test
    public void bug10() {
        testInstance(TestHelpers.prepareSkiingBug10());
    }

    @Test
    public void bug11() {
        testInstance(TestHelpers.prepareSkiingBug11());
    }

    @Test
    public void bug12() {
        testInstance(TestHelpers.prepareSkiingBug12());
    }

    @Test
    public void bug13() {
        testInstance(TestHelpers.prepareSkiingBug13());
    }

    @Test
    public void bug14() {
        testInstance(TestHelpers.prepareSkiingBug14());
    }

    @Test
    public void bug15() {
        testInstance(TestHelpers.prepareSkiingBug15());
    }

    @Test
    public void bug16() {
        testInstance(TestHelpers.prepareSkiingBug16());
    }

    @Test
    public void bug17() {
        testInstance(TestHelpers.prepareSkiingBug17());
    }

    @Test
    public void bug18() {
        testInstance(TestHelpers.prepareSkiingBug18());
    }

    @Test
    public void bug19() {
        testInstance(TestHelpers.prepareSkiingBug19());
    }

    @Test
    public void bug20() {
        testInstance(TestHelpers.prepareSkiingBug20());
    }

    @Test
    public void bug21() {
        testInstance(TestHelpers.prepareSkiingBug21());
    }

    @Test
    public void bug22() {
        testInstance(TestHelpers.prepareSkiingBug22());
    }

    @Test
    public void bug23() {
        testInstance(TestHelpers.prepareSkiingBug23());
    }

    @Test
    public void bug24() {
        testInstance(TestHelpers.prepareSkiingBug24());
    }

    @Test
    public void bug25() {
        testInstance(TestHelpers.prepareSkiingBug25());
    }

    @Test
    public void bug26() {
        testInstance(TestHelpers.prepareSkiingBug26());
    }

    @Test
    public void bug27() {
        testInstance(TestHelpers.prepareSkiingBug27());
    }

    @Test
    public void bug28() {
        testInstance(TestHelpers.prepareSkiingBug28());
    }

    @Test
    public void bug29() {
        testInstance(TestHelpers.prepareSkiingBug29());
    }

    @Test
    public void bug30() {
        testInstance(TestHelpers.prepareSkiingBug30());
    }

    @Test
    public void bug31() {
        testInstance(TestHelpers.prepareSkiingBug31());
    }

    @Test
    public void bug32() {
        testInstance(TestHelpers.prepareSkiingBug32());
    }

    @Test
    public void bug33() {
        testInstance(TestHelpers.prepareSkiingBug33());
    }

    @Test
    public void bug34() {
        testInstance(TestHelpers.prepareSkiingBug34());
    }

    @Test
    public void bug35() {
        testInstance(TestHelpers.prepareSkiingBug35());
    }

    @Test
    public void bug36() {
        testInstance(TestHelpers.prepareSkiingBug36());
    }

    @Test
    public void bug37() {
        testInstance(TestHelpers.prepareSkiingBug37());
    }

    @Test
    public void bug38() {
        testInstance(TestHelpers.prepareSkiingBug38());
    }

    @Test
    public void bug39() {
        testInstance(TestHelpers.prepareSkiingBug39());
    }

    @Test
    public void bug40() {
        testInstance(TestHelpers.prepareSkiingBug40());
    }

    @Test
    public void bug41() {
        testInstance(TestHelpers.prepareSkiingBug41());
    }

    @Test
    public void bug42() {
        testInstance(TestHelpers.prepareSkiingBug42());
    }

    @Test
    public void bug43() {
        testInstance(TestHelpers.prepareBinaryFilteringBug19());
    }

    @Test
    public void phase2Bug1() {
        testInstance(TestHelpers.prepareCheckerBug1());
    }

    @Test
    public void phase2Bug2() {
        testInstance(new Instance(
                reverseInstance(TestHelpers.prepareCheckerBug2().getTasks()),
                TestHelpers.prepareCheckerBug2().getC()
        ));
    }

    @Test
    public void phase2Bug3() {
        testInstance(new Instance(
                TestHelpers.prepareCheckerBug3().getTasks(),
                TestHelpers.prepareCheckerBug3().getC()
        ));
    }

    @Test
    public void paperExemple() {
        Instance instance = TestHelpers.preparePaperRunningExample();
        new BruteMatrix(instance.getTasks(), instance.getC()).printMatrix();
    }

    public Task[] reverseInstance(Task[] tasks) {
        Task[] reverseTasks = new Task[tasks.length];
        int maxLct = 0;

        for (Task task : tasks) {
            maxLct = Math.max(maxLct, task.getLct());
        }

        for (int i = 0; i < tasks.length; i++) {
            reverseTasks[i] = new Task(i+1, maxLct - tasks[i].getLct(), maxLct - tasks[i].getEst(), tasks[i].getP(), tasks[i].getH());
        }

        return reverseTasks;
    }

    public void testInstance(Instance instance) {
        CumulativeArguments args = new CumulativeArguments(true, true);

        int horizon = 0;
        for (int i = 0; i < instance.getTasks().length; i++) {
            horizon = Math.max(horizon, instance.getTasks()[i].getLct());
        }

        args.useVirtualInitialisation = false;
        args.virtualCache = new VirtualInitialisationCache((horizon*3) * (horizon*3));
        args.restrictBinarySearch = true;

        StandaloneBinarySearchChecker binarySearchChecker = new StandaloneBinarySearchChecker(instance.getTasks(), instance.getC(), args);
        BaptisteEnergeticChecker baptiste = new BaptisteEnergeticChecker(instance.getTasks(), instance.getC(), args);

        Task[] reverseTasks = reverseInstance(instance.getTasks());
        BinarySearchChecker reverseBinarySearchChecker = new BinarySearchChecker(reverseTasks, instance.getC(), args);
        BaptisteEnergeticChecker reverseBaptiste = new BaptisteEnergeticChecker(reverseTasks, instance.getC(), args);

        boolean b = baptiste.isConsistent() && reverseBaptiste.isConsistent();
        boolean d = binarySearchChecker.isConsistent() && reverseBinarySearchChecker.isConsistent();

        if (b != d) {
            System.out.println(instance.getC());
            System.out.println(TasksGenerator.generateTestFromTask(instance.getTasks()));
        }
        assertEquals(b, d);
    }

    //@Test
    public void testEverything() throws FileNotFoundException {
        int[] ns = {2, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150,
                200, 250, 500, 750, 1000, 1500, 2000, 3000, 4000};
        for (int n : ns) {
            System.out.println(n);
            Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
            Task[] baseTasks = new Task[n];

            int k = 0;
            while (sc.hasNext()) {
                sc.nextLine();
                int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
                for (int i = 0; i < n; i++) {
                    String[] line = sc.nextLine().split(",");
                    baseTasks[i] = new Task(
                            Integer.parseInt(line[0].trim()),
                            Integer.parseInt(line[1].trim()),
                            Integer.parseInt(line[2].trim()),
                            Integer.parseInt(line[3].trim()),
                            Integer.parseInt(line[4].trim()));
                }
                // System.out.println(++k);
                if (k == -1) {
                    System.out.println(C);
                    System.out.println(TasksGenerator.generateTestFromTask(baseTasks));
                }
                testInstance(new Instance(baseTasks, C));
            }
        }
    }
}
