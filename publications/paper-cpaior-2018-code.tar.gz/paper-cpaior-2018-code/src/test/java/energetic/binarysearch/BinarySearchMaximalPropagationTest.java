package energetic.binarysearch;

import constraints.cumulative.Instance;
import constraints.cumulative.Task;
import org.junit.Test;
import tools.TasksGenerator;
import energetic.bruteforce.BruteForceExperimentation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

@SuppressWarnings("Duplicates")
public class BinarySearchMaximalPropagationTest {
    public Task[] reverseInstance(Task[] tasks) {
        Task[] reverseTasks = new Task[tasks.length];
        int maxLct = 0;

        for (Task task : tasks) {
            maxLct = Math.max(maxLct, task.getLct());
        }

        for (int i = 0; i < tasks.length; i++) {
            reverseTasks[i] = new Task(i+1, maxLct - tasks[i].getLct(), maxLct - tasks[i].getEst(), tasks[i].getP(), tasks[i].getH());
        }

        return reverseTasks;
    }

    public void testInstance(Instance instance) {
        BruteForceExperimentation experimentation = new BruteForceExperimentation(instance.getTasks(), instance.getC());
        boolean result = experimentation.isMaximalPropagationAchieved();
        assertEquals(true, result);
    }

    @Test
    public void testEverything() throws FileNotFoundException {
        int[] ns = {2, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150,
                200, 250, 500, 750, 1000, 1500, 2000, 3000, 4000};
        for (int n : ns) {
            System.out.println(n);
            Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
            Task[] baseTasks = new Task[n];

            int k = 0;
            while (sc.hasNext()) {
                k++;
                sc.nextLine();
                int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
                for (int i = 0; i < n; i++) {
                    String[] line = sc.nextLine().split(",");
                    baseTasks[i] = new Task(
                            Integer.parseInt(line[0].trim()),
                            Integer.parseInt(line[1].trim()),
                            Integer.parseInt(line[2].trim()),
                            Integer.parseInt(line[3].trim()),
                            Integer.parseInt(line[4].trim()));
                }
                // System.out.println(++k);
                if (k == -1) {
                    System.out.println(C);
                    System.out.println(TasksGenerator.generateTestFromTask(baseTasks));
                }
                testInstance(new Instance(baseTasks, C));
            }
        }
    }
}
