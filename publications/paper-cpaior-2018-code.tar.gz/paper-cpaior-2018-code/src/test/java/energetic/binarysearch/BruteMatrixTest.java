package energetic.binarysearch;

import constraints.cumulative.Instance;
import energetic.baptiste.BaptisteEnergeticChecker;
import org.junit.Test;
import tools.TestHelpers;

public class BruteMatrixTest {

    @Test
    public void testPrintRow() throws Exception {
        //Instance instance = TestHelpers.prepareReverseCounterexempleBaptiste();
        Instance instance = TestHelpers.prepareSkiingSmallCounterExample();

        BaptisteEnergeticChecker baptiste = new BaptisteEnergeticChecker(instance.getTasks(), instance.getC());
        System.out.println(baptiste.isConsistent());

        BruteMatrix matrix = new BruteMatrix(instance.getTasks(), instance.getC());
        matrix.printMatrix();
        matrix.checkConsistency();
    }
}