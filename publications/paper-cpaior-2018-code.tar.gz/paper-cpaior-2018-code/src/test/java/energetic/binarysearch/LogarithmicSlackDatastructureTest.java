package energetic.binarysearch;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.Instance;
import org.junit.Test;
import tools.TestHelpers;
import constraints.cumulative.Task;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import static org.junit.Assert.*;

public class LogarithmicSlackDatastructureTest {
    @Test
    public void testSmallInstance() {
        testAllValues(TestHelpers.prepareSkiingSmallCounterExample());
    }

    @Test
    public void testSmallInstance2() {
        testAllValues(TestHelpers.prepareSkiingCounterExample());
    }

    @Test
    public void testEverything() throws FileNotFoundException {
        int[] ns = {2, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150, 200, 250, 500, 750, 1000, 1500, 2000, 3000, 4000};
        for (int n : ns) {
            System.out.println(n);
            Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
            Task[] baseTasks = new Task[n];

            while (sc.hasNext()) {
                sc.nextLine();
                int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
                for (int i = 0; i < n; i++) {
                    String[] line = sc.nextLine().split(",");
                    baseTasks[i] = new Task(
                            Integer.parseInt(line[0].trim()),
                            Integer.parseInt(line[1].trim()),
                            Integer.parseInt(line[2].trim()),
                            Integer.parseInt(line[3].trim()),
                            Integer.parseInt(line[4].trim())
                    );
                }
                testAllValues(new Instance(baseTasks, C));
            }
        }
    }

    public void testAllValues(Instance instance) {
        BruteMatrix matrix = new BruteMatrix(instance.getTasks(), instance.getC());
        LogarithmicSlackDatastructure datastructure = new LogarithmicSlackDatastructure(instance.getTasks(), instance.getC(), new CumulativeArguments());
        int max = datastructure.getInfinity() / 3 + 1;

        for (int t1 = 0; t1 < max; t1++) {
            for (int t2 = 0;  t2 < max; t2++) {
                if (t2 > t1) {
                    int v1 = matrix.querySlack(t1, t2);
                    int v2 = datastructure.querySlack(t1, t2);
                    datastructure.querySlack(t1, t2);
                    assertEquals(v1, v2);
                }
            }
        }
    }
}