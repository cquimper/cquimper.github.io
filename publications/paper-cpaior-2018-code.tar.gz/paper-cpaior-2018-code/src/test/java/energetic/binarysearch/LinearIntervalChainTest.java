package energetic.binarysearch;

import datastructures.intervals.LinearIntervalChain;
import org.junit.Test;

import static org.junit.Assert.*;

public class LinearIntervalChainTest {
    @Test
    public void simpleTest() {
        LinearIntervalChain chain = new LinearIntervalChain(0, 100, 1);

        chain.add(25, 2);
        chain.add(29, 3);
        chain.add(45, 4);

        LinearIntervalChain.Interval interval = chain.getFirst();

        assertEquals(0, interval.l);
        assertEquals(25, interval.u);
        assertEquals(1, interval.value);

        interval = interval.next;
        assertEquals(25, interval.l);
        assertEquals(29, interval.u);
        assertEquals(2, interval.value);

        interval = interval.next;
        assertEquals(29, interval.l);
        assertEquals(45, interval.u);
        assertEquals(3, interval.value);

        interval = interval.next;
        assertEquals(45, interval.l);
        assertEquals(100, interval.u);
        assertEquals(4, interval.value);
    }
}