package tools;

import org.junit.Test;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.Writer;

import static org.junit.Assert.*;

public class TasksGeneratorTest {

    @Test
    public void testGenerateDisjunctiveTaks() throws Exception {
        System.out.println(TasksGenerator.generateDisjunctiveTaks(4));
    }

    @Test
    public void testGenerateCumulativeTaks() throws Exception {
        int[] ns = {4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 40, 60, 80, 100, 150, 200, 250, 500, 750, 1000, 1500, 2000, 3000, 4000};

        for(int n : ns) {
            PrintWriter writer = new PrintWriter("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt");
            int m = 100;
            writer.println();
            for (int i = 0; i < m; i++) {
                writer.println(TasksGenerator.generateCumulativeTasks(n));
            }
            writer.flush();
            writer.close();
        }
    }
}