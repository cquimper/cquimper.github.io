package tools;

import constraints.cumulative.*;
import constraints.cumulative.Task;

public class TestHelpers {

  public static Task[] prepareTest() {
    return new Task[] {
      new Task(1, 544, 674, 94, 1),
      new Task(2, 13, 79, 66, 1),
      new Task(3, 0, 900, 10, 1),
      new Task(4, 779, 832, 53, 1),
      new Task(5, 79, 900, 26, 1),
      new Task(6, 529, 544, 15, 1),
      new Task(7, 79, 900, 65, 1),
      new Task(8, 324, 406, 82, 1),
      new Task(9, 0, 900, 10, 1),
      new Task(10, 79, 900, 27, 1),
      new Task(11, 640, 733, 93, 1),
      new Task(12, 79, 900, 92, 1),
      new Task(13, 427, 523, 96, 1),
      new Task(14, 173, 243, 70, 1),
      new Task(15, 79, 900, 83, 1)
    };
  }

  public static Task[] prepareCounterexempleOfInfiniteEnergetic() {
    return new Task[] {
      new Task(1, 0, 193, 95, 1),
      new Task(2, 155, 189, 34, 1),
      new Task(3, 36, 43, 7, 1),
      new Task(4, 0, 193, 29, 1),
    };
  }

  public static Task[] prepareCounterexempleOfInfiniteEnergetic2() {
    return new Task[] {
      new Task(1, 0, 193, 95, 1),
      new Task(2, 155, 189, 34, 1),
      new Task(3, 36, 43, 7, 1),
      new Task(4, 28, 57, 29, 1),
    };
  }

  public static Task[] prepareCounterexempleOfInfiniteEnergetic3() {
    return new Task[] {
      new Task(1, 0, 1215, 62, 1),
      new Task(2, 0, 85, 85, 1),
      new Task(3, 0, 1215, 79, 1),
      new Task(4, 0, 1215, 96, 1),
      new Task(5, 0, 1215, 62, 1),
      new Task(6, 0, 1215, 85, 1),
      new Task(7, 0, 1215, 43, 1),
      new Task(8, 0, 1215, 53, 1),
      new Task(9, 0, 1215, 12, 1),
      new Task(10, 0, 1215, 36, 1),
      new Task(11, 0, 1215, 95, 1),
      new Task(12, 0, 1215, 37, 1),
      new Task(13, 0, 1215, 2, 1),
      new Task(14, 0, 1215, 48, 1),
      new Task(15, 0, 1215, 46, 1),
      new Task(16, 0, 1215, 81, 1),
      new Task(17, 0, 1215, 97, 1),
      new Task(18, 0, 1215, 54, 1),
      new Task(19, 0, 1215, 5, 1),
      new Task(20, 0, 1215, 77, 1),
    };
  }

  public static Task[] prepareCounterexempleOfInfiniteEnergetic3Simplified() {
    return new Task[] {
      new Task(1, 0, 1215, 62, 1),
      new Task(2, 0, 85, 85, 1),
      new Task(3, 0, 1215, 79, 1),
      new Task(4, 0, 1215, 96, 1),
      new Task(5, 0, 1215, 62, 1),
      new Task(6, 0, 1215, 85, 1),
      new Task(7, 0, 1215, 43, 1),
      new Task(8, 0, 1215, 53, 1),
      new Task(9, 0, 1215, 12, 1),
      new Task(10, 0, 1215, 36, 1),
      new Task(11, 0, 1215, 95, 1),
      new Task(12, 0, 1215, 37, 1),
      new Task(13, 0, 1215, 2, 1),
      new Task(14, 0, 1215, 48, 1),
      new Task(15, 0, 1215, 46, 1),
      new Task(16, 0, 1215, 81, 1),
      new Task(17, 0, 1215, 97, 1),
      new Task(18, 0, 1215, 54, 1),
      new Task(19, 0, 1215, 5, 1),
      new Task(20, 0, 1215, 77, 1),
    };
  }

  // The set of tasks in Hamed paper
  public static Task[] prepareSetOfTasks() {
    return new Task[] {
      new Task(1, 0, 19, 4, 1),
      new Task(2, 2, 22, 9, 1),
      new Task(3, 9, 30, 7, 1),
      new Task(4, 12, 20, 6, 1),
    };
  }

  public static Task[] prepareSetOfReverseTasks() {
    return new Task[] {
      new Task(1, 0, -19, -4, 1),
      new Task(2, -2, -22, -9, 1),
      new Task(3, -9, -30, -7, 1),
      new Task(4, -12, -20, -6, 1),
    };
  }

  public static Task[] prepareSetOfTasksFromVilimPaper() {
    return new Task[] {
      new Task(1, 0, 5, 1, 3),
      new Task(2, 2, 5, 3, 1),
      new Task(3, 2, 5, 2, 2),
      new Task(4, 0, 7, 3, 2),
    };
  }

  public static Task[] prepareCounterexampleOfStorm() {
    return new Task[] {
      new Task(1, 259, 354, 95, 1),
      new Task(2, 0, 383, 34, 1),
      new Task(3, 0, 383, 7, 1),
      new Task(4, 11, 40, 29, 1),
    };
  }

  public static Task[] prepareCounterexampleOfStormWith3Tasks() {
    return new Task[] {
      new Task(1, 259, 354, 95, 1), new Task(2, 0, 383, 34, 1), new Task(3, 11, 40, 29, 1),
    };
  }

  // Fig.5 of Vilim's paper
  public static Task[] prepareSetOfTasksFromSecondExempleOfVilimPaper() {
    return new Task[] {
      new Task(1, 0, 7, 2, 1), // W
      new Task(2, 0, 7, 6, 1), // X
      new Task(3, 6, 7, 1, 1), // Y
      new Task(4, 0, 8, 6, 1), // Z
    };
  }

  public static Task[] prepareSetOfFourTasks() {
    return new Task[] {
      new Task(1, 5, 22, 13, 1),
      new Task(2, 6, 22, 4, 1),
      new Task(3, 19, 27, 4, 1),
      new Task(4, 21, 24, 1, 1),
    };
  }

  public static Task[] prepareCounterExempleOfCase1() {
    return new Task[] {
      new Task(1, 0, 383, 34, 1), new Task(2, 12, 53, 15, 1), new Task(3, 11, 52, 15, 1),
    };
  }

  public static Task[] prepareCounterExempleOfAirport() {
    return new Task[] {
      new Task(1, 0, 54, 54, 1),
      new Task(2, 1, 152, 34, 1),
      new Task(3, 2, 153, 61, 1),
      new Task(4, 3, 154, 2, 1),
    };
  }

  public static Task[] prepareCounterExempleOfAirport2() {
    return new Task[] {
      new Task(1, 0, 54, 54, 1),
      new Task(2, 115, 149, 34, 1),
      new Task(3, 54, 150, 61, 1),
      new Task(4, 55, 151, 2, 1),
    };
  }

  public static Task[] prepareSetOfFourTasksReverseTrial() {
    return new Task[] {
      new Task(1, 8, 25, 13, 1),
      new Task(2, 8, 24, 4, 1),
      new Task(3, 3, 11, 4, 1),
      new Task(4, 6, 9, 1, 1),
    };
  }

  public static Task[] prepareSetOfFourTasksReverse() {
    return new Task[] {
      new Task(1, -5, -22, -13, 1),
      new Task(2, -6, -22, -4, 1),
      new Task(3, -19, -27, -4, 1),
      new Task(4, -21, -24, -1, 1),
    };
  }

  public static Task[] prepareBugCase1() {
    return new Task[] {
      new Task(1, 0, 1215, 34, 1),
      new Task(2, 0, 1215, 61, 1),
      new Task(3, 0, 1215, 2, 1),
      new Task(4, 0, 54, 54, 1),
    };
  }

  public static Task[] prepareSecondBugCase1() {
    return new Task[] {
      new Task(1, 182, 200, 9, 1),
      new Task(2, 0, 172, 15, 1),
      new Task(3, 0, 200, 89, 1),
      new Task(4, 101, 171, 70, 1),
    };
  }

  public static Task[] prepareExempleOfFixpointForCase1() {
    return new Task[] {
      new Task(1, 44, 82, 38, 1),
      new Task(2, 0, 244, 19, 1),
      new Task(3, 1, 29, 28, 1),
      new Task(4, 145, 232, 87, 1),
    };
  }

  public static Task[] prepareSetOfTaskBetterThanVilim() {
    return new Task[] {
      new Task(1, 421, 687, 27, 1),
      new Task(2, 193, 582, 51, 1),
      new Task(3, 641, 1034, 68, 1),
      new Task(4, 486, 907, 91, 1),
      new Task(5, 342, 641, 99, 1),
      new Task(6, 295, 691, 65, 1),
      new Task(7, 117, 565, 91, 1),
      new Task(8, 238, 837, 99, 1),
      new Task(9, 211, 460, 91, 1),
      new Task(10, 647, 1034, 82, 1),
      new Task(11, 435, 796, 32, 1),
      new Task(12, 47, 452, 43, 1),
      new Task(13, 857, 1034, 44, 1),
      new Task(14, 28, 588, 21, 1),
      new Task(15, 280, 809, 73, 1),
    };
  }

  public static Task[] prepareExempleForCase2() {
    return new Task[] {
      new Task(1, 0, 54, 54, 1),
      new Task(2, 0, 200, 34, 1),
      new Task(3, 0, 200, 61, 1),
      new Task(4, 0, 200, 2, 1),
    };
  }

  public static Task[] prepareExemple2ForCase2() {
    return new Task[] {
      new Task(1, 182, 200, 9, 1),
      new Task(2, 0, 106, 15, 1),
      new Task(3, 85, 195, 89, 1),
      new Task(4, 13, 83, 70, 1),
    };
  }

  public static Task[] prepareSetOfTasksFromOpenShop() {
    return new Task[] {
      new Task(1, 0, 186, 61, 1),
      new Task(2, 0, 9, 9, 1),
      new Task(3, 0, 186, 87, 1),
      new Task(4, 0, 186, 29, 1),
    };
  }

  public static Task[] prepareSetOfTasksWhereCase1And2NotWorking() {
    return new Task[] {
      new Task(1, 271, 366, 95, 1),
      new Task(2, 391, 425, 34, 1),
      new Task(3, 0, 427, 7, 1),
      new Task(4, 0, 427, 29, 1),
    };
  }

  // C = 3
  public static Task[] prepareCumulativeSetForNotFirstNotLast() {
    return new Task[] {
      new Task(1, 5, 29, 21, 1),
      new Task(2, 10, 19, 1, 1),
      new Task(3, 1, 7, 2, 2),
      new Task(4, 21, 27, 1, 1),
    };
  }

  // C = 3
  public static Task[] prepareCumulativeSetForNotFirstNotLast2() {
    return new Task[] {
      new Task(1, 7, 29, 20, 2),
      new Task(2, 0, 16, 2, 2),
      new Task(3, 26, 28, 2, 2),
      new Task(4, 14, 24, 1, 1),
    };
  }

  public static Instance prepareInstanceCounterexempleInfinite() {
    return new Instance(
        new Task[] {
          new Task(1, 9, 35, 20, 2),
          new Task(2, 17, 33, 11, 1),
          new Task(3, 20, 30, 2, 2),
          new Task(4, 0, 24, 1, 2),
        },
        3);
  }

  public static Instance prepareCounterexempleInfinite() {
    return new Instance(
        new Task[] {
          new Task(1, 9, 35, 20, 2), new Task(2, 17, 33, 11, 1), new Task(3, 20, 30, 2, 2),
        },
        3);
  }

  public static Instance prepareReverseCounterexempleBaptiste() {
    return new Instance(
        new Task[] {
          new Task(1, 0, 26, 20, 2), new Task(2, 2, 18, 11, 1), new Task(3, 5, 15, 2, 2),
        },
        3);
  }

  public static Instance prepareTestReverseCounterexempleBaptiste() {
    return new Instance(
        new Task[] {
          new Task(1, 0, 26, 20, 2),
          new Task(2, 35 - 33, 35 - 17, 11, 1),
          new Task(3, 35 - 30, 35 - 20, 2, 2),
        },
        3);
  }

  public static Instance prepareBaptisteBugInstance() {
    return new Instance(
        new Task[] {
          new Task(1, 8, 15, 6, 1), new Task(2, 5, 15, 9, 1),
        },
        1);
  }

  public static Instance prepareAlternativeTestWhenTMaxMustBeGreaterThanLctMax() {
    return new Instance(
        new Task[] {
          new Task(1, 1, 11, 4, 1), new Task(2, 2, 11, 8, 1),
        },
        1);
  }

  public static Instance prepareCounterexampleOfAlternative1() {
    return new Instance(
        new Task[] {
          new Task(1, 3, 19, 10, 1), new Task(2, 6, 14, 4, 1),
        },
        1);
  }

  // Counter-example when overflow is scheduled in priority
  public static Instance prepareCounterexampleOfAlternative2() {
    return new Instance(
        new Task[] {
          new Task(1, 9, 18, 9, 2), new Task(2, 9, 12, 1, 2),
        },
        3);
  }

  // Counter-example when overflow is scheduled in priority
  public static Instance prepareKimExample() {
    return new Instance(
        new Task[] {
          new Task(1, 1, 4, 2, 2), new Task(2, 0, 6, 3, 2), new Task(3, 5, 6, 1, 2),
        },
        3);
  }

  public static Instance prepareKimSuperExample() {
    return new Instance(
        new Task[] {
          new Task(1, 1, 27, 1, 2),
          new Task(2, 1, 3, 1, 1),
          new Task(3, 1, 3, 1, 1),
          new Task(4, 5, 6, 1, 2),
          new Task(5, 0, 6, 3, 2),
        },
        2);
  }

  public static Instance prepareSkiingCounterExample() {
    return new Instance(
        new Task[] {
          new Task(1, 22, 38, 15, 1),
          new Task(2, 22, 36, 2, 1),
          new Task(3, 7, 24, 10, 1),
          new Task(4, 26, 27, 1, 1),
        },
        2);
  }

  public static Instance prepareSkiingSmallCounterExample() {
    return new Instance(
        new Task[] {
          new Task(1, 5, 19, 14, 2), new Task(2, 7, 19, 3, 2),
        },
        3);
  }

  public static Instance prepareSkiingBugExample1() {
    return new Instance(
        new Task[] {
          new Task(1, 0, 15, 13, 1), new Task(2, 1, 8, 4, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug2() {
    return new Instance(
        new Task[] {
          new Task(1, 6, 16, 8, 1), new Task(2, 5, 11, 2, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug3() {
    return new Instance(
        new Task[] {
          new Task(1, 6, 17, 8, 2), new Task(2, 10, 18, 7, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug4() {
    return new Instance(
        new Task[] {
          new Task(1, 2, 15, 6, 1), new Task(2, 9, 17, 8, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug5() {
    return new Instance(
        new Task[] {
          new Task(1, 8, 18, 10, 1), new Task(2, 11, 15, 4, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug6() {
    return new Instance(
        new Task[] {
          new Task(1, 0, 18, 15, 2), new Task(2, 2, 4, 2, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug7() {
    return new Instance(
        new Task[] {
          new Task(1, 1, 17, 11, 2), new Task(2, 1, 8, 6, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug8() {
    return new Instance(
        new Task[] {
          new Task(1, 37, 39, 2, 1),
          new Task(2, 4, 19, 9, 2),
          new Task(3, 0, 15, 14, 2),
          new Task(4, 23, 38, 7, 1),
        },
        3);
  }

  public static Instance prepareSkiingBug9() {
    return new Instance(
        new Task[] {
          new Task(1, 9, 27, 12, 1),
          new Task(2, 20, 39, 6, 1),
          new Task(3, 29, 37, 8, 1),
          new Task(4, 7, 19, 7, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug10() {
    return new Instance(
        new Task[] {
          new Task(1, 37, 39, 2, 1),
          new Task(2, 4, 19, 9, 2),
          new Task(3, 0, 15, 14, 2),
          new Task(4, 23, 38, 7, 1),
        },
        3);
  }

  public static Instance prepareSkiingBug11() {
    return new Instance(
        new Task[] {
          new Task(1, 1, 18, 14, 1), new Task(2, 9, 18, 2, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug12() {
    return new Instance(
        new Task[] {
          new Task(1, 1, 39, 27, 2),
          new Task(2, 11, 13, 1, 1),
          new Task(3, 25, 32, 5, 2),
          new Task(4, 32, 39, 1, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug13() {
    return new Instance(
        new Task[] {
          new Task(1, 4, 17, 11, 1),
          new Task(2, 15, 32, 12, 1),
          new Task(3, 12, 34, 8, 1),
          new Task(4, 22, 38, 1, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug14() {
    return new Instance(
        new Task[] {
          new Task(1, 9, 35, 20, 2),
          new Task(2, 17, 33, 11, 1),
          new Task(3, 20, 30, 2, 2),
          new Task(4, 0, 24, 1, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug15() {
    return new Instance(
        new Task[] {
          new Task(1, 5, 48, 26, 1),
          new Task(2, 24, 44, 4, 1),
          new Task(3, 15, 24, 7, 1),
          new Task(4, 38, 44, 4, 1),
          new Task(5, 46, 47, 1, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug16() {
    return new Instance(
        new Task[] {
          new Task(1, 5, 32, 15, 1),
          new Task(2, 5, 21, 8, 1),
          new Task(3, 23, 37, 9, 1),
          new Task(4, 33, 34, 1, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug17() {
    return new Instance(
        new Task[] {
          new Task(1, 4, 32, 23, 2),
          new Task(2, 7, 27, 10, 2),
          new Task(3, 18, 19, 1, 2),
          new Task(4, 19, 37, 1, 1),
        },
        3);
  }

  public static Instance prepareSkiingBug18() {
    return new Instance(
        new Task[] {
          new Task(1, 27, 33, 1, 1),
          new Task(2, 12, 22, 7, 1),
          new Task(3, 17, 34, 14, 1),
          new Task(4, 9, 23, 4, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug19() {
    return new Instance(
        new Task[] {
          new Task(1, 8, 33, 19, 1),
          new Task(2, 26, 37, 7, 1),
          new Task(3, 36, 38, 2, 1),
          new Task(4, 20, 35, 3, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug20() {
    return new Instance(
        new Task[] {
          new Task(1, 6, 38, 30, 1),
          new Task(2, 5, 30, 2, 1),
          new Task(3, 33, 39, 2, 1),
          new Task(4, 37, 39, 1, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug21() {
    return new Instance(
        new Task[] {
          new Task(1, 5, 32, 22, 1),
          new Task(2, 0, 29, 3, 1),
          new Task(3, 21, 28, 2, 1),
          new Task(4, 30, 39, 1, 1),
        },
        1);
  }

  public static Instance prepareSkiingBug22() {
    return new Instance(
        new Task[] {
          new Task(1, 10, 32, 15, 2),
          new Task(2, 1, 20, 17, 2),
          new Task(3, 3, 26, 2, 2),
          new Task(4, 38, 39, 1, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug23() {
    return new Instance(
        new Task[] {
          new Task(1, 13, 27, 9, 2),
          new Task(2, 14, 38, 17, 2),
          new Task(3, 31, 39, 7, 2),
          new Task(4, 28, 36, 2, 1),
        },
        3);
  }

  public static Instance prepareSkiingBug24() {
    return new Instance(
        new Task[] {
          new Task(1, 6, 28, 14, 1),
          new Task(2, 0, 17, 14, 1),
          new Task(3, 0, 39, 5, 1),
          new constraints.cumulative.Task(4, 11, 17, 2, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug25() {
    return new Instance(
        new Task[] {
          new Task(1, 13, 36, 19, 2),
          new Task(2, 8, 37, 14, 2),
          new Task(3, 17, 22, 1, 2),
          new Task(4, 21, 37, 1, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug26() {
    return new Instance(
        new Task[] {
          new Task(1, 17, 38, 21, 2),
          new Task(2, 11, 19, 7, 2),
          new Task(3, 9, 24, 4, 2),
          new Task(4, 9, 17, 3, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug27() {
    return new Instance(
        new Task[] {
          new Task(1, 9, 38, 29, 1),
          new Task(2, 14, 17, 2, 1),
          new Task(3, 14, 23, 3, 1),
          new Task(4, 9, 22, 1, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug28() {
    return new Instance(
        new Task[] {
          new Task(1, 80, 109, 27, 1),
          new Task(2, 53, 139, 69, 1),
          new Task(3, 64, 112, 8, 1),
          new Task(4, 9, 75, 4, 1),
          new Task(5, 84, 117, 6, 1),
          new Task(6, 95, 148, 8, 1),
          new Task(7, 135, 138, 1, 1),
          new Task(8, 117, 128, 3, 1),
          new Task(9, 26, 137, 2, 1),
          new Task(10, 126, 132, 1, 1),
          new Task(11, 83, 103, 1, 1),
          new Task(12, 68, 149, 1, 1),
          new Task(13, 25, 81, 1, 1),
          new Task(14, 49, 126, 1, 1),
          new Task(15, 122, 137, 1, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug29() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 53, 4, 1),
          new constraints.cumulative.Task(2, 0, 49, 1, 3),
          new constraints.cumulative.Task(3, 4, 51, 1, 2),
          new constraints.cumulative.Task(4, 0, 50, 2, 1),
          new constraints.cumulative.Task(5, 0, 52, 5, 1),
          new constraints.cumulative.Task(6, 2, 54, 1, 1),
          new constraints.cumulative.Task(7, 7, 51, 1, 3),
          new constraints.cumulative.Task(8, 8, 54, 3, 2),
          new constraints.cumulative.Task(9, 0, 54, 1, 2),
          new constraints.cumulative.Task(10, 0, 51, 3, 2),
          new constraints.cumulative.Task(11, 3, 54, 3, 2),
          new constraints.cumulative.Task(12, 3, 54, 5, 1),
          new constraints.cumulative.Task(13, 0, 54, 4, 1),
        },
        6);
  }

  public static Instance prepareSkiingBug30() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 10, 18, 5, 2),
          new constraints.cumulative.Task(2, 7, 18, 8, 2),
        },
        3);
  }

  public static Instance prepareSkiingBug31() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 16, 16, 1),
          new constraints.cumulative.Task(2, 0, 1, 1, 1),
        },
        2);
  }

  public static Instance prepareSkiingBug32() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 5, 5, 1),
          new constraints.cumulative.Task(2, 0, 18, 4, 3),
          new constraints.cumulative.Task(3, 0, 18, 3, 3),
          new constraints.cumulative.Task(4, 5, 9, 4, 3),
          new constraints.cumulative.Task(5, 9, 11, 2, 1),
          new constraints.cumulative.Task(6, 0, 18, 4, 1),
          new constraints.cumulative.Task(7, 11, 14, 3, 3),
          new constraints.cumulative.Task(8, 0, 4, 4, 2),
          new constraints.cumulative.Task(9, 0, 18, 3, 1),
          new constraints.cumulative.Task(10, 5, 6, 1, 2),
          new constraints.cumulative.Task(11, 9, 14, 5, 1),
          new constraints.cumulative.Task(12, 0, 4, 4, 2),
          new constraints.cumulative.Task(13, 9, 12, 3, 1),
          new constraints.cumulative.Task(14, 5, 10, 5, 3),
          new constraints.cumulative.Task(15, 4, 6, 2, 1),
          new constraints.cumulative.Task(16, 11, 15, 4, 1),
        },
        6);
  }

  public static Instance prepareSkiingBug33() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 4, 4, 2),
          new constraints.cumulative.Task(2, 4, 5, 1, 2),
          new constraints.cumulative.Task(3, 0, 5, 5, 2),
          new constraints.cumulative.Task(4, 5, 9, 4, 1),
          new constraints.cumulative.Task(5, 10, 12, 2, 3),
          new constraints.cumulative.Task(6, 0, 5, 5, 2),
          new constraints.cumulative.Task(7, 0, 19, 4, 1),
          new constraints.cumulative.Task(8, 13, 17, 4, 2),
          new constraints.cumulative.Task(9, 0, 18, 3, 3),
          new constraints.cumulative.Task(10, 8, 12, 4, 1),
          new constraints.cumulative.Task(11, 14, 18, 4, 3),
          new constraints.cumulative.Task(12, 11, 19, 4, 3),
          new constraints.cumulative.Task(13, 3, 19, 1, 3),
          new constraints.cumulative.Task(14, 5, 10, 5, 3),
          new constraints.cumulative.Task(15, 10, 12, 2, 2)
        },
        6);
  }

  public static Instance prepareSkiingBug34() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 6, 32, 24, 2),
          new constraints.cumulative.Task(2, 8, 15, 3, 1),
          new constraints.cumulative.Task(3, 7, 23, 7, 2),
          new constraints.cumulative.Task(4, 32, 36, 1, 1),
        },
        3);
  }

  public static Instance prepareSkiingBug35() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 4, 4, 3),
          new constraints.cumulative.Task(2, 7, 11, 1, 1),
          new constraints.cumulative.Task(3, 4, 5, 1, 2),
          new constraints.cumulative.Task(4, 7, 9, 2, 3),
          new constraints.cumulative.Task(5, 0, 5, 5, 2),
          new constraints.cumulative.Task(6, 15, 16, 1, 1),
          new constraints.cumulative.Task(7, 5, 8, 3, 2),
          new constraints.cumulative.Task(8, 5, 7, 2, 2),
          new constraints.cumulative.Task(9, 7, 8, 1, 1),
          new constraints.cumulative.Task(10, 8, 11, 3, 3),
          new constraints.cumulative.Task(11, 2, 16, 4, 2),
          new constraints.cumulative.Task(12, 3, 16, 2, 3),
          new constraints.cumulative.Task(13, 9, 12, 3, 3),
          new constraints.cumulative.Task(14, 0, 16, 4, 2),
        },
        6);
  }

  public static Instance prepareSkiingBug36() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 8, 5, 2),
          new constraints.cumulative.Task(2, 0, 7, 2, 2),
          new constraints.cumulative.Task(3, 2, 9, 2, 2),
          new constraints.cumulative.Task(4, 0, 13, 4, 1),
          new constraints.cumulative.Task(5, 0, 13, 5, 2),
          new constraints.cumulative.Task(6, 0, 11, 2, 1),
          new constraints.cumulative.Task(7, 5, 13, 5, 2),
          new constraints.cumulative.Task(8, 5, 12, 1, 2),
          new constraints.cumulative.Task(9, 0, 11, 3, 1),
          new constraints.cumulative.Task(10, 3, 12, 1, 1),
          new constraints.cumulative.Task(11, 4, 13, 1, 1),
          new constraints.cumulative.Task(12, 5, 13, 1, 1),
          new constraints.cumulative.Task(13, 2, 13, 1, 1),
        },
        4);
  }

  public static Instance prepareSkiingBug37() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 1, 1, 1),
          new constraints.cumulative.Task(2, 0, 3, 3, 1),
          new constraints.cumulative.Task(3, 3, 7, 4, 2),
          new constraints.cumulative.Task(4, 1, 3, 2, 2),
          new constraints.cumulative.Task(5, 5, 7, 2, 2),
          new constraints.cumulative.Task(6, 0, 10, 2, 2),
          new constraints.cumulative.Task(7, 3, 8, 5, 1),
          new constraints.cumulative.Task(8, 7, 12, 5, 2),
          new constraints.cumulative.Task(9, 8, 13, 2, 2),
          new constraints.cumulative.Task(10, 8, 10, 2, 2),
          new constraints.cumulative.Task(11, 10, 12, 2, 2),
          new constraints.cumulative.Task(12, 2, 13, 3, 1),
          new constraints.cumulative.Task(13, 11, 12, 1, 1),
          new constraints.cumulative.Task(14, 1, 13, 4, 2),
          new constraints.cumulative.Task(14, 10, 11, 1, 1),
        },
        5);
  }

  public static Instance prepareSkiingBug38() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 4, 4, 2),
          new constraints.cumulative.Task(2, 0, 1, 1, 2),
          new constraints.cumulative.Task(3, 0, 5, 5, 2),
          new constraints.cumulative.Task(4, 8, 12, 4, 1),
          new constraints.cumulative.Task(5, 12, 14, 2, 3),
          new constraints.cumulative.Task(6, 3, 8, 5, 2),
          new constraints.cumulative.Task(7, 0, 19, 4, 1),
          new constraints.cumulative.Task(8, 10, 14, 4, 2),
          new constraints.cumulative.Task(9, 6, 15, 3, 3),
          new constraints.cumulative.Task(10, 9, 13, 4, 1),
          new constraints.cumulative.Task(11, 15, 19, 4, 3),
          new constraints.cumulative.Task(12, 0, 19, 4, 3),
          new constraints.cumulative.Task(13, 15, 16, 1, 3),
          new constraints.cumulative.Task(14, 5, 10, 5, 3),
          new constraints.cumulative.Task(15, 10, 12, 2, 2),
        },
        6);
  }

  public static Instance prepareSkiingBug39() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 5, 5, 2),
          new constraints.cumulative.Task(2, 0, 5, 5, 1),
          new constraints.cumulative.Task(3, 5, 7, 2, 2),
          new constraints.cumulative.Task(4, 0, 2, 2, 2),
          new constraints.cumulative.Task(5, 0, 16, 4, 2),
          new constraints.cumulative.Task(6, 0, 10, 3, 2),
          new constraints.cumulative.Task(7, 10, 13, 3, 1),
          new constraints.cumulative.Task(8, 10, 11, 1, 2),
          new constraints.cumulative.Task(9, 9, 13, 4, 2),
          new constraints.cumulative.Task(10, 9, 20, 2, 1),
          new constraints.cumulative.Task(11, 12, 15, 3, 2),
          new constraints.cumulative.Task(12, 13, 16, 3, 2),
          new constraints.cumulative.Task(13, 15, 17, 2, 2),
          new constraints.cumulative.Task(14, 11, 25, 5, 2),
          new constraints.cumulative.Task(15, 11, 21, 1, 1),
          new constraints.cumulative.Task(16, 9, 19, 3, 2),
          new constraints.cumulative.Task(17, 12, 25, 4, 1),
          new constraints.cumulative.Task(18, 19, 24, 5, 1),
          new constraints.cumulative.Task(19, 17, 22, 5, 2),
          new constraints.cumulative.Task(20, 7, 25, 5, 2),
          new constraints.cumulative.Task(21, 17, 22, 5, 1),
        },
        5);
  }

  public static Instance prepareSkiingBug40() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 20, 25, 5, 2),
          new constraints.cumulative.Task(2, 15, 20, 5, 1),
          new constraints.cumulative.Task(3, 17, 19, 2, 2),
          new constraints.cumulative.Task(4, 23, 25, 2, 2),
          new constraints.cumulative.Task(5, 8, 25, 4, 2),
          new constraints.cumulative.Task(6, 14, 25, 3, 2),
          new constraints.cumulative.Task(7, 11, 14, 3, 1),
          new constraints.cumulative.Task(8, 16, 17, 1, 2),
          new constraints.cumulative.Task(9, 11, 15, 4, 2),
          new constraints.cumulative.Task(10, 11, 13, 2, 1),
          new constraints.cumulative.Task(11, 13, 16, 3, 2),
          new constraints.cumulative.Task(12, 8, 11, 3, 2),
          new constraints.cumulative.Task(13, 8, 10, 2, 2),
          new constraints.cumulative.Task(14, 0, 10, 5, 2),
          new constraints.cumulative.Task(15, 10, 11, 1, 1),
          new constraints.cumulative.Task(16, 5, 8, 3, 2),
          new constraints.cumulative.Task(17, 0, 10, 4, 1),
          new constraints.cumulative.Task(18, 0, 5, 5, 1),
          new constraints.cumulative.Task(19, 3, 8, 5, 2),
          new constraints.cumulative.Task(20, 0, 19, 5, 2),
          new constraints.cumulative.Task(21, 0, 5, 5, 1),
        },
        5);
  }

  public static Instance prepareSkiingBug41() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 4, 4, 2),
          new constraints.cumulative.Task(2, 4, 5, 1, 2),
          new constraints.cumulative.Task(3, 0, 5, 5, 2),
          new constraints.cumulative.Task(4, 5, 9, 4, 1),
          new constraints.cumulative.Task(5, 12, 14, 2, 3),
          new constraints.cumulative.Task(6, 0, 5, 5, 2),
          new constraints.cumulative.Task(7, 5, 9, 4, 1),
          new constraints.cumulative.Task(8, 9, 13, 4, 2),
          new constraints.cumulative.Task(9, 14, 17, 3, 3),
          new constraints.cumulative.Task(10, 8, 12, 4, 1),
          new constraints.cumulative.Task(11, 13, 17, 4, 3),
          new constraints.cumulative.Task(12, 4, 19, 4, 3),
          new constraints.cumulative.Task(13, 18, 19, 1, 3),
          new constraints.cumulative.Task(14, 5, 10, 5, 3),
          new constraints.cumulative.Task(15, 10, 12, 2, 2),
        },
        6);
  }

  public static Instance prepareSkiingBug42() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 5, 5, 1),
          new constraints.cumulative.Task(2, 0, 2, 2, 1),
          new constraints.cumulative.Task(3, 10, 19, 4, 2),
          new constraints.cumulative.Task(4, 0, 3, 3, 1),
          new constraints.cumulative.Task(5, 2, 6, 4, 1),
          new constraints.cumulative.Task(6, 0, 27, 4, 2),
          new constraints.cumulative.Task(7, 4, 6, 2, 2),
          new constraints.cumulative.Task(8, 5, 10, 5, 1),
          new constraints.cumulative.Task(9, 13, 18, 5, 2),
          new constraints.cumulative.Task(10, 23, 27, 4, 1),
          new constraints.cumulative.Task(11, 10, 14, 4, 1),
          new constraints.cumulative.Task(12, 14, 18, 4, 1),
          new constraints.cumulative.Task(13, 6, 27, 5, 2),
          new constraints.cumulative.Task(14, 18, 22, 4, 2),
          new constraints.cumulative.Task(15, 22, 24, 2, 1),
          new constraints.cumulative.Task(16, 2, 27, 3, 1),
          new constraints.cumulative.Task(17, 19, 22, 3, 2),
          new constraints.cumulative.Task(18, 13, 15, 2, 1),
        },
        4);
  }

  public static Instance prepareBaptisteBug1() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 9, 18, 9, 2),
          new constraints.cumulative.Task(2, 9, 12, 1, 2),
        },
        3);
  }

  public static Instance prepareBaptisteBug2() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 17, 10, 1),
          new constraints.cumulative.Task(2, 5, 17, 3, 1),
        },
        1);
  }

  public static Instance prepareBaptisteBug3() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 9, 18, 9, 2),
          new constraints.cumulative.Task(2, 9, 12, 1, 2),
        },
        3);
  }

  public static Instance prepareBaptisteBug4() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 5, 19, 14, 2),
          new constraints.cumulative.Task(2, 7, 19, 3, 2),
        },
        3);
  }

  public static Instance prepareBaptisteBug5() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 2, 18, 15, 1),
          new constraints.cumulative.Task(2, 1, 12, 1, 1),
        },
        1);
  }

  public static Instance prepareBaptisteBug6() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 4, 39, 17, 2),
          new constraints.cumulative.Task(2, 8, 26, 10, 2),
          new constraints.cumulative.Task(3, 8, 16, 7, 1),
          new constraints.cumulative.Task(4, 24, 34, 1, 1),
        },
        3);
  }

  public static Instance prepareBaptisteBug7() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 9, 18, 9, 2),
          new constraints.cumulative.Task(2, 9, 12, 1, 2),
        },
        3);
  }

  public static Instance prepareBaptisteBug8() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 9, 16, 6, 1),
          new constraints.cumulative.Task(2, 13, 19, 3, 1),
        },
        1);
  }

  public static Instance prepareBaptisteBug9() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 9, 18, 9, 2),
          new constraints.cumulative.Task(2, 9, 12, 1, 2),
        },
        3);
  }

  public static Instance prepareBaptisteBug10() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 9, 18, 9, 2),
          new constraints.cumulative.Task(2, 9, 12, 1, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug1() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 1, 18, 12, 2),
          new constraints.cumulative.Task(2, 7, 18, 4, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug2() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 18, 14, 2),
          new constraints.cumulative.Task(2, 2, 15, 3, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug3() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 4, 17, 3, 2),
          new constraints.cumulative.Task(2, 4, 17, 2, 1),
          new constraints.cumulative.Task(3, 1, 17, 4, 1),
          new constraints.cumulative.Task(4, 9, 17, 4, 1),
          new constraints.cumulative.Task(5, 0, 14, 4, 2),
          new constraints.cumulative.Task(6, 0, 8, 1, 2),
          new constraints.cumulative.Task(7, 0, 8, 5, 2),
          new constraints.cumulative.Task(8, 0, 13, 5, 1),
          new constraints.cumulative.Task(9, 0, 13, 1, 2),
          new constraints.cumulative.Task(10, 0, 8, 4, 1),
          new constraints.cumulative.Task(11, 4, 13, 5, 2),
          new constraints.cumulative.Task(12, 0, 8, 4, 2),
        },
        4);
  }

  public static Instance prepareBinaryFilteringBug4() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 4, 9, 5, 1),
          new constraints.cumulative.Task(2, 0, 17, 2, 2),
          new constraints.cumulative.Task(3, 0, 4, 4, 2),
          new constraints.cumulative.Task(4, 3, 9, 2, 2),
          new constraints.cumulative.Task(5, 9, 14, 5, 2),
          new constraints.cumulative.Task(6, 4, 13, 1, 1),
          new constraints.cumulative.Task(7, 4, 7, 3, 2),
          new constraints.cumulative.Task(8, 0, 17, 1, 2),
          new constraints.cumulative.Task(9, 4, 17, 3, 2),
          new constraints.cumulative.Task(10, 7, 12, 5, 1),
          new constraints.cumulative.Task(11, 0, 17, 4, 2),
          new constraints.cumulative.Task(12, 9, 10, 1, 1),
          new constraints.cumulative.Task(13, 4, 17, 5, 2),
          new constraints.cumulative.Task(14, 4, 17, 5, 1),
          new constraints.cumulative.Task(15, 0, 17, 5, 1),
        },
        5);
  }

  public static Instance prepareBinaryFilteringBug5() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 48, 5, 1),
          new constraints.cumulative.Task(2, 0, 53, 4, 1),
          new constraints.cumulative.Task(3, 0, 49, 3, 1),
          new constraints.cumulative.Task(4, 0, 53, 5, 1),
          new constraints.cumulative.Task(5, 0, 52, 3, 1),
          new constraints.cumulative.Task(6, 5, 52, 1, 1),
          new constraints.cumulative.Task(7, 4, 53, 4, 1),
          new constraints.cumulative.Task(8, 3, 52, 1, 1),
          new constraints.cumulative.Task(9, 3, 53, 4, 1),
          new constraints.cumulative.Task(10, 4, 53, 1, 1),
          new constraints.cumulative.Task(11, 2, 53, 1, 1),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug6() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 1, 19, 16, 2),
          new constraints.cumulative.Task(2, 8, 16, 1, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug7() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 2, 18, 8, 2),
          new constraints.cumulative.Task(2, 8, 14, 5, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug8() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 0, 54, 4, 3),
          new constraints.cumulative.Task(2, 0, 50, 1, 1),
          new constraints.cumulative.Task(3, 4, 52, 1, 2),
          new constraints.cumulative.Task(4, 0, 51, 2, 3),
          new constraints.cumulative.Task(5, 0, 52, 5, 2),
          new constraints.cumulative.Task(6, 2, 55, 1, 1),
          new constraints.cumulative.Task(7, 0, 50, 3, 2),
          new constraints.cumulative.Task(8, 5, 54, 3, 2),
          new constraints.cumulative.Task(9, 8, 52, 1, 1),
          new constraints.cumulative.Task(10, 9, 55, 3, 3),
          new constraints.cumulative.Task(11, 2, 55, 1, 2),
          new constraints.cumulative.Task(12, 6, 55, 2, 3),
          new constraints.cumulative.Task(13, 3, 55, 3, 4),
          new constraints.cumulative.Task(14, 0, 55, 4, 2),
        },
        6);
  }

  public static Instance prepareBinaryFilteringBug9() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 6, 11, 5, 2),
          new constraints.cumulative.Task(2, 0, 1, 1, 2),
          new constraints.cumulative.Task(3, 4, 5, 1, 3),
          new constraints.cumulative.Task(4, 17, 19, 2, 3),
          new constraints.cumulative.Task(5, 0, 5, 5, 3),
          new constraints.cumulative.Task(6, 5, 10, 5, 2),
          new constraints.cumulative.Task(7, 1, 4, 3, 3),
          new constraints.cumulative.Task(8, 10, 13, 3, 3),
          new constraints.cumulative.Task(9, 11, 15, 4, 2),
          new constraints.cumulative.Task(10, 5, 17, 5, 1),
          new constraints.cumulative.Task(11, 15, 16, 1, 3),
          new constraints.cumulative.Task(12, 5, 19, 3, 1),
          new constraints.cumulative.Task(13, 14, 19, 2, 1),
          new constraints.cumulative.Task(14, 10, 13, 3, 1),
          new constraints.cumulative.Task(15, 5, 17, 5, 2),
          new constraints.cumulative.Task(16, 13, 17, 4, 1),
          new constraints.cumulative.Task(17, 5, 19, 1, 3),
        },
        6);
  }

  public static Instance prepareBinaryFilteringBug10() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 4, 5, 1, 1),
          new constraints.cumulative.Task(2, 5, 12, 2, 3),
          new constraints.cumulative.Task(3, 5, 15, 2, 3),
          new constraints.cumulative.Task(4, 0, 5, 5, 3),
          new constraints.cumulative.Task(5, 7, 16, 1, 1),
          new constraints.cumulative.Task(6, 4, 11, 3, 1),
          new constraints.cumulative.Task(7, 5, 8, 3, 1),
          new constraints.cumulative.Task(8, 7, 16, 4, 2),
          new constraints.cumulative.Task(9, 8, 9, 1, 1),
          new constraints.cumulative.Task(10, 0, 6, 6, 1),
          new constraints.cumulative.Task(11, 9, 12, 3, 1),
          new constraints.cumulative.Task(12, 8, 16, 1, 2),
          new constraints.cumulative.Task(13, 7, 9, 2, 2),
          new constraints.cumulative.Task(14, 1, 4, 3, 2),
          new constraints.cumulative.Task(15, 12, 15, 3, 3),
          new constraints.cumulative.Task(16, 7, 16, 5, 2),
          new constraints.cumulative.Task(17, 8, 16, 4, 2),
        },
        6);
  }

  public static Instance prepareBinaryFilteringBug11() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 5, 19, 14, 2),
          new constraints.cumulative.Task(2, 9, 17, 3, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug12() {
    return new Instance(
        new Task[] {
          new constraints.cumulative.Task(1, 8, 34, 18, 2),
          new constraints.cumulative.Task(2, 18, 39, 6, 2),
          new constraints.cumulative.Task(3, 29, 39, 9, 1),
          new constraints.cumulative.Task(4, 21, 25, 1, 2),
        },
        3);
  }

  public static Instance prepareBinaryFilteringBug13() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 18, 35, 6, 2),
                    new constraints.cumulative.Task(2, 2, 37, 27, 2),
                    new constraints.cumulative.Task(3, 0, 9, 1, 2),
                    new constraints.cumulative.Task(4, 19, 37, 1, 1),
            },
            3);
  }

  public static Instance prepareBinaryFilteringBug14() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 6, 10, 4, 3),
                    new constraints.cumulative.Task(2, 0, 19, 1, 1),
                    new constraints.cumulative.Task(3, 13, 14, 1, 2),
                    new constraints.cumulative.Task(4, 0, 20, 2, 3),
                    new constraints.cumulative.Task(5, 0, 5, 5, 2),
                    new constraints.cumulative.Task(6, 2, 24, 1, 1),
                    new constraints.cumulative.Task(7, 1, 19, 3, 2),
                    new constraints.cumulative.Task(8, 11, 14, 3, 2),
                    new constraints.cumulative.Task(9, 14, 15, 1, 1),
                    new constraints.cumulative.Task(10, 15, 18, 3, 3),
                    new constraints.cumulative.Task(11, 2, 24, 1, 2),
                    new constraints.cumulative.Task(12, 11, 13, 2, 3),
                    new constraints.cumulative.Task(13, 10, 24, 3, 4),
                    new constraints.cumulative.Task(14, 0, 24, 4, 2),
            },
            6);
  }

  public static Instance prepareBinaryFilteringBug15() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 6, 10, 4, 3),
                    new constraints.cumulative.Task(2, 0, 19, 1, 1),
                    new constraints.cumulative.Task(3, 13, 14, 1, 2),
                    new constraints.cumulative.Task(4, 0, 20, 2, 3),
                    new constraints.cumulative.Task(5, 0, 5, 5, 2),
                    new constraints.cumulative.Task(6, 2, 24, 1, 1),
                    new constraints.cumulative.Task(7, 1, 19, 3, 2),
                    new constraints.cumulative.Task(8, 11, 14, 3, 2),
                    new constraints.cumulative.Task(9, 14, 15, 1, 1),
                    new constraints.cumulative.Task(10, 15, 18, 3, 3),
                    new constraints.cumulative.Task(11, 2, 24, 1, 2),
                    new constraints.cumulative.Task(12, 11, 13, 2, 3),
                    new constraints.cumulative.Task(13, 10, 24, 3, 4),
                    new constraints.cumulative.Task(14, 0, 24, 4, 2),
            },
            6);
  }

  public static Instance prepareBinaryFilteringBug16() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 4, 4, 2),
                    new constraints.cumulative.Task(2, 5, 6, 1, 2),
                    new constraints.cumulative.Task(3, 0, 5, 5, 2),
                    new constraints.cumulative.Task(4, 6, 13, 4, 1),
                    new constraints.cumulative.Task(5, 13, 15, 2, 3),
                    new constraints.cumulative.Task(6, 0, 5, 5, 2),
                    new constraints.cumulative.Task(7, 4, 19, 4, 1),
                    new constraints.cumulative.Task(8, 4, 19, 4, 2),
                    new constraints.cumulative.Task(9, 5, 18, 3, 3),
                    new constraints.cumulative.Task(10, 9, 13, 4, 1),
                    new constraints.cumulative.Task(11, 10, 19, 4, 3),
                    new constraints.cumulative.Task(12, 10, 19, 4, 3),
                    new constraints.cumulative.Task(13, 8, 19, 1, 3),
                    new constraints.cumulative.Task(14, 5, 10, 5, 3),
                    new constraints.cumulative.Task(15, 10, 12, 2, 2),
            },
            6);
  }

  public static Instance prepareBinaryFilteringBug17() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 7, 9, 2, 2),
                    new constraints.cumulative.Task(2, 0, 11, 5, 3),
                    new constraints.cumulative.Task(3, 0, 14, 3, 3),
                    new constraints.cumulative.Task(4, 0, 2, 2, 3),
                    new constraints.cumulative.Task(5, 4, 26, 5, 2),
                    new constraints.cumulative.Task(6, 13, 16, 3, 1),
                    new constraints.cumulative.Task(7, 9, 22, 1, 1),
                    new constraints.cumulative.Task(8, 7, 23, 4, 2),
                    new constraints.cumulative.Task(9, 16, 23, 4, 3),
                    new constraints.cumulative.Task(10, 9, 22, 5, 3),
                    new constraints.cumulative.Task(11, 9, 13, 4, 2),
                    new constraints.cumulative.Task(12, 17, 19, 2, 2),
                    new constraints.cumulative.Task(13, 25, 26, 1, 1),
                    new constraints.cumulative.Task(14, 16, 23, 3, 2),
            },
            6);
  }

  public static Instance prepareBinaryFilteringBug18() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 9, 14, 5, 2),
                    new constraints.cumulative.Task(2, 0, 1, 1, 2),
                    new constraints.cumulative.Task(3, 5, 9, 1, 3),
                    new constraints.cumulative.Task(4, 5, 19, 2, 3),
                    new constraints.cumulative.Task(5, 0, 5, 5, 3),
                    new constraints.cumulative.Task(6, 9, 14, 5, 2),
                    new constraints.cumulative.Task(7, 1, 4, 3, 3),
                    new constraints.cumulative.Task(8, 4, 7, 3, 3),
                    new constraints.cumulative.Task(9, 15, 19, 4, 2),
                    new constraints.cumulative.Task(10, 9, 19, 5, 1),
                    new constraints.cumulative.Task(11, 8, 9, 1, 3),
                    new constraints.cumulative.Task(12, 5, 19, 3, 1),
                    new constraints.cumulative.Task(13, 5, 19, 2, 1),
                    new constraints.cumulative.Task(14, 11, 19, 3, 1),
                    new constraints.cumulative.Task(15, 9, 19, 5, 2),
                    new constraints.cumulative.Task(16, 14, 18, 4, 1),
                    new constraints.cumulative.Task(17, 14, 19, 1, 3),
            },
            6);
  }

  public static Instance prepareBinaryFilteringBug19() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 2, 11, 4, 3),
                    new constraints.cumulative.Task(2, 0, 7, 1, 1),
                    new constraints.cumulative.Task(3, 6, 12, 1, 2),
                    new constraints.cumulative.Task(4, 0, 2, 2, 3),
                    new constraints.cumulative.Task(5, 0, 5, 5, 2),
                    new constraints.cumulative.Task(6, 2, 16, 1, 1),
                    new constraints.cumulative.Task(7, 3, 7, 3, 2),
                    new constraints.cumulative.Task(8, 5, 12, 3, 2),
                    new constraints.cumulative.Task(9, 8, 13, 1, 1),
                    new constraints.cumulative.Task(10, 10, 16, 3, 3),
                    new constraints.cumulative.Task(11, 7, 16, 1, 2),
                    new constraints.cumulative.Task(12, 8, 16, 2, 3),
                    new constraints.cumulative.Task(13, 8, 16, 3, 4),
                    new constraints.cumulative.Task(14, 5, 16, 4, 2),
            },
            6);
  }

  public static Instance prepareBinaryFilteringBug20() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 11, 5, 1),
                    new constraints.cumulative.Task(2, 0, 21, 3, 1),
                    new constraints.cumulative.Task(3, 0, 7, 4, 1),
                    new constraints.cumulative.Task(4, 4, 26, 5, 1),
                    new constraints.cumulative.Task(5, 2, 22, 1, 1),
                    new constraints.cumulative.Task(6, 7, 26, 2, 1),
                    new constraints.cumulative.Task(7, 7, 17, 1, 1),
                    new constraints.cumulative.Task(8, 7, 23, 4, 1),
                    new constraints.cumulative.Task(9, 7, 26, 4, 1),
                    new constraints.cumulative.Task(10, 8, 22, 5, 1),
                    new constraints.cumulative.Task(11, 5, 12, 1, 1),
                    new constraints.cumulative.Task(12, 7, 12, 4, 1),
                    new constraints.cumulative.Task(13, 7, 21, 5, 1),
                    new constraints.cumulative.Task(14, 12, 14, 2, 1),
            },
            3);
  }

  public static Instance prepareDerrienBug1() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 1, 1, 1),
                    new constraints.cumulative.Task(2, 13, 15, 2, 2),
                    new constraints.cumulative.Task(3, 0, 5, 5, 1),
                    new constraints.cumulative.Task(4, 5, 10, 5, 2),
                    new constraints.cumulative.Task(5, 1, 4, 3, 1),
                    new constraints.cumulative.Task(6, 6, 15, 4, 2),
                    new constraints.cumulative.Task(7, 5, 17, 5, 2),
                    new constraints.cumulative.Task(8, 17, 18, 1, 1),
                    new constraints.cumulative.Task(9, 0, 5, 5, 2),
                    new constraints.cumulative.Task(10, 10, 17, 2, 2),
                    new constraints.cumulative.Task(11, 5, 17, 5, 2),
                    new constraints.cumulative.Task(12, 17, 19, 2, 2),
                    new constraints.cumulative.Task(13, 15, 19, 4, 1),
                    new constraints.cumulative.Task(14, 18, 19, 1, 1),
            },
            4);
  }

  public static Instance prepareDerrienBug2() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 4, 9, 2, 2),
                    new constraints.cumulative.Task(2, 4, 12, 5, 1),
                    new constraints.cumulative.Task(3, 0, 4, 4, 2),
                    new constraints.cumulative.Task(4, 0, 2, 2, 2),
                    new constraints.cumulative.Task(5, 3, 7, 4, 2),
                    new constraints.cumulative.Task(6, 9, 17, 5, 1),
                    new constraints.cumulative.Task(7, 2, 3, 1, 1),
                    new constraints.cumulative.Task(8, 14, 17, 3, 1),
                    new constraints.cumulative.Task(9, 9, 17, 1, 1),
                    new constraints.cumulative.Task(10, 5, 17, 5, 2),
                    new constraints.cumulative.Task(11, 4, 17, 5, 1),
            },
            4);
  }

  public static Instance prepareDerrienBug3() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 9, 5, 2),
                    new constraints.cumulative.Task(2, 0, 13, 5, 1),
                    new constraints.cumulative.Task(3, 0, 11, 2, 2),
                    new constraints.cumulative.Task(4, 7, 13, 2, 2),
                    new constraints.cumulative.Task(5, 0, 16, 4, 2),
                    new constraints.cumulative.Task(6, 0, 13, 4, 2),
                    new constraints.cumulative.Task(7, 0, 13, 3, 2),
                    new constraints.cumulative.Task(8, 9, 16, 3, 1),
                    new constraints.cumulative.Task(9, 5, 17, 4, 2),
                    new constraints.cumulative.Task(10, 8, 17, 3, 1),
                    new constraints.cumulative.Task(11, 12, 19, 3, 1),
                    new constraints.cumulative.Task(12, 11, 19, 2, 2),
                    new constraints.cumulative.Task(13, 11, 24, 5, 1),
                    new constraints.cumulative.Task(14, 11, 20, 1, 2),
                    new constraints.cumulative.Task(15, 9, 19, 3, 1),
                    new constraints.cumulative.Task(16, 12, 24, 4, 2),
                    new constraints.cumulative.Task(17, 13, 24, 5, 1),
                    new constraints.cumulative.Task(18, 2, 19, 4, 2),
                    new constraints.cumulative.Task(19, 16, 24, 5, 2),
                    new constraints.cumulative.Task(20, 6, 24, 5, 2),
                    new constraints.cumulative.Task(21, 12, 24, 5, 1),
            },
            5);
  }

  public static Instance prepareDerrienBug4() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 4, 5, 1, 1),
                    new constraints.cumulative.Task(2, 7, 10, 2, 3),
                    new constraints.cumulative.Task(3, 0, 15, 2, 3),
                    new constraints.cumulative.Task(4, 0, 5, 5, 3),
                    new constraints.cumulative.Task(5, 7, 16, 1, 1),
                    new constraints.cumulative.Task(6, 4, 7, 3, 1),
                    new constraints.cumulative.Task(7, 5, 8, 3, 1),
                    new constraints.cumulative.Task(8, 7, 16, 4, 2),
                    new constraints.cumulative.Task(9, 8, 9, 1, 1),
                    new constraints.cumulative.Task(10, 2, 8, 6, 1),
                    new constraints.cumulative.Task(11, 9, 12, 3, 1),
                    new constraints.cumulative.Task(12, 5, 16, 1, 2),
                    new constraints.cumulative.Task(13, 10, 12, 2, 2),
                    new constraints.cumulative.Task(14, 0, 11, 3, 2),
                    new constraints.cumulative.Task(15, 12, 15, 3, 3),
                    new constraints.cumulative.Task(16, 7, 16, 5, 2),
                    new constraints.cumulative.Task(17, 5, 16, 4, 2),
            },
            6);
  }

  public static Instance prepareIntervalBug1() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 11, 1, 1),
                    new constraints.cumulative.Task(2, 0, 19, 2, 2),
                    new constraints.cumulative.Task(3, 0, 5, 5, 1),
                    new constraints.cumulative.Task(4, 5, 10, 5, 2),
                    new constraints.cumulative.Task(5, 1, 14, 3, 1),
                    new constraints.cumulative.Task(6, 0, 17, 4, 2),
                    new constraints.cumulative.Task(7, 5, 19, 5, 2),
                    new constraints.cumulative.Task(8, 4, 19, 1, 1),
                    new constraints.cumulative.Task(9, 0, 5, 5, 2),
                    new constraints.cumulative.Task(10, 5, 19, 2, 2),
                    new constraints.cumulative.Task(11, 5, 19, 5, 2),
                    new constraints.cumulative.Task(12, 0, 19, 2, 2),
                    new constraints.cumulative.Task(13, 5, 19, 4, 1),
                    new constraints.cumulative.Task(14, 5, 19, 1, 1),
            },
            4);
  }

  public static Instance prepareIntervalBug2() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 4, 5, 1, 1),
                    new constraints.cumulative.Task(2, 7, 12, 2, 3),
                    new constraints.cumulative.Task(3, 0, 15, 2, 3),
                    new constraints.cumulative.Task(4, 0, 5, 5, 3),
                    new constraints.cumulative.Task(5, 9, 16, 1, 1),
                    new constraints.cumulative.Task(6, 4, 7, 3, 1),
                    new constraints.cumulative.Task(7, 5, 8, 3, 1),
                    new constraints.cumulative.Task(8, 10, 16, 4, 2),
                    new constraints.cumulative.Task(9, 8, 9, 1, 1),
                    new constraints.cumulative.Task(10, 0, 11, 6, 1),
                    new constraints.cumulative.Task(11, 9, 12, 3, 1),
                    new constraints.cumulative.Task(12, 5, 16, 1, 2),
                    new constraints.cumulative.Task(13, 7, 13, 2, 2),
                    new constraints.cumulative.Task(14, 0, 13, 3, 2),
                    new constraints.cumulative.Task(15, 13, 16, 3, 3),
                    new constraints.cumulative.Task(16, 7, 12, 5, 2),
                    new constraints.cumulative.Task(17, 5, 16, 4, 2),
            },
            6);
  }

  public static Instance prepareIntervalBug3() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 14, 1, 1),
                    new constraints.cumulative.Task(2, 0, 7, 1, 2),
                    new constraints.cumulative.Task(3, 4, 14, 3, 1),
                    new constraints.cumulative.Task(4, 4, 13, 1, 2),
                    new constraints.cumulative.Task(5, 0, 3, 3, 2),
                    new constraints.cumulative.Task(6, 0, 5, 4, 2),
                    new constraints.cumulative.Task(7, 0, 14, 5, 1),
                    new constraints.cumulative.Task(8, 1, 12, 5, 1),
                    new constraints.cumulative.Task(9, 0, 8, 3, 2),
                    new constraints.cumulative.Task(10, 5, 10, 5, 1),
                    new constraints.cumulative.Task(11, 6, 14, 2, 1),
                    new constraints.cumulative.Task(12, 3, 6, 3, 1),
                    new constraints.cumulative.Task(13, 5, 14, 1, 1),
                    new constraints.cumulative.Task(14, 6, 12, 2, 1),
                    new constraints.cumulative.Task(15, 6, 14, 2, 1),
                    new constraints.cumulative.Task(16, 6, 14, 2, 1),
            },
            4);
  }

  public static Instance prepareIntervalBug4() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 5, 18, 3, 2),
                    new constraints.cumulative.Task(2, 0, 8, 1, 2),
                    new constraints.cumulative.Task(3, 0, 18, 1, 2),
                    new constraints.cumulative.Task(4, 14, 18, 4, 2),
                    new constraints.cumulative.Task(5, 4, 5, 1, 1),
                    new constraints.cumulative.Task(6, 5, 18, 3, 1),
                    new constraints.cumulative.Task(7, 0, 13, 3, 2),
                    new constraints.cumulative.Task(8, 0, 18, 2, 1),
                    new constraints.cumulative.Task(9, 2, 5, 3, 1),
                    new constraints.cumulative.Task(10, 5, 8, 3, 2),
                    new constraints.cumulative.Task(11, 8, 11, 3, 2),
                    new constraints.cumulative.Task(12, 8, 12, 4, 2),
                    new constraints.cumulative.Task(13, 0, 13, 5, 2),
                    new constraints.cumulative.Task(14, 12, 14, 2, 2),
                    new constraints.cumulative.Task(15, 7, 18, 1, 2),
                    new constraints.cumulative.Task(16, 15, 18, 3, 1),
            },
            4);
  }

  public static Instance prepareIntervalBug5() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 7, 11, 4, 1),
                    new constraints.cumulative.Task(2, 2, 5, 3, 2),
                    new constraints.cumulative.Task(3, 6, 13, 2, 3),
                    new constraints.cumulative.Task(4, 0, 2, 2, 2),
                    new constraints.cumulative.Task(5, 2, 14, 5, 2),
                    new constraints.cumulative.Task(6, 5, 6, 1, 2),
                    new constraints.cumulative.Task(7, 0, 2, 2, 2),
                    new constraints.cumulative.Task(8, 2, 14, 4, 1),
                    new constraints.cumulative.Task(9, 9, 15, 5, 1),
                    new constraints.cumulative.Task(10, 6, 18, 3, 3),
                    new constraints.cumulative.Task(11, 6, 18, 1, 1),
                    new constraints.cumulative.Task(12, 11, 16, 5, 3),
                    new constraints.cumulative.Task(13, 11, 18, 4, 2),
                    new constraints.cumulative.Task(14, 0, 4, 4, 2),
                    new constraints.cumulative.Task(15, 4, 9, 5, 1),
                    new constraints.cumulative.Task(16, 5, 18, 2, 3),
                    new constraints.cumulative.Task(17, 2, 18, 1, 1),
                    new constraints.cumulative.Task(18, 14, 18, 3, 1),
                    new constraints.cumulative.Task(19, 11, 18, 1, 2),
            },
            6);
  }

  public static Instance prepareIntervalBug6() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 4, 5, 1, 1),
                    new constraints.cumulative.Task(2, 10, 12, 2, 3),
                    new constraints.cumulative.Task(3, 0, 7, 2, 3),
                    new constraints.cumulative.Task(4, 0, 5, 5, 3),
                    new constraints.cumulative.Task(5, 13, 14, 1, 1),
                    new constraints.cumulative.Task(6, 4, 7, 3, 1),
                    new constraints.cumulative.Task(7, 12, 16, 4, 2),
                    new constraints.cumulative.Task(8, 7, 8, 1, 1),
                    new constraints.cumulative.Task(9, 0, 14, 3, 1),
                    new constraints.cumulative.Task(10, 8, 11, 3, 1),
                    new constraints.cumulative.Task(11, 5, 16, 4, 2),
                    new constraints.cumulative.Task(12, 7, 16, 2, 2),
                    new constraints.cumulative.Task(13, 0, 8, 3, 2),
                    new constraints.cumulative.Task(14, 7, 16, 3, 3),
                    new constraints.cumulative.Task(15, 8, 13, 5, 2),
                    new constraints.cumulative.Task(16, 5, 16, 4, 2),
            },
            6);
  }

  public static Instance prepareIntervalBug7() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 0, 5, 5, 2),
                    new constraints.cumulative.Task(2, 0, 8, 5, 1),
                    new constraints.cumulative.Task(3, 5, 7, 2, 2),
                    new constraints.cumulative.Task(4, 0, 2, 2, 2),
                    new constraints.cumulative.Task(5, 5, 17, 4, 2),
                    new constraints.cumulative.Task(6, 5, 12, 3, 2),
                    new constraints.cumulative.Task(7, 12, 15, 3, 1),
                    new constraints.cumulative.Task(8, 7, 14, 1, 2),
                    new constraints.cumulative.Task(9, 5, 17, 4, 2),
                    new constraints.cumulative.Task(10, 12, 20, 2, 1),
                    new constraints.cumulative.Task(11, 8, 17, 3, 2),
                    new constraints.cumulative.Task(12, 16, 19, 3, 2),
                    new constraints.cumulative.Task(13, 12, 19, 2, 2),
                    new constraints.cumulative.Task(14, 14, 25, 5, 2),
                    new constraints.cumulative.Task(15, 14, 21, 1, 1),
                    new constraints.cumulative.Task(16, 12, 20, 3, 2),
                    new constraints.cumulative.Task(17, 15, 25, 4, 1),
                    new constraints.cumulative.Task(18, 15, 25, 5, 1),
                    new constraints.cumulative.Task(19, 19, 24, 5, 2),
                    new constraints.cumulative.Task(20, 6, 16, 5, 2),
                    new constraints.cumulative.Task(21, 15, 25, 5, 1),
            },
            5);
  }

  public static Instance prepareIntervalBug8() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 51, 55, 4, 3),
                    new constraints.cumulative.Task(2, 54, 55, 1, 1),
                    new constraints.cumulative.Task(3, 4, 51, 1, 2),
                    new constraints.cumulative.Task(4, 52, 54, 2, 3),
                    new constraints.cumulative.Task(5, 47, 52, 5, 2),
                    new constraints.cumulative.Task(6, 0, 52, 1, 1),
                    new constraints.cumulative.Task(7, 51, 54, 3, 2),
                    new constraints.cumulative.Task(8, 4, 47, 3, 2),
                    new constraints.cumulative.Task(9, 3, 44, 1, 1),
                    new constraints.cumulative.Task(10, 0, 43, 3, 3),
                    new constraints.cumulative.Task(11, 0, 53, 1, 2),
                    new constraints.cumulative.Task(12, 0, 49, 2, 3),
                    new constraints.cumulative.Task(13, 0, 51, 3, 4),
                    new constraints.cumulative.Task(14, 0, 55, 4, 2),
            },
            6);
  }

  public static Instance prepareCheckerBug1() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 1, 5, 4, 1),
                    new constraints.cumulative.Task(2, 1, 2, 1, 3),
                    new constraints.cumulative.Task(3, 5, 14, 1, 2),
                    new constraints.cumulative.Task(4, 3, 5, 2, 1),
                    new constraints.cumulative.Task(5, 0, 11, 5, 1),
                    new constraints.cumulative.Task(6, 13, 18, 1, 1),
                    new constraints.cumulative.Task(7, 14, 15, 1, 3),
                    new constraints.cumulative.Task(8, 0, 6, 6, 1),
                    new constraints.cumulative.Task(9, 15, 18, 3, 2),
                    new constraints.cumulative.Task(10, 0, 1, 1, 2),
                    new constraints.cumulative.Task(11, 0, 3, 3, 2),
                    new constraints.cumulative.Task(12, 8, 11, 3, 2),
                    new constraints.cumulative.Task(13, 3, 8, 5, 1),
                    new constraints.cumulative.Task(14, 9, 18, 4, 1),
            },
            6);
  }

  public static Instance prepareCheckerBug2() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 1, 4, 1, 2),
                    new constraints.cumulative.Task(2, 1, 4, 3, 2),
                    new constraints.cumulative.Task(3, 0, 13, 1, 3),
                    new constraints.cumulative.Task(4, 0, 7, 3, 2),
                    new constraints.cumulative.Task(5, 0, 4, 4, 1),
                    new constraints.cumulative.Task(6, 1, 4, 3, 1),
                    new constraints.cumulative.Task(7, 0, 6, 4, 2),
                    new constraints.cumulative.Task(8, 6, 11, 5, 1),
                    new constraints.cumulative.Task(9, 9, 14, 2, 3),
                    new constraints.cumulative.Task(10, 7, 10, 3, 3),
                    new constraints.cumulative.Task(11, 2, 14, 1, 1),
                    new constraints.cumulative.Task(12, 4, 6, 2, 3),
                    new constraints.cumulative.Task(13, 10, 11, 1, 1),
                    new constraints.cumulative.Task(14, 0, 14, 2, 3),
                    new constraints.cumulative.Task(15, 6, 14, 2, 1),
                    new constraints.cumulative.Task(16, 11, 14, 3, 3),
                    new constraints.cumulative.Task(17, 4, 14, 2, 3),
            },
            6);
  }

  public static Instance prepareCheckerBug3() {
    return new Instance(
            new Task[] {
                    new constraints.cumulative.Task(1, 10, 13, 3, 2),
                    new constraints.cumulative.Task(2, 0, 4, 4, 2),
                    new constraints.cumulative.Task(3, 15, 16, 1, 2),
                    new constraints.cumulative.Task(4, 10, 13, 3, 1),
                    new constraints.cumulative.Task(5, 10, 18, 3, 2),
                    new constraints.cumulative.Task(6, 13, 16, 3, 2),
                    new constraints.cumulative.Task(7, 6, 10, 3, 2),
                    new constraints.cumulative.Task(8, 6, 10, 4, 2),
                    new constraints.cumulative.Task(9, 4, 13, 4, 2),
                    new constraints.cumulative.Task(10, 3, 4, 1, 1),
            },
            4);
  }

    public static Instance preparePaperRunningExample() {
        return new Instance(new Task[] {
                new constraints.cumulative.Task(1, 6, 10, 3, 1),
                new constraints.cumulative.Task(2, 3, 9, 4, 2),
                new constraints.cumulative.Task(3, 4, 6, 1, 2),
            }, 2);
    }
}
