package tools;

import org.junit.Test;

public class TasksToLatexTest {

    @Test
    public void testShowTasksOnTimeline() throws Exception {
        System.out.println(TasksToLatex.showTasksOnTimeline(TestHelpers.prepareSetOfFourTasks()));
    }

    @Test
    public void testGenerateTable() throws Exception {
        System.out.println(TasksToLatex.generateTable(TestHelpers.prepareSetOfFourTasksReverseTrial()));
    }
}