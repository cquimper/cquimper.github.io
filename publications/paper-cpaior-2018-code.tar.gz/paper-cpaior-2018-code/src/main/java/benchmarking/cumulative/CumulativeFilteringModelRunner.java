package benchmarking.cumulative;

import benchmarking.BenchmarkInstance;
import benchmarking.ModelRunner;
import constraints.cumulative.algorithms.ComparisonPropagator;
import constraints.cumulative.algorithms.factory.BaptistePropagatorFactory;
import constraints.cumulative.algorithms.factory.BinarySearchPropagatorFactory;
import constraints.cumulative.choco.RcpspModel;
import constraints.cumulative.algorithms.factory.ComparisonPropagatorFactory;

public class CumulativeFilteringModelRunner implements ModelRunner {
    private CumulativeArguments args;

    public CumulativeFilteringModelRunner(CumulativeArguments args) {
        this.args = args;
    }

    public String run(BenchmarkInstance instance) {
        if (args.doRuntimeComparison) {
            return runToCompareTime(instance);
        } else {
            return runToCompareValidity(instance);
        }
    }

    public String runToCompareValidity(BenchmarkInstance instance) {
        RcpspModel model;
        try {
            CumulativeArguments args = new CumulativeArguments(this.args);
            args.useDerrienCaracterisation = true;
            args.useVirtualInitialisation = true;
            args.restrictBinarySearch = true;

            model = new RcpspModel(instance.getInputPath(), new ComparisonPropagatorFactory(), args);
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }

        return "";
    }


    public String runToCompareTime(BenchmarkInstance instance) {
        return runToCompareTimeBetweenBaptiteAndBinary(instance);
    }

    private String runToCompareTimeBetweenBaptiteAndBinary(BenchmarkInstance instance) {
        RcpspModel[] models = new RcpspModel[2];
        try {
            CumulativeArguments baptisteArgs = new CumulativeArguments(true, true);
            CumulativeArguments binaryArgs = new CumulativeArguments(true, true);

            binaryArgs.useVirtualInitialisation = true;
            binaryArgs.restrictBinarySearch = true;

            models[0] = new RcpspModel(instance.getInputPath(), new BaptistePropagatorFactory(), baptisteArgs);
            models[1] = new RcpspModel(instance.getInputPath(), new BinarySearchPropagatorFactory(), binaryArgs);
        } catch (Exception e) {
            System.out.println("Exception here");
            e.printStackTrace();
            return e.toString();
        }

        String[] types = {"Baptiste", "Binary"};

        StringBuilder out = new StringBuilder("type, time (sec.), backtracks, nodes, makespan\n");

        for (int i = 0; i < models.length; i++) {
            RcpspModel model = models[i];
            out.append(types[i])
                    .append(", ")
                    .append(model.howMuchTime())
                    .append(", ")
                    .append(model.howManyBacktracks())
                    .append(", ")
                    .append(model.howManyVisitedNodes())
                    .append(", ")
                    .append(model.makeSpanSolution())
                    .append("\n");
        }

        return out.toString();
    }
}
