package benchmarking.cumulative;

import datastructures.VirtualInitialisationCache;


public class CumulativeArguments {
    /**
       @deprecated
       We now always use Derrien's caracterisation in binary search.
    */
    @Deprecated
    public boolean useDerrienCaracterisation;

    /**
       @deprecated
       We now never use Derrien's caracterisation in binary search.
    */
    @Deprecated
    public boolean useBuggyCaracterisation;
    public boolean doRuntimeComparison;
    public boolean useCache;
    public boolean useVirtualInitialisation;
    public boolean restrictBinarySearch;
    public VirtualInitialisationCache virtualCache;
    public Passes numberOfPasses;

    public CumulativeArguments(CumulativeArguments other) {
        this.useDerrienCaracterisation = other.useDerrienCaracterisation;
        this.useBuggyCaracterisation = other.useBuggyCaracterisation;
        this.doRuntimeComparison = other.doRuntimeComparison;
        this.useCache = other.useCache;
        this.useVirtualInitialisation = other.useVirtualInitialisation;
        this.restrictBinarySearch = other.restrictBinarySearch;
        this.virtualCache = null;
        this.numberOfPasses = Passes.FourPasses;
    }

    public CumulativeArguments() {
        this(false, false);
    }

    public CumulativeArguments(boolean useDerrienCaracterisation, boolean doRuntimeComparison) {
        this.useDerrienCaracterisation = useDerrienCaracterisation;
        this.doRuntimeComparison = doRuntimeComparison;
        this.useBuggyCaracterisation = false;
        this.useCache = false;
        this.useVirtualInitialisation = false;
        this.virtualCache = null;
        this.restrictBinarySearch = false;
        this.numberOfPasses = Passes.FourPasses;
    }

    public boolean doTwoPasses() {
        return numberOfPasses == Passes.TwoPasses;
    }

    public boolean doFourPasses() {
        return numberOfPasses == Passes.FourPasses;
    }

    public boolean doSixPasses() {
        return numberOfPasses == Passes.SixPasses;
    }

    public enum Passes {
        TwoPasses,
        FourPasses,
        SixPasses
    }
}
