package benchmarking.cumulative;

import benchmarking.BenchmarkInstance;
import benchmarking.ModelRunner;
import constraints.cumulative.algorithms.BaptisteCheckerAlgorithm;
import constraints.cumulative.algorithms.BinarySearchCheckerAlgorithm;
import constraints.cumulative.algorithms.factory.BaptisteCheckerAlgorithmFactory;
import constraints.cumulative.algorithms.factory.BinarySearchCheckerAlgorithmFactory;
import constraints.cumulative.algorithms.factory.ComparisonAlgorithmFactory;
import constraints.cumulative.choco.RcpspModel;

public class CumulativeModelRunner implements ModelRunner {
    private CumulativeArguments args;

    public CumulativeModelRunner(CumulativeArguments args) {
        this.args = args;
    }

    public String run(BenchmarkInstance instance) {
        if (args.doRuntimeComparison) {
            return runToCompareTime(instance);
        } else {
            return runToCompareValidity(instance);
        }
    }

    public String runToCompareValidity(BenchmarkInstance instance) {
        RcpspModel model;
        try {
            model = new RcpspModel(instance.getInputPath(), new ComparisonAlgorithmFactory(
                                                                                           new BaptisteCheckerAlgorithmFactory(),
                                                                                           new BinarySearchCheckerAlgorithmFactory()), args);
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }

        return "";
    }

    public String runToCompareTime(BenchmarkInstance instance) {
        return runToCompareTimeBetweenBaptiteAndBinary(instance);
    }

    private String runToCompareTimeBetweenCacheAndNoChache(BenchmarkInstance instance) {
        RcpspModel[] models = new RcpspModel[3];
        try {
            CumulativeArguments cache = new CumulativeArguments(true, true);
            CumulativeArguments noCache = new CumulativeArguments(true, true);
            CumulativeArguments virtual = new CumulativeArguments(true, true);
            cache.useCache = true;
            noCache.useCache = false;
            virtual.useVirtualInitialisation = true;

            models[0] = new RcpspModel(instance.getInputPath(), new BinarySearchCheckerAlgorithmFactory(), cache);
            models[1] = new RcpspModel(instance.getInputPath(), new BinarySearchCheckerAlgorithmFactory(), noCache);
            models[2] = new RcpspModel(instance.getInputPath(), new BinarySearchCheckerAlgorithmFactory(), virtual);
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }

        String[] types = {"Cache", "NoCache", "Virtual"};

        StringBuilder out = new StringBuilder("type, time (sec.), backtracks, nodes, makespan\n");

        for (int i = 0; i < models.length; i++) {
            RcpspModel model = models[i];
            out.append(types[i])
                    .append(", ")
                    .append(model.howMuchTime())
                    .append(", ")
                    .append(model.howManyBacktracks())
                    .append(", ")
                    .append(model.howManyVisitedNodes())
                    .append(", ")
                    .append(model.makeSpanSolution())
                    .append("\n");
        }

        return out.toString();
    }

    private String runToCompareTimeBetweenBaptiteAndBinary(BenchmarkInstance instance) {
        RcpspModel[] models = new RcpspModel[4];
        try {
            CumulativeArguments baptisteDerrienArgs = new CumulativeArguments(true, true);
            CumulativeArguments baptisteNoDerrienArgs = new CumulativeArguments(false, true);
            CumulativeArguments binaryDerrien = new CumulativeArguments(true, true);
            binaryDerrien.useVirtualInitialisation = true;
            binaryDerrien.restrictBinarySearch = true;
            CumulativeArguments binaryNoDerrien = new CumulativeArguments(true, true);
            binaryNoDerrien.useVirtualInitialisation = true;
            binaryNoDerrien.restrictBinarySearch = false;
            models[0] = new RcpspModel(instance.getInputPath(), new BaptisteCheckerAlgorithmFactory(), baptisteDerrienArgs);
            models[1] = new RcpspModel(instance.getInputPath(), new BaptisteCheckerAlgorithmFactory(), baptisteNoDerrienArgs);
            models[2] = new RcpspModel(instance.getInputPath(), new BinarySearchCheckerAlgorithmFactory(), binaryDerrien);
            models[3] = new RcpspModel(instance.getInputPath(), new BinarySearchCheckerAlgorithmFactory(), binaryNoDerrien);
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }

        String[] types = {"Baptiste (Derrien)", "Baptiste (sans Derrien)", "Binary search (Restrict search)", "Binary Search (No restrict)"};

        StringBuilder out = new StringBuilder("type, time (sec.), backtracks, nodes, makespan\n");

        for (int i = 0; i < models.length; i++) {
            if (i == 1 || i == 2) {
                continue;
            }
            RcpspModel model = models[i];
            out.append(types[i])
                    .append(", ")
                    .append(model.howMuchTime())
                    .append(", ")
                    .append(model.howManyBacktracks())
                    .append(", ")
                    .append(model.howManyVisitedNodes())
                    .append(", ")
                    .append(model.makeSpanSolution())
                    .append("\n");
        }

        return out.toString();
    }
}
