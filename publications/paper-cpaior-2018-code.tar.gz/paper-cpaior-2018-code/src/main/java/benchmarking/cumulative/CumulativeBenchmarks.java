package benchmarking.cumulative;

import benchmarking.BenchmarkInstance;
import benchmarking.BenchmarkRun;
import benchmarking.ModelRunner;
import lib.AlphanumComparator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.Collectors;

public class CumulativeBenchmarks {
    public static void runBenchmarks(ModelRunner modelRunner, String baseInputPath,
                                     String baseOutputPath, String benchmark, int threadsCount)
            throws InterruptedException, IOException {
        List<String> collect = Files.walk(Paths.get(baseInputPath + "/" + benchmark))
                .filter(file -> Files.isRegularFile(file))
                .map(Path::toString)
                .collect(Collectors.toList());
        String[] files = collect.toArray(new String[collect.size()]);

        Arrays.sort(files, new AlphanumComparator());

        ArrayBlockingQueue<BenchmarkInstance> queue = new ArrayBlockingQueue<>(files.length);
        for (String file : files) {
            String name = file.substring(file.lastIndexOf('/'));
            name = name.substring(1, name.lastIndexOf("."));
            queue.put(new BenchmarkInstance(name, file, baseOutputPath + "/" + benchmark + "/" + name));
        }

        Thread[] threads = new Thread[threadsCount];
        for (int i = 0; i < threadsCount; i++) {
            threads[i] = new BenchmarkRun(queue, modelRunner);
            threads[i].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        System.out.printf("Hey, I am done doing benchmarks for " + benchmark + ".");
    }
}
