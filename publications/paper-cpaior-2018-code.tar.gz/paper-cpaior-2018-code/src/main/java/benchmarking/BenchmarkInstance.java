package benchmarking;

public class BenchmarkInstance {
    private String name;
    private String inputPath;
    private String outputPath;

    public BenchmarkInstance(String name, String inputPath, String outputPath) {
        this.name = name;
        this.inputPath = inputPath;
        this.outputPath = outputPath;
    }

    public String getName() {
        return name;
    }

    public String getInputPath() {
        return inputPath;
    }

    public String getOutputPath() {
        return outputPath + ".txt";
    }
}
