package benchmarking;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Queue;

public class BenchmarkRun extends Thread {
    private final Queue<BenchmarkInstance> queue;
    private ModelRunner modelRunner;

    public BenchmarkRun(Queue<BenchmarkInstance> queue, ModelRunner modelRunner) {
        this.queue = queue;
        this.modelRunner = modelRunner;
    }

    @Override
    public void run() {
        while (!queue.isEmpty()) {
            BenchmarkInstance instance = queue.poll();

            System.out.println("I am running instance " + instance.getName());

            String output;
            try {
                output = modelRunner.run(instance);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            try {
                Writer writer = new FileWriter(instance.getOutputPath());
                writer.write(output);
                writer.flush();
                writer.close();
                System.out.println("Instance " + instance.getName() + " done.");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
