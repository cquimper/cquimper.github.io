package benchmarking;

public interface ModelRunner {
    String run(BenchmarkInstance instance);
}
