package benchmarking;

public class FakeModelRunner implements ModelRunner {
    @Override
    public String run(BenchmarkInstance instance) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "Fake run of instance " + instance.getName() + " \n";
    }
}
