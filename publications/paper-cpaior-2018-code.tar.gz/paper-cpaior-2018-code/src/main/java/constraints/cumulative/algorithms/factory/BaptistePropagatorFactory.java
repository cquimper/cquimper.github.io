package constraints.cumulative.algorithms.factory;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.BaptistePropagator;
import constraints.cumulative.algorithms.CheckerAlgorithm;


public class BaptistePropagatorFactory implements CheckerAlgorithmFactory {
    @Override
    public CheckerAlgorithm create(CumulativeArguments args) {
        return new BaptistePropagator(args);
    }
}
