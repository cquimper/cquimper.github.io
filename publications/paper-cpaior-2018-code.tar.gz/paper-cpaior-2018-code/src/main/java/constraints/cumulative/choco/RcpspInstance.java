package constraints.cumulative.choco;

import java.io.File;
import java.util.Scanner;

public class RcpspInstance {
    public int[] capacities;
    public int numberOfTasks;
    public int numberOfResources;
    public int heights[][];
    public int[] processingTimes;
    public int[][] precedences;
    int processingTimesSum;

    public RcpspInstance(String fileName) throws Exception {

        if(fileName.contains("bl"))
        {
            Scanner s = new Scanner (new File (fileName)).useDelimiter("\\s+");
            while (!s.hasNextInt() )
                s.nextLine();

            numberOfTasks = s.nextInt();
            numberOfResources = s.nextInt();
            capacities = new int[numberOfResources];
            for(int i=0; i<numberOfResources; i++)
            {
                capacities[i] = s.nextInt();
            }

            precedences = new int[numberOfTasks][numberOfTasks];

            for(int i=0; i<numberOfTasks; i++)
            {
                for(int j=0; j<numberOfTasks; j++)
                {
                    precedences[i][j] = -1;
                }
            }
            heights = new int[numberOfResources][numberOfTasks];
            processingTimes = new int[numberOfTasks];
            processingTimesSum = 0;

            int nbSuccesseurs;
            for(int i=0; i<numberOfTasks; i++)
            {
                processingTimes[i] = s.nextInt();
                processingTimesSum += processingTimes[i];

                for(int j=0; j<numberOfResources; j++)
                {
                    //Height[j][i] = x => la tâche i utilise x unités sur la ressource j
                    heights[j][i] = s.nextInt();
                }
                int k;
                nbSuccesseurs = s.nextInt();
                for(int j=0; j<nbSuccesseurs; j++)
                {
                    //i < k
                    //Le fichier est en base 1
                    k = s.nextInt();

                    if(precedences[i][k-1] == 0 || precedences[k-1][i] == 1)
                        throw new Exception("Les précédences du problème sont incohérentes.");

                    precedences[i][k-1] = 1;
                    precedences[k-1][i] = 0;
                }
            }
        }
        else if(fileName.contains("psplib"))
        {
            Scanner s = new Scanner (new File (fileName)).useDelimiter("\\s+");
            String line = s.nextLine();

            while (!line.contains("jobs")) //Nb Tasks
                line = s.nextLine();
            numberOfTasks = Integer.parseInt(line.split(":\\s+")[1]);

            while (!line.contains("renewable")) //Nb ressources
                line = s.nextLine();
            numberOfResources = Integer.parseInt(line.split(":\\s+")[1].split("\\s+")[0]);

            while (!s.hasNextInt() )
                s.nextLine();
            s.nextLine(); //Project Information (Pas important)
            while (!s.hasNextInt() )
                s.nextLine();

            //On initialise le tableau de précédences
            precedences = new int[numberOfTasks][numberOfTasks];
            for(int i=0; i<numberOfTasks; i++)
            {
                for(int j=0; j<numberOfTasks; j++)
                {
                    precedences[i][j] = -1;
                }
            }

            int nbSuccesseurs;
            for(int i=0; i<numberOfTasks; i++)
            {
                s.nextInt();//jobnr
                s.nextInt();//mode ?

                int k;
                nbSuccesseurs = s.nextInt();
                for(int j=0; j<nbSuccesseurs; j++)
                {
                    //i < k
                    //Le fichier est en base 1
                    k = s.nextInt();

                    if(precedences[i][k-1] == 0 || precedences[k-1][i] == 1 || i == k-1)
                        throw new Exception("Les précédences du problème sont incohérentes.");

                    precedences[i][k-1] = 1;
                    precedences[k-1][i] = 0;
                }
            }

            while (!s.hasNextInt() )
                line = s.nextLine();

            heights = new int[numberOfResources][numberOfTasks];
            processingTimes = new int[numberOfTasks];
            processingTimesSum = 0;
            for(int i=0; i<numberOfTasks; i++)
            {
                s.nextInt();//jobnr
                s.nextInt();//mode ?
                processingTimes[i] = s.nextInt();
                processingTimesSum += processingTimes[i];

                for(int j=0; j<numberOfResources; j++)
                {
                    //Height[j][i] = x => la tâche i utilise x unités sur la ressource j
                    heights[j][i] = s.nextInt();
                }
            }
            while (!s.hasNextInt() )
                s.nextLine();

            capacities = new int[numberOfResources];
            for(int i=0; i<numberOfResources; i++)
            {
                capacities[i] = s.nextInt();
            }
        }
    }

    public int horizon()
    {
        return processingTimesSum;
    }
}
