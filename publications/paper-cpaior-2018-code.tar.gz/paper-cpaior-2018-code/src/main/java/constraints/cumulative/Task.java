package constraints.cumulative;

public class Task extends constraints.disjunctive.Task {
    private int h;
    public Task(int id, int est, int lct, int p, int h) {
        super(id, est, lct, p);
        this.h = h;
    }

    public Task(int id, int est, int lct, int p) {
        this(id, est, lct, p, 1);
    }

    public Task(Task task) {
        this(task.getId()+1, task.getEst(), task.getLct(), task.getP(), task.getH());
    }

    public void update(int est, int lct) {
        this.est = est;
        this.lct = lct;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }

    public int getE() {
        return getP() * h;
    }

    public int getEnv(int C) {
        return C * getEst() + getE();
    }

    public int getEnvc(int C, int c) {
        return (C-c) * getEst() + getE();
    }

    public int computeLeftShift(int t1, int t2) {
        return Math.max(0, getH() * (Math.min(t2, getEct()) - Math.max(t1, getEst())));
    }

    public int computeRightShift(int t1, int t2) {
        return Math.max(0, getH() * (Math.min(t2, getLct()) - Math.max(t1, getLst())));
    }

    public int computeMinimumIntersection(int t1, int t2) {
        return Math.min(computeLeftShift(t1, t2), computeRightShift(t1, t2));
    }

    @Override
    public String toString() {
        return String.format("Id: %d, est: %d, ect: %d, lst: %d, lct: %d, p: %d, h: %d, est+lct: %d",
                             getId()+1, getEst(), getEct(), getLst(), getLct(), getP(), h, getEst() + getLct());
    }
}
