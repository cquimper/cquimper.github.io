package constraints.cumulative.choco;

import constraints.cumulative.Instance;
import constraints.cumulative.Task;
import constraints.cumulative.algorithms.CheckerAlgorithm;
import energetic.FilteredBounds;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.ESat;
import constraints.cumulative.algorithms.PropagatorAlgorithm;
import energetic.binarysearch.BinarySearchChecker;

public class CumulativePropagator extends Propagator<IntVar> {

    private final Instance positiveInstance;
    private final Instance negativeInstance;
    private IntVar[] startingTimes;
    private IntVar[] endingTimes;
    private IntVar makespan;

    private Integer[] processingTimes;
    private Integer[] heights;
    private int capacity;
    private final CheckerAlgorithm checkerAlgorithm;
    private final PropagatorAlgorithm filteringAlgorithm;

    private int nbTasks;

    private Task[] tasks;
    private Task[] negativeTasks;

    private int sumO1;
    private int sumO2;
    private int maxO1;
    private int maxO2;
    private int count;


    public CumulativePropagator(IntVar[] startingTimes_makespan, IntVar[] endingTimes, Integer[] heights,
                                Integer[] processingTimes, int capacity, CheckerAlgorithm checkerAlgorithm) {
        super(startingTimes_makespan);

        sumO1 = sumO2 = maxO1 = maxO2 = count = 0;

        this.nbTasks = startingTimes_makespan.length - 1;
        this.processingTimes = processingTimes;
        this.heights = heights;
        this.capacity = capacity;
        this.checkerAlgorithm = checkerAlgorithm;

        this.startingTimes = new IntVar[nbTasks];
        for(int i=0; i<nbTasks; i++) {
            startingTimes[i] = vars[i];
        }
        this.makespan = vars[nbTasks];
        this.endingTimes = endingTimes;

        tasks = new Task[nbTasks];
        negativeTasks = new Task[nbTasks];

        int maxLct = Integer.MIN_VALUE;
        for (int i = 0; i < nbTasks; i++)
        {
            int est = startingTimes[i].getLB();
            int lct = startingTimes[i].getUB() + processingTimes[i];
            tasks[i] = new Task(i + 1, est, lct, processingTimes[i], heights[i]);
            maxLct = Math.max(maxLct, lct);
        }
        for (int i = 0; i < nbTasks; i++)
        {
            int est = startingTimes[i].getLB();
            int lct = startingTimes[i].getUB() + processingTimes[i];
            negativeTasks[i] = new Task(i + 1, -lct + maxLct, -est + maxLct, processingTimes[i], heights[i]);
        }

        positiveInstance = new Instance(tasks, capacity);
        negativeInstance = new Instance(negativeTasks, capacity);

        checkerAlgorithm.initialize(positiveInstance, negativeInstance);

        if (checkerAlgorithm instanceof PropagatorAlgorithm) {
            // Yeah, I know, it is bad to do a cast like that, but for now, it is simpler.
            // Bad excuse, sorry.
            filteringAlgorithm = (PropagatorAlgorithm) checkerAlgorithm;
        } else {
            filteringAlgorithm = null;
        }
    }


    @Override
    public void propagate(int evtmask) throws ContradictionException {
        int maxLct = Integer.MIN_VALUE;
        for (int i = 0; i < nbTasks; i++)
        {
            int lct = startingTimes[i].getUB() + processingTimes[i];
            tasks[i].setEst(startingTimes[i].getLB());
            tasks[i].setLct(lct);
            maxLct = Math.max(maxLct, lct);
        }
        for (int i = 0; i < nbTasks; i++)
        {
            int est = startingTimes[i].getLB();
            int lct = startingTimes[i].getUB() + processingTimes[i];
            negativeTasks[i].setEst(-lct + maxLct);
            negativeTasks[i].setLct(-est + maxLct);
        }

        checkerAlgorithm.update();
        if (!(checkerAlgorithm.isConsistent()))
            throw new ContradictionException();

        if (filteringAlgorithm != null) {
            BinarySearchChecker.reset();
            FilteredBounds bounds = filteringAlgorithm.filter();

            if (bounds == null || bounds.est == null || bounds.lct == null) {
                throw new ContradictionException();
            }

            for (int i = 0; i < bounds.est.length; i++) {
                if (bounds.est[i] > startingTimes[i].getLB()) {
                    startingTimes[i].updateLowerBound(bounds.est[i], this);
                }
                int lct = bounds.lct[i];
                if (lct < startingTimes[i].getUB() + processingTimes[i]) {
                    startingTimes[i].updateUpperBound(lct - processingTimes[i], this);
                }
            }

            count += BinarySearchChecker.count;
            sumO1 += BinarySearchChecker.sumO1;
            sumO2 += BinarySearchChecker.sumO2;
            maxO1 = Math.max(BinarySearchChecker.maxO1, maxO1);
            maxO2 = Math.max(BinarySearchChecker.maxO2, maxO2);
        }
    }

    public void print() {
        int c = count;
        if (c == 0) {
            return;
        }
        System.out.printf("n:%d, avg O1: %d, max O1: %d, avg O2: %d, maxO2: %d\n", tasks.length, sumO1 / c, maxO1, sumO2 / c, maxO2);
    }

    @Override
    public ESat isEntailed() {
        int min = startingTimes[0].getUB();
        int max = endingTimes[0].getLB();
        // check start + duration = end
        for (int i = 0; i < nbTasks; i++) {
            min = Math.min(min, startingTimes[i].getUB());
            max = Math.max(max, endingTimes[i].getLB());
            if (startingTimes[i].getLB() + processingTimes[i] > endingTimes[i].getUB()
                    || startingTimes[i].getUB() + processingTimes[i] < endingTimes[i].getLB()) {
                return ESat.FALSE;
            }
        }

        //check capacity
        int maxLoad = 0;
        if (min <= max) {
            int capamax = capacity;
            int[] consoMin = new int[max - min];
            for (int i = 0; i < nbTasks; i++) {
                for (int t = startingTimes[i].getUB(); t < endingTimes[i].getLB(); t++) {
                    consoMin[t - min] += heights[i];
                    if (consoMin[t - min] > capamax) {
                        return ESat.FALSE;
                    }
                    maxLoad = Math.max(maxLoad, consoMin[t - min]);
                }
            }
        }

        // check variables are instantiated
        for (int i = 0; i < vars.length - 1; i++) {
            if (!vars[i].isInstantiated()) {
                return ESat.UNDEFINED;
            }
        }

        assert min <= max;
        if (maxLoad < capacity)
            return ESat.TRUE;

        return ESat.UNDEFINED;
    }
}
