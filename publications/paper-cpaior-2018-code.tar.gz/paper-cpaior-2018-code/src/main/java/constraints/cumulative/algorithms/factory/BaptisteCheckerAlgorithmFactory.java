package constraints.cumulative.algorithms.factory;

import constraints.cumulative.algorithms.CheckerAlgorithm;
import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.BaptisteCheckerAlgorithm;


public class BaptisteCheckerAlgorithmFactory implements CheckerAlgorithmFactory {
    @Override
    public CheckerAlgorithm create(CumulativeArguments args) {
        return new BaptisteCheckerAlgorithm(args);
    }
}
