package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;
import energetic.baptiste.BaptisteEnergeticChecker;
import tools.TasksGenerator;

@SuppressWarnings("Duplicates")
public class ComparisonAlgorithm implements CheckerAlgorithm {
    private CheckerAlgorithm a;
    private CheckerAlgorithm b;
    private Instance positiveInstance;
    private Instance negativeInstance;

    public ComparisonAlgorithm(CheckerAlgorithm a, CheckerAlgorithm b) {
        this.a = a;
        this.b = b;
    }

    @Override
    public void initialize(Instance positiveInstance, Instance negativeInstance) {
        this.positiveInstance = positiveInstance;
        this.negativeInstance = negativeInstance;
        a.initialize(positiveInstance, negativeInstance);
        b.initialize(positiveInstance, negativeInstance);
    }

    @Override
    public void update() {
        a.update();
        b.update();
    }

    @Override
    public boolean isConsistent() {
        boolean a_consistent = a.isConsistent();
        boolean b_consistent = b.isConsistent();

        if (a_consistent != b_consistent) {
            System.out.println("Instance failed.");
            System.out.println(positiveInstance.getC());
            System.out.println(TasksGenerator.generateTestFromTask(positiveInstance.getTasks()));
            System.out.println(TasksGenerator.generateTestFromTask(negativeInstance.getTasks()));
        }

        return a_consistent;
    }
}
