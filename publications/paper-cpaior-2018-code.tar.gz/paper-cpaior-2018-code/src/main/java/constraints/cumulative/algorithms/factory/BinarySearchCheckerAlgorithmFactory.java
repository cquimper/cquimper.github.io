package constraints.cumulative.algorithms.factory;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.BinarySearchCheckerAlgorithm;
import constraints.cumulative.algorithms.CheckerAlgorithm;


public class BinarySearchCheckerAlgorithmFactory implements CheckerAlgorithmFactory {
    @Override
    public CheckerAlgorithm create(CumulativeArguments args) {
        return new BinarySearchCheckerAlgorithm(args);
    }
}
