package constraints.cumulative.algorithms.factory;

import constraints.cumulative.algorithms.CheckerAlgorithm;
import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.BaptisteCheckerAlgorithm;
import constraints.cumulative.algorithms.ComparisonAlgorithm;


public class ComparisonAlgorithmFactory implements CheckerAlgorithmFactory {
    private CheckerAlgorithmFactory a;
    private CheckerAlgorithmFactory b;

    public ComparisonAlgorithmFactory(CheckerAlgorithmFactory a, CheckerAlgorithmFactory b) {
        this.a = a;
        this.b = b;
    }

    @Override
    public CheckerAlgorithm create(CumulativeArguments args) {
        return new ComparisonAlgorithm(a.create(args), b.create(args));
    }
}
