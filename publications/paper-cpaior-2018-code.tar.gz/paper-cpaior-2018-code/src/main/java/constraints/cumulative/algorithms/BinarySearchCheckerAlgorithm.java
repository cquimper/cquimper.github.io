package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;
import energetic.binarysearch.BinarySearchChecker;
import benchmarking.cumulative.CumulativeArguments;
import energetic.binarysearch.StandaloneBinarySearchChecker;

public class BinarySearchCheckerAlgorithm implements CheckerAlgorithm {
    private CumulativeArguments args;
    private StandaloneBinarySearchChecker positiveChecker;
    private StandaloneBinarySearchChecker negativeChecker;

    public BinarySearchCheckerAlgorithm(CumulativeArguments args) {
        this.args = args;
    }

    @Override
    public void initialize(Instance positiveInstance, Instance negativeInstance) {
        positiveChecker = new StandaloneBinarySearchChecker(positiveInstance.getTasks(), positiveInstance.getC(), args);
        negativeChecker = new StandaloneBinarySearchChecker(negativeInstance.getTasks(), negativeInstance.getC(), args);
    }

    @Override
    public void update() {
        positiveChecker.update();
        negativeChecker.update();
    }

    @Override
    public boolean isConsistent() {
        return positiveChecker.isConsistent() && negativeChecker.isConsistent();
    }
}
