package constraints.cumulative.algorithms.factory;

import constraints.cumulative.algorithms.CheckerAlgorithm;
import benchmarking.cumulative.CumulativeArguments;


public interface CheckerAlgorithmFactory {
    CheckerAlgorithm create(CumulativeArguments args);
}
