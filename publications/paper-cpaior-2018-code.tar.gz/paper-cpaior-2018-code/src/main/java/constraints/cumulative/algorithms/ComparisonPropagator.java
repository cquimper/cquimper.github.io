package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;
import energetic.FilteredBounds;
import energetic.baptiste.BaptisteEnergeticChecker;
import sun.awt.Mutex;
import tools.TasksGenerator;
import lib.Mailgun;
import energetic.bruteforce.BruteForceExperimentation;
import benchmarking.cumulative.CumulativeArguments;
import energetic.binarysearch.BinarySearchFiltering;
import energetic.FilteringUtil;
import energetic.FilteringUtil.NonMatchingBoundsExeception;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.Semaphore;

@SuppressWarnings("Duplicates")
public class ComparisonPropagator extends PropagatorAlgorithm {
    private CumulativeArguments args;
    public static boolean sendMail = true;
    private static Semaphore semaphore = new Semaphore(1);

    private Instance instance;
    private BaptisteEnergeticChecker baptiste;
    private BinarySearchFiltering binary;

    public ComparisonPropagator(CumulativeArguments args) {
        this.args = args;
    }

    @Override
    public void initialize(Instance positiveInstance, Instance negativeInstance) {
        this.instance = positiveInstance;
        this.baptiste = new BaptisteEnergeticChecker(instance.getTasks(), instance.getC(), args);
        this.binary = new BinarySearchFiltering(instance.getTasks(), instance.getC(), args);
    }

    @Override
    public void update() {
        baptiste.update();
        binary.update();
    }

    @Override
    public boolean isConsistent() {
        //TODO Is-it ok to do not care of this method?
        return true;
    }

    @Override
    public FilteredBounds filter() {
        boolean passes = true;
        FilteredBounds bounds;
        try {
            bounds = FilteringUtil.filterAndCompareAtFixpoint(baptiste, binary, instance.getTasks());
        } catch (NonMatchingBoundsExeception ex) {
            passes = false;
            bounds = null;
        }

        if (!passes) {
            String message = Integer.toString(instance.getC()) + "\n";
            message += TasksGenerator.generateTestFromTask(instance.getTasks());
            System.out.println(message);

            try {
                semaphore.acquire();
                if (sendMail) {
                    Mailgun.send("Your tests failed", message);
                    sendMail = false;
                }
            } catch (InterruptedException ignored) {
            } finally {
                semaphore.release();
            }
        }

        return bounds;
    }
}
