package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;
import energetic.FilteredBounds;

public abstract class PropagatorAlgorithm implements CheckerAlgorithm {
    public abstract void initialize(Instance positiveInstance, Instance negativeInstance);
    public abstract void update();
    public abstract boolean isConsistent();
    public abstract FilteredBounds filter();
}
