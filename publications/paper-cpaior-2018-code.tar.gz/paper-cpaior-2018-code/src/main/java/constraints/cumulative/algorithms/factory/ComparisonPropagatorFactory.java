package constraints.cumulative.algorithms.factory;

import constraints.cumulative.algorithms.CheckerAlgorithm;
import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.BaptisteCheckerAlgorithm;
import constraints.cumulative.algorithms.ComparisonAlgorithm;
import constraints.cumulative.algorithms.ComparisonPropagator;


public class ComparisonPropagatorFactory implements CheckerAlgorithmFactory {
    @Override
    public CheckerAlgorithm create(CumulativeArguments args) {
        return new ComparisonPropagator(args);
    }
}
