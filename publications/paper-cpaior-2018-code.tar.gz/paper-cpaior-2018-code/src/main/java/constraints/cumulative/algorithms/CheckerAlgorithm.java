package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;

public interface CheckerAlgorithm {
    void initialize(Instance positiveInstance, Instance negativeInstance);
    void update();
    boolean isConsistent();
}
