package constraints.cumulative.algorithms.factory;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.BinarySearchPropagator;
import constraints.cumulative.algorithms.CheckerAlgorithm;


public class BinarySearchPropagatorFactory implements CheckerAlgorithmFactory {
    @Override
    public CheckerAlgorithm create(CumulativeArguments args) {
        return new BinarySearchPropagator(args);
    }
}
