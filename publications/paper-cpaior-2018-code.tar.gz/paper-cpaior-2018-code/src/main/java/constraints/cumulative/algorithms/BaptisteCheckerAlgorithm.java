package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;
import energetic.baptiste.BaptisteEnergeticChecker;
import benchmarking.cumulative.CumulativeArguments;

public class BaptisteCheckerAlgorithm implements CheckerAlgorithm {
    private CumulativeArguments args;
    private BaptisteEnergeticChecker positiveChecker;
    private BaptisteEnergeticChecker negativeChecker;

    public BaptisteCheckerAlgorithm(CumulativeArguments args) {
        this.args = args;
    }

    @Override
    public void initialize(Instance positiveInstance, Instance negativeInstance) {
        positiveChecker = new BaptisteEnergeticChecker(positiveInstance.getTasks(), positiveInstance.getC(), args);
        negativeChecker = new BaptisteEnergeticChecker(negativeInstance.getTasks(), negativeInstance.getC(), args);
    }

    @Override
    public void update() {
        positiveChecker.update();
        negativeChecker.update();
    }

    @Override
    public boolean isConsistent() {
        return positiveChecker.isConsistent() && negativeChecker.isConsistent();
    }
}
