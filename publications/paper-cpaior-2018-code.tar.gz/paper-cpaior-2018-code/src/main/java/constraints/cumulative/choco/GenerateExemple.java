package constraints.cumulative.choco;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.algorithms.factory.CheckerAlgorithmFactory;
import datastructures.VirtualInitialisationCache;
import java.util.ArrayList;
import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solution;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.search.strategy.Search;
import org.chocosolver.solver.search.strategy.selectors.values.IntDomainMin;
import org.chocosolver.solver.search.strategy.selectors.variables.Largest;
import org.chocosolver.solver.search.strategy.selectors.variables.Smallest;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.Task;
import org.chocosolver.util.tools.ArrayUtils;

public class GenerateExemple {
    public GenerateExemple() throws Exception {

        Model model = new Model("Generate exemple");
        int n = 3;

        IntVar[] est = new IntVar[n];
        IntVar[] lct = new IntVar[n];
        IntVar[] ps = new IntVar[n];
        IntVar[] hs = new IntVar[n];
        IntVar[] vars = new IntVar[n*4];
        int k = 0;

        for (int i = 0; i < n; i++)
        {
            vars[k++] = est[i] = model.intVar("est[" + i +"]", 0, 10, true);
            vars[k++] = lct[i] = model.intVar("lct[" + i +"]", 0, 10, true);
            vars[k++] = ps[i] = model.intVar("p[" + i +"]", 1, 5, true);
            vars[k++] = hs[i] = model.intVar("h[" + i +"]", 1, 2, true);
        }

        for (int i = 0; i < n; i++) {
            model.arithm(est[i], "+", ps[i], "<", lct[i]).post();
            model.allDifferent(est).post();
            model.allDifferent(lct).post();
            model.allDifferent(ps).post();
            model.notAllEqual(hs).post();
        }

       model.post(new Constraint("ExampleConstraint",
                                new GenerateExamplePropagator(est, lct, ps, hs)));

        //model.arithm(startingTimes[0], "=", 0).post();
        //model.setObjective(false, makespan);
        Solver solver = model.getSolver();

        //solver.setSearch(Search.intVarSearch(new StaticVarOrder(model), new IntDomainMin(), startingTimes_and_makespan));      	break;
        solver.setSearch(Search.domOverWDegSearch(vars));
        //solver.setSearch(Search.conflictOrderingSearch(Search.intVarSearch(new Largest(), new IntDomainMin(), vars)));

        solver.setRestartOnSolutions();
        solver.limitTime(20 * 60 * 1000);

        //Solution best = solver.findOptimalSolution(makespan, false);
        solver.showSolutions();
        if (solver.solve()) {
        }

        solver.printStatistics();
    }
}
