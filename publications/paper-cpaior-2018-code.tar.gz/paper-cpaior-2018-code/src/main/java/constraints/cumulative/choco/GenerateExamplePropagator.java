package constraints.cumulative.choco;

import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.constraints.PropagatorPriority;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.ESat;
import constraints.cumulative.Task;
import energetic.binarysearch.BruteMatrix;

public class GenerateExamplePropagator extends Propagator<IntVar> {
    IntVar[] est;
    IntVar[] lct;
    IntVar[] hs;
    IntVar[] ps;

    public GenerateExamplePropagator(IntVar[] est, IntVar[] lct, IntVar[] ps, IntVar[] hs) {
        super(est, PropagatorPriority.VERY_SLOW, false);
        this.est = est;
        this.lct = lct;
        this.ps = ps;
        this.hs = hs;
    }

    @Override
    public void propagate(int evtmask) throws ContradictionException {
        for (int i = 0; i < vars.length - 1; i++) {
            if (!vars[i].isInstantiated()) {
                return;
            }
        }

        Task[] tasks = new Task[est.length];
        for (int i = 0; i < tasks.length; i++) {
            tasks[i] = new Task(i+1, est[i].getValue(), lct[i].getValue(), ps[i].getValue(), hs[i].getValue());
        }

        BruteMatrix matrix = new BruteMatrix(tasks, 2);
        if (matrix.countFail() != 1) {
            throw new ContradictionException();
        }
    }

    @Override
    public ESat isEntailed() {
        // check variables are instantiated
        for (int i = 0; i < vars.length - 1; i++) {
            if (!vars[i].isInstantiated()) {
                return ESat.UNDEFINED;
            }
        }

        return ESat.TRUE;
    }
}
