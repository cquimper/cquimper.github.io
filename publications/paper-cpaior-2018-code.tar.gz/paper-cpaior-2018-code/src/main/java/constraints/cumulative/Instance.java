package constraints.cumulative;

public class Instance {
    private Task[] tasks;
    private int C;

    public Instance(Task[] tasks, int c) {
        this.tasks = tasks;
        C = c;
    }

    public Task[] getTasks() {
        return tasks;
    }

    public int getC() {
        return C;
    }
}
