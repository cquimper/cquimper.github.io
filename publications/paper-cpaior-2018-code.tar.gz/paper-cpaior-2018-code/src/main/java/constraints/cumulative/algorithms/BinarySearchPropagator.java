package constraints.cumulative.algorithms;

import constraints.cumulative.Instance;
import energetic.FilteredBounds;
import energetic.binarysearch.BinarySearchChecker;
import benchmarking.cumulative.CumulativeArguments;
import energetic.binarysearch.BinarySearchFiltering;
import energetic.FilteringUtil;
import tools.TasksGenerator;

public class BinarySearchPropagator extends PropagatorAlgorithm {
    private CumulativeArguments args;
    private Instance instance;
    private BinarySearchChecker positiveChecker;
    private BinarySearchChecker negativeChecker;
    private BinarySearchFiltering algo;

    public BinarySearchPropagator(CumulativeArguments args) {
        this.args = args;
    }

    @Override
    public void update() {
        positiveChecker.update();
        negativeChecker.update();
        algo.update();
    }

    @Override
    public void initialize(Instance positiveInstance, Instance negativeInstance) {
        this.instance = positiveInstance;
        this.positiveChecker = new BinarySearchChecker(positiveInstance.getTasks(), positiveInstance.getC(), args);
        this.negativeChecker = new BinarySearchChecker(negativeInstance.getTasks(), negativeInstance.getC(), args);
        this.algo = new BinarySearchFiltering(positiveInstance.getTasks(), positiveInstance.getC(), args);
    }

    @Override
    public boolean isConsistent() {
        args.virtualCache.reinitialise();
        boolean isConsistent = positiveChecker.isConsistent();
        args.virtualCache.reinitialise();
        isConsistent &= negativeChecker.isConsistent();
        args.virtualCache.reinitialise();

        return isConsistent;
    }

    @Override
    public FilteredBounds filter() {
        try {
            return FilteringUtil.filterUntilFixpoint(algo, instance.getTasks());
        } catch (Exception e) {
            System.out.println(instance.getC());
            System.out.println(TasksGenerator.generateTestFromTask(instance.getTasks()));
            throw e;
        }
    }
}
