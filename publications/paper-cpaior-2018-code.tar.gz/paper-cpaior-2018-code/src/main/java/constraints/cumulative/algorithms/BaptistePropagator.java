package constraints.cumulative.algorithms;

import benchmarking.cumulative.CumulativeArguments;
import constraints.cumulative.Instance;
import energetic.FilteredBounds;
import energetic.FilteringUtil;
import energetic.baptiste.BaptisteEnergeticChecker;
import tools.TasksGenerator;

public class BaptistePropagator extends PropagatorAlgorithm {
    private CumulativeArguments args;
    private Instance instance;
    private BaptisteEnergeticChecker positiveChecker;
    private BaptisteEnergeticChecker negativeChecker;

    public BaptistePropagator(CumulativeArguments args) {
        this.args = args;
    }

    @Override
    public void initialize(Instance positiveInstance, Instance negativeInstance) {
        this.instance = positiveInstance;
        this.positiveChecker = new BaptisteEnergeticChecker(positiveInstance.getTasks(), positiveInstance.getC(), args);
        this.negativeChecker = new BaptisteEnergeticChecker(negativeInstance.getTasks(), negativeInstance.getC(), args);
    }

    @Override
    public void update() {
        positiveChecker.update();
        negativeChecker.update();
    }

    @Override
    public boolean isConsistent() {
        return positiveChecker.isConsistent() && negativeChecker.isConsistent();
    }

    @Override
    public FilteredBounds filter() {
        try {
            return FilteringUtil.filterUntilFixpoint(positiveChecker, instance.getTasks());
        } catch (Exception e) {
            System.out.println(instance.getC());
            System.out.println(TasksGenerator.generateTestFromTask(instance.getTasks()));
            throw e;
        }
    }
}
