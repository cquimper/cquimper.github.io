package datastructures

data class Point constructor(val x1: Int, val x2: Int, val y: Int, val h: Int) {
}