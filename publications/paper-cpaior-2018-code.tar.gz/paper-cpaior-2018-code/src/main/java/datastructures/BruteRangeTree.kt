package datastructures

class BruteRangeTree constructor(private var points: Array<Point>) {
    fun query(l: Int, u: Int, yMax: Int): Int {
        var sum = 0

        for ((x1, x2, y, h) in points) {
            if (y > yMax) {
                continue
            }
            val lower = Math.max(l, x1)
            val upper = Math.min(u, x2)
            if (lower < upper) {
                sum += (upper - lower) * h
            }
        }
        return sum;
    }
}
