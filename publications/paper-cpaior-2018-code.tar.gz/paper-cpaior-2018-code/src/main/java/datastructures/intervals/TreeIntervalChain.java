package datastructures.intervals;

import java.util.*;

public class TreeIntervalChain {
    private TreeMap<Integer, Interval> tree;
    public TreeIntervalChain(int l, int u, int value) {
        tree = new TreeMap<>();
        tree.put(l-1, new Interval(l-1, u+1, value));
    }

    public Collection<Interval> getIntervals() {
        return tree.values();
    }

    public void replace(int l, int u, int value) {
        Interval floor = tree.floorEntry(l).getValue();
        if (floor.l == l && floor.u == u) {
            floor.value = value;
            return;
        }

        Interval newInterval = new Interval(l, u, value);
        Interval next = null;
        if (floor.u > u) {
            next = new Interval(u, floor.u, floor.value);
        } else if (floor.u < u) {
            Map.Entry<Integer, Interval> entry = tree.ceilingEntry(l+1);
            while (entry != null && entry.getValue().u > l && entry.getValue().u <= u) {
                // We have to remove some entries. This takes at most n log n steps
                // for all executions since the total of intervals added to the tree
                // is at most 2n.
                tree.remove(entry.getKey());
                entry = tree.ceilingEntry(l+1);
            }
            if (entry != null && entry.getValue().u > l && entry.getValue().l < u) {
                tree.remove(entry.getKey());
                entry.getValue().l = u;
                tree.put(u, entry.getValue());
            }
        }

        if (next != null) {
            tree.put(next.l, next);
        }

        tree.put(l, newInterval);

        floor.u = l;
    }

    public int findAssociatedLower(int u) {
        return tree.floorEntry(u-1).getValue().value;
    }

    public Interval findAssociatedLowerInterval(int key) {
        return tree.floorEntry(key-1).getValue();
    }

    public Interval findNextEntry(int key) {
        Map.Entry<Integer, Interval> entry = tree.higherEntry(key);
        return entry != null ? entry.getValue() : null;
    }

    public class Interval implements Comparable<Interval> {
        public int l;
        public int u;
        public int value;
        public Interval next;

        public Interval(int l, int u, int value) {
            this.l = l;
            this.u = u;
            this.value = value;
            this.next = null;
        }

        @Override
        public int compareTo(Interval o) {
            int r = Integer.compare(l, o.l);
            return r;
        }

        @Override
        public boolean equals(Object obj) {
            return obj instanceof Interval && l == ((Interval) obj).l;
        }
    }
}
