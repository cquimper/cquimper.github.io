package datastructures.intervals;

public class LinearIntervalChain {
    private int[] table;
    private Interval first;
    private Interval last;
    private int maxValue;
    public LinearIntervalChain(int l, int u, int value) {
        table = new int[u];
        for (int i = 0; i < table.length; i++)
            table[i] = value;
        maxValue = u;
    }

    @Deprecated
    public void add(int l, int value) {
        assert l >= last.l;
        last.next = new Interval(l, last.u, value);
        last.u = l;
        last = last.next;
    }

    public Interval getFirst() {
        Interval current = first = new Interval(0,0, table[0]);
        for (int i = 0; i < table.length; i++) {
            if (current.value == table[i]) {
                current.u = i + 1;
            } else {
                current.next = new Interval(i, i+1, table[i]);
                current = current.next;
            }
        }
        return first;
    }

    public void replace(int l, int u, int value) {
        for (int i = l; i < u && i < maxValue; i++) {
            table[i] = value;
        }
    }

    public int findAssociatedLower(int u) {
        return table[u-1];
    }

    public class Interval {
        public int l;
        public int u;
        public int value;
        public Interval next;

        public Interval(int l, int u, int value) {
            this.l = l;
            this.u = u;
            this.value = value;
            this.next = null;
        }
    }
}
