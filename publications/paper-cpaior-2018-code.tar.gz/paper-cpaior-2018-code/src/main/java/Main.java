import benchmarking.FakeModelRunner;
import benchmarking.ModelRunner;
import benchmarking.cumulative.CumulativeBenchmarks;
import benchmarking.cumulative.CumulativeModelRunner;
import benchmarking.cumulative.CumulativeArguments;
import benchmarking.cumulative.CumulativeFilteringModelRunner;
import constraints.cumulative.algorithms.ComparisonPropagator;
import energetic.binarysearch.BruteFilteringMatrix;
import lib.Mailgun;
import constraints.cumulative.choco.GenerateExemple;

import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length < 4) {
            System.out.println("Usage: java -jar jarname.jar baseInputPath baseOutputPath benchmark threadsCount [compareValidity]");
            return;
        }

        String baseInputPath = args[0];
        String baseOutputPath = args[1];
        String benchmark = args[2];
        int threadsCount = Integer.parseInt(args[3]);

        boolean compareValidity = args.length >= 5 && args[4].trim().equals("true");
        CumulativeArguments arguments = new CumulativeArguments(true, !compareValidity);
        ModelRunner modelRunner = new CumulativeModelRunner(arguments);
        //ModelRunner modelRunner = new CumulativeFilteringModelRunner(arguments);
        CumulativeBenchmarks.runBenchmarks(modelRunner, baseInputPath, baseOutputPath, benchmark, threadsCount);
    }
}
