package tools;

import constraints.cumulative.Instance;
import constraints.cumulative.Task;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TaskReader {
    public static ArrayList<Instance> readTasksFromCustomFile(int n) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("/Users/yanickouellet/IdeaProjects/hello/data/custom_cumul/" + n + ".txt"));
        ArrayList<Instance> instances = new ArrayList<>();

        while (sc.hasNext()) {
            Task[] tasks = new Task[n];
            sc.nextLine();
            int C = Integer.parseInt(sc.nextLine().split(",")[1].trim());
            for (int i = 0; i < n; i++) {
                String[] line = sc.nextLine().split(",");
                tasks[i] = new Task(
                        i+1,
                        Integer.parseInt(line[1].trim()),
                        Integer.parseInt(line[2].trim()),
                        Integer.parseInt(line[3].trim()),
                        Integer.parseInt(line[4].trim())
                );
            }
            instances.add(new Instance(tasks, C));
        }

        return instances;
    }
}

