package tools;

import constraints.cumulative.Task;

import java.util.Arrays;
import java.util.stream.Stream;

public class TasksToLatex {
    public static String appendToS(int i, int value) {
        return String.format("Append $\\langle %d,%d \\rangle$ to $S$",i , value);
    }

    public static String traceOfInnerLoop(int ect, int lst, int id) {
        StringBuilder builder = new StringBuilder();
        builder.append(String.format("$ect_T = %s$. Traite la tâche %d, ",
                getNumberOrInfinity(ect), id
        ));

        builder.append(String.format("$ect_T = %s %s %d = lst_%d$ ",
                getNumberOrInfinity(ect), getOperator(ect, lst), lst, id
        ));

        return builder.toString();
    }

    public static String scheduleOnTimeline(int begin, int end, int id) {
        return generateEvent(begin, end, id);
    }

    public static String showTasksOnTimeline(Task[] tasks) {
        Stream<Task> stream = Arrays.stream(tasks);
        int begin = stream
                .mapToInt(Task::getEst)
                .min().getAsInt();

        stream = Arrays.stream(tasks);
        int end = stream
                .mapToInt(Task::getLct)
                .max().getAsInt();

        stream = Arrays.stream(tasks);
        StringBuilder builder = new StringBuilder();
        stream.forEach(t -> {
            builder.append(generateTitle(t));
            builder.append(generateBegin(begin, end));
            builder.append(generateEvent(t));
            builder.append(generateEnd());
        });

        return builder.toString();
    }

    private static String generateTitle(Task task) {
        return String.format("Task %d: processing time of %d\\\\\n",task.getId()+1, task.getP());
    }

    private static String generateEvent(Task task) {
        return generateEvent(task.getEst(), task.getLct(), task.getId() + 1);
    }

    public static String generateEvent(int begin, int end, int num) {
        return String.format("\\event[%d]{%d}{%d}\n",
                begin,
                end,
                num
        );
    }
    public static String generateBegin(int begin, int end) {
        return String.format("\\begin{chronology}[2]{%d}{%d}{17cm}{10cm}\n", begin, end);
    }
    public static String generateEnd() {
        return "\\end{chronology}\\\\\n\n";
    }

    public static String generateTable(Task[] tasks) {
        Stream<Task> stream;

        stream = Arrays.stream(tasks);
        StringBuilder builder = new StringBuilder();
        builder.append(generateTableBegin());
        stream.forEach(t -> {
            builder.append(generateTableRow(t));
        });
        builder.append(generateTableEnd());

        return builder.toString();
    }

    private static String generateTableBegin() {
        return "\\begin{tabular}{| l | l | l | l | l | l | l |}\n" +
                "  \\hline\n" +
                "  i & est & lct & p & h & ect & lst \\\\\n" +
                "  \\hline\n"
                ;
    }

    private static String generateTableRow(Task task) {
        return String.format("  %d & %d & %d & %d & %d & %d & %d\\\\\n",
                task.getId()+1,
                task.getEst(),
                task.getLct(),
                task.getP(),
                task.getH(),
                task.getEct(),
                task.getLst()
        );
    }

    private static String generateTableEnd() {
        return "  \\hline\n\\end{tabular}\n";
    }

    private static String getOperator(int x1, int x2) {
        if (x1 > x2)
            return ">";
        else if (x1 == x2)
            return "=";
        else
            return "<";
    }

    private static String getNumberOrInfinity(int x) {
        return x == Integer.MIN_VALUE ? "-\\infty" : Integer.toString(x);
    }
}
