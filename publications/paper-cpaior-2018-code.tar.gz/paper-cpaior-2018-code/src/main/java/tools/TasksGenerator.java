package tools;

import constraints.cumulative.Task;
import constraints.cumulative.Instance;

import java.util.Random;

public class TasksGenerator {
    public static String generateDisjunctiveTaks(int n) {
        return generateDisjunctiveTaks(n, 0, 30, 1);
    }


    public static String generateCumulativeTasks(int n) {
        return generateDisjunctiveTaks(n, 0, 10 * n, 4);
    }

    public static Instance generateCumulativeTasks(int n, int begin, int end, int maxC) {
        Task[] tasks = new Task[n];
        int processingMax = end - begin - n; //Each task should have p >= 1

        int C = nextInt(1, maxC);

        for (int i = 0; i < n; i++) {
            int processing = nextInt(1, processingMax - (n - i) + 1);
            processingMax -= processing;
            int est = nextInt(0, end - processing);
            int lct = nextInt(est + processing, end);
            int c = nextInt(1, C);
            tasks[i] = new Task(i+1, est, lct, processing, c);
        }

        return new Instance(tasks, C);
    }

    public static String generateDisjunctiveTaks(int n, int begin, int end, int maxC) {
        int processingMax = end - begin - n; //Each task should have p >= 1

        StringBuilder builder = new StringBuilder();

        int C = nextInt(1, maxC);

        builder.append(String.format("%d, %d\n", n, C));
        for (int i = 0; i < n; i++) {
            int processing = nextInt(1, processingMax - (n - i) + 1);
            processingMax -= processing;
            int est = nextInt(0, end - processing);
            int lct = nextInt(est + processing, end);
            int c = nextInt(1, C);
            builder.append(String.format("%d, %d, %d, %d, %d\n",
                    i+1,
                    est,
                    lct,
                    processing,
                    c
            ));
        }

        return builder.toString();
    }

    public static String generateTestFromTask(Task[] tasks) {
        StringBuilder builder = new StringBuilder();

        for (Task task : tasks) {
            builder.append(String.format("new constraints.cumulative.Task(%d, %d, %d, %d, %d),\n",
                    task.getId()+1,
                    task.getEst(),
                    task.getLct(),
                    task.getP(),
                    task.getH()
                    ));
        }

        return builder.toString();
    }

    private static Random r;
    private static int nextInt(int min, int max) {
        if (r == null) r = new Random();
        if (max - min == 0) return min;
        if (max-min < 0)
            System.out.println("fuuu");
        return min + r.nextInt(max - min);
    }
}
