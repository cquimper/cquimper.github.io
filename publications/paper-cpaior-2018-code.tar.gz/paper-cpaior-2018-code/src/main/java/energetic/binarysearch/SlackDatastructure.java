package energetic.binarysearch;

public interface SlackDatastructure {
    int querySlack(int l, int u);
}
