package energetic.binarysearch.strategies;

import energetic.binarysearch.SlackDatastructure;
import energetic.binarysearch.InconsistentException;

public class DefaultComputeSlackStrategy implements ComputeSlackStrategy {
    public int computeSlack(SlackDatastructure datastructure, int t1, int t2) throws InconsistentException {
        int slack = datastructure.querySlack(t1, t2);

        if (slack < 0 && t2 > t1) {
            throw new InconsistentException();
        }
        return slack;
    }
}
