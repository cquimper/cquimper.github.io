package energetic.binarysearch;

import constraints.cumulative.Task;
import benchmarking.cumulative.CumulativeArguments;
import energetic.FilteringAlgorithm;
import energetic.FilteredBounds;
import kotlin.NotImplementedError;
import energetic.binarysearch.strategies.ComputeSlackStrategy;
import energetic.binarysearch.strategies.TwoPassesComputeSlackStrategy;
import energetic.binarysearch.strategies.FourPassesComputeSlackStrategy;
import energetic.binarysearch.strategies.FilteringComputeSlackStrategy;

@SuppressWarnings("Duplicates")
public class BinarySearchFiltering implements NegativeIntervalEventListener, FilteringAlgorithm {
    private Task[] tasks;
    private Task[] reverseTasks;
    private int C;
    private CumulativeArguments args;
    private int[] estPrime;
    private int[] lctPrime;
    private int maxLct;
    private boolean doReversePasses;
    private boolean fail;

    private BinarySearchChecker checker;
    private BinarySearchChecker reverseChecker;
    private LogarithmicSlackDatastructure datastructure;

    public BinarySearchFiltering(Task[] tasks, int C, CumulativeArguments args) {
        this.args = args;
        this.tasks = tasks;
        this.reverseTasks = new Task[tasks.length];
        this.C = C;
        this.doReversePasses = false;
        this.fail = false;

        maxLct = 0;
        estPrime = new int[tasks.length];
        lctPrime = new int[tasks.length];
        for (int i = 0; i < tasks.length; i++) {
            estPrime[i] = tasks[i].getEst();
            lctPrime[i] = tasks[i].getLct();
            maxLct = Math.max(maxLct, tasks[i].getLct());
        }

        for (int i = 0; i < tasks.length; i++) {
            reverseTasks[i] =
                new Task(
                         i + 1,
                         maxLct - tasks[i].getLct(),
                         maxLct - tasks[i].getEst(),
                         tasks[i].getP(),
                         tasks[i].getH());
        }

        checker = new BinarySearchChecker(tasks, C, args);
        reverseChecker = new BinarySearchChecker(reverseTasks, C, args, true);
    }

    @Override
    public void update() {
        maxLct = 0;
        for (int i = 0; i < tasks.length; i++) {
            maxLct = Math.max(maxLct, tasks[i].getLct());
        }

        for (int i = 0; i < tasks.length; i++) {
            reverseTasks[i].update(maxLct - tasks[i].getLct(), maxLct - tasks[i].getEst());
        }
    }

    @Override
    public FilteredBounds filter() {
        new BruteFilteringMatrix(tasks, C);
        fail = false;
        doReversePasses = false;
        for (int i = 0; i < tasks.length; i++) {
            estPrime[i] = tasks[i].getEst();
            lctPrime[i] = tasks[i].getLct();
            maxLct = Math.max(maxLct, tasks[i].getLct());
        }

        datastructure = new LogarithmicSlackDatastructure(tasks, C, args);
        VirtualSlackDatastructure virtualDatastructure =
                new VirtualSlackDatastructure(datastructure, maxLct);

        FilteringComputeSlackStrategy computeSlackStrategy;

        if (args.doTwoPasses()) {
            computeSlackStrategy = new TwoPassesComputeSlackStrategy(this, true);
        } else if (args.doFourPasses()) {
            computeSlackStrategy = new FourPassesComputeSlackStrategy(this, true);
        } else {
            throw new NotImplementedError();
        }

        checker.setComputeSlackStrategy(computeSlackStrategy);
        checker.setDatastructure(datastructure);
        reverseChecker.setComputeSlackStrategy(computeSlackStrategy);
        reverseChecker.setDatastructure(virtualDatastructure);

        checker.update();
        reverseChecker.update();

        int inf = Integer.MAX_VALUE;
        int negInf = Integer.MIN_VALUE;

        for (int i = 0; i < tasks.length; i++) {
            //Filter est on O1 x O2 U Ot matrix
            computeSlackStrategy.setTaskToFilter(tasks[i]);
            computeSlackStrategy.setUseLeftShift(true);
            checker.isConsistent(negInf, tasks[i].getEct(), negInf, inf);

            //Filter est on O2 U Ot x O1 matrix
            computeSlackStrategy.setTaskToFilter(reverseTasks[i]);
            computeSlackStrategy.setUseLeftShift(false);
            reverseChecker.isConsistent(maxLct - tasks[i].getLct(), maxLct - tasks[i].getEst(), negInf, inf);

            if (fail) {
                return null;
            }
        }

        if (args.doFourPasses()) {
            doReversePasses = true;
            for (int i = 0; i < tasks.length; i++) {
                //Filter lct on O1 x O2 U Ot matrix
                computeSlackStrategy.setTaskToFilter(tasks[i]);
                computeSlackStrategy.setUseLeftShift(false);
                checker.isConsistent(tasks[i].getEst(), tasks[i].getLct(), negInf, inf);

                //Filter lct on O2 U Ot x O1 matrix
                computeSlackStrategy.setTaskToFilter(reverseTasks[i]);
                computeSlackStrategy.setUseLeftShift(true);
                reverseChecker.isConsistent(negInf, maxLct - tasks[i].getLst(), negInf, inf);

                if (fail || !derrienPart(tasks[i])) {
                    return null;
                }
            }
        }

        return new FilteredBounds(estPrime, lctPrime);
    }

    private boolean derrienPart(Task at) {
        int t1;
        int t2;
        boolean pass = true;

        // L_3
        filterForTaskAndInterval(at, at.getEst(), at.getEct());
        // R_3
        filterForTaskAndInterval(at, at.getLst(), at.getLct());
        for (int i = 0; i < tasks.length; i++) {
            Task it = tasks[i];

            //L_1
            t1 = it.getEst();
            t2 = at.getEct();
            if (t2 > it.getLct() && t1 < at.getEct()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t2 = at.getEct();
            t1 = it.getEst() + it.getLct() - t2;
            if (t2 < it.getLct() && t2 > it.getLst() && t2 > it.getEct() && t1 < at.getEct()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t1 = it.getLst();
            t2 = at.getEct();
            if (t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct() && t1 < at.getEct()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            // L_2
            t1 = at.getEst();
            t2 = it.getLct();
            if (t2 > at.getEst() && t1 <= it.getEst()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t1 = at.getEst();
            t2 = it.getEst() + it.getLct() - t1;
            if (t2 > at.getEst() && t1 > it.getEst() && t1 < it.getEct() && t1 < it.getLst()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t1 = at.getEst();
            t2 = it.getEct();
            if (t2 > at.getEst() && t1 > it.getEst() && t1 < it.getEct() && t1 >= it.getLst()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            // R_1
            t1 = it.getEst();
            t2 = at.getLct();
            if (t2 >= it.getLct() && t1 < at.getLct()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t2 = at.getLct();
            t1 = it.getEst() + it.getLct() - t2;
            if (t2 < it.getLct() && t2 > it.getLst() && t2 > it.getEct() && t1 < at.getLct()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t1 = it.getLst();
            t2 = at.getLct();
            if (t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct() && t1 < at.getLct()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            // R_2
            t1 = at.getLst();
            t2 = it.getLct();
            if (t2 > at.getLst() && t1 <= it.getEst()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t1 = at.getLst();
            t2 = it.getEst() + it.getLct() - t1;
            if (t2 > at.getLst() && t1 > it.getEst() && t1 < it.getEct() && t1 < it.getLst()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            t1 = at.getLst();
            t2 = it.getEct();
            if (t2 > at.getLst() && t1 > it.getEst() && t1 < it.getEct() && t1 >= it.getLst()) {
                pass &= filterForTaskAndInterval(at, t1, t2);
            }

            if (!pass) {
                return false;
            }
        }

        return true;
    }

    private boolean filterForTaskAndInterval(Task task, int t1, int t2) {
        if (t2 <= t1)
            return true;

        int slack = datastructure.querySlack(t1, t2);

        if (slack < 0) {
            return false;
        }

        int i = task.getId();
        slack += task.computeMinimumIntersection(t1, t2);
        int leftShift = task.computeLeftShift(t1, t2);
        int rightShift = task.computeRightShift(t1, t2);
        if (slack < leftShift) {
            int adjustment = (int) Math.ceil(t2 - 1.0 * slack / task.getH());
            estPrime[i] = Math.max(estPrime[i], adjustment);
        }

        if (slack < rightShift) {
            int adjustment = (int) (t1 + 1.0 * slack / task.getH());
            lctPrime[i] = Math.min(lctPrime[i], adjustment);
        }

        if (estPrime[i] + task.getP() > lctPrime[i]) {
            return false;
        }

        return true;
    }

    public void fail(Task task, int t1, int t2, int avail) {
        if (fail) {
            return;
        }

        boolean doReverseTasks = false;
        int i = task.getId();
        if (task != tasks[i]) {
            doReverseTasks = true;
            task = tasks[i];
            int temp = t1;
            t1 = maxLct - t2;
            t2 = maxLct - temp;
        }

        if (args.doTwoPasses()) {
            filterEst(task, t1, t2, avail);
            filterLct(task, t1, t2, avail);
        } else if (args.doFourPasses()) {
            if (!doReversePasses && !doReverseTasks) {
                avail += task.computeLeftShift(t1, t2);
                filterEst(task, t1, t2, avail);
            } else if (!doReversePasses && doReverseTasks) {
                avail += tasks[i].computeLeftShift(t1, t2);
                filterEst(task, t1, t2, avail);
            } else if (doReversePasses && !doReverseTasks) {
                avail += task.computeRightShift(t1, t2);
                filterLct(task, t1, t2, avail);
            } else {
                avail += tasks[i].computeRightShift(t1, t2);
                filterLct(task, t1, t2, avail);
            }
        } else {
            throw new NotImplementedError();
        }

        if (estPrime[i] + task.getP() > lctPrime[i]) {
            fail = true;
        }
    }

    public void filterEst(Task task, int t1, int t2, int avail) {
        int i = task.getId();
        int leftShift = task.computeLeftShift(t1, t2);
        if (leftShift > avail) {
            int newEst = (int) Math.ceil(t2 - (avail * 1.0) / task.getH());
            estPrime[i] = Math.max(estPrime[i], newEst);
        }
    }

    public void filterLct(Task task, int t1, int t2, int avail) {
        int i = task.getId();
        int rightShift = task.computeRightShift(t1, t2);
        if (rightShift > avail) {
            int newLct = (int) Math.floor(t1 + (avail * 1.0) / task.getH());
            lctPrime[i] = Math.min(lctPrime[i], newLct);
        }
    }
}
