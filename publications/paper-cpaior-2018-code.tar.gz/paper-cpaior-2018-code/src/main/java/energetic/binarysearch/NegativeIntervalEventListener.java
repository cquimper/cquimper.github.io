package energetic.binarysearch;

import constraints.cumulative.Task;

public interface NegativeIntervalEventListener {
    void fail(Task task, int t1, int t2, int slack);
}
