package energetic.binarysearch.strategies;

import energetic.binarysearch.SlackDatastructure;
import energetic.binarysearch.InconsistentException;
import energetic.binarysearch.NegativeIntervalEventListener;
import constraints.cumulative.Task;

public class FourPassesComputeSlackStrategy extends FilteringComputeSlackStrategy {
    public FourPassesComputeSlackStrategy(NegativeIntervalEventListener listener, boolean useLeftShift) {
        super(listener, useLeftShift);
    }

    public int computeSlack(SlackDatastructure datastructure, int t1, int t2) throws InconsistentException {
        int slack = datastructure.querySlack(t1, t2);

        slack += taskToFilter.computeMinimumIntersection(t1, t2);
        slack -= useLeftShift ? taskToFilter.computeLeftShift(t1, t2) : taskToFilter.computeRightShift(t1, t2);

        if (slack < 0 && t2 > t1) {
            listener.fail(taskToFilter, t1, t2, slack);
        }

        return slack;
    }
}
