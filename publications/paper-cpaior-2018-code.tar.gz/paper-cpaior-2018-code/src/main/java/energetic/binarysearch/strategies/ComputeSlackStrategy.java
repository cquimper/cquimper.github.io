package energetic.binarysearch.strategies;

import energetic.binarysearch.SlackDatastructure;
import energetic.binarysearch.InconsistentException;

public interface ComputeSlackStrategy {
    int computeSlack(SlackDatastructure datastructure, int t1, int t2) throws InconsistentException;
}
