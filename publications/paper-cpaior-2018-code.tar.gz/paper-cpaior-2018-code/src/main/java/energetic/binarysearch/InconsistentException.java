package energetic.binarysearch;

public class InconsistentException extends Exception {
}
