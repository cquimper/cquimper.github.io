package energetic.binarysearch;


import constraints.cumulative.Task;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

@SuppressWarnings("Duplicates")
public class BruteMatrix {
    private Task[] tasks;
    private int C;
    private int n;
    private int[] setO1;
    private Pair[] setO2;
    public static HashMap<Integer, Integer> histogram = new HashMap();

    public BruteMatrix(Task[] tasks, int C) {
        this.tasks = tasks;
        this.C = C;
        this.n = tasks.length;

        makeSets();
    }

    public int querySlack(int t1, int t2) {
        int available = (t2 - t1) * C;

        return available - queryConsumed(t1, t2);
    }

    public void printMatrix() {
        System.out.printf("%-5s|", "j ");
        for (int i = 0; i < setO2.length; i++) {
            System.out.printf("%-5s", i);
        }
        System.out.println();

        System.out.printf("%-5s|", "t1");
        for (Pair pair : setO2) {
            System.out.printf("%-5s", pair.t1);
        }
        System.out.println();

        System.out.printf("%-5s|", "");
        for (Pair pair : setO2) {
            System.out.printf("%-5d", pair.t);
        }
        System.out.println();

        System.out.print("-----");
        for (Pair pair : setO2) {
            System.out.print("-----");
        }
        System.out.println();


        for (int i = 0; i < setO1.length; i++) {
            int t1 = setO1[i];
            if (i > 0 && t1 == setO1[i-1]) {
                continue;
            }
            printRow(t1);
        }
    }

    public boolean isOtFailIfAllO2Pass() {
        boolean fail = false;
        for (int t1 : setO1) {
            for (Pair pair : setO2) {
                if (t1 >= pair.t)
                    continue;
                int slack = querySlack(t1, pair.t);
                if (slack < 0 && pair.t1 == -1) {
                    return false;
                } else if (slack < 0) {
                    fail = true;
                }
            }
        }
        return fail;
    }

    public void printRow(int t1) {
        System.out.printf("%-5d|", t1);
        for (Pair pair : setO2) {
            int t2 = pair.t;
            if (t1 >= t2) {
                System.out.printf("%-5s", "N");
            } else {
                System.out.printf("%-5d", querySlack(t1, t2), pair.set);
            }
        }
        System.out.println();
    }

    public boolean isMonge() {
        for (int i = 0; i < setO1.length; i++) {
            for (int j = 0; j < setO2.length; j++) {
                for (int k = i + 1; k < setO1.length; k++) {
                    for (int l = j + 1; l < setO2.length; l++) {
                        int left = querySlack(setO1[i], setO2[j].t) + querySlack(setO1[k], setO2[l].t);
                        int right = querySlack(setO1[i], setO2[l].t) + querySlack(setO1[k], setO2[j].t);
                        if (left > right) {
                            System.out.printf("Problem: i:%d, j:%d, k: %d, l: %d}\n", i, j, k, l);
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }

    public boolean checkConsistency() {


        for (int t1 : setO1) {
            Pair prev = new Pair(0, -2, "");
            ArrayList<Integer> list = new ArrayList<>();
            for (Pair pair : setO2) {
                if (pair.t1 == t1 && !list.contains(pair.t) && pair.t > t1) {
                    boolean isO2= false;
                    for (Pair elem : setO2) {
                        if (elem.t == pair.t && elem.t1 == -1) {
                            isO2 = true;
                        }
                    }

                    if (!isO2)
                        list.add(pair.t);
                    //if (prev.t > t1 && pair.t > t1 && querySlack(t1, prev.t) < querySlack(t1, pair.t)) {
                      //  System.out.printf("t1: %d, t2: %d, t2: %d\n", t1, prev.t, pair.t);
                        //return false;
                    //}
                    //prev = pair;
                } else if (pair.t1 == -1) {
                    if (!histogram.containsKey(list.size())) {
                        histogram.put(list.size(), 0);
                    }
                    histogram.put(list.size(), 1 + histogram.get(list.size()));

                    for (int i = 0; i < list.size() - 2; i++) {
                        int x1 = list.get(i);
                        int x2 = list.get(i+1);
                        int x3 = list.get(i+2);
                        int y1 = querySlack(t1, x1);
                        int y2 = querySlack(t1, x2);
                        int y3 = querySlack(t1, x3);

                        int s1 = (y2 - y1) / (x2 - x1);
                        int s2 = (y3 - y2) / (x3 - x2);

                        if (s1 < s2) {
                            System.out.printf("t1: %d, t2: %d, t2: %d, t2: %d\n", t1, x1, x2, x3);
                            return false;
                        }
                        //(37, 0) (35, 2),(27, 10)

                    }


                    list.clear();
                }
            }
        }
        return true;
    }

    public boolean isConsistent() {
        for (int t1 : setO1) {
            for (Pair pair : setO2) {
                if (pair.t > t1 && querySlack(t1, pair.t) < 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public int countFail() {
        int count = 0;
        for (int t1 : setO1) {
            for (Pair pair : setO2) {
                if (pair.t > t1 && querySlack(t1, pair.t) < 0) {
                    count++;
                }
            }
        }
        return count;
    }

    private int queryConsumed(int t1, int t2) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += minimumIntersection(i, t1, t2);
        }

        return sum;
    }

    private int minimumIntersection(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0, min(
                t2 - t1,
                task.getP(),
                task.getEct() - t1,
                t2 - task.getLst())
        );
    }

    private int min(int... elems) {
        assert elems.length > 1;

        int min = Integer.MAX_VALUE;
        for (int elem : elems) {
            min = Math.min(min, elem);
        }

        return min;
    }

    private void makeSets() {
        setO1 = new int[n * 3];
        setO2 = new Pair[n * 3 + 3 * n * n];

        for (int i = 0; i < n; i++) {
            Task task = tasks[i];
            int position = i * 3;
            setO1[position] = task.getEst();
            setO1[position+1] = task.getLst();
            setO1[position+2] = task.getEct();

            setO2[position] = new Pair(task.getLst(), -1, Pair.O2);
            setO2[position+1] = new Pair(task.getEct(), -1, Pair.O2);
            setO2[position+2] = new Pair(task.getLct(), -1, Pair.O2);
        }

        int k = n * 3;
        for (int t : setO1) {
            for (int i = 0; i < n; i++) {
                Task task = tasks[i];
                setO2[k] = new Pair(task.getEst() + task.getLct() - t, t, Pair.OT);
                k++;
            }
        }

        assert k == n * 3 + 3 * n * n;

        Arrays.sort(setO1);
        Arrays.sort(setO2, (Pair p1, Pair p2) -> -1000 * (p1.t - p2.t) + (p1.t1 - p2.t1));

        int size = 0;
        for (int i = 0; i < setO2.length; i++) {
            if (i == 0 || setO2[i].t != setO2[i-1].t || setO2[i].t1 != setO2[i-1].t1) {
                size++;
            }
        }

        k = 0;
        Pair[] temp = new Pair[size];
        for (int i = 0; i < setO2.length; i++) {
            if (i == 0 || setO2[i].t != setO2[i-1].t || setO2[i].t1 != setO2[i-1].t1) {
                temp[k++] = setO2[i];
            }
        }

        setO2 = temp;

        for (int i = 0; i < n-1; i++)
            assert(setO1[i] <= setO1[i+1] );
    }

    private static class Pair {
        public int t;
        public int t1;
        public String set;
        public static final String O2 = "O2";
        public static final String OT = "OT";

        public Pair(int t, int t1, String set) {
            this.t = t;
            this.t1 = t1;
            this.set = set;
        }
    }
}
