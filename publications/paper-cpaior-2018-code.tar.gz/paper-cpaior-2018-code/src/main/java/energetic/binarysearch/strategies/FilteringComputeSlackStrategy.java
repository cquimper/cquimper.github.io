package energetic.binarysearch.strategies;

import energetic.binarysearch.SlackDatastructure;
import energetic.binarysearch.InconsistentException;
import energetic.binarysearch.NegativeIntervalEventListener;
import constraints.cumulative.Task;

public abstract class FilteringComputeSlackStrategy implements ComputeSlackStrategy {
    protected NegativeIntervalEventListener listener;
    protected Task taskToFilter;
    protected boolean useLeftShift;

    public FilteringComputeSlackStrategy(NegativeIntervalEventListener listener, boolean useLeftShift) {
        this.listener = listener;
        this.useLeftShift = useLeftShift;
    }

    public void setTaskToFilter(Task task) {
        this.taskToFilter = task;
    }

    public void setUseLeftShift(boolean useLeftShift) {
        this.useLeftShift = useLeftShift;
    }

    public abstract int computeSlack(SlackDatastructure datastructure, int t1, int t2) throws InconsistentException;
}
