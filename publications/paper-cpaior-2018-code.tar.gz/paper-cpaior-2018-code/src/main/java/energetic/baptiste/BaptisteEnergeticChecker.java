package energetic.baptiste;

import constraints.cumulative.Task;
import benchmarking.cumulative.CumulativeArguments;
import energetic.FilteringAlgorithm;
import energetic.FilteredBounds;

import java.util.Arrays;
import java.util.HashSet;

@SuppressWarnings("Duplicates")
public class BaptisteEnergeticChecker implements FilteringAlgorithm {
    private Instance normalInstance;
    private int n;
    private int C;
    private boolean useDerrienCaracterisation;
    private Task[] tasks;


    public BaptisteEnergeticChecker(Task[] tasks, int C, CumulativeArguments args) {
        this.useDerrienCaracterisation = args.useDerrienCaracterisation;
        this.C = C;
        this.tasks = tasks;
        n = tasks.length;

        normalInstance = new Instance(tasks);
    }

    public BaptisteEnergeticChecker(Task[] tasks, int C) {
        this(tasks, C, new CumulativeArguments());
    }

    public BaptisteEnergeticChecker(Task[] tasks) {
        this(tasks, 1);
    }

    @Override
    public void update() {
        normalInstance = new Instance(tasks);
    }

    public boolean isConsistent() {
        return normalInstance.isConsistent();
    }

    @Override
    public FilteredBounds filter() {
        return normalInstance.filter();
    }

    private class Instance {
        private Task[] tasks;
        private Task[] tasksByLct;
        private Task[] tasksByEct;
        private Task[] tasksByLst;
        private Task[] tasksMiddle;
        private int[] setO1;
        private int[] estPrime;
        private int[] lctPrime;

        public Instance(Task[] tasks) {
            int n = tasks.length;

            this.tasks = tasks;
            this.tasksByLct = Arrays.copyOf(tasks, n);
            this.tasksByEct = Arrays.copyOf(tasks, n);
            this.tasksByLst = Arrays.copyOf(tasks, n);
            this.tasksMiddle = Arrays.copyOf(tasks, n);

            Arrays.sort(tasksByLct, (Task t1, Task t2) -> t1.getLct() - t2.getLct());
            Arrays.sort(tasksByEct, (Task t1, Task t2) -> t1.getEct() - t2.getEct());
            Arrays.sort(tasksByLst, (Task t1, Task t2) -> t1.getLst() - t2.getLst());
            Arrays.sort(tasksMiddle, (Task t1, Task t2) -> t1.getEst() + t1.getLct() - t2.getEst() - t2.getLct());
            makeSets();
        }

        public boolean isConsistent() {
            assert setO1 != null;
            int n = tasksByLct.length;
            int[][] markers = new int[n][];
            for (int i = 0; i < n; i++) {
                markers[i] = new int[4];
            }

            for (int t1 : setO1) {
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < 4; j++) {
                        markers[i][j] = -1;
                    }
                }

                int iLct = 0;
                int iEct = 0;
                int iLst = 0;
                int iMiddle = 0;
                int W = 0;
                int t2Old = t1;
                int slope = computeSlope(t1);

                while (iLct < n || iEct < n || iLst < n || iMiddle < n) {
                    int t2Lct = Integer.MAX_VALUE;
                    int t2Ect = Integer.MAX_VALUE;
                    int t2Lst = Integer.MAX_VALUE;
                    int t2Middle = Integer.MAX_VALUE;
                    if (iLct < n) {
                        t2Lct = tasksByLct[iLct].getLct();
                    }
                    if (iEct < n) {
                        t2Ect = tasksByEct[iEct].getEct();
                    }
                    if (iLst < n) {
                        t2Lst = tasksByLst[iLst].getLst();
                    }
                    if (iMiddle < n) {
                        t2Middle = tasksMiddle[iMiddle].getEst() + tasksMiddle[iMiddle].getLct() - t1;
                    }

                    int t2 = min(t2Lct, t2Ect, t2Lst, t2Middle);
                    int j = -1;

                    Task task = null;
                    if (t2 == t2Lct) {
                        task = tasksByLct[iLct++];
                        j = 0;
                    } else if (t2 == t2Ect) {
                        task = tasksByEct[iEct++];
                        j = 1;
                    } else if (t2 == t2Lst) {
                        task = tasksByLst[iLst++];
                        j = 2;
                    } else if (t2 == t2Middle) {
                        task = tasksMiddle[iMiddle++];
                        j = 3;
                    } else {
                        assert false;
                    }

                    int i = task.getId();
                    if (t1 < t2 && t2 != markers[i][0] && t2 != markers[i][1] && t2 != markers[i][2] && t2 != markers[i][3]) {
                        markers[i][j] = t2;
                        W += slope * (t2 - t2Old);
                        if (C * (t2 - t1) - W < 0)
                            return false;
                        t2Old = t2;
                        slope += minimumIntersection(task, t1, t2+1)
                            - 2 * minimumIntersection(task, t1, t2)
                            + minimumIntersection(task, t1, t2 - 1);
                    }
                }
            }

            return true;
        }

        public FilteredBounds filter() {
            return filterWithDerrien();
            //return filterWithBaptiste();
        }

        private FilteredBounds filterWithBaptiste() {
            estPrime = new int[n];
            lctPrime = new int[n];

            for (int i = 0; i < n; i++) {
                estPrime[i] = tasks[i].getEst();
                lctPrime[i] = tasks[i].getLct();
            }

            int size = 3 * n;
            int[] setO2 = new int[size];

            for (int i = 0; i < n; i++) {
                Task task = tasks[i];
                int position = i * 3;
                setO2[position] = task.getEct();
                setO2[position+1] = task.getLst();
                setO2[position+2] = task.getLct();
            }

            for (int t1 : setO1) {
                for (int t2 : setO2) {
                    if (!filterForInterval(t1, t2)) {
                        return null;
                    }
                }
                for (int i = 0; i < n; i++) {
                    int t2 = tasks[i].getEst() + tasks[i].getLct() - t1;
                    if (!filterForInterval(t1, t2)) {
                        return null;
                    }
                }
            }

            for (int t2 : setO2) {
                for (int i = 0; i < n; i++) {
                    int t1 = tasks[i].getEst() + tasks[i].getLct() - t2;
                    if (!filterForInterval(t1, t2)) {
                        return null;
                    }
                }
            }

            return new FilteredBounds(estPrime, lctPrime);
        }

        public FilteredBounds filterWithDerrien() {
            estPrime = new int[n];
            lctPrime = new int[n];

            for (int i = 0; i < n; i++) {
                estPrime[i] = tasks[i].getEst();
                lctPrime[i] = tasks[i].getLct();
            }
            boolean pass = true;

            // Part one of Derrien's algo (page 67 of his thesis)
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    //Filter for set OC. Page 60 of Derrien's thesis
                    //"Interval d'intérêts de Derrien pour le checker" in manuscript notes
                    // There are few errors in Lemma 4.3 in Derrien's thesis, so it is better to use manuscript notes

                    Task it = tasks[i];
                    Task jt = tasks[j];

                    int t1 = it.getEst();
                    int t2 = jt.getLct();
                    if (t1 <= jt.getEst() && t2 >= it.getLct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t2 = jt.getLct();
                    t1 = it.getEst() + it.getLct() - t2;
                    if (t1 <= jt.getEst() && t2 < it.getLct() && t2 > it.getLst() && t2 > it.getEct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t1 = it.getLst();
                    t2 = jt.getLct();
                    if (t1 <= jt.getEst() && t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t1 = it.getEst();
                    t2 = jt.getEst() + jt.getLct() - t1;
                    if (t1 > jt.getEst() && t1 < jt.getEct() && t1 < jt.getLst() && t2 > it.getLct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t1 = it.getLst();
                    t2 = jt.getEst() + jt.getLct() - t1;
                    if (t1 > jt.getEst() && t1 < jt.getEct() && t1 < jt.getLst() && t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t1 = it.getEst();
                    t2 = jt.getLct();
                    if (t1 > jt.getEst() && t1 < jt.getEct() && t1 >= jt.getLst() && t2 >= it.getLct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t2 = jt.getEct();
                    t1 = it.getEst() + it.getLct() - t2;
                    if (t1 > jt.getEst() && t1 < jt.getEct() && t1 >= jt.getLst() && t2 < it.getLct() && t2 > it.getLst() && t2 > it.getEct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    t1 = it.getLst();
                    t2 = jt.getEct();
                    if (t1 > jt.getEst() && t1 < jt.getEct() && t1 >= jt.getLst() && t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct()) {
                        pass &= filterForInterval(t1, t2);
                    }

                    if (!pass) {
                        return null;
                    }
                }
            }

            // Part two of Derrien's algo
            int t1;
            int t2;
            for (int a = 0; a < n; a++) {
                Task at = tasks[a];

                // L_3
                filterForTaskAndInterval(at, at.getEst(), at.getEct());
                // R_3
                filterForTaskAndInterval(at, at.getLst(), at.getLct());
                for (int i = 0; i < n; i++) {
                    Task it = tasks[i];

                    //L_1
                    t1 = it.getEst();
                    t2 = at.getEct();
                    if (t2 > it.getLct() && t1 < at.getEct()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t2 = at.getEct();
                    t1 = it.getEst() + it.getLct() - t2;
                    if (t2 < it.getLct() && t2 > it.getLst() && t2 > it.getEct() && t1 < at.getEct()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t1 = it.getLst();
                    t2 = at.getEct();
                    if (t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct() && t1 < at.getEct()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    // L_2
                    t1 = at.getEst();
                    t2 = it.getLct();
                    if (t2 > at.getEst() && t1 <= it.getEst()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t1 = at.getEst();
                    t2 = it.getEst() + it.getLct() - t1;
                    if (t2 > at.getEst() && t1 > it.getEst() && t1 < it.getEct() && t1 < it.getLst()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t1 = at.getEst();
                    t2 = it.getEct();
                    if (t2 > at.getEst() && t1 > it.getEst() && t1 < it.getEct() && t1 >= it.getLst()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    // R_1
                    t1 = it.getEst();
                    t2 = at.getLct();
                    if (t2 >= it.getLct() && t1 < at.getLct()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t2 = at.getLct();
                    t1 = it.getEst() + it.getLct() - t2;
                    if (t2 < it.getLct() && t2 > it.getLst() && t2 > it.getEct() && t1 < at.getLct()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t1 = it.getLst();
                    t2 = at.getLct();
                    if (t2 < it.getLct() && t2 > it.getLst() && t2 <= it.getEct() && t1 < at.getLct()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    // R_2
                    t1 = at.getLst();
                    t2 = it.getLct();
                    if (t2 > at.getLst() && t1 <= it.getEst()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t1 = at.getLst();
                    t2 = it.getEst() + it.getLct() - t1;
                    if (t2 > at.getLst() && t1 > it.getEst() && t1 < it.getEct() && t1 < it.getLst()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    t1 = at.getLst();
                    t2 = it.getEct();
                    if (t2 > at.getLst() && t1 > it.getEst() && t1 < it.getEct() && t1 >= it.getLst()) {
                        pass &= filterForTaskAndInterval(at, t1, t2);
                    }

                    if (!pass) {
                        return null;
                    }
                }
            }

            return new FilteredBounds(estPrime, lctPrime);
        }

        private boolean filterForInterval(int t1, int t2) {
            if (t2 <= t1)
                return true;

            int W = 0;
            for (int i = 0; i < n; i++) {
                W += tasks[i].computeMinimumIntersection(t1, t2);
            }

            if (W > C * (t2 - t1)) {
                return false;
            }

            for (int i = 0; i < n; i++) {
                int slack = C * (t2 - t1) - W + tasks[i].computeMinimumIntersection(t1, t2);
                int leftShift = tasks[i].computeLeftShift(t1, t2);
                int rightShift = tasks[i].computeRightShift(t1, t2);
                if (slack < leftShift) {
                    int adjustment = (int) Math.ceil(t2 - 1.0 * slack / tasks[i].getH());
                    estPrime[i] = Math.max(estPrime[i], adjustment);
                }

                if (slack < rightShift) {
                    int adjustment = (int) (t1 + 1.0 * slack / tasks[i].getH());
                    lctPrime[i] = Math.min(lctPrime[i], adjustment);
                }

                if (estPrime[i] + tasks[i].getP() > lctPrime[i]) {
                    return false;
                }
            }

            return true;
        }

        private boolean filterForTaskAndInterval(Task task, int t1, int t2) {
            if (t2 <= t1)
                return true;

            int W = 0;
            for (int i = 0; i < n; i++) {
                W += tasks[i].computeMinimumIntersection(t1, t2);
            }

            if (W > C * (t2 - t1)) {
                return false;
            }

            int i = task.getId();
            int slack = C * (t2 - t1) - W + task.computeMinimumIntersection(t1, t2);
            int leftShift = task.computeLeftShift(t1, t2);
            int rightShift = task.computeRightShift(t1, t2);
            if (slack < leftShift) {
                int adjustment = (int) Math.ceil(t2 - 1.0 * slack / task.getH());
                estPrime[i] = Math.max(estPrime[i], adjustment);
            }

            if (slack < rightShift) {
                int adjustment = (int) (t1 + 1.0 * slack / task.getH());
                lctPrime[i] = Math.min(lctPrime[i], adjustment);
            }

            if (estPrime[i] + task.getP() > lctPrime[i]) {
                return false;
            }

            return true;
        }

        private int min(int... elems) {
            assert elems.length > 1;

            int min = Integer.MAX_VALUE;
            for (int elem : elems) {
                if (elem < min) {
                    min = elem;
                }
            }

            return min;
        }

        private int computeSlope(int t1) {
            int slope = 0;
            for (int j = 0; j < n; j++) {
                slope += minimumIntersection(tasksByEct[j], t1, t1+1);
            }
            return slope;
        }

        private int minimumIntersection(Task task, int t1, int t2) {
            return task.getH() * Math.max(0, min(
                    t2 - t1,
                    task.getP(),
                    task.getEct() - t1,
                    t2 - task.getLst())
            );
        }

        private void makeSets() {
            int size = useDerrienCaracterisation ? 2 : 3;
            setO1 = new int[n * size];

            for (int i = 0; i < n; i++) {
                Task task = tasksByEct[i];
                int position = i * size;
                setO1[position] = task.getEst();
                setO1[position+1] = task.getLst();
                if (!useDerrienCaracterisation) {
                    setO1[position+2] = task.getEct();
                }
            }

            Arrays.sort(setO1);

            for (int i = 0; i < n*size-1; i++)
                assert(setO1[i] <= setO1[i+1]);
        }
    }
}
