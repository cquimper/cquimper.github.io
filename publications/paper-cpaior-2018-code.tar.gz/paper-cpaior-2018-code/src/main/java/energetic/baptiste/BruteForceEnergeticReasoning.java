package energetic.baptiste;

import java.util.Arrays;
import constraints.cumulative.Task;
import energetic.FilteredBounds;
import energetic.FilteringAlgorithm;

@SuppressWarnings("Duplicates")
public class BruteForceEnergeticReasoning implements FilteringAlgorithm {
    private Task[] tasks;
    private int n;
    private int C;
    private Pair[] setO1;
    private Pair[] setO2;

    public BruteForceEnergeticReasoning(Task[] tasks, int C) {
        this.tasks = tasks;
        this.C = C;
        n = tasks.length;
    }

    public BruteForceEnergeticReasoning(Task[] tasks) {
        this(tasks, 1);
    }

    @Override
    public void update() {
    }

    public boolean isConsistent() {
        boolean consistent = true;
        int maxLct = 0;
        for (int i = 0; i < n; i++) {
            if (tasks[i].getLct() > maxLct)
                maxLct = tasks[i].getLct();
        }

        for (int t1 = 0; t1 < maxLct; t1++) {
            for (int t2 = t1 + 1; t2 < maxLct; t2++) {
                int MI = 0;
                for (int i = 0; i < n; i++) {
                    MI += minimumIntersection(i, t1, t2);
                }
                if (MI > C * (t2 - t1)) {
                    consistent = false;
                    System.out.printf("(%d,%d)\n", t1, t2);
                }
            }
        }

        return consistent;
    }

    @Override
    public FilteredBounds filter() {
        int[] estPrimes = new int[tasks.length];
        int[] lctPrimes = new int[tasks.length];
        boolean consistent = true;
        boolean changed = true;

        int maxLct = 0;
        for (int i = 0; i < n; i++) {
            estPrimes[i] = tasks[i].getEst();
            lctPrimes[i] = tasks[i].getLct();
            if (tasks[i].getLct() > maxLct)
                maxLct = tasks[i].getLct();
        }

        for (int t1 = 0; t1 <= maxLct; t1++) {
            for (int t2 = t1 + 1; t2 <= maxLct; t2++) {
                int MI = 0;
                for (int i = 0; i < n; i++) {
                    MI += minimumIntersection(i, t1, t2);
                }
                if (MI > C * (t2 - t1)) {
                    return null;
                }

                for (int i = 0; i < n; i++) {
                    Task iTask = tasks[i];
                    int pi = iTask.getP();
                    int hi = iTask.getH();
                    int slack = C * (t2 - t1) - MI + minimumIntersection(i, t1, t2);
                    int leftShift = leftShift(i, t1, t2);
                    int rightShift = rightShift(i, t1, t2);

                    if (slack < leftShift) {
                        double adjustment = 1.0 * slack / hi;
                        int ectPrime = (int) Math.ceil(t2 - adjustment);
                        estPrimes[i] = Math.max(estPrimes[i], ectPrime);

                        //System.out.printf("Task %d filtered to %d on interval [%d, %d)\n", i+1, estPrime, t1, t2);
                    }

                    if (slack < rightShift) {
                        double adjustment = 1.0 * slack / hi;
                        int lctPrime= (int) (t1 + adjustment);
                        lctPrimes[i] = Math.min(lctPrimes[i], lctPrime);
                    }
                }
            }
        }

        return new FilteredBounds(estPrimes, lctPrimes);
    }

    private int minimumIntersection(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0, min(
                t2 - t1,
                task.getP(),
                task.getEct() - t1,
                t2 - task.getLst())
        );
    }

    private int leftShift(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0,
                Math.min(task.getEct(),t2) - Math.max(t1, task.getEst())
        );
    }

    private int rightShift(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0,
                Math.min(t2,task.getLct()) - Math.max(t1, task.getLst())
        );
    }

    private Pair[] makeSetT(int t) {
        Pair[] set = new Pair[n];

        for (int i = 0; i < n; i++) {
            Task task = tasks[i];
            set[i] = new Pair(i, task.getEst() + task.getLct() - t);
        }

        return set;
    }

    private Pair[] mergeAndSort(Pair[] first, Pair[] second) {
        Pair[] result = new Pair[first.length + second.length];

        int k = 0;
        for (Pair elem: first) {
            result[k++] = elem;
        }
        for (Pair elem: second) {
            result[k++] = elem;
        }

        for (int i = 0; i < result.length; i++) {
            assert result[i] != null;
        }

        Arrays.sort(result, (Pair p1, Pair p2)-> p1.timepoint - p2.timepoint);
        for (int i = 0; i < result.length - 1; i++) {
            assert result[i].timepoint <= result[i+1].timepoint;
        }

        return result;
    }

    private int min(int... elems) {
        assert elems.length > 1;

        int min = Integer.MAX_VALUE;
        for (int elem : elems) {
            min = Math.min(min, elem);
        }

        return min;
    }

    private class Pair {
        public int index;
        public int timepoint;

        public Pair(int index, int timepoint) {
            this.index = index;
            this.timepoint = timepoint;
        }
    }
}
