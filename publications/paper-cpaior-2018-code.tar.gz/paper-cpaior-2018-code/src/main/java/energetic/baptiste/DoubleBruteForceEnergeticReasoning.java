package energetic.baptiste;
import java.util.Arrays;
import constraints.cumulative.Task;
import energetic.FilteredBounds;
import energetic.FilteringAlgorithm;

@SuppressWarnings("Duplicates")
public class DoubleBruteForceEnergeticReasoning implements FilteringAlgorithm {
    private Task[] tasks;
    private int n;
    private int C;
    private Pair[] setO1;
    private Pair[] setO2;

    public DoubleBruteForceEnergeticReasoning(Task[] tasks, int C) {
        this.tasks = tasks;
        this.C = C;
        n = tasks.length;
    }

    public DoubleBruteForceEnergeticReasoning(Task[] tasks) {
        this(tasks, 1);
    }

    public boolean isConsistent() {
        boolean consistent = true;
        int maxLct = 0;
        for (int i = 0; i < n; i++) {
            if (tasks[i].getLct() > maxLct)
                maxLct = tasks[i].getLct();
        }

        for (int t1 = 0; t1 < maxLct; t1++) {
            for (int t2 = t1 + 1; t2 < maxLct; t2++) {
                int MI = 0;
                for (int i = 0; i < n; i++) {
                    MI += minimumIntersection(i, t1, t2);
                }
                if (MI > C * (t2 - t1)) {
                    consistent = false;
                    System.out.printf("(%d,%d)\n", t1, t2);
                }
            }
        }

        return consistent;
    }

    @Override
    public void update() {
    }

    public FilteredBounds filter() {
        int[] estPrimes = new int[tasks.length];
        int[] lctPrimes = new int[tasks.length];
        boolean consistent = true;
        boolean changed = true;

        int maxLct = 0;
        for (int i = 0; i < n; i++) {
            estPrimes[i] = tasks[i].getEst();
            lctPrimes[i] = tasks[i].getLct();
            if (tasks[i].getLct() > maxLct)
                maxLct = tasks[i].getLct();
        }

        for (int t1 = 0; t1 <= maxLct; t1++) {
            for (int t2 = t1 + 1; t2 <= maxLct; t2++) {
                int MI = 0;
                for (int i = 0; i < n; i++) {
                    MI += minimumIntersection(i, t1, t2);
                }

                if (MI > C * (t2 - t1)) {
                    return null;
                }

                for (int i = 0; i < n; i++) {
                    Task iTask = tasks[i];
                    int slack = C * (t2 - t1) - MI + minimumIntersection(i, t1, t2);

                    if (t2 < iTask.getLct()) {
                        int oldEst = iTask.getEst();
                        boolean detect = true;
                        while (detect) {
                            detect = false;
                            int leftShift = leftShift(i, t1, t2);
                            if (leftShift > slack) {
                                iTask.setEst(iTask.getEst()+1);
                                detect = true;
                                //System.out.printf("t1: %d t2: %d \n", t1, t2);
                            }
                        }
                        estPrimes[i] = Math.max(estPrimes[i], iTask.getEst());
                        iTask.setEst(oldEst);
                    }

                    if (t1 > iTask.getEst()) {
                        int oldLct = iTask.getLct();
                        boolean detect = true;
                        while (detect) {
                            detect = false;
                            int rightShift = rightShift(i, t1, t2);
                            if (rightShift > slack) {
                                iTask.setLct(iTask.getLct() - 1);
                                detect = true;
                                //System.out.printf("t1: %d t2: %d \n", t1, t2);
                            }
                        }
                        lctPrimes[i] = Math.min(lctPrimes[i], iTask.getLct());
                        iTask.setLct(oldLct);
                    }
                }
            }
        }
        return new FilteredBounds(estPrimes, lctPrimes);
    }

    private int minimumIntersection(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0, min(
                t2 - t1,
                task.getP(),
                task.getEct() - t1,
                t2 - task.getLst())
        );
    }

    private int leftShift(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0,
                Math.min(task.getEct(),t2) - Math.max(t1, task.getEst())
        );
    }

    private int rightShift(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0,
                Math.min(t2,task.getLct()) - Math.max(t1, task.getLst())
        );
    }

    private Pair[] makeSetT(int t) {
        Pair[] set = new Pair[n];

        for (int i = 0; i < n; i++) {
            Task task = tasks[i];
            set[i] = new Pair(i, task.getEst() + task.getLct() - t);
        }

        return set;
    }

    private Pair[] mergeAndSort(Pair[] first, Pair[] second) {
        Pair[] result = new Pair[first.length + second.length];

        int k = 0;
        for (Pair elem: first) {
            result[k++] = elem;
        }
        for (Pair elem: second) {
            result[k++] = elem;
        }

        for (int i = 0; i < result.length; i++) {
            assert result[i] != null;
        }

        Arrays.sort(result, (Pair p1, Pair p2)-> p1.timepoint - p2.timepoint);
        for (int i = 0; i < result.length - 1; i++) {
            assert result[i].timepoint <= result[i+1].timepoint;
        }

        return result;
    }

    private int min(int... elems) {
        assert elems.length > 1;

        int min = Integer.MAX_VALUE;
        for (int elem : elems) {
            min = Math.min(min, elem);
        }

        return min;
    }

    private class Pair {
        public int index;
        public int timepoint;

        public Pair(int index, int timepoint) {
            this.index = index;
            this.timepoint = timepoint;
        }
    }
}
