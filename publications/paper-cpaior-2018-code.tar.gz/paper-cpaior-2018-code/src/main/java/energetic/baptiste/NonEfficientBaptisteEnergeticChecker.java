package energetic.baptiste;

import constraints.cumulative.Task;

import java.util.Arrays;
import java.util.HashSet;

@SuppressWarnings("Duplicates")
public class NonEfficientBaptisteEnergeticChecker {
    private Instance normalInstance;
    private int n;
    private int C;


    @Deprecated()
    public NonEfficientBaptisteEnergeticChecker(Task[] tasks, int C, boolean noReverse) {
        this(tasks, C);
    }

    public NonEfficientBaptisteEnergeticChecker(Task[] tasks, int C) {
        this.C = C;
        n = tasks.length;

        normalInstance = new Instance(tasks);
    }

    public NonEfficientBaptisteEnergeticChecker(Task[] tasks) {
        this(tasks, 1);
    }

    public boolean isConsistent() {
        return normalInstance.isConsistent();
    }

    private class Instance {
        private Task[] tasks;
        private Pair[] setO1;
        private Pair[] setO2;

        public Instance(Task[] tasks) {
            this.tasks = tasks;
            makeSets();
        }

        public boolean isConsistent() {
            assert setO1 != null && setO2 != null;

            for (int k = 0; k < setO1.length; k++) {
                Pair pair1 = setO1[k];
                int i = pair1.index;
                int t1 = pair1.timepoint;
                int slope = computeSlope(i, t1);
                int slack = 0;
                int t2old = t1;

                Pair[] setOt = makeSetT(t1);
                Pair[] setO2UnionOt = mergeAndSort(setO2, setOt);

                HashSet<String> marked = new HashSet<>();
                for (Pair pair2 : setO2UnionOt) {
                    int j = pair2.index;
                    int t2 = pair2.timepoint;
                    if (t1 >= t2)
                        continue;
                    assert t2 > t1;

                    String key = Integer.toString(j) + ":" + Integer.toString(t2);
                    if (marked.contains(key)) {
                        continue;
                    }
                    marked.add(key);

                    slack += slope * (t2 - t2old);
                    if (slack > C * (t2 - t1)) {
                        return false;
                    }
                    slope = slope
                            + minimumIntersection(j, t1, t2 -1)
                            - 2 * minimumIntersection(j, t1, t2)
                            + minimumIntersection(j, t1, t2 + 1);
                    t2old = t2;
                }
            }
            return true;
        }

        private Pair[] mergeAndSort(Pair[] first, Pair[] second) {
            Pair[] result = new Pair[first.length + second.length];

            int k = 0;
            for (Pair elem: first) {
                result[k++] = elem;
            }
            for (Pair elem: second) {
                result[k++] = elem;
            }

            for (int i = 0; i < result.length; i++) {
                assert result[i] != null;
            }

            Arrays.sort(result, (Pair p1, Pair p2)-> p1.timepoint - p2.timepoint);
            for (int i = 0; i < result.length - 1; i++) {
                assert result[i].timepoint <= result[i+1].timepoint;
            }

            return result;
        }

        private int min(int... elems) {
            assert elems.length > 1;

            int min = Integer.MAX_VALUE;
            for (int elem : elems) {
                min = Math.min(min, elem);
            }

            return min;
        }

        private int computeSlope(int i, int t1) {
            int slope = 0;
            for (int j = 0; j < n; j++) {
                slope += minimumIntersection(j, t1, t1+1);
            }
            return slope;
        }

        private int minimumIntersection(int i, int t1, int t2) {
            Task task = tasks[i];
            return task.getH() * Math.max(0, min(
                    t2 - t1,
                    task.getP(),
                    task.getEct() - t1,
                    t2 - task.getLst())
            );
        }

        private void makeSets() {
            setO1 = new Pair[n * 3];
            setO2 = new Pair[n * 3];

            for (int i = 0; i < n; i++) {
                Task task = tasks[i];
                int position = i * 3;
                setO1[position] = new Pair(i, task.getEst());
                setO1[position+1] = new Pair(i, task.getLst());
                setO1[position+2] = new Pair(i, task.getEct());

                setO2[position] = new Pair(i, task.getLst());
                setO2[position+1] = new Pair(i, task.getEct());
                setO2[position+2] = new Pair(i, task.getLct());
            }

            Arrays.sort(setO1, (Pair p1, Pair p2)-> p1.timepoint - p2.timepoint);

            for (int i = 0; i < n-1; i++)
                assert(setO1[i].timepoint <= setO1[i+1].timepoint);
        }

        private Pair[] makeSetT(int t) {
            Pair[] set = new Pair[n];

            for (int i = 0; i < n; i++) {
                Task task = tasks[i];
                set[i] = new Pair(i, task.getEst() + task.getLct() - t);
            }

            return set;
        }
    }

    private class Pair {
        public int index;
        public int timepoint;

        public Pair(int index, int timepoint) {
            this.index = index;
            this.timepoint = timepoint;
        }
    }
}
