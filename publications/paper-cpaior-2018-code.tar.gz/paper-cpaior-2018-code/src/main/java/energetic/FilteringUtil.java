package energetic;

import constraints.cumulative.Task;

@SuppressWarnings("Duplicates")
public class FilteringUtil {
    public static FilteredBounds
        filterAndCompareUntilFixpoint(FilteringAlgorithm a,
                                      FilteringAlgorithm b,
                                      Task[] tasks) throws NonMatchingBoundsExeception {
        int n = tasks.length;
        int[] oldEst = new int[n];
        int[] oldLct = new int[n];
        FilteredBounds aBounds = null;
        FilteredBounds bBounds = null;

        for (int i = 0; i < n; i++) {
            oldEst[i] = tasks[i].getEst();
            oldLct[i] = tasks[i].getLct();
        }

        boolean changed = true;
        while (changed) {
            changed = false;
            aBounds = a.filter();
            bBounds = b.filter();

            if (bBounds != null && (aBounds == null)) {
                throw new NonMatchingBoundsExeception();
            }

            if (bBounds == null) {
                return null;
            }

            for (int i = 0; i < n; i++) {
                if (aBounds.est[i] > bBounds.est[i] || aBounds.lct[i] < bBounds.lct[i]) {
                    throw new NonMatchingBoundsExeception();
                }
            }

            //assert aBounds == bBounds || aBounds.equals(bBounds);
            if (aBounds == null || aBounds.est == null || aBounds.lct == null) {
                for (int i = 0; i < n; i++) {
                    tasks[i].setEst(oldEst[i]);
                    tasks[i].setLct(oldLct[i]);
                }
                return null;
            }


            for (int i = 0; i < n; i++) {
                if (aBounds.est[i] != tasks[i].getEst()) {
                    assert aBounds.est[i] > tasks[i].getEst();
                    tasks[i].setEst(aBounds.est[i]);
                    changed = true;
                }
                if (aBounds.lct[i] != tasks[i].getLct()) {
                    assert aBounds.lct[i] < tasks[i].getLct();
                    tasks[i].setLct(aBounds.lct[i]);
                    changed = true;
                }
            }
            a.update();
            b.update();
        }

        for (int i = 0; i < n; i++) {
            tasks[i].setEst(oldEst[i]);
            tasks[i].setLct(oldLct[i]);
        }

        //assert aBounds != null;
        //assert aBounds.equals(bBounds);

        return aBounds;
    }

    public static FilteredBounds filterUntilFixpoint(FilteringAlgorithm algo,
                                                     Task[] tasks) {
        int n = tasks.length;
        int[] oldEst = new int[n];
        int[] oldLct = new int[n];
        FilteredBounds bounds = null;

        for (int i = 0; i < n; i++) {
            oldEst[i] = tasks[i].getEst();
            oldLct[i] = tasks[i].getLct();
        }

        boolean changed = true;
        while (changed) {
            changed = false;
            bounds = algo.filter();
            if (bounds == null || bounds.est == null || bounds.lct == null) {
                for (int i = 0; i < n; i++) {
                    tasks[i].setEst(oldEst[i]);
                    tasks[i].setLct(oldLct[i]);
                }
                return null;
            }

            for (int i = 0; i < n; i++) {
                if (bounds.est[i] != tasks[i].getEst()) {
                    assert bounds.est[i] > tasks[i].getEst();
                    tasks[i].setEst(bounds.est[i]);
                    changed = true;
                }

                if (bounds.lct[i] != tasks[i].getLct()) {
                    assert bounds.lct[i] < tasks[i].getLct();
                    tasks[i].setLct(bounds.lct[i]);
                    changed = true;
                }
            }
            algo.update();
        }

        for (int i = 0; i < n; i++) {
            tasks[i].setEst(oldEst[i]);
            tasks[i].setLct(oldLct[i]);
        }

        assert bounds != null;
        return bounds;
    }

    public static FilteredBounds filterAndCompareAtFixpoint(FilteringAlgorithm a, FilteringAlgorithm b, Task[] tasks)
            throws NonMatchingBoundsExeception {
        FilteredBounds aBounds = filterUntilFixpoint(a, tasks);
        FilteredBounds bBounds = filterUntilFixpoint(b, tasks);

        if (aBounds == null && bBounds == null) {
            return null;
        }

        if (aBounds == null || bBounds == null || !aBounds.equals(bBounds)) {
            throw new NonMatchingBoundsExeception();
        }

        return aBounds;
    }

    public static class NonMatchingBoundsExeception extends Exception {}
}
