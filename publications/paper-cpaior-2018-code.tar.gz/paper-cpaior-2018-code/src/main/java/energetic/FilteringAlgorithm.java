package energetic;

import constraints.cumulative.Task;

public interface FilteringAlgorithm {
    public void update();
    public FilteredBounds filter();
}
