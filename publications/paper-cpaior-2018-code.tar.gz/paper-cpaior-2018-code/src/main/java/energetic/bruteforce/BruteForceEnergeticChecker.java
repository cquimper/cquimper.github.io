package energetic.bruteforce;

import constraints.cumulative.Task;

import java.util.Arrays;

public class BruteForceEnergeticChecker {
    private Task[] tasks;
    private int n;
    private int C;
    private Pair[] setO1;
    private Pair[] setO2;

    public BruteForceEnergeticChecker(Task[] tasks, int C) {
        this.tasks = tasks;
        this.C = C;
        n = tasks.length;
    }

    public BruteForceEnergeticChecker(Task[] tasks) {
        this(tasks, 1);
    }

    public boolean isConsistent() {
        boolean consistent = true;
        int maxLct = 0;
        for (int i = 0; i < n; i++) {
            if (tasks[i].getLct() > maxLct)
                maxLct = tasks[i].getLct();
        }

        for (int t1 = 0; t1 < maxLct; t1++) {
            for (int t2 = t1 + 1; t2 < maxLct; t2++) {
                int MI = 0;
                for (int i = 0; i < n; i++) {
                    MI += minimumIntersection(i, t1, t2);
                }
                if (MI > C * (t2 - t1)) {
                    consistent = false;
                    System.out.printf("(%d,%d)\n", t1, t2);
                }
            }
        }

        return consistent;
    }

    private int minimumIntersection(int i, int t1, int t2) {
        Task task = tasks[i];
        return task.getH() * Math.max(0, min(
                t2 - t1,
                task.getP(),
                task.getEct() - t1,
                t2 - task.getLst())
        );
    }

    private Pair[] makeSetT(int t) {
        Pair[] set = new Pair[n];

        for (int i = 0; i < n; i++) {
            Task task = tasks[i];
            set[i] = new Pair(i, task.getEst() + task.getLct() - t);
        }

        return set;
    }

    private Pair[] mergeAndSort(Pair[] first, Pair[] second) {
        Pair[] result = new Pair[first.length + second.length];

        int k = 0;
        for (Pair elem: first) {
            result[k++] = elem;
        }
        for (Pair elem: second) {
            result[k++] = elem;
        }

        for (int i = 0; i < result.length; i++) {
            assert result[i] != null;
        }

        Arrays.sort(result, (Pair p1, Pair p2)-> p1.timepoint - p2.timepoint);
        for (int i = 0; i < result.length - 1; i++) {
            assert result[i].timepoint <= result[i+1].timepoint;
        }

        return result;
    }

    private int min(int... elems) {
        assert elems.length > 1;

        int min = Integer.MAX_VALUE;
        for (int elem : elems) {
            min = Math.min(min, elem);
        }

        return min;
    }

    private class Pair {
        public int index;
        public int timepoint;

        public Pair(int index, int timepoint) {
            this.index = index;
            this.timepoint = timepoint;
        }
    }
}
