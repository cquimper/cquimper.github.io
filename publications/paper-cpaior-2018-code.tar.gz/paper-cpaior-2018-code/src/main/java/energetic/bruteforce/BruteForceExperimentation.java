package energetic.bruteforce;

import constraints.cumulative.Task;

public class BruteForceExperimentation {
    private Task[] tasks;
    private int C;
    private int n;

    private int minimumAvail;
    private int minimumAvailT1;
    private int bestBound;
    private int bestBoundT1;

    public BruteForceExperimentation(Task[] tasks, int C) {
        this.tasks = tasks;
        this.C = C;
        this.n = tasks.length;
    }

    public boolean isMaximalPropagationAchieved() {
        for (Task task : tasks) {
            if (!isMaximalPropagationAchievedForTask(task)) {
                return false;
            }
        }
        return true;
    }

    private boolean isMaximalPropagationAchievedForTask(Task task) {
        int[] setO1 = new int[3 * n];
        int[] setO2 = new int[3 * n];
        int[] setOt = new int[n];

        for (int i = 0; i < n; i++) {
            setO1[i * 3] = tasks[i].getEst();
            setO1[i * 3 + 1] = tasks[i].getEct();
            setO1[i * 3 + 2] = tasks[i].getLst();

            setO2[i * 3] = tasks[i].getEct();
            setO2[i * 3 + 1] = tasks[i].getLst();
            setO2[i * 3 + 2] = tasks[i].getLct();

            setOt[i] = tasks[i].getEst() + tasks[i].getEct();
        }

        for (int t2 : setO2) {
            minimumAvail = Integer.MAX_VALUE;
            minimumAvailT1 = -1;
            bestBound = Integer.MAX_VALUE;
            bestBoundT1 = -1;

            for (int t1 : setO1) {
                processInterval(t1, t2, task);
            }

            for (int t : setOt) {
                int t1 = t - t2;
                processInterval(t1, t2, task);
            }

            for (int t1 : setO1) {
                for (int t : setOt) {
                    if (t - t1 == t2) {
                        processInterval(t1, t2, task);
                    }
                }
            }

            if (minimumAvailT1 != bestBoundT1) {
                System.out.println("We have a problem here.");
                return false;
            }
        }

        return true;
    }

    private void processInterval(int t1, int t2, Task task) {
        if (t1 >= t2) {
            return;
        }

        double avail = computeAvail(t1, t2, task) * 1.0;
        int lctBound = (int) Math.ceil(t1 + avail / task.getH());

        if (avail < minimumAvail) {
            minimumAvail = (int) avail;
            minimumAvailT1 = t2;
        }

        if (lctBound < bestBound) {
            bestBound = lctBound;
            bestBoundT1 = t2;
        }
    }

    private int computeAvail(int t1, int t2, Task task) {
        int avail = 0;
        for (int i = 0; i < n; i++) {
            avail += tasks[i].computeMinimumIntersection(t1, t2);
        }
        return C * (t2 - t1) - avail + task.computeMinimumIntersection(t1, t2);
    }

    private class Interval {
        public int t1;
        public int t2;

        public Interval(int t1, int t2) {
            this.t1 = t1;
            this.t2 = t2;
        }
    }
}
