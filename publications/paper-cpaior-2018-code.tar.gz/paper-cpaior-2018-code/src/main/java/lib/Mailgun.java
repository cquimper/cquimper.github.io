package lib;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import in.ashwanthkumar.slack.webhook.Slack;
import in.ashwanthkumar.slack.webhook.SlackMessage;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import javax.ws.rs.core.MediaType;

public class Mailgun {
    private static void sendWithMailgun(String subject, String content) {
    }

    public static void send(String subject, String content) {
        sendWithSlack(content);
    }

    private static void sendWithSlack(String content) {
    }
}
