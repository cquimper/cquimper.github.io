package sorting;

import constraints.cumulative.Task;

public class MemorizedTasksInsertionSort {
    private Task[] arrayToSort;
    private TasksToIntFunctionWithTwoParams comparator;

    public MemorizedTasksInsertionSort(Task[] arrayToSort, TasksToIntFunctionWithTwoParams comparator) {
        this.arrayToSort = arrayToSort;
        this.comparator = comparator;
    }

    public void sort() {
        for (int j = 1; j < arrayToSort.length; j++) {
            Task key = arrayToSort[j];
            int i = j - 1;
            while (i >= 0 &&  comparator.apply(arrayToSort[i], key) > 0) {
                arrayToSort[i+1] = arrayToSort[i];
                i--;
            }
            arrayToSort[i+1] = key;
        }
    }
}
