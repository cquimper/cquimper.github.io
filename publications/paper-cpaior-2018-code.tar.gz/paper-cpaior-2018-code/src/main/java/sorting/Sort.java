package sorting;

public class Sort {
    public static void insertionSort(int[] array) {
        insertionSort(array, 0, array.length);
    }

    public static void quickSort(int[] array) {
        quickSort(array, 0, array.length);
    }

    public static void quickSort(int[] array, int l, int u) {
        if (l >= u) {
            return;
        }

        if (u - l <= 10) {
            insertionSort(array, l, u);
        } else {
            int p = partition(array, l, u);
            quickSort(array, l, p);
            quickSort(array, p+1, u);
        }
    }

    public static int partition(int[] array, int l, int u) {
        int pivot;
        int middle = (l+u) / 2;
        if (max(array[l], array[u-1]) > array[middle] && min(array[l], array[u-1]) < middle) {
            pivot = middle;
        } else if (max(array[u-1], array[middle]) > array[l] && min(array[u-1], array[middle]) < array[l]) {
            pivot = l;
        } else {
            pivot = u-1;
        }

        swap(array, pivot, u-1);
        pivot = u-1;

        int i = l-1;
        for (int j = l; j < u; j++) {
            if (array[j] < array[pivot]) {
                i++;
                swap(array, i, j);
            }
        }
        if (i+1 < u && array[u-1] < array[i+1]) {
            swap(array, i+1, u-1);
        }

        return i+1;
    }

    private static void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private static int min(int a, int b) {
        return a < b ? a : b;
    }

    private static int max(int a, int b) {
        return a > b ? a : b;
    }

    private static void insertionSort(int[] array, int l, int u) {
        for (int j = l+1; j < u; j++) {
            int key = array[j];
            int i = j - 1;
            while (i >= 0 && array[i] > key) {
                array[i+1] = array[i];
                i--;
            }
            array[i+1] = key;
        }
    }
}
