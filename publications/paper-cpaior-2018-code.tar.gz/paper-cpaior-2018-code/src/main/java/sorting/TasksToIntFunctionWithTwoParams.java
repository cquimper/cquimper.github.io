package sorting;

import constraints.cumulative.Task;

@FunctionalInterface
public interface TasksToIntFunctionWithTwoParams {
    int apply(Task a, Task b);
}
