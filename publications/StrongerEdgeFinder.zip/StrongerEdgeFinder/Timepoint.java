
public class Timepoint {
	//Attributes used to modelize the linked list
	public Timepoint next;
	public Timepoint previous;
	
	//Attributes of a Timepoint
	public int time;
	public int capacity;
	
	//Attributes used by the Edge-Finder filtering algorithm
	public int increment;
	public int incrementMax;
	public int hMaxTotal;
	public int hreal;
	public int overflow;
	public int minimumOverflow;
	
	public Timepoint(int ptime, int pcapacity)
	{
		next = null;
		previous = null;
		time = ptime;
		capacity = pcapacity;
		increment = 0;
		incrementMax = 0;
		overflow = 0;
		minimumOverflow = 0;
		hMaxTotal = 0;
		hreal = 0;
	}
	
	public void InsertAfter(Timepoint tp)
	{
		tp.previous = this;
		tp.next = this.next;
		if(next != null)
		{
			next.previous = tp;
		}
		next = tp;
	}
	
	@Override
    public String toString() {
        return "Timepoint : (t = " + this.time + ", next = " + this.next.time + ", c = " + this.capacity + ")";
    }
}
