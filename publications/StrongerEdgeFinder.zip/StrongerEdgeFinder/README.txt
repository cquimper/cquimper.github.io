Code written by Vincent Gingras
vincent.gingras.5@ulaval.ca
https://www.linkedin.com/in/vincent-gingras-02358649


Task.java :
Class to modelize a task from a scheduling problem. The file also contains the various comparators that are used to sort the tasks throughout the filtering algorithms. 

Profile.java :
Class to modelize a Profile as presented in [1]. The Profile is implemented as a two-way linked list, where a node from the linked list is a Timepoint, pointing to the previous and next Timepoint. 

Timepoint.java :
Class to modelize a Timepoint from a Profile as presented in [1]. The class also has various attributes used by the Edge-Finder algorithm, such as the increment of both h_req and h_max values at this time, and the overflow and minimum overflow at this time after the execution of the ScheduleTasks algorithm, as presented in [1].

Parameters.java :
Class to encapsulate the various parameters that are passed to the Edge-Finder constraints. 

CumulativeThetaLambdaTree.java :
Implementation of the data structure Theta-Lambda-tree with all of its functionalities, as presented by Petr Vilím [2]. The tree is used in the detection phase of the Edge-Finder algorithm presented by Vilím [2].

ExtendThetaTree.java :
Implementation of the extended data structure Theta-tree with all of its functionalities, as presented by Petr Vilím [2]. The tree is used in the bound adjustment phase of the Edge-Finder algorithm presented by Vilím [2].

EdgeFinderVilim.java :
Class encapsulating the Edge-Finder algorithm as presented by Petr Vilím [2]. The algorithm proceeds in two phases : the detection phase and the adjustment phase. These two phases are separated in two distinct functions. Also, an overload check function is added to the class, since such a function is trivial using the Theta-Lambda-tree. Vilím presents a similar algorithm in his PhD Thesis. [3]

EdgeFinderConstraintVilim.java :
Integration of Vilím's filtering algorithm to Choco solver 2.1.5 as a constraint. At the beginning of this constraint propagation, a vector of Tasks is initialized using the starting time variables from the solver, and the processing times and heights that were passed as parameters to the constraint. Vilím's Edge-Finder algorithm is then executed on this set of Tasks, and the lower bounds of the starting time variables are updated afterward using the newly updated earliest starting times of the Tasks. The same work is done on a vector of reverse Tasks to filter the upper bounds of the starting time variables.

EdgeFinder.java :
Class encapsulating the Edge-Finder algorithm as presented by Vincent Gingras and Claude-Guy Quimper [1]. Just like Vilím's algorithmm, it proceeds in two phases : the detection phase and the adjustment phase. These two phases are separated in two distinct functions. Also, an overload check function is added to the class. The description of this Overload Check algorithm, using the Profile, can also be seen in [1].

EdgeFinderConstraint.java :
Integration of the Edge-Finder filtering algorithm presented in [1] to Choco solver 2.1.5 as a constraint. At the beginning of this constraint propagation, a vector of Tasks is initialized using the starting time variables from the solver, and the processing times and heights that were passed as parameters to the constraint. The presented Edge-Finder algorithm [1] is then executed on this set of Tasks, and the lower bounds of the starting time variables are updated afterward using the newly updated earliest starting times of the Tasks. The same work is done on a vector of reverse Tasks to filter the upper bounds of the starting time variables.



References :
[1] Vincent Gingras and Claude-Guy Quimper. Generalizing the Edge-Finder Rule for the Cumulative Constraint. To appear in Proceedings of the 25th International Joint Conference on Artificial Intelligence (IJCAI 16), 2016

[2] Petr Vilím. Edge finding filtering algorithm for discrete cumulative resources in O(kn log n). In Principles and Practice of Constraint Programming (CP 09), p.802–816, 2009

[3] Petr Vilím. Global constraints in scheduling. PhD thesis, Charles University in Prague, 2007.
