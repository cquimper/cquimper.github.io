
public class Parameters {
	public int capacity;
	public int[] processingTimes;
	public int[] heights;
	/*
	 * Class to encapsulate the various parameters that are passed to the Edge-Finder constraints. 
	 */
	public Parameters(int capacity, int[] processingTimes, int[] heights)
	{
		this.capacity = capacity;
		this.processingTimes = processingTimes;
		this.heights = heights;
	}
}
