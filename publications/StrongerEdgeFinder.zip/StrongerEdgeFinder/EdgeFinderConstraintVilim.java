import java.util.List;
import java.util.Vector;

import choco.cp.model.managers.IntConstraintManager;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.ContradictionException;
import choco.kernel.solver.Solver;
import choco.kernel.solver.constraints.SConstraint;
import choco.kernel.solver.constraints.integer.AbstractLargeIntSConstraint;
import choco.kernel.solver.variables.integer.IntDomainVar;


public class EdgeFinderConstraintVilim extends AbstractLargeIntSConstraint  {
	public static int CPT_EF_VILIM = 0;
	public static long TOTAL_TIME_VILIM = 0;
	
	private int processing_times[];
	private int heights[];
	private int capacity;
	
    private int nbTasks;
    
    private IntDomainVar[] startingTimes;
    private IntDomainVar makespan;

    Vector<Integer> vector;
    
	public static class EdgeFinderConstraintVilimManager extends IntConstraintManager {   
        public SConstraint<IntDomainVar> makeConstraint(Solver solver, IntegerVariable[] variables, Object param, List<String> options) {
            if (solver instanceof CPSolver) {
                return new EdgeFinderConstraintVilim(solver.getVar(variables), (Parameters) param);
            }
            return null;
        }
    }
	
	private EdgeFinderConstraintVilim (IntDomainVar[] vars, Parameters param) {
		super(vars);

		nbTasks = vars.length-1; 
		
		startingTimes = new IntDomainVar[nbTasks];
		
		capacity=param.capacity;
		processing_times = param.processingTimes;
		heights = param.heights;
		
		vector = new Vector<Integer>();
		for(int i=0; i<nbTasks; i++)
		{
			if(heights[i] > 0)
				vector.add(i);
		}
		
		for(int i=0; i<nbTasks; i++)
        {
        	startingTimes[i] = vars[i];
        }
		makespan = vars[nbTasks];
	}
	
	public void propagate() throws ContradictionException {
		Task[] tasks = new Task[vector.size()];
		Task[] negativeTasks = new Task[vector.size()];

		for (int i = 0; i < vector.size(); i++)
		{		
			int j = vector.get(i);
			final int est = startingTimes[j].getInf();
			final int lct = startingTimes[j].getSup() + processing_times[j];
			tasks[i] = new Task(est, lct, processing_times[j], heights[j]);
			negativeTasks[i] = new Task(-lct, -est, processing_times[j], heights[j]);	
		}

		boolean fixpoint;
		do
		{
			CPT_EF_VILIM ++;
			long startTime = System.nanoTime();
			
			fixpoint = true;
			
			EdgeFinderVilim ef = new EdgeFinderVilim(tasks, capacity);
			EdgeFinderVilim efn = new EdgeFinderVilim(negativeTasks, capacity);
			if(!ef.Filter() || !efn.Filter())
			{
				long endTime = System.nanoTime();
				TOTAL_TIME_VILIM += (endTime - startTime) / 1000;
				fail();
			}
			//The makespan is filtered
			if(ef.makespan > makespan.getInf())
				makespan.setInf(ef.makespan);
			
			for (int i = 0; i < vector.size(); i++) 
			{
				int j = vector.get(i);
	            if (tasks[i].earliestStartingTime() > startingTimes[j].getInf()) 
	            {
	            	//We update both set of tasks so that we don't have to reinitialize them.
	            	startingTimes[j].setInf(tasks[i].earliestStartingTime());        	
	            	negativeTasks[i].setLatestCompletionTime(-startingTimes[j].getInf());
	            	fixpoint = false;
	            }
	            if (-negativeTasks[i].earliestCompletionTime() < startingTimes[j].getSup()) 
	            {
	            	//We update both set of tasks so that we don't have to reinitialize them.
	            	startingTimes[j].setSup(-negativeTasks[i].earliestCompletionTime());
	            	tasks[i].setLatestCompletionTime(startingTimes[j].getSup() + processing_times[j]);
	            	fixpoint = false;
	            }
	        }
			long endTime = System.nanoTime();
			TOTAL_TIME_VILIM += (endTime - startTime) / 1000;
		}
		while(!fixpoint);
	}
	
	
	public void awake() throws ContradictionException {
        propagate();
    }
		
}
