====== Readme ======
To run a minizinc model on a given instance, one needs to call minizinc with "master-model.mzn", the dzn file of the instance, and several dzn files that specify the configuration.
For example, the command `minizinc models/master-model.mzn instances/data_ksd15_d/j3010_10.dzn models/configs/adjustments/capacityMinus4.dzn models/configs/branching/overcostFirst.dzn models/configs/cost-functions/linearCost.dzn models/configs/models/decomposition.dzn`
runs the instance j3010_10 with the linear cost function and the decomposition configuration. 

To run the model with the filtering algorithm, one must compile the C++ code and configure Minizinc such that it supports the custom Chuffed version built by the C++ project.
