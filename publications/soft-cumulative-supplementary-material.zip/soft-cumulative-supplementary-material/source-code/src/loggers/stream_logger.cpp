#include "stream_logger.h"
#include "assert.h"
#include <string>
#include <stdexcept>

using namespace loggers;
using namespace std;

StreamLogger::StreamLogger(ostream& stream) : stream(stream) {
}

void StreamLogger::must(bool condition, string message) {
    if (!condition) {
        log("assert", message);
        throw std::logic_error("Assertion fail:" + message);
    }
}

void StreamLogger::explain(string message) {
    log("explanation", message);
}

void StreamLogger::warn(string message) {
    log("warning", message);
}

void StreamLogger::info(string message) {
    log("info", message);
}

void send_tag(const string& tag, ostream& stream) {
    stream << "[" << tag << "] ";
}
// Linear in |message|. I don't think anything can be quicker
// and we do not have a split in the STL.
void StreamLogger::log(string tag, string message) {
    send_tag(tag, stream);
    for (size_t i = 0; i < message.size(); i++) {
        stream << message.at(i);
        if (message.at(i) == '\n' && i != message.size() - 1) {
            send_tag(tag, stream);
        }
    }

    if (message.back() != '\n') {
        stream << endl;
    }
}
