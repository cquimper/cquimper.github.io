#ifndef STREAMLOGGER_H
#define STREAMLOGGER_H

#include "logger.h"
#include <iostream>

namespace loggers {

    class StreamLogger : public Logger {
    public:
        explicit StreamLogger(std::ostream& stream);
        void must(bool condition, std::string message) override;
        void explain(std::string message) override;
        void warn(std::string message) override;
        void info(std::string message) override;
    private:
        std::ostream& stream;
        void log(std::string tag, std::string message);
    };

}  // loggers

#endif /* STREAMLOGGER_H */
