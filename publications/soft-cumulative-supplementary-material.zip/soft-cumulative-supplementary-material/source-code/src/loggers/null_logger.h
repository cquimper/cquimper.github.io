#ifndef NULL_LOGGER_H
#define NULL_LOGGER_H

#include "logger.h"

namespace loggers{

    class NullLogger : public Logger {
    public:
        void must(bool condition, std::string message) override {}
        void explain(std::string message) override {}
        void warn(std::string message) override {}
        void info(std::string message) override {}
    };

}  // loggers


#endif /* NULL_LOGGER_H */
