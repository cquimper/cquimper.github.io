#ifndef LOGGERS_LOGGER_H
#define LOGGERS_LOGGER_H

#include <string>
#include <sstream>

namespace loggers {

    class Logger
    {
    public:
        // Should fail on Debug and write an error message in release. If I try to use assert here, I have some compilation problems
        void virtual must(bool condition, std::string message) = 0;
        void virtual explain(std::string message) = 0;
        void virtual warn(std::string message) = 0;
        void virtual info(std::string message) = 0;

        template<typename T>
        void info(const T& object) {
            std::stringstream stream;
            stream << object;
            info(stream.str());
        }
        template <typename T>
        void infos(const std::string message, const T& object) {
            std::stringstream stream;
            stream << message << object;
            info(stream.str());
        }
    };

}  // loggers

#endif /* LOGGERS_LOGGER_H */
