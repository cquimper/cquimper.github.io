#ifndef LITERAL_H
#define LITERAL_H

namespace algorithms {

enum LiteralType { GreaterThanOrEqual, LesserThanOrEqual };
enum VariableType { Start, End, P };

struct Literal {
    int taskId;
    VariableType variableType;
    LiteralType litteralType;
    int value;

    Literal(int taskId, VariableType variableType, LiteralType literalType, int value);
};
}

#endif /* LITERAL_H */
