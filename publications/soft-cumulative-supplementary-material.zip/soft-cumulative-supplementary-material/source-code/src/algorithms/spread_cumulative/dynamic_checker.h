#ifndef ENERGETIC_NOGOODS_DYNAMIC_CHECKER_H
#define ENERGETIC_NOGOODS_DYNAMIC_CHECKER_H

#include "../../datastructures/task.h"
#include <vector>

namespace algorithms::spread_cumulative {
struct PathEdge {
public:
    int lowerBound;
    size_t lowerBoundIndex;
    int upperBound;
    size_t upperBoundIndex;
    int unfixedEnergy;
    int leftShiftedCost;

    PathEdge(int lowerBound, int upperBound, size_t lowerBoundIndex, size_t upperBoundIndex,
             int unfixedEnergy, int leftShiftedCost)
        : lowerBound(lowerBound), upperBound(upperBound), lowerBoundIndex(lowerBoundIndex),
          upperBoundIndex(upperBoundIndex), unfixedEnergy(unfixedEnergy),
          leftShiftedCost(leftShiftedCost) {}
};

class DynamicChecker {
private:
    const std::vector<datastructures::Task> &tasks;
    std::vector<int> timepoints;
    std::vector<std::vector<int>> energyMap;
    int capacity;

    // If the algorithm is currently filtering a task, these are non null.
    // Original is the task before it was fixed, used for energy computation.
    datastructures::Task *fixedFilteredTask;
    datastructures::Task const *originalFilteredTask;

    int compute_linear_cost(int lowerBound, int upperBound, int energy) const;

    int compute_quadratic_cost(int lowerBound, int upperBound, int energy) const;

    int compute_cost_for_path(const PathEdge &interval);

    int compute_minimum_energy_linearly(size_t lowerBoundIndex, size_t upperBoundIndex) const;

    int compute_minimum_energy_with_map(size_t lowerBoundIndex, size_t upperBoundIndex);

    int compute_minimum_energy(size_t lowerBoundIndex, size_t upperBoundIndex);

    int get_sliding_window_adjustment(std::vector<PathEdge> &longestPath, size_t estIndex,
                                      size_t ectIndex);

public:
    DynamicChecker(const std::vector<datastructures::Task> &tasks, int capacity);

    void initialize();

    int efficient_compute_minimum_overcost(std::vector<PathEdge> *longuestPath = nullptr);

    int compute_minimum_overcost();

    int filter_est_on_longest_path(int overcostUpperBound, std::vector<PathEdge> &longestPath);

    void precompute_energy();

    void set_filter_task(datastructures::Task *fixedFilteredTask,
                         datastructures::Task const *originalFilteredTask);
};
} // namespace algorithms::spread_cumulative

#endif // ENERGETIC_NOGOODS_DYNAMIC_CHECKER_H
