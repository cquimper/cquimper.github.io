
#include "dynamic_checker.h"

using namespace algorithms::spread_cumulative;
using namespace datastructures;
using namespace std;

DynamicChecker::DynamicChecker(const vector<Task> &tasks, int capacity) : tasks(tasks), capacity(capacity),
    fixedFilteredTask(nullptr), originalFilteredTask(nullptr) {
    initialize();
}

void DynamicChecker::initialize() {
    timepoints.clear();
    for (const Task &task : tasks) {
        timepoints.emplace_back(task.est());
        timepoints.emplace_back(task.ect());
        timepoints.emplace_back(task.lst());
        timepoints.emplace_back(task.lct());
    }

    sort(timepoints.begin(), timepoints.end());

    timepoints.erase(unique(timepoints.begin(), timepoints.end()), timepoints.end());

    // TODO Use a virtual cache
    energyMap.clear();
    energyMap.resize(timepoints.size());

    for (size_t i = 0; i < timepoints.size(); i++) {
        energyMap.at(i) = vector<int>(timepoints.size(), -1);
    }

    for (size_t i = 0; i < timepoints.size() - 1; i++) {
        assert(timepoints.at(i) < timepoints.at(i+1));
    }
}

int DynamicChecker::compute_minimum_energy_with_map(size_t lowerBoundIndex, size_t upperBoundIndex) {
    assert(!energyMap.empty());
    if (energyMap.at(lowerBoundIndex).at(upperBoundIndex) < 0) {
        energyMap.at(lowerBoundIndex).at(upperBoundIndex) = compute_minimum_energy_linearly(lowerBoundIndex, upperBoundIndex);
    }
    return energyMap.at(lowerBoundIndex).at(upperBoundIndex);
}

int DynamicChecker::compute_minimum_energy_linearly(size_t lowerBoundIndex, size_t upperBoundIndex) const {
    int lowerBound = timepoints.at(lowerBoundIndex);
    int upperBound = timepoints.at(upperBoundIndex);

    int energy = 0;
    for (const Task &task : tasks) {
        energy += task.minimum_intersection(lowerBound, upperBound);
    }
    return energy;
}

int DynamicChecker::compute_minimum_energy(size_t lowerBoundIndex, size_t upperBoundIndex) {
    int energy;
    if (energyMap.empty()) {
        energy = compute_minimum_energy_linearly(lowerBoundIndex, upperBoundIndex);
    } else {
        energy = compute_minimum_energy_with_map(lowerBoundIndex, upperBoundIndex);
    }

    if (fixedFilteredTask == nullptr) {
        return energy;
    }

    int lowerBound = timepoints.at(lowerBoundIndex);
    int upperBound = timepoints.at(upperBoundIndex);
    energy -= originalFilteredTask->minimum_intersection(lowerBound, upperBound);
    energy += fixedFilteredTask->minimum_intersection(lowerBound, upperBound);

    return energy;
}

int DynamicChecker::compute_linear_cost(int lowerBound, int upperBound, int energy) const {
    int overflow = -min(0, capacity * (upperBound - lowerBound) - energy);
    return overflow;
}

int DynamicChecker::compute_quadratic_cost(int lowerBound, int upperBound, int energy) const {
    if (energy == 0) {
        return energy;
    }
    energy = compute_linear_cost(lowerBound, upperBound, energy);

    // See notes to visualize the computation
    int length = upperBound - lowerBound;
    int lowerEnergy = energy / length;
    int lowerEnergySquare = lowerEnergy * lowerEnergy;
    int upperEnergySquare = (lowerEnergy+1) * (lowerEnergy+1) - lowerEnergySquare;

    return length * lowerEnergySquare + (energy % length) * upperEnergySquare;
}

int DynamicChecker::compute_minimum_overcost() {
    return efficient_compute_minimum_overcost();
    int minEst = std::min_element(tasks.begin(), tasks.end(),
            [](const Task &task1, const Task &task2){ return task1.est() < task2.est();})->est();
    int maxLct = std::max_element(tasks.begin(), tasks.end(),
                                  [](const Task &task1, const Task &task2){ return task1.lct() < task2.lct();})->lct();

    size_t numberTimepoints = maxLct - minEst + 1;
    vector<int> overcost(numberTimepoints, 0);
    for (long upperIndex = 1; upperIndex < numberTimepoints; upperIndex++) {
        for (long lowerIndex = 0; lowerIndex < upperIndex; lowerIndex++) {
            int lowerBound = lowerIndex + minEst;
            int upperBound = upperIndex + minEst;

            //int cost = compute_linear_cost(lowerBound, upperBound);
            int cost = 0;
            overcost.at(upperIndex) = max(overcost.at(upperIndex), overcost.at(lowerIndex) + cost);
        }
    }
    return overcost.at(numberTimepoints-1);
}

int DynamicChecker::efficient_compute_minimum_overcost(vector<PathEdge> *longuestPath) {
    vector<int> overcost(timepoints.size(), 0);

    for (size_t upperIndex = 1; upperIndex < timepoints.size(); upperIndex++) {
        for (size_t lowerIndex = 0; lowerIndex < upperIndex; lowerIndex++) {
            int lowerBound = timepoints.at(lowerIndex);
            int upperBound = timepoints.at(upperIndex);

            int cost = compute_quadratic_cost(lowerBound, upperBound, compute_minimum_energy(lowerIndex, upperIndex));
            overcost.at(upperIndex) = max(overcost.at(upperIndex), overcost.at(lowerIndex) + cost);
        }
    }

    if (longuestPath != nullptr) {
        int totalCost = 0;
        size_t upperIndex = timepoints.size() - 1;
        while (upperIndex > 0) {
            for (size_t lowerIndex = 0; lowerIndex < upperIndex; lowerIndex++) {
                int lowerBound = timepoints.at(lowerIndex);
                int upperBound = timepoints.at(upperIndex);

                int energy = compute_minimum_energy(lowerIndex, upperIndex);
                int cost = compute_quadratic_cost(lowerBound, upperBound, energy);
                if (overcost.at(lowerIndex) + cost == overcost.at(upperIndex)) {
                    int unfixedEnergy = energy;

                    if (fixedFilteredTask != nullptr) {
                        unfixedEnergy -= fixedFilteredTask->minimum_intersection(lowerBound, upperBound);
                        unfixedEnergy += originalFilteredTask->minimum_intersection(lowerBound, upperBound);
                    }

                    longuestPath->emplace_back(lowerBound, upperBound, lowerIndex, upperIndex, unfixedEnergy, cost);
                    upperIndex = lowerIndex;
                    totalCost += cost;
                    break;
                }
            }
        }

        assert(totalCost == overcost.at(timepoints.size() - 1));

        reverse(longuestPath->begin(), longuestPath->end()); // Later intervals are added first
    }

    return overcost.at(timepoints.size()-1);
}

void DynamicChecker::precompute_energy() {
}

void DynamicChecker::set_filter_task(datastructures::Task *fixedFilteredTask,
                                     datastructures::Task const *originalFilteredTask) {
    this->fixedFilteredTask = fixedFilteredTask;
    this->originalFilteredTask = originalFilteredTask;

}

int DynamicChecker::compute_cost_for_path(const PathEdge &interval)  {
    int energy = compute_minimum_energy(interval.lowerBoundIndex, interval.upperBoundIndex);
    int cost = compute_quadratic_cost(interval.lowerBound, interval.upperBound, energy);
    return cost;
}

pair<size_t, size_t> find_interval_indexes(const vector<PathEdge> &path, int est, int ect) {
    size_t estInterval = 0;
    size_t ectInterval = 0;

    int foundCount = 0;
    size_t currentIntervalIndex = 0;

    while (foundCount < 2 && currentIntervalIndex < path.size()) {
        const PathEdge &interval = path.at(currentIntervalIndex);
        if (interval.lowerBound <= est && est < interval.upperBound) {
            estInterval = currentIntervalIndex;
            foundCount++;
        }

        if (interval.lowerBound < ect && ect <= interval.upperBound) {
            ectInterval = currentIntervalIndex;
            foundCount++;
        }
        currentIntervalIndex++;
    }

    if (foundCount != 2) {
        throw logic_error("Something is wrong, one or two interval was not found.");
    }

    return make_pair<>(estInterval, ectInterval);
}

int DynamicChecker::filter_est_on_longest_path(int overcostUpperBound, vector<PathEdge> &longestPath) {
    if (fixedFilteredTask == nullptr) {
        throw invalid_argument("Filtered task not set.");
    }

    int lowerBound = efficient_compute_minimum_overcost(&longestPath);

    if (lowerBound <= overcostUpperBound) {
        return originalFilteredTask->est();
    }

    pair<size_t, size_t> indexes = find_interval_indexes(longestPath, fixedFilteredTask->est(), fixedFilteredTask->ect());
    size_t estIndex = indexes.first;
    size_t ectIndex = indexes.second;

    while (lowerBound > overcostUpperBound && fixedFilteredTask->lct() <= originalFilteredTask->lct()) {
        lowerBound -= get_sliding_window_adjustment(longestPath, estIndex, ectIndex);

        fixedFilteredTask->est() += 1;
        fixedFilteredTask->lct() += 1;

        lowerBound += get_sliding_window_adjustment(longestPath, estIndex, ectIndex);

        if (fixedFilteredTask->est() >= longestPath.at(estIndex).upperBound) {
            estIndex++;
        }

        if (fixedFilteredTask->ect() > longestPath.at(ectIndex).upperBound) {
            ectIndex++;
        }
    }

    return fixedFilteredTask->est();
}
int DynamicChecker::get_sliding_window_adjustment(vector<PathEdge> &longestPath, size_t estIndex, size_t ectIndex) {
    vector<int> indexes(4, 0);

    indexes.at(0) = estIndex;
    indexes.at(1) = estIndex+1;
    indexes.at(2) = ectIndex;
    indexes.at(3) = ectIndex+1;

    sort(indexes.begin(), indexes.end());

    int adjustment = 0;
    for (size_t i = 0; i < 4; i++) {
         if (indexes.at(i) < longestPath.size() && (i == 0 || indexes.at(i) != indexes.at(i-1))) {
            adjustment += compute_cost_for_path(longestPath.at(indexes.at(i)));
         }
    }

    return adjustment;
}
