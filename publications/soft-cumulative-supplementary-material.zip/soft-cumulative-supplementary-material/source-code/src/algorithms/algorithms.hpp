#include <assert.h>
#include <algorithm>
#include "algorithms.h"

using namespace std;

template <class Comp>
size_t algorithms::binary_search(const vector<int>& array, int value, BinarySearchType type, Comp comp) {
    //lower_bound returns a pointer to the first element greater than or equal to value

    throw "This implementation is probably bugged. See deactivated tests";
    if (type == GREATER_OR_EQUAL) {
        return std::lower_bound(array.begin(), array.end(), value, comp) - array.begin();
    } else if (type == SMALLER_OR_EQUAL) {
        auto result = std::lower_bound(array.begin(), array.end(), value, comp);

        if (result != array.end() && *result == value) {
            while (result+1 != array.end() && *(result+1) == *result) {
                result++;
            }
            return result - array.begin();
        }

        // we return the size of the array to follow the std convention for lower_bound
        if (result == array.end()) return array.size();

        return result - array.begin() - 1;
    } else {
        assert(false);
    }
}

