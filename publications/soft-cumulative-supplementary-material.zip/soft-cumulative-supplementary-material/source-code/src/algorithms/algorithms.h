#ifndef ENERGETIC_NOGOODS_ALGORITHMS_H
#define ENERGETIC_NOGOODS_ALGORITHMS_H

#include <vector>
#include <functional>

namespace algorithms {

enum BinarySearchType {
    SMALLER_OR_EQUAL,
    GREATER_OR_EQUAL
};

    template <class Comp = std::less<int>>
    size_t binary_search(const std::vector<int>& array, int value, BinarySearchType type = SMALLER_OR_EQUAL,
                         Comp comp = std::less<int>());

    size_t binary_search(const std::vector<int>& array, int value, BinarySearchType type = SMALLER_OR_EQUAL);
}


#include "algorithms.hpp"

#endif //ENERGETIC_NOGOODS_ALGORITHMS_H
