#include "greater.h"
#include <iostream>

using namespace std;

GreaterPropagator::GreaterPropagator(IntView<> x, IntView<> y) : x(x), y(y) {
    x.attach(this, 0, EVENT_U); //Trigger propagation when the upper bound is updated
    y.attach(this, 1, EVENT_L); //Trigger propagation when the lower bound is updated
}

bool GreaterPropagator::propagate() {
    return propagate_x() && propagate_y();
}

bool GreaterPropagator::propagate_x() {
    cout << "Adding nogood" << endl;
    setDom(y, setMax, x.getMax() - 1, x.getMaxLit());
    return true;
}

bool GreaterPropagator::propagate_y() {
    cout << "Adding nogood" << endl;
    setDom(x, setMin, y.getMin() + 1, y.getMinLit());
    return true;
}

void greater_than(IntVar* x, IntVar* y) {
    IntView<> viewX(x);
    IntView<> viewY(y);
    auto *p = new GreaterPropagator(viewX, viewY);
}
