#include "chuffed_utils.h"

Lit constraints::getNegLeqLit(IntVar *v, int val) {
    return (INT_VAR_LL == v->getType() ? v->getMaxLit() : v->getLit(val + 1, 2));
}
Lit constraints::getNegGeqLit(IntVar *v, int val) {
    return (INT_VAR_LL == v->getType() ? v->getMinLit() : v->getLit(val - 1, 3));
}
