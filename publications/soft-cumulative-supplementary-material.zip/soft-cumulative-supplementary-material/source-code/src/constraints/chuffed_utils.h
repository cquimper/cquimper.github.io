#ifndef CHUFFED_UTILS_H
#define CHUFFED_UTILS_H

#include <chuffed/vars/int-var.h>

namespace constraints {

Lit getNegLeqLit(IntVar *v, int val);
Lit getNegGeqLit(IntVar *v, int val);

} // namespace constraints

#endif /* CHUFFED_UTILS_H */
