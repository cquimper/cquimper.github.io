#ifndef GREATER_H
#define GREATER_H

#include <chuffed/core/propagator.h>

// X > Y
class GreaterPropagator : Propagator {
private:
    IntView<> x;
    IntView<> y;
    bool propagate_x();
    bool propagate_y();

public:
    GreaterPropagator(IntView<> x, IntView<> y);
    bool propagate();
};

void greater_than(IntVar* x, IntVar* y);
#endif
