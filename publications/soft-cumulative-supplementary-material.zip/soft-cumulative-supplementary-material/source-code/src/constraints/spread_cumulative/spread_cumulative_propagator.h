#ifndef ENERGETIC_NOGOODS_SPREAD_CUMULATIVE_PROPAGATOR_H
#define ENERGETIC_NOGOODS_SPREAD_CUMULATIVE_PROPAGATOR_H

#include <vector>
#include <chuffed/core/propagator.h>
#include <functional>
#include <memory>
#include "../../datastructures/task.h"
#include "../../algorithms/spread_cumulative/dynamic_checker.h"

using namespace std;

namespace constraints::spread_cumulative {
    void spread_cumulative(const vec<IntVar *> &p_starts, const vec<int> &p_processing_times,
                           const vec<int> &p_heights, int capacity, IntVar *overcost, int filteringAlgorithm);

    enum FilteringAlgorithm {
        CHECKER_ONLY = 0,
        BRUTE_FILTERING = 1,
        PATH_FILTERING = 2
    };

    class SpreadCumulativePropagator : Propagator {
    public:
        SpreadCumulativePropagator(const vector<IntVar *> &starts, const vector<int> &processingTimes,
                                   const vector<int> &heights, int capacity, IntVar *overcost,
                                   FilteringAlgorithm filteringAlgorithm);

        bool propagate() override;

    private:
        vector<datastructures::Task> tasks;
        const vector<IntVar *> &starts;
        const vector<int> &processingTimes;
        const vector<int> &heights;
        int capacity;
        FilteringAlgorithm filteringAlgorithm;
        IntVar *overcost;
        std::unique_ptr<algorithms::spread_cumulative::DynamicChecker> checker;

        void explain_interval(int lowerBound, int upperBound, int energy,
                              vector<int> &est, vector<int> &lst, vector<bool> &tasksIncluded) const;

        void explain_path(const vector<algorithms::spread_cumulative::PathEdge> &path,
                          vector<int> &est, vector<int> &lst, vector<bool> &tasksIncluded) const;

        std::pair<int, int> filter_task(datastructures::Task &unfixedTask, int maxOvercost, vec<Lit> &literals,
                                        const std::function<int(const datastructures::Task &,
                                                                const datastructures::Task &, int, int, int,
                                                                const vector<algorithms::spread_cumulative::PathEdge> &)> &adjustmentFunction);

    };
}


#endif //ENERGETIC_NOGOODS_SPREAD_CUMULATIVE_PROPAGATOR_H
