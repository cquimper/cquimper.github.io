#include "spread_cumulative_propagator.h"
#include "../../datastructures/task.h"
#include "../../algorithms/spread_cumulative/dynamic_checker.h"
#include "../chuffed_utils.h"
#include <iostream>

using namespace std;
using namespace constraints;
using namespace constraints::spread_cumulative;
using namespace algorithms::spread_cumulative;
using namespace datastructures;

extern std::map<IntVar *, string> intVarString;

void checker_log(const string &output) {
    //cout << "%[checker]: " << output << endl;
}

static int overcostCount = 0;

void
constraints::spread_cumulative::spread_cumulative(const vec<IntVar *> &p_starts, const vec<int> &p_processing_times,
                                                  const vec<int> &p_heights, int capacity, IntVar *overcost,
                                                  int filteringAlgorithm) {
    auto *starts = new vector<IntVar *>;
    auto *processing_times = new vector<int>;
    auto *heights = new vector<int>;

    for (size_t i = 0; i < p_starts.size(); i++) {
        starts->push_back(p_starts[i]);
        processing_times->push_back(p_processing_times[i]);
        heights->push_back(p_heights[i]);
        intVarString.at(p_starts[i]) = "Starts" + to_string(i);
    }

    intVarString.at(overcost) = "Overcost" + to_string(overcostCount++);

    new SpreadCumulativePropagator(*starts, *processing_times, *heights, capacity, overcost,
                                   static_cast<FilteringAlgorithm>(filteringAlgorithm));
}

SpreadCumulativePropagator::SpreadCumulativePropagator(const vector<IntVar *> &starts,
                                                       const vector<int> &processingTimes, const vector<int> &heights,
                                                       int capacity, IntVar *overcost,
                                                       FilteringAlgorithm filteringAlgorithm) : starts(starts),
                                                                                                processingTimes(
                                                                                                        processingTimes),
                                                                                                heights(heights),
                                                                                                capacity(capacity),
                                                                                                overcost(overcost),
                                                                                                filteringAlgorithm(
                                                                                                        filteringAlgorithm) {
    int i = 0;
    for (auto start : starts) {
        start->attach(this, i++, EVENT_LU);
    }
    overcost->attach(this, i++, EVENT_U);
    cout << "% Capacity: " << capacity << endl;
    cout << "% Filtering algorithm: " << filteringAlgorithm << endl;
}

vec<Lit> build_naive_lits(const vector<IntVar *> &starts, const vector<int> &est, const vector<int> &lst,
                          const vector<bool> &tasksIncluded, IntVar *overcost) {
    vec<Lit> literals;
    for (size_t i = 0; i < starts.size(); i++) {
        if (tasksIncluded.at(i)) {
            IntVar *start = starts.at(i);
            literals.push(getNegGeqLit(start, est.at(i)));
            literals.push(getNegLeqLit(start, lst.at(i)));
        }
    }
    literals.push(overcost->getMaxLit());
    return literals;
}

Clause *build_clause_for_filtering_from_literals(const vec<Lit> &literals) {

    Clause *reason = Reason_new(literals.size() + 1);
    for (int i = 1; i <= literals.size(); i++) {
        (*reason)[i] = literals[i - 1];
    }
    return reason;
}

int compute_energetic_like_adjustment(const Task &task, int computedLowerBound, int upperBoundOvercost) {
    // This rule is based on the energetic reasoning adjustment rule

    // The double is required for the latter division to be a floating division. Otherwise, it will
    // be rounded down before the ceil.
    double overflow = computedLowerBound - upperBoundOvercost;
    if (overflow <= 0) {
        return task.est();
    }
    int adjustedEst = task.est() + (int) ceil(overflow / task.h());
    //cout << "Overflow of " << overflow << " and adjustedEst of " << adjustedEst << endl;

    return adjustedEst;
}

int compute_brute_force_adjustment(const Task &unfixedTask, const Task &fixedTask, int computedLowerBound,
                                   int upperBoundOvercost, int capacity,
                                   const vector<PathEdge> &longuestPath) {
    return fixedTask.est() + 1;
}

int compute_energy_adjustment(int l, int u, const Task &unfixedTask, const Task &fixedTask) {
    return fixedTask.minimum_intersection(l, u) - unfixedTask.minimum_intersection(l, u);
}

int compute_longuest_path_adjustment(const Task &unfixedTask, const Task &tempFixedTask, int computedLowerBound,
                                     int upperBoundOvercost, int capacity,
                                     const vector<PathEdge> &longuestPath) {
    // Extra cost causing the constraint to fail if the task is fixed
    int remainingExtraCost = computedLowerBound - upperBoundOvercost;
    assert(remainingExtraCost > 0);

    Task fixedTask(tempFixedTask);

    // TODO Find a way to simplify the code for the paper
    for (const PathEdge &edge : longuestPath) {
        int energy = edge.unfixedEnergy +
                     compute_energy_adjustment(edge.lowerBound, edge.upperBound, unfixedTask, fixedTask);
        int previousCost = max(0, energy - capacity * (edge.upperBound - edge.lowerBound));
        int currentCost = previousCost;
        int unfixedCost = max(0, edge.unfixedEnergy - capacity * (edge.upperBound - edge.lowerBound));
        int delta = 1;

        while (currentCost > unfixedCost && delta > 0 && remainingExtraCost > 0) {
            fixedTask.est() += 1;
            fixedTask.lct() += 1;

            previousCost = currentCost;
            energy = edge.unfixedEnergy +
                     compute_energy_adjustment(edge.lowerBound, edge.upperBound, unfixedTask, fixedTask);
            currentCost = max(0, energy - capacity * (edge.upperBound - edge.lowerBound));

            delta = previousCost - currentCost;
            assert(delta >= 0);
            remainingExtraCost -= delta;
        }
    }

    assert(fixedTask.est() > unfixedTask.est());
    return fixedTask.est();
}

static int savedCalls = 0;
static int totalCalls = 0;
static int totalCallsWithNoFiltering = 0;
static int totalUselessCallsSaved = 0;
static int potentialCallsToSave = 0;
static int minCalls = 0;

bool SpreadCumulativePropagator::propagate() {
    tasks.clear();
    for (size_t i = 0; i < starts.size(); i++) {
        tasks.emplace_back(
                Task(starts.at(i)->getMin(), starts.at(i)->getMax() + processingTimes.at(i), processingTimes.at(i),
                     heights.at(i), i));
    }

    checker = make_unique<DynamicChecker>(tasks, capacity);
    //checker->precompute_energy();

    vector<PathEdge> longestPath;
    int lowerBound = checker->efficient_compute_minimum_overcost(&longestPath);

    vector<int> estForExplainations;
    vector<int> lstForExplanations;
    vector<bool> tasksIncluded;

    explain_path(longestPath, estForExplainations, lstForExplanations, tasksIncluded);


    auto literals = build_naive_lits(starts, estForExplainations, lstForExplanations, tasksIncluded, overcost);

    //cout << "% Lower bound: " << lowerBound << ", maxOvercost: " << overcost->getMax() << endl;
    if (lowerBound > overcost->getMax()) {
        sat.confl = Reason_new(literals);
        return false;
    }

    if (lowerBound > overcost->getMin()) {
        overcost->setMin(lowerBound, build_clause_for_filtering_from_literals(literals));
    }

    if (filteringAlgorithm == CHECKER_ONLY) {
        return true;
    }

    assert(filteringAlgorithm != CHECKER_ONLY);
    auto adjustmentFunction =
            filteringAlgorithm == BRUTE_FILTERING ? compute_brute_force_adjustment : compute_longuest_path_adjustment;

    int maxOvercost = overcost->getMax();
    for (Task &task : tasks) {
        int freeEnergy = max(0, task.p() - (task.ect() - task.lst())) * task.h();
        if (freeEnergy <= maxOvercost - lowerBound) {
            continue;
        }

        literals.clear();
        pair<int, int> energeticResult = filter_task(task, maxOvercost, literals, adjustmentFunction);
        //pair<int, int> bruteResult = filter_task(task, maxOvercost, literals, compute_brute_force_adjustment);

//        if (energeticResult.first != bruteResult.first && bruteResult.first <= task.lst()) {
//            cout << "wrong" << endl;
//            cout << energeticResult.first << ", " << bruteResult.first << endl;
//            exit(1);
//        }

        int adjustedEst = energeticResult.first;

        if (adjustedEst > task.lst()) {
            sat.confl = Reason_new(literals);
            return false;
        }

        if (adjustedEst > starts.at(task.id())->getMin()) {
            starts.at(task.id())->setMin(adjustedEst, build_clause_for_filtering_from_literals(literals));
        }
    }

    return true;
}

std::pair<int, int>
SpreadCumulativePropagator::filter_task(datastructures::Task &unfixedTask, int maxOvercost, vec<Lit> &literals,
                                        const std::function<int(const Task &, const Task &, int,
                                                                int, int,
                                                                const vector<PathEdge> &)> &adjustmentFunction) {
    int initialLct = unfixedTask.lct();
    Task fixedTask = Task(unfixedTask);

    checker->set_filter_task(&fixedTask, &unfixedTask);

    fixedTask.lct() = unfixedTask.ect();

    vector<int> est;
    vector<int> lst;
    vector<bool> tasksIncluded;
    vector<PathEdge> longestPath;

    // TODO Temp code for test

    int filteredEst = checker->filter_est_on_longest_path(maxOvercost, longestPath);


//    int checkerLowerBound = checker->efficient_compute_minimum_overcost(&longestPath);
//
//    while (checkerLowerBound > maxOvercost && fixedTask.lct() <= unfixedTask.lct()) {
//        int adjustmentDelta =
//                adjustmentFunction(unfixedTask, fixedTask, checkerLowerBound, maxOvercost, capacity, longestPath) -
//                fixedTask.est();
//        fixedTask.est() += adjustmentDelta;
//        fixedTask.lct() += adjustmentDelta;
//        explain_path(longestPath, est, lst, tasksIncluded);
//
//        if (fixedTask.lct() <= initialLct) {
//            longestPath.clear();
//            checkerLowerBound = checker->efficient_compute_minimum_overcost(&longestPath);
//        }
//    }

//    int filteredEst = fixedTask.est();
    if (filteredEst > unfixedTask.est()) {
        explain_path(longestPath, est, lst, tasksIncluded);
        est.at(unfixedTask.id()) = unfixedTask.est();
        lst.at(unfixedTask.id()) = unfixedTask.lst();
        tasksIncluded.at(unfixedTask.id()) = true;

        literals.clear();
        build_naive_lits(starts, est, lst, tasksIncluded, overcost).moveTo(literals);
    }

    return make_pair(filteredEst, 0);
}

// Explain a longest path. est and lst should correspond to numeric_limits::max and min if they are not needed
// for the explanation.
void SpreadCumulativePropagator::explain_path(const vector<algorithms::spread_cumulative::PathEdge> &path,
                                              std::vector<int> &est, std::vector<int> &lst,
                                              vector<bool> &tasksIncluded) const {
    if (est.empty()) {
        for (size_t i = 0; i < tasks.size(); i++) {
            est.emplace_back(numeric_limits<int>::min());
            lst.emplace_back(numeric_limits<int>::max());
            tasksIncluded.emplace_back(false);
        }
    }

    for (const PathEdge &edge : path) {
        explain_interval(edge.lowerBound, edge.upperBound, 0, est, lst, tasksIncluded);
    }
}

// Explain a given interval. For now, it includes a task only if it has energy in the interval.
void SpreadCumulativePropagator::explain_interval(int lowerBound, int upperBound, int energy, vector<int> &est,
                                                  vector<int> &lst, vector<bool> &tasksIncluded) const {
    assert(!tasks.empty());

    for (const Task &task : tasks) {
        if (task.minimum_intersection(lowerBound, upperBound) > 0) {
            // From chuffed. And page 240 Explaining tteff
            int minProcessingInInterval = min(task.left_shift(lowerBound, upperBound), task.right_shift(lowerBound, upperBound));
            //int extendedDuration = min(extraSlack / task.h(), minProcessingInInterval);
            //int extendedDuration = minProcessingInInterval;
            //extraSlack -= extendedDuration * task.h();
            //minProcessingInInterval -= extendedDuration;

            int adjustedLst = max(upperBound - minProcessingInInterval, task.lst());
            int adjustedEst = min(lowerBound + minProcessingInInterval - task.p(), task.est());

            est.at(task.id()) = max(est.at(task.id()), adjustedEst);
            lst.at(task.id()) = min(lst.at(task.id()), adjustedLst);
            //est.at(task.id()) = task.est();
            //lst.at(task.id()) = task.lst();
            tasksIncluded.at(task.id()) = true;
        }
    }
}
