#include "virtual_cache.h"
#include <assert.h>

using namespace datastructures;


VirtualCache::VirtualCache(int maxValue) : T(static_cast<unsigned long>(maxValue)), a(
        static_cast<unsigned long>(maxValue)), b(static_cast<unsigned long>(maxValue)), cpt(-1) {
}

bool VirtualCache::contains_key(int key) const {
    return b.at(key) <= cpt && a.at(b.at(key)) == key;
}

int VirtualCache::get(int key) const {
    assert(contains_key(key));
    return T.at(key);
}

void VirtualCache::put(int key, int value) {
    T.at(key) = value;
    cpt += 1;
    a.at(cpt) = key;
    b.at(key) = cpt;
}

void VirtualCache::reset() {
    cpt = -1;
}

