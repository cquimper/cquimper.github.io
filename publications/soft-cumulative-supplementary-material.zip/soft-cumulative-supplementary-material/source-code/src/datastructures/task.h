#ifndef ENERGETIC_NOGOODS_TASK_H
#define ENERGETIC_NOGOODS_TASK_H

#include <algorithm>
#include <assert.h>

namespace datastructures {

class Task {
private:
    int m_est;
    int m_lct;
    int m_p;
    int m_h;
    int m_id;

public:
    Task(int m_est, int m_lct, int m_p, int m_h)
        : m_est(m_est), m_lct(m_lct), m_p(m_p), m_h(m_h), m_id(-1) {}
    Task(int m_est, int m_lct, int m_p, int m_h, int m_id)
        : m_est(m_est), m_lct(m_lct), m_p(m_p), m_h(m_h), m_id(m_id) {}

    int &est() { return m_est; }

    int &lct() { return m_lct; }

    int est() const { return m_est; }

    int lct() const { return m_lct; }

    int p() const { return m_p; }

    int h() const { return m_h; }

    int lst() const { return m_lct - m_p; }

    int ect() const { return m_est + m_p; }

    int minimum_intersection(int t1, int t2) const {
        return h() * std::min(left_shift(t1, t2), right_shift(t1, t2));
               //std::max(0, std::min(t2 - t1, std::min(p(), std::min(ect() - t1, t2 - lst()))));
    }

    // The left shift DOES NOT include the multiplication by h
    int left_shift(int t1, int t2) const {
        return std::max(0, std::min(t2, ect()) - std::max(t1, est()));
    }

    int right_shift(int t1, int t2) const {
        return std::max(0, std::min(t2, lct()) - std::max(t1, lst()));
    }

    int id() const { return m_id; }

    int& id() {return m_id; }

    void update(int est, int lct) {
        m_est = est;
        m_lct = lct;
    }

    bool has_fixed_part_in_interval(int l, int u) const {
        assert(l < u);
        bool hasFixedPart = lst() < ect();
        bool strictlyBefore = ect() <= l;
        bool strictlyAfter = lst() >= u;

        return hasFixedPart && !strictlyBefore && !strictlyAfter;
    }

    bool has_fixed_part() const {
        return lst() < ect();
    }

    bool is_fixed() const {
        return est() + p() == lct();
    }
};

} // namespace datastructures

#endif // ENERGETIC_NOGOODS_TASK_H
