#ifndef ENERGETIC_NOGOODS_COMPULSORY_ENERGY_H
#define ENERGETIC_NOGOODS_COMPULSORY_ENERGY_H

#include <vector>
#include <utility>

namespace datastructures {

class CompulsoryEnergy {
public:
    CompulsoryEnergy(std::vector<std::pair<int, int>>& pairs);
    int compute(int l, int u) const;
private:
    size_t n;
    std::vector<int> times;
    std::vector<int> slopes;
    std::vector<int> sum;
};

}

#endif //ENERGETIC_NOGOODS_COMPULSORY_ENERGY_H
