#ifndef DISJOINT_SETS_H
#define DISJOINT_SETS_H

#include <vector>

namespace datastructures {
    class DisjointSets {
    private:
        std::vector<int> parents;
        std::vector<int> maximum;
        void merge(int x, int y);
        int disjointSetsCount;
    public:
        explicit DisjointSets(size_t size);
        int find(int x);
        int find_max(int x);
        void find_and_merge(int x, int y);
        int disjoint_sets_count() const;
    };
}

#endif /* DISJOINT_SETS_H */
