#ifndef ENERGETIC_NOGOODS_VIRTUAL_CACHE_H
#define ENERGETIC_NOGOODS_VIRTUAL_CACHE_H

#include <vector>

namespace datastructures {

// Cache based on the virtual initialisation technique
// The datastructure only support int as keys. If a key greater than the max of an int is required,
// we will have many other problems.
class VirtualCache {
private:
    std::vector<int> T;
    std::vector<int> a;
    std::vector<int> b;
    int cpt;
public:
    explicit VirtualCache(int maxValue);
    bool contains_key(int key) const;
    void reset();
    void put(int key, int value);
    int get(int k) const;
};

}

#endif //ENERGETIC_NOGOODS_VIRTUAL_CACHE_H
