#include "disjoint_sets.h"
#include <assert.h>

using namespace datastructures;

DisjointSets::DisjointSets(size_t n) : parents(n, -1), disjointSetsCount(n) {
    for (size_t i = 0; i < n; i++) {
        maximum.push_back(i);
    }
}

int DisjointSets::find(int x) {
    assert(x < parents.size());
    int elementToFind = x;

    while (parents.at(x) >= 0) {
        x = parents.at(x);
    }

    int parent = x;
    x = elementToFind;
    while (parents.at(x) >= 0) {
        int temp = parents.at(x);
        parents.at(x) = parent;
        x = temp;
    }

    return parent;
}

int DisjointSets::find_max(int x) {
    return maximum.at(find(x));
}

void DisjointSets::find_and_merge(int x, int y) {
    merge(find(x), find(y));
}

void DisjointSets::merge(int x, int y) {
    assert(parents.at(x) < 0 && parents.at(y) < 0 && x != y);

    int parent;
    if (parents.at(x) < parents.at(y)) {
        parent = parents.at(y) = x;
    } else if (parents.at(x) > parents.at(y)) {
        parent = parents.at(x) = y;
    } else {
        parent = parents.at(y) = x;
        parents.at(x)--;
    }

    maximum.at(parent) = std::max(maximum.at(x), maximum.at(y));
    disjointSetsCount--;
}

int DisjointSets::disjoint_sets_count() const {
    return disjointSetsCount;
}
