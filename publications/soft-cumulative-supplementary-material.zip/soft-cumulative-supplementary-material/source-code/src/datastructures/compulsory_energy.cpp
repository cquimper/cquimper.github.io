#include <algorithm>
#include <assert.h>
#include <limits>
#include "compulsory_energy.h"
#include "../algorithms/algorithms.h"

using namespace std;
using namespace datastructures;
using namespace algorithms;

CompulsoryEnergy::CompulsoryEnergy(vector<pair<int, int>>& pairs) :
        n(pairs.size()+2), times(n), slopes(n-1), sum(n-1){
    //The last element of slopes and sum is not defined.

    sort(pairs.begin(), pairs.end());

    times[0] = std::numeric_limits<int>::min();
    slopes[0] = 0;
    sum[0] = 0;
    for (size_t i = 1; i < n-1; i++) {
        times[i] = pairs[i-1].first;
        slopes[i] = slopes[i-1] + pairs[i-1].second;
        sum[i] = sum[i-1] + (times[i] - times[i-1]) * slopes[i-1];
    }
    times[n-1] = std::numeric_limits<int>::max();
}

int CompulsoryEnergy::compute(int l, int u) const {
    assert(l < u);

    size_t t1Index = binary_search<>(times, l, SMALLER_OR_EQUAL);
    size_t t2Index = binary_search<>(times, u, SMALLER_OR_EQUAL);

    assert(t1Index != n && t2Index != n);

    int lowerSum = sum[t1Index] + (l - times[t1Index]) * slopes[t1Index];
    int upperSum = sum[t2Index] + (u - times[t2Index]) * slopes[t2Index];

    return upperSum - lowerSum;
}
